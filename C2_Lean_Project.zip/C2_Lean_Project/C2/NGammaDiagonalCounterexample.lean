import C2.NGammaDiagonal

/-! The explicit Hurwitz counterexample from the manuscript. -/
noncomputable section
namespace C2.NGamma
open Matrix

def counterA : Matrix (Fin 2) (Fin 2) ℝ := !![2,3; -3,-3]
def counterGamma : Fin 2 → ℝ := ![1,1/2]
def counterStep : Matrix (Fin 2) (Fin 2) ℝ := !![-7/3,-2; 1,1]

lemma counterA_charpoly_eval (z : ℂ) :
    (complexify counterA).charpoly.eval z = z^2+z+3 := by
  rw [eval_charpoly, Matrix.det_fin_two]
  norm_num [complexify, counterA, Matrix.map_apply]
  ring

/-- Every complex continuous eigenvalue has strictly negative real part. -/
theorem counterA_hurwitz (z : ℂ) (hz : (complexify counterA).charpoly.eval z = 0) :
    z.re < 0 := by
  rw [counterA_charpoly_eval] at hz
  have hr := congrArg Complex.re hz
  have hi := congrArg Complex.im hz
  simp [pow_two, Complex.mul_re, Complex.mul_im] at hr hi
  by_cases hy : z.im = 0
  · rw [hy] at hr
    nlinarith [sq_nonneg (z.re + 1/2)]
  · have hfac : z.im * (2*z.re+1) = 0 := by nlinarith [hi]
    have hh := (mul_eq_zero.mp hfac).resolve_left hy
    linarith

lemma counterE : stepE 2 counterGamma counterA = !![-3,-6; 3,4] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [stepE, counterGamma, counterA, Matrix.mul_apply, Fin.sum_univ_two]

lemma counterF : stepF 2 counterGamma counterA = !![1,0; -3,-2] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [stepF, counterGamma, counterA, Matrix.mul_apply, Fin.sum_univ_two]

lemma counterE_det : (stepE 2 counterGamma counterA).det = 6 := by
  rw [counterE, Matrix.det_fin_two]
  norm_num

lemma counter_step : stepMatrix 2 counterGamma counterA = counterStep := by
  have h : stepE 2 counterGamma counterA * counterStep = stepF 2 counterGamma counterA := by
    rw [counterE, counterF]
    ext i j
    fin_cases i <;> fin_cases j <;>
      norm_num [counterStep, Matrix.mul_apply, Fin.sum_univ_two]
  have he : IsUnit (stepE 2 counterGamma counterA).det := by
    rw [counterE_det]
    exact isUnit_iff_ne_zero.mpr (by norm_num)
  have hh := congrArg (fun N => (stepE 2 counterGamma counterA)⁻¹ * N) h
  dsimp only at hh
  rw [Matrix.nonsing_inv_mul_cancel_left _ _ he] at hh
  exact hh.symm

lemma counterStep_charpoly_eval (z : ℂ) :
    (complexify counterStep).charpoly.eval z = z^2+(4/3)*z-1/3 := by
  rw [eval_charpoly, Matrix.det_fin_two]
  norm_num [complexify, counterStep, Matrix.map_apply]
  ring

/-- The discrete realization has the displayed real root less than -1. -/
theorem counter_unstable_root :
    let z : ℂ := ((-2-Real.sqrt 7)/3 : ℝ)
    (complexify (stepMatrix 2 counterGamma counterA)).charpoly.eval z = 0 ∧
      1 < ‖z‖ := by
  dsimp only
  rw [counter_step, counterStep_charpoly_eval]
  have hs : (Real.sqrt 7)^2 = 7 := Real.sq_sqrt (by norm_num)
  have hpos : 1 < Real.sqrt 7 := by
    nlinarith [Real.sqrt_nonneg (7:ℝ)]
  constructor
  · apply Complex.ext <;> simp [Complex.mul_re, Complex.mul_im, pow_two]
    nlinarith
  · rw [Complex.norm_real]
    rw [Real.norm_eq_abs, abs_of_neg (by linarith : (-2-Real.sqrt 7)/3 < 0)]
    linarith

/-- Hurwitz stability and individually A-stable weights do not suffice for an
 independently weighted state-space discretization. -/
theorem hurwitz_not_sufficient :
    (∀ z : ℂ, (complexify counterA).charpoly.eval z = 0 → z.re < 0) ∧
    (∀ i, (1/2 : ℝ) ≤ counterGamma i) ∧
    (stepE 2 counterGamma counterA).det ≠ 0 ∧
    ¬ MatrixSchurStable (stepMatrix 2 counterGamma counterA) := by
  refine ⟨counterA_hurwitz, ?_, ?_, ?_⟩
  · intro i
    fin_cases i <;> norm_num [counterGamma]
  · rw [counterE_det]
    norm_num
  · intro h
    obtain ⟨hz, hn⟩ := counter_unstable_root
    exact (not_lt_of_ge hn.le) (h _ hz)

end C2.NGamma
