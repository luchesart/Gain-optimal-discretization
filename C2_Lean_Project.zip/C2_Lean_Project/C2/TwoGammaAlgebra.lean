import Mathlib

/-! Closed-form two-factor endpoint allocation. The generic optimizer is
specialized through its proved resource equation, rather than presumed to
have the displayed parameter values. -/
noncomputable section
open scoped BigOperators
open Set
namespace C2.TwoGamma

def gain (r₁ r₂ : ℝ) : ℝ :=
  (Real.sqrt (1+r₁+r₂) + Real.sqrt (1+r₁+r₂+r₁*r₂))^2

def radical (r₁ r₂ : ℝ) : ℝ := Real.sqrt ((1+r₁+r₂)*(1+r₁+r₂+r₁*r₂))
def allocation (r₁ r₂ : ℝ) : ℝ := (gain r₁ r₂+r₁^2)/(r₁+r₂+2)
def scalar (r₁ r₂ : ℝ) : ℝ := allocation r₁ r₂+allocation r₂ r₁-r₁-r₂-2

def optimalX (r₁ r₂ : ℝ) : ℝ :=
  (gain r₁ r₂-r₁*r₂-2*r₂)/(gain r₁ r₂+r₁*r₂)

def optimalGamma (r₁ r₂ : ℝ) : ℝ := (1+optimalX r₁ r₂)/2

theorem gain_comm (r₁ r₂ : ℝ) : gain r₂ r₁ = gain r₁ r₂ := by
  unfold gain
  congr 2 <;> congr 1 <;> ring

theorem gain_expanded {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    gain r₁ r₂ = 2*(1+r₁+r₂)+r₁*r₂+2*radical r₁ r₂ := by
  have ha := Real.sq_sqrt (show 0 ≤ 1+r₁+r₂ by linarith)
  have hb := Real.sq_sqrt (show 0 ≤ 1+r₁+r₂+r₁*r₂ by positivity)
  have hc : radical r₁ r₂ = Real.sqrt (1+r₁+r₂)*Real.sqrt (1+r₁+r₂+r₁*r₂) := by
    exact Real.sqrt_mul (by linarith) _
  unfold gain
  rw [hc]
  nlinarith

theorem gain_quadratic {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    (gain r₁ r₂-r₁*r₂)^2 = 4*(1+r₁+r₂)*gain r₁ r₂ := by
  have hq := Real.sq_sqrt (show 0 ≤ (1+r₁+r₂)*(1+r₁+r₂+r₁*r₂) by positivity)
  change (radical r₁ r₂)^2 = _ at hq
  rw [gain_expanded h₁ h₂]
  nlinarith [hq]

theorem radical_gt {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    1+r₁ < radical r₁ r₂ := by
  have hq := Real.sq_sqrt (show 0 ≤ (1+r₁+r₂)*(1+r₁+r₂+r₁*r₂) by positivity)
  change (radical r₁ r₂)^2 = _ at hq
  have hn : 0 ≤ radical r₁ r₂ := Real.sqrt_nonneg _
  have hp : 0 < r₂*(1+r₁)*(r₁+r₂+2) := by positivity
  nlinarith [hq]

theorem gain_pos {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) : 0 < gain r₁ r₂ := by
  rw [gain_expanded h₁ h₂]
  have : 0 ≤ radical r₁ r₂ := Real.sqrt_nonneg _
  positivity

theorem allocation_gt {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    r₁+2 < allocation r₁ r₂ := by
  have hr := radical_gt h₁ h₂
  have hg := gain_expanded h₁ h₂
  unfold allocation
  apply (lt_div_iff₀ (show 0 < r₁+r₂+2 by linarith)).mpr
  nlinarith

theorem allocation_mul {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    allocation r₁ r₂ * allocation r₂ r₁ = gain r₁ r₂ := by
  have hd : r₁+r₂+2 ≠ 0 := by positivity
  have hq := gain_quadratic h₁ h₂
  have he : r₂+r₁+2 = r₁+r₂+2 := by ring
  unfold allocation
  rw [gain_comm r₁ r₂, he]
  field_simp
  nlinarith [hq]

theorem scalar_pos {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    0 < scalar r₁ r₂ := by
  unfold scalar
  linarith [allocation_gt h₁ h₂, allocation_gt h₂ h₁]

theorem allocation_stationarity {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    allocation r₁ r₂-r₁^2/allocation r₁ r₂ = scalar r₁ r₂ := by
  have ht : 0 < allocation r₁ r₂ := by linarith [allocation_gt h₁ h₂]
  have hden : allocation r₁ r₂*(r₁+r₂+2) = gain r₁ r₂+r₁^2 := by
    unfold allocation
    field_simp
  have hp := allocation_mul h₁ h₂
  unfold scalar
  field_simp [ne_of_gt ht]
  nlinarith [hden,hp]

theorem scalar_comm (r₁ r₂ : ℝ) : scalar r₂ r₁ = scalar r₁ r₂ := by
  unfold scalar
  ring

end C2.TwoGamma
