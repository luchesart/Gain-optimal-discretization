import C2.CADEffectiveIsolation
import C2.CADIsolationSamples

/-! Sorted finite root descriptors and explicit rational samples. Even ranks
represent exact grid root points; odd ranks represent open isolating cells.
All returned data and sample operations are executable rational arithmetic. -/
namespace C2.CADEffective.Dense
open Polynomial Set C2.CADIsolation

/-- Increasing descriptor ranks, interleaving points and open cells. -/
def rootRanks (p : Poly) (a b : ℚ) (n : ℕ) : List ℕ :=
  (List.range (2*2^n+1)).filter fun r =>
    if r % 2 = 0 then decide (eval p (gridPoint a b n (r/2)) = 0)
    else decide (eval p (gridPoint a b n (r/2)) * eval p (gridPoint a b n (r/2+1)) < 0)

/-- Mathematical meaning of a returned exact-algebraic descriptor. -/
noncomputable def rootAtRank (p : Poly) (a b : ℚ) (n r : ℕ) (x : ℝ) : Prop :=
  if r % 2 = 0 then x = (gridPoint a b n (r/2):ℝ) ∧ realEval (denote p) x = 0
  else x ∈ Ioo (gridPoint a b n (r/2):ℝ) (gridPoint a b n (r/2+1):ℝ) ∧
    realEval (denote p) x = 0

theorem mem_rootRanks (p : Poly) (a b : ℚ) (n r : ℕ) :
    r ∈ rootRanks p a b n ↔
    if r % 2 = 0 then selectedPoint (denote p) a b n (r/2)
      else selectedInterval (denote p) a b n (r/2) := by
  simp only [rootRanks,List.mem_filter,List.mem_range]
  by_cases hr : r % 2 = 0
  · simp only [hr,ite_true,decide_eq_true_eq,eval_denote,selectedPoint]
    constructor
    · rintro ⟨hb,hp⟩
      exact ⟨by omega,hp⟩
    · rintro ⟨hb,hp⟩
      exact ⟨by omega,hp⟩
  · simp only [hr,ite_false,decide_eq_true_eq,eval_denote,selectedInterval]
    constructor
    · rintro ⟨hb,hp⟩
      exact ⟨by omega,hp⟩
    · rintro ⟨hb,hp⟩
      exact ⟨by omega,hp⟩

theorem rootRanks_sorted (p : Poly) (a b : ℚ) (n : ℕ) :
    List.Pairwise (· < ·) (rootRanks p a b n) := by
  exact List.pairwise_lt_range.filter _

/-- Every returned descriptor denotes exactly one actual real root. -/
theorem rootRanks_unique_root (p : Poly) {a b : ℚ} (hab : a < b) {n r : ℕ}
    (hm : certifiedMesh (denote p) a b n) (hr : r ∈ rootRanks p a b n) :
    ∃! x, rootAtRank p a b n r x := by
  have hsel := (mem_rootRanks p a b n r).mp hr
  by_cases he : r % 2 = 0
  · simp only [he,if_pos] at hsel
    have hs := selectedPoint_sound (denote p) hab.le hsel
    refine ⟨(gridPoint a b n (r/2):ℝ),?_,?_⟩
    · simpa [rootAtRank,he] using hs.2
    · intro y hy
      exact (by simpa only [rootAtRank,he,if_pos] using hy :
        y = (gridPoint a b n (r/2):ℝ) ∧ realEval (denote p) y = 0).1
  · simp only [he,if_neg] at hsel
    simpa only [rootAtRank,he,if_neg] using selectedInterval_sound (denote p) hab hm hsel

/-- The finite returned descriptor list accounts for every root in [a,b]. -/
theorem rootRanks_complete (p : Poly) {a b : ℚ} (hab : a < b) {n : ℕ}
    (hm : certifiedMesh (denote p) a b n) {x : ℝ}
    (hx : x ∈ Icc (a:ℝ) (b:ℝ)) (hpx : realEval (denote p) x = 0) :
    ∃ r ∈ rootRanks p a b n, rootAtRank p a b n r x := by
  rcases certifiedMesh_covers_roots (denote p) hab hm hx hpx with hp | hc
  · obtain ⟨j,hj,hxj⟩ := hp
    refine ⟨2*j,?_,?_⟩
    · rw [mem_rootRanks]
      simpa using hj
    · simpa [rootAtRank] using And.intro hxj hpx
  · obtain ⟨i,hi,hxi⟩ := hc
    have hdiv : (2*i+1)/2 = i := by omega
    refine ⟨2*i+1,?_,?_⟩
    · rw [mem_rootRanks]
      simpa [hdiv] using hi
    · simpa [rootAtRank,hdiv] using And.intro hxi hpx

/-- Rational sample between two descriptor ranks. -/
def betweenRanks (a b : ℚ) (n r s : ℕ) : ℚ :=
  if r % 2 = 0 then
    if s % 2 = 0 then midpoint (gridPoint a b n (r/2)) (gridPoint a b n (s/2))
    else gridPoint a b n (s/2)
  else gridPoint a b n (r/2+1)

/-- Rank order is the true root order, and the computed rational sample lies
strictly between the corresponding roots. No algebraic-order oracle is used. -/
theorem betweenRanks_correct (p : Poly) {a b : ℚ} (hab : a < b) {n r s : ℕ}
    (hr : r ∈ rootRanks p a b n) (hs : s ∈ rootRanks p a b n) (hrs : r < s)
    {x y : ℝ} (hx : rootAtRank p a b n r x) (hy : rootAtRank p a b n s y) :
    x < (betweenRanks a b n r s:ℝ) ∧ (betweenRanks a b n r s:ℝ) < y := by
  have hsr := (mem_rootRanks p a b n r).mp hr
  have hss := (mem_rootRanks p a b n s).mp hs
  by_cases he : r % 2 = 0 <;> by_cases hf : s % 2 = 0
  · simp only [rootAtRank,he,hf,if_pos] at hx hy
    rw [hx.1,hy.1]
    simpa only [betweenRanks,he,hf,if_pos] using
      rational_sample_between_points hab n (show r/2 < s/2 by omega)
  · simp only [rootAtRank,he,hf,if_pos,if_neg] at hx hy
    simp only [he,if_pos] at hsr
    simp only [hf,if_neg] at hss
    rw [hx.1]
    simpa only [betweenRanks,he,hf,if_pos,if_neg] using
      rational_sample_point_before_cell (denote p) hab n (show r/2 ≤ s/2 by omega)
        hsr hss hy.1
  · simp only [rootAtRank,he,hf,if_pos,if_neg] at hx hy
    simp only [he,if_neg] at hsr
    simp only [hf,if_pos] at hss
    rw [hy.1]
    simpa only [betweenRanks,he,if_neg] using
      rational_sample_cell_before_point (denote p) hab n (show r/2 < s/2 by omega)
        hsr hss hx.1
  · simp only [rootAtRank,he,hf,if_neg] at hx hy
    simpa only [betweenRanks,he,if_neg] using
      rational_sample_between_cells hab.le n (show r/2 < s/2 by omega) hx.1 hy.1

theorem root_rank_order (p : Poly) {a b : ℚ} (hab : a < b) {n r s : ℕ}
    (hr : r ∈ rootRanks p a b n) (hs : s ∈ rootRanks p a b n) (hrs : r < s)
    {x y : ℝ} (hx : rootAtRank p a b n r x) (hy : rootAtRank p a b n s y) : x < y :=
  (betweenRanks_correct p hab hr hs hrs hx hy).1.trans
    (betweenRanks_correct p hab hr hs hrs hx hy).2

end C2.CADEffective.Dense
