import C2.NGammaPolynomialDegree

/-!
# Quantitative persistence of a root outside the unit disk

Root factorization supplies a uniform lower bound for the value of every
Schur-stable polynomial at an exterior point. Applied to the actual characteristic
polynomial, this excludes an entire neighborhood of zero gain when a zero-gain
factor has an exterior root. No root-continuity oracle is assumed.
-/
noncomputable section
open scoped BigOperators
open Polynomial
namespace C2.NGamma.PolynomialModel

theorem schur_eval_norm_lower_bound {p : Polynomial ℂ} (hp : SchurStable p)
    {z : ℂ} (hz : 1 < ‖z‖) :
    ‖p.leadingCoeff‖ * (‖z‖-1)^p.natDegree ≤ ‖p.eval z‖ := by
  have hm : ∀ s : Multiset ℂ, (∀ a ∈ s, ‖a‖ ≤ 1) →
      (‖z‖-1)^s.card ≤ ‖(s.map (fun a => z-a)).prod‖ := by
    intro s
    induction s using Multiset.induction_on with
    | empty => simp
    | @cons a s ih =>
      intro hs
      have ha : ‖z‖-1 ≤ ‖z-a‖ := by
        have h := norm_sub_norm_le z a
        have h' := hs a (Multiset.mem_cons_self _ _)
        linarith
      have hh := ih (fun b hb => hs b (Multiset.mem_cons_of_mem hb))
      simp only [Multiset.card_cons,Multiset.map_cons,Multiset.prod_cons,norm_mul,pow_succ]
      calc
        (‖z‖-1)^s.card*(‖z‖-1) ≤ ‖(s.map (fun a => z-a)).prod‖*‖z-a‖ :=
          mul_le_mul hh ha (by linarith) (norm_nonneg _)
        _ = _ := by ring
  have hroot : ∀ a ∈ p.roots, ‖a‖ ≤ 1 := by
    intro a ha
    exact le_of_lt (hp a (isRoot_of_mem_roots ha))
  have hcard : p.roots.card=p.natDegree := by
    simpa using (natDegree_eq_card_roots (IsAlgClosed.splits p)).symm
  rw [eval_eq_prod_roots_sub_of_splits_id (IsAlgClosed.splits p),norm_mul]
  exact mul_le_mul_of_nonneg_left (hcard ▸ hm p.roots hroot) (norm_nonneg _)

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem cube_factor_leading_pos {r x : ℝ} (hr : 0 < r) (hx : -1 ≤ x) :
    0 < 1+r*(1+x)/2 := by
  have h : 0 ≤ 1+x := by linarith
  positivity

theorem cube_factor_natDegree {r x : ℝ} (hr : 0 < r) (hx : -1 ≤ x) :
    (factor r x).natDegree=1 := by
  rw [factor_linear]
  apply natDegree_linear
  exact_mod_cast ne_of_gt (cube_factor_leading_pos hr hx)

theorem cube_factor_ne_zero {r x : ℝ} (hr : 0 < r) (hx : -1 ≤ x) :
    factor r x ≠ 0 := by
  intro h
  have hd := cube_factor_natDegree hr hx
  simp [h] at hd

theorem cube_factor_leadingCoeff {r x : ℝ} (hr : 0 < r) (hx : -1 ≤ x) :
    (factor r x).leadingCoeff = ((1+r*(1+x)/2 : ℝ) : ℂ) := by
  rw [factor_linear,leadingCoeff_linear]
  · push_cast
    rfl
  · exact_mod_cast ne_of_gt (cube_factor_leading_pos hr hx)

theorem q_natDegree_le_one (x : ℝ) : (q x).natDegree ≤ 1 := by
  exact natDegree_linear_le

theorem cube_characteristic_degree_leading {r x : ι → ℝ} {d : ℕ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, -1 ≤ x i) (hd : 1 ≤ d) (b : ℝ) :
    (characteristic r x d b).natDegree=Fintype.card ι+d ∧
    (characteristic r x d b).leadingCoeff=(∏ i, ((1+r i*(1+x i)/2 : ℝ) : ℂ)) := by
  have hn : (∏ i, factor (r i) (x i)) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (fun i _ => cube_factor_ne_zero (hr i) (hx i))
  have hD : (∏ i, factor (r i) (x i)).natDegree=Fintype.card ι := by
    rw [natDegree_prod _ _ (fun i _ => cube_factor_ne_zero (hr i) (hx i))]
    simp only [cube_factor_natDegree (hr _) (hx _),Finset.sum_const,Finset.card_univ,
      smul_eq_mul,mul_one]
  have hQ : (∏ i, q (x i)).natDegree ≤ Fintype.card ι := by
    calc
      _ ≤ ∑ i, (q (x i)).natDegree := natDegree_prod_le _ _
      _ ≤ ∑ _i : ι, 1 := Finset.sum_le_sum (fun i _ => q_natDegree_le_one (x i))
      _ = _ := by simp
  have ht : (C (b : ℂ)*∏ i, q (x i)).natDegree < (X^d*∏ i, factor (r i) (x i)).natDegree := by
    have hle := (natDegree_C_mul_le (b : ℂ) (∏ i, q (x i))).trans hQ
    rw [natDegree_X_pow_mul d hn,hD]
    omega
  unfold characteristic
  constructor
  · rw [natDegree_add_eq_left_of_natDegree_lt ht,natDegree_X_pow_mul d hn,hD]
  · rw [leadingCoeff_add_of_degree_lt' (degree_lt_degree ht),leadingCoeff_mul,
      leadingCoeff_pow,leadingCoeff_X,one_pow,one_mul,leadingCoeff_prod]
    exact Finset.prod_congr rfl (fun i _ => cube_factor_leadingCoeff (hr i) (hx i))

def factorRoot (r x : ℝ) : ℂ :=
  (((1-r*(1-x)/2)/(1+r*(1+x)/2) : ℝ) : ℂ)

theorem cube_factorRoot_eval {r x : ℝ} (hr : 0 < r) (hx : -1 ≤ x) :
    (factor r x).eval (factorRoot r x)=0 := by
  have hn : (1+(r:ℂ)*(1+x)/2) ≠ 0 := by
    exact_mod_cast ne_of_gt (cube_factor_leading_pos hr hx)
  rw [factor_linear]
  simp only [eval_add,eval_mul,eval_C,eval_X]
  unfold factorRoot
  push_cast
  rw [mul_div_cancel₀ _ hn]
  ring

theorem cube_factorRoot_exterior {r x : ℝ} (hr : 0 < r) (hx : -1 ≤ x)
    (hbad : x < -2/r) : 1 < ‖factorRoot r x‖ := by
  have ha := cube_factor_leading_pos hr hx
  have hnum : (1-r*(1-x)/2)/(1+r*(1+x)/2) < -1 := by
    apply (div_lt_iff₀ ha).2
    have hb := (lt_div_iff₀ hr).mp hbad
    nlinarith
  unfold factorRoot
  rw [Complex.norm_real,Real.norm_eq_abs,abs_of_neg (by linarith)]
  linarith

theorem cube_zero_gain_exterior_root {r x : ι → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, -1 ≤ x i) (d : ℕ)
    (j : ι) (hbad : x j < -2/r j) :
    (characteristic r x d 0).eval (factorRoot (r j) (x j))=0 ∧
      1 < ‖factorRoot (r j) (x j)‖ := by
  constructor
  · have hprod : (∏ i, (factor (r i) (x i)).eval (factorRoot (r j) (x j)))=0 := by
      exact Finset.prod_eq_zero (Finset.mem_univ j) (cube_factorRoot_eval (hr j) (hx j))
    simp [characteristic,eval_prod,hprod]
  · exact cube_factorRoot_exterior (hr j) (hx j) hbad

/-- A fixed-degree characteristic family cannot acquire Schur stability at
arbitrarily small gain when its zero-gain polynomial has an exterior root. -/
theorem cube_exterior_root_small_gain_not_schur {r x : ι → ℝ} {d : ℕ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, -1 ≤ x i) (hd : 1 ≤ d)
    {z : ℂ} (hz : 1 < ‖z‖) (hroot : (characteristic r x d 0).eval z=0) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ b : ℝ, |b| < ε → ¬SchurStable (characteristic r x d b) := by
  let L : ℂ := ∏ i, ((1+r i*(1+x i)/2 : ℝ) : ℂ)
  let Q : ℂ := ∏ i, (q (x i)).eval z
  let C : ℝ := ‖L‖*(‖z‖-1)^(Fintype.card ι+d)
  have hL : L ≠ 0 := by
    apply Finset.prod_ne_zero_iff.mpr
    intro i _
    exact_mod_cast ne_of_gt (cube_factor_leading_pos (hr i) (hx i))
  have hC : 0 < C := mul_pos (norm_pos_iff.mpr hL) (pow_pos (sub_pos.mpr hz) _)
  have hQ : 0 < ‖Q‖+1 := by positivity
  refine ⟨C/(‖Q‖+1),div_pos hC hQ,?_⟩
  intro b hb hstable
  have hbound := schur_eval_norm_lower_bound hstable hz
  obtain ⟨hdeg,hlead⟩ := cube_characteristic_degree_leading hr hx hd b
  rw [hdeg,hlead] at hbound
  have hzero : z^d*(∏ i, (factor (r i) (x i)).eval z)=0 := by
    simpa [characteristic,eval_prod] using hroot
  have heval : (characteristic r x d b).eval z=(b:ℂ)*Q := by
    simp only [characteristic,eval_add,eval_mul,eval_pow,eval_X,eval_prod,eval_C]
    rw [hzero,zero_add]
  rw [heval,norm_mul,Complex.norm_real,Real.norm_eq_abs] at hbound
  have hsmall := (lt_div_iff₀ hQ).mp hb
  change C ≤ |b| *‖Q‖ at hbound
  nlinarith [abs_nonneg b]

/-- The outside-cube branch of the global theorem: one coordinate below -2/r
precludes any positive initial interval of Schur stability. -/
theorem cube_bad_coordinate_small_gain_not_schur {r x : ι → ℝ} {d : ℕ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, -1 ≤ x i) (hd : 1 ≤ d)
    (j : ι) (hbad : x j < -2/r j) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ b : ℝ, |b| < ε → ¬SchurStable (characteristic r x d b) := by
  have hh := cube_zero_gain_exterior_root hr hx d j hbad
  exact cube_exterior_root_small_gain_not_schur hr hx hd hh.2 hh.1

end C2.NGamma.PolynomialModel
