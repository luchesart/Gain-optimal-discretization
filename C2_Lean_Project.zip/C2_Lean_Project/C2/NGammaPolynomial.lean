import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.Tactic

/-! Actual complex characteristic polynomials of positive cascades.
These statements use complex roots and do not replace Schur stability by a
phase inequality or an assumed root count. -/

noncomputable section
open scoped BigOperators
open Polynomial

namespace C2.NGamma.PolynomialModel

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

def q (x : ℝ) : Polynomial ℂ :=
  C (((1 + x) / 2 : ℝ) : ℂ) * X + C (((1 - x) / 2 : ℝ) : ℂ)

def factor (r x : ℝ) : Polynomial ℂ := X - 1 + C (r : ℂ) * q x

def characteristic (r x : ι → ℝ) (d : ℕ) (b : ℝ) : Polynomial ℂ :=
  X ^ d * ∏ i, factor (r i) (x i) + C (b : ℂ) * ∏ i, q (x i)

def SchurStable (p : Polynomial ℂ) : Prop :=
  ∀ z : ℂ, p.eval z = 0 → ‖z‖ < 1

theorem q_eval (x : ℝ) (z : ℂ) :
    (q x).eval z = ((1 + (x : ℂ)) * z + 1 - x) / 2 := by
  simp only [q, eval_add, eval_mul, eval_C, eval_X]
  push_cast
  ring

theorem factor_eval (r x : ℝ) (z : ℂ) :
    (factor r x).eval z = z - 1 + r * (q x).eval z := by
  simp [factor]

theorem q_eval_one (x : ℝ) : (q x).eval 1 = 1 := by
  rw [q_eval]
  ring

theorem q_eval_neg_one (x : ℝ) : (q x).eval (-1) = -(x : ℂ) := by
  rw [q_eval]
  ring

theorem factor_eval_one (r x : ℝ) : (factor r x).eval 1 = (r : ℂ) := by
  rw [factor_eval, q_eval_one]
  ring

theorem factor_eval_neg_one (r x : ℝ) :
    (factor r x).eval (-1) = -(2 + (r : ℂ) * x) := by
  rw [factor_eval, q_eval_neg_one]
  ring

theorem characteristic_eval_one (r x : ι → ℝ) (d : ℕ) (b : ℝ) :
    (characteristic r x d b).eval 1 = (∏ i, (r i : ℂ)) + b := by
  simp [characteristic, eval_prod, factor_eval_one, q_eval_one]

theorem characteristic_eval_neg_one (r x : ι → ℝ) (d : ℕ) (b : ℝ) :
    (characteristic r x d b).eval (-1) =
      (-1 : ℂ) ^ (d + Fintype.card ι) * ∏ i, (2 + (r i : ℂ) * x i) +
      b * (-1 : ℂ) ^ Fintype.card ι * ∏ i, (x i : ℂ) := by
  simp only [characteristic, eval_add, eval_mul, eval_pow, eval_X, eval_prod,
    eval_C, factor_eval_neg_one, q_eval_neg_one]
  rw [Finset.prod_neg, Finset.prod_neg]
  simp only [Finset.card_univ]
  rw [pow_add]
  ring

theorem q_factor_no_common_root (r x : ℝ) (z : ℂ)
    (hq : (q x).eval z = 0) : (factor r x).eval z ≠ 0 := by
  intro hd
  rw [factor_eval, hq] at hd
  have hz : z = 1 := by linear_combination hd
  rw [hz, q_eval_one] at hq
  exact one_ne_zero hq

theorem factor_root_formula {r x : ℝ} (hr : 0 < r) (hx : 0 ≤ x)
    {z : ℂ} (hz : (factor r x).eval z = 0) :
    z = (((1 - r * (1 - x) / 2) / (1 + r * (1 + x) / 2) : ℝ) : ℂ) := by
  have ha : 0 < 1 + r * (1 + x) / 2 := by positivity
  have hn : (1 + (r : ℂ) * (1 + x) / 2) ≠ 0 := by
    exact_mod_cast ne_of_gt ha
  rw [factor_eval, q_eval] at hz
  push_cast
  apply (eq_div_iff hn).2
  linear_combination hz

theorem factor_schur {r x : ℝ} (hr : 0 < r) (hx : 0 ≤ x) :
    SchurStable (factor r x) := by
  intro z hz
  rw [factor_root_formula hr hx hz, Complex.norm_real]
  have ha : 0 < 1 + r * (1 + x) / 2 := by positivity
  apply abs_lt.mpr
  constructor
  · apply (lt_div_iff₀ ha).2
    nlinarith [mul_nonneg (le_of_lt hr) hx]
  · apply (div_lt_iff₀ ha).2
    linarith

theorem zero_gain_schur {r x : ι → ℝ} (hr : ∀ i, 0 < r i)
    (hx : ∀ i, 0 ≤ x i) (d : ℕ) : SchurStable (characteristic r x d 0) := by
  intro z hz
  have h : z ^ d * ∏ i, (factor (r i) (x i)).eval z = 0 := by
    simpa [characteristic, eval_prod] using hz
  rcases mul_eq_zero.mp h with hpow | hprod
  · have hz0 : z = 0 := pow_eq_zero hpow
    simp [hz0]
  · obtain ⟨i, _, hi⟩ := Finset.prod_eq_zero_iff.mp hprod
    exact factor_schur (hr i) (hx i) z hi

theorem one_not_root {r x : ι → ℝ} (hr : ∀ i, 0 < r i)
    (d : ℕ) {b : ℝ} (hb : 0 ≤ b) :
    (characteristic r x d b).eval 1 ≠ 0 := by
  rw [characteristic_eval_one]
  have hp : 0 < ∏ i, r i := Finset.prod_pos (fun i _ => hr i)
  have hn : (∏ i, r i) + b ≠ 0 := ne_of_gt (by linarith)
  exact_mod_cast hn

theorem endpoint_is_root {r x : ι → ℝ} (hx : ∀ i, x i ≠ 0) :
    (characteristic r x 1 (∏ i, (r i + 2 / x i))).eval (-1) = 0 := by
  rw [characteristic_eval_neg_one]
  have hprod : ((∏ i, (r i + 2 / x i) : ℝ) : ℂ) * ∏ i, (x i : ℂ) =
      ∏ i, (2 + (r i : ℂ) * x i) := by
    push_cast
    rw [← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro i _
    have hn : (x i : ℂ) ≠ 0 := by exact_mod_cast hx i
    field_simp
    ring
  rw [pow_add]
  simp only [pow_one]
  calc
    (-1 : ℂ) * (-1) ^ Fintype.card ι * (∏ i, (2 + (r i : ℂ) * x i)) +
        (↑(∏ i, (r i + 2 / x i))) * (-1) ^ Fintype.card ι * (∏ i, (x i : ℂ)) =
      (-1) ^ Fintype.card ι *
        (- (∏ i, (2 + (r i : ℂ) * x i)) +
          (↑(∏ i, (r i + 2 / x i))) * ∏ i, (x i : ℂ)) := by ring
    _ = 0 := by rw [hprod]; ring

end C2.NGamma.PolynomialModel
