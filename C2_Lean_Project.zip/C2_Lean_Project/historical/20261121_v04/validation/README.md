# Evidence index — C2 v0.4.0, 9 November 2026

The current verdict is ../VERIFICATION.json: all 45 numbered manuscript
results are COMPLETE and the whole article is formalized. The release has
208 source modules, 1741 public theorems/lemmas and 2176 audited public
declarations. There is no remaining partial manuscript result.

Current final checks:
- 20261109/final_modular_v04.log: complete C2 umbrella import;
- 20261109/final_single_file_v04.log: generated standalone source;
- ../work/axiom_audit.json and ../work/SharedAxiomAudit.log: every explicit
  public inventory root, with only propext, Classical.choice and Quot.sound;
- ../work/lean_inventory_draft.json: exact current module/source hashes;
- 20261109/v03_module_preservation.json: all 156 v0.3 modules byte-identical,
  with 52 new modules and 386 new public proofs;
- 20261109/release_v04/: packaging checks, final hash freeze and release scripts.

Current Theorem 3 evidence is cad_native_theorem_completion_20261109.json
and the accepted independent cad_end_to_end_review_20261109.json. The
effective, projection, factor, isolation and delineability records document
their individual proved stages. The native theorem discharges those stages
for the actual returned output of CADNative.run. Its runtime uses finite
rational coefficient lists, terminating data searches, dyadic isolation and
rational samples. No practical complexity claim or verification of the
separate SymPy/resultant implementation is made.

The current PDF review is
20261109_v04_pdf/pdf_review/review_20261109.json, with reviewed page images
in that directory and the successful build log at
20261109_v04_pdf/latex_build.log. The review binds the PDF to the current
TeX input hashes. Existing numerical experiments were not rerun.

Historical evidence is retained, not used as the current completion verdict.
In particular, independent_scope_review_20261109.json is the earlier v0.3
scope review, superseded by cad_end_to_end_review_20261109.json; the entire
20261109/pdf_review/ directory and 20261109/latex_build.log describe the v0.3
PDF, superseded by 20261109_v04_pdf/. The unversioned final_modular.log and
final_single_file.log under 20261109/ are also earlier release checks.
Any v0.3 final_validation_summary.json records 44 COMPLETE / 1 PARTIAL as
historical scope only. Intermediate stage records may retain their then-open
integration obligations; they do not supersede the final native theorem or
VERIFICATION.json. Earlier release documents and the former CAD obligations
are retained under ../historical/20261109_v03/ and older historical directories.
Resource-contention and abandoned attempts remain marked under attempts/.
