import C2.NGammaCayley

noncomputable section
open scoped BigOperators Topology
open Filter
namespace C2.NGamma.Cayley

/-- A continuous real argument of a numerator factor on the upper semicircle. -/
def qPhase (x t : ℝ) : ℝ := Real.arctan t + Real.arctan (x*t)

def qAmplitude (x t : ℝ) : ℝ :=
  Real.sqrt (1+(x*t)^2) / Real.sqrt (1+t^2)

theorem qAmplitude_pos (x t : ℝ) : 0 < qAmplitude x t := by
  unfold qAmplitude
  positivity

theorem q_polar (x t : ℝ) :
    (PolynomialModel.q x).eval (point t) =
      (qAmplitude x t : ℂ) * Complex.exp ((qPhase x t : ℂ) * Complex.I) := by
  rw [q_eval_point, linear_polar]
  have hneg : 1 - Complex.I * (t : ℂ) =
      (Real.sqrt (1+t^2) : ℂ) * Complex.exp (-(Real.arctan t : ℂ)*Complex.I) := by
    simpa using linear_polar (-t)
  rw [hneg]
  simp only [qAmplitude, qPhase, Complex.ofReal_div, Complex.ofReal_add,
    add_mul, Complex.exp_add, neg_mul, Complex.exp_neg]
  field_simp
  ring

theorem qPhase_continuous (x : ℝ) : Continuous (qPhase x) := by
  unfold qPhase
  exact Real.continuous_arctan.add (Real.continuous_arctan.comp (continuous_const.mul continuous_id))

theorem arctan_mul_tendsto_atTop {x : ℝ} (hx : 0 ≤ x) :
    Tendsto (fun t : ℝ => Real.arctan (x*t)) atTop
      (𝓝 (if x = 0 then 0 else Real.pi/2)) := by
  split_ifs with h
  · simp [h]
  · exact (Real.tendsto_arctan_atTop.mono_right nhdsWithin_le_nhds).comp
      ((tendsto_const_mul_atTop_of_pos (lt_of_le_of_ne hx (Ne.symm h))).2 tendsto_id)

theorem qPhase_tendsto_atTop {x : ℝ} (hx : 0 ≤ x) :
    Tendsto (qPhase x) atTop (𝓝 (Real.pi - (if x = 0 then Real.pi/2 else 0))) := by
  have h := (Real.tendsto_arctan_atTop.mono_right nhdsWithin_le_nhds).add
    (arctan_mul_tendsto_atTop hx)
  convert h using 1
  split_ifs <;> ring

/-- The endpoint contribution of zero numerator parameters is counted explicitly. -/
theorem sum_qPhase_tendsto_atTop {n : ℕ} {x : Fin n → ℝ}
    (hx : ∀ i, 0 ≤ x i) :
    Tendsto (fun t => ∑ i, qPhase (x i) t) atTop
      (𝓝 ((n : ℝ)*Real.pi - ∑ i, if x i = 0 then Real.pi/2 else 0)) := by
  have h := tendsto_finset_sum Finset.univ (fun i _ => qPhase_tendsto_atTop (hx i))
  simpa only [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul] using h

theorem totalPhase_tendsto_atTop {n : ℕ} {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) (d : ℕ) :
    Tendsto (Phase.totalPhase (fun i => x i+2/r i) x d) atTop
      (𝓝 ((d : ℝ)*Real.pi + ∑ i, if x i = 0 then Real.pi/2 else 0)) := by
  have hi (i : Fin n) : Tendsto (Phase.contribution (x i+2/r i) (x i)) atTop
      (𝓝 (if x i = 0 then Real.pi/2 else 0)) := by
    have ha : 0 < x i+2/r i := add_pos_of_nonneg_of_pos (hx i) (div_pos (by norm_num) (hr i))
    have h := (arctan_mul_tendsto_atTop (le_of_lt ha)).sub (arctan_mul_tendsto_atTop (hx i))
    simp only [ne_of_gt ha, if_false] at h
    convert h using 1
    split_ifs <;> ring
  have h0 := (Real.tendsto_arctan_atTop.mono_right nhdsWithin_le_nhds).const_mul (2*(d:ℝ))
  have h := h0.add (tendsto_finset_sum Finset.univ (fun i _ => hi i))
  convert h using 1 <;> try {unfold Phase.totalPhase; rfl}
  congr 1
  ring

end C2.NGamma.Cayley
