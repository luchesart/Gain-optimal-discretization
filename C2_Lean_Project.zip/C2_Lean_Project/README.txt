Gain-optimal discretization and constrained MIACE tuning for rational loops with pure delay
Lean proof project — version 0.5.0, 21 November 2026

All 45 numbered results are COMPLETE: 22 in the main text and 23 in the
appendices. Stable LaTeX identifiers bind manuscript statements to Lean.
COMPLETE covers hypotheses and conclusions; it does not assert literal
identity of the written proof or verification of every external program.
See PROOF_MAP_EN.csv and MANUSCRIPT_FORMALIZATION_NOTES.md for exact scope.

Version 0.5.0 strengthens Proposition 1 (prop:robust) to sharp asymmetric
parameter boxes and the unique optimal nominal center. C2.RobustAsymmetric
adds 23 public theorems and six definitions. It proves the actual root-based
robust stability budget over the entire closed uncertainty rectangle,
complete feasible-center interval, both total-width regimes, unique optimum,
and the true robust gain supremum after optimizing every admissible center.
Widths 0, 1/2 and 1 are included; threshold equality is not stable. The
uncertain coefficients are constant, not switching or time-varying.

The current project has 209 proof modules, 1764 explicit public theorem/lemma
declarations and 2205 explicit public declarations audited. All 208 v0.4.0
proof modules are preserved byte-for-byte. Every old module was freshly
compiled on 21 November, then the new module and complete regenerated
umbrella were checked. The generated 27418-line standalone source was
independently checked in isolation; its bytes match the released file.
The full fresh audit resolves all 2205 public roots and finds only propext,
Classical.choice and Quot.sound. No sorryAx or custom axioms are accepted.
Evidence and exact stage hashes are recorded in VERIFICATION.json.

The gain-projection result is now Theorem 16, historically Theorem 3.
C2.CADNative.run constructs factor/Bézout data, projection, squarefree
reductions, certified dyadic isolation, rational samples and exact sign tests
from the input rational polynomial system. Its output is none exactly when
positive-gain feasibility is empty; otherwise the unique algebraic descriptor
is the global least upper bound, including disconnected components, with
0 < sup <= K0 < K. No factorization, root, cell or marking oracle is supplied.
Exact rational-data enumeration is total but may be impractically slow.
The separate SymPy/resultant implementation remains unverified.

Pinned environment: Lean 4.19.0; mathlib
c44e0c8ee63ca166450922a373c7409c5d26b00b.
Reproduce on a normal pinned installation:
  lake exe cache get
  python tools/make_single_file.py
  python tools/theorem_inventory.py
  lake build
  lake env lean -j1 live/C2_Live_Lean419.lean
  python tools/run_axiom_audit.py

After cache restoration, tools/build_direct.py provides direct topological
compilation with pinned dependency checks. The release used those direct
Lean checks, the full umbrella, the standalone check and the all-public-root
audit; a fresh lake build is not claimed. The official Lean.CollectAxioms
collector shares one visited set across roots, proving the allowed-axiom
condition for every root through their union. Exact per-root lists are not
produced. AxiomAudit.lean remains an optional per-root reporting input.

C2.lean imports all modules. live/C2_Live_Lean419.lean is generated from the
same frozen source files. This is a local Lean check, not an online live.lean
website session. Distributions omit dependencies and compiled caches; Lake
restores the pinned dependencies from the manifest.

The general realization theorem explicitly uses degree-minimal dimension;
a separate Kalman controllability/observability equivalence is not claimed.
The full-cube result concerns the initial interval adjacent to zero. The
separate CAD theorem includes all feasible gain components. Fractional delays,
switching uncertainty and new plant classes are outside the current claims.

Prior v0.4.0 metadata, generated source and axiom evidence are archived under
historical/20261121_v04. Older dated records remain historical. The October
IJC version is a separate checkpoint; no journal submission is claimed.
