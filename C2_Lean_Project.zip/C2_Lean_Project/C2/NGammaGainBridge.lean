import C2.NGammaGlobalOptimum
import C2.NGammaReflection
import C2.NGammaAmplitude

/-! Exact identifications between the allocation coordinates w=1/t and
the amplitude/phase used for the actual characteristic polynomial. -/
noncomputable section
open scoped BigOperators
namespace C2.NGamma.Global

theorem magnitudeFactor_eq_amplitudeFactor (r x t : ℝ) :
    magnitudeFactor r x t = Cayley.amplitudeFactor r x t := by
  unfold magnitudeFactor Cayley.amplitudeFactor
  rw [Real.sqrt_div (by positivity)]
  simp only [mul_pow]
  ring

theorem allocationGain_eq_amplitudeFactor {r w : ℝ} (hr : 0 < r) (hw : 0 < w) (x : ℝ) :
    allocationGain r x w = Cayley.amplitudeFactor r x (1/w) := by
  have hsq : (allocationGain r x w)^2 = (Cayley.amplitudeFactor r x (1/w))^2 := by
    unfold allocationGain
    rw [Real.sq_sqrt (by positivity),Cayley.amplitudeFactor_sq]
    have hD : 0 < x^2+w^2 := by positivity
    have hE : 0 < 1+(x*(1/w))^2 := by positivity
    field_simp
    <;> ring
  nlinarith [allocationGain_pos hr hw x,Cayley.amplitudeFactor_pos hr x (1/w)]

theorem allocationProduct_eq_amplitude {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) {w : ℝ} (hw : 0 < w) :
    (∏ j, allocationGain (r j) (x j) w) = Cayley.amplitude r x (1/w) := by
  exact Finset.prod_congr rfl (fun j _ => allocationGain_eq_amplitudeFactor (hr j) hw (x j))

theorem phase_balance_iff_totalPhase {n : ℕ} (r x : Fin n → ℝ) {w : ℝ} (hw : 0 < w) :
    (∑ j, allocationPhase (r j) (x j) w) = 2*Real.arctan w ↔
      Phase.totalPhase (fun j => x j+2/r j) x 1 (1/w) = Real.pi := by
  rw [Phase.phase_eq_pi_iff_sumRatio _ _ _ (one_div_pos.mpr hw)]
  norm_num
  simpa only [allocationPhase,phase,sumRatio,Phase.sumRatio,one_div] using
    (ratio_eq_two_iff_phase_eq r x hw).symm

theorem reflected_amplitude_strict {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hneg : ∃ j, x j < 0) {t : ℝ} (ht : 0 < t) :
    Cayley.amplitude r x t < Cayley.amplitude r (fun j => |x j|) t := by
  have h := reflected_magnitude_product_strict r x hr hneg ht
  simpa only [magnitudeFactor_eq_amplitudeFactor] using h

end C2.NGamma.Global
