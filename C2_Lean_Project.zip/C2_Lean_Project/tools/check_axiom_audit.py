#!/usr/bin/env python3
"""Fail unless each inventoried public declaration has an allowed Lean axiom report.

Usage: python tools/check_axiom_audit.py work/AxiomAudit.log
Run `lake env lean AxiomAudit.lean > work/AxiomAudit.log 2>&1` beforehand.
"""
import argparse
import json
import pathlib
import re
import sys

root = pathlib.Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser()
ap.add_argument('log',type=pathlib.Path)
ap.add_argument('--inventory',type=pathlib.Path,default=root/'work/lean_inventory_draft.json')
ap.add_argument('--json',type=pathlib.Path,default=root/'work/axiom_audit.json')
args = ap.parse_args()
expected = {d['name'] for d in json.loads(args.inventory.read_text())['declarations'] if not d['private']}
text = args.log.read_text()
reports = {}
for m in re.finditer(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", text):
    reports[m[1]] = [a.strip() for a in (m[2] or '').split(',') if a.strip()]
allowed = {'propext','Classical.choice','Quot.sound'}
failures = {name:sorted(set(axioms)-allowed) for name,axioms in reports.items() if set(axioms)-allowed}
missing = sorted(expected-set(reports))
errors = [line for line in text.splitlines() if re.search(r'\berror:',line)]
passed = not failures and not missing and not errors
result = dict(passed=passed,expected_count=len(expected),reported_count=len(expected & reports.keys()),
              allowed_axioms=sorted(allowed),unexpected_axioms=failures,missing_declarations=missing,
              lean_errors=errors,reports={n:reports[n] for n in sorted(expected & reports.keys())})
args.json.parent.mkdir(parents=True,exist_ok=True)
args.json.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['passed','expected_count','reported_count','unexpected_axioms','missing_declarations','lean_errors']},ensure_ascii=False))
sys.exit(0 if passed else 1)
