import Mathlib

/-!
# Absolute areas for a pure-delay plant

The timing assumptions are stated for the actual tracking error and centred
command sequences. The absolute values occur inside each series.
-/

noncomputable section
open scoped BigOperators

namespace C2.MIACE

def area (T : ℝ) (s : ℕ → ℝ) : ℝ := T * ∑' n, |s n|

def cost (η Ae Au : ℝ) : ℝ := Real.sqrt (Ae ^ 2 + η * Au ^ 2)

theorem area_nonneg {T : ℝ} (hT : 0 ≤ T) (s : ℕ → ℝ) :
    0 ≤ area T s := by
  exact mul_nonneg hT (tsum_nonneg (fun n => abs_nonneg _))

/-- The zero command prehistory gives the first `d` errors equal to one;
the delayed plant gives the centred-command identity in the second premise. -/
theorem pure_delay_area_identity (T : ℝ) (d : ℕ) (e v : ℕ → ℝ)
    (hs : Summable (fun n => |e n|))
    (hstart : ∀ n < d, e n = 1)
    (htiming : ∀ n, v n = -e (n + d)) :
    area T e = (d : ℝ) * T + area T v := by
  have hhead : ∑ n ∈ Finset.range d, |e n| = (d : ℝ) := by
    calc
      ∑ n ∈ Finset.range d, |e n| = ∑ _n ∈ Finset.range d, (1 : ℝ) := by
        apply Finset.sum_congr rfl
        intro n hn
        rw [hstart n (Finset.mem_range.mp hn), abs_one]
      _ = (d : ℝ) := by simp
  have htail : (∑' n, |v n|) = ∑' n, |e (n + d)| := by
    apply tsum_congr
    intro n
    rw [htiming n, abs_neg]
  have hsplit := hs.sum_add_tsum_nat_add d
  rw [hhead, ← htail] at hsplit
  dsimp [area]
  rw [← hsplit]
  ring

theorem pure_delay_tracking_area_lower_bound {T : ℝ} (hT : 0 ≤ T)
    (d : ℕ) (e v : ℕ → ℝ) (hs : Summable (fun n => |e n|))
    (hstart : ∀ n < d, e n = 1)
    (htiming : ∀ n, v n = -e (n + d)) :
    (d : ℝ) * T ≤ area T e := by
  rw [pure_delay_area_identity T d e v hs hstart htiming]
  linarith [area_nonneg hT v]

/-- Strict order preservation explains why every positive MIACE weight has
the same minimizers on any fixed pure-delay response family. -/
theorem cost_strictMono_on_delay_line {η D : ℝ} (hη : 0 < η) (hD : 0 ≤ D) :
    StrictMonoOn (fun x : ℝ => cost η x (x - D)) (Set.Ici D) := by
  intro x hx y hy hxy
  dsimp [cost]
  change D ≤ x at hx
  change D ≤ y at hy
  have hx0 : 0 ≤ x := le_trans hD hx
  have hy0 : 0 ≤ y := le_trans hD hy
  have hsq : x ^ 2 < y ^ 2 := by nlinarith
  have hrest : η * (x - D) ^ 2 ≤ η * (y - D) ^ 2 := by
    apply mul_le_mul_of_nonneg_left _ hη.le
    nlinarith
  apply Real.sqrt_lt_sqrt
  · positivity
  · linarith

theorem cost_le_cost_iff_on_delay_line {η D x y : ℝ}
    (hη : 0 < η) (hD : 0 ≤ D) (hx : D ≤ x) (hy : D ≤ y) :
    cost η x (x - D) ≤ cost η y (y - D) ↔ x ≤ y := by
  constructor
  · intro h
    by_contra hxy
    have hstrict := cost_strictMono_on_delay_line hη hD hy hx (lt_of_not_ge hxy)
    linarith
  · intro h
    rcases lt_or_eq_of_le h with h | h
    · exact (cost_strictMono_on_delay_line hη hD hx hy h).le
    · rw [h]

/-- Pointwise minimizer equivalence, without assuming existence of a
minimizer or finiteness of the design family. -/
theorem pure_delay_minimizer_iff {ι : Type*} (S : Set ι)
    (Ae Au : ι → ℝ) {η D : ℝ} (hη : 0 < η) (hD : 0 ≤ D)
    (hAu : ∀ i ∈ S, 0 ≤ Au i)
    (harea : ∀ i ∈ S, Ae i = D + Au i) (i : ι) (hi : i ∈ S) :
    (∀ j ∈ S, cost η (Ae i) (Au i) ≤ cost η (Ae j) (Au j)) ↔
      (∀ j ∈ S, Ae i ≤ Ae j) := by
  have hxi : D ≤ Ae i := by rw [harea i hi]; linarith [hAu i hi]
  have hai : Au i = Ae i - D := by linarith [harea i hi]
  constructor <;> intro h j hj
  · have hxj : D ≤ Ae j := by rw [harea j hj]; linarith [hAu j hj]
    have haj : Au j = Ae j - D := by linarith [harea j hj]
    have hij := h j hj
    rw [hai, haj] at hij
    exact (cost_le_cost_iff_on_delay_line hη hD hxi hxj).mp hij
  · have hxj : D ≤ Ae j := by rw [harea j hj]; linarith [hAu j hj]
    have haj : Au j = Ae j - D := by linarith [harea j hj]
    rw [hai, haj]
    exact (cost_le_cost_iff_on_delay_line hη hD hxi hxj).mpr (h j hj)

end C2.MIACE
