import Mathlib

/-!
# Open gain projections and finite exceptional fibers

This module proves the topological step used by the exact projection
algorithm: finite exceptional gain fibers can be omitted when computing the
global supremum of a strict feasible gain set. It does not formalize
polynomial projection, algebraic root isolation, or the CAD algorithm.
-/

noncomputable section

namespace C2.GainProjection

open Set

/-- The projection onto gain of a finite family of strict inequalities.
The admissible parameter set is arbitrary; in the application it is `[0,1]`.
Continuity will only be needed in the gain variable at each fixed parameter. -/
def feasibleGains {ι : Type*} (Γ : Set ℝ) (f : ℝ → ℝ → ι → ℝ) : Set ℝ :=
  {k | ∃ γ ∈ Γ, ∀ i, 0 < f γ k i}

/-- A finite strict continuous system has an open gain projection, even when
the parameter domain is closed and a witness occurs at its endpoint. -/
theorem feasibleGains_isOpen {ι : Type*} [Finite ι]
    (Γ : Set ℝ) (f : ℝ → ℝ → ι → ℝ)
    (hf : ∀ γ ∈ Γ, ∀ i, Continuous (fun k => f γ k i)) :
    IsOpen (feasibleGains Γ f) := by
  have heq : feasibleGains Γ f =
      ⋃ γ ∈ Γ, ⋂ i, {k : ℝ | 0 < f γ k i} := by
    ext k
    simp [feasibleGains]
  rw [heq]
  exact isOpen_iUnion fun γ => isOpen_iUnion fun hγ =>
    isOpen_iInter_of_finite fun i => isOpen_lt continuous_const (hf γ hγ i)

/-- Every nonempty open subset of the real line is infinite. -/
theorem open_nonempty_infinite {S : Set ℝ} (hS : IsOpen S)
    (hne : S.Nonempty) : S.Infinite := by
  obtain ⟨a, b, hab, hsub⟩ := hS.exists_Ioo_subset hne
  exact (Ioo_infinite hab).mono hsub

/-- Removing finitely many exceptional points from an open gain set preserves
all upper bounds. In particular, feasible gains at exceptional fibers cannot
produce a larger isolated maximum. -/
theorem upperBounds_diff_finite {S E : Set ℝ} (hS : IsOpen S)
    (hE : E.Finite) : upperBounds (S \ E) = upperBounds S := by
  ext b
  constructor
  · intro hb x hx
    by_contra hxb
    have hbx : b < x := lt_of_not_ge hxb
    have hopen : IsOpen (S ∩ Ioi b) := hS.inter isOpen_Ioi
    have hinf : (S ∩ Ioi b).Infinite :=
      open_nonempty_infinite hopen ⟨x, hx, hbx⟩
    obtain ⟨y, hy, hyE⟩ := hinf.exists_not_mem_finite hE
    exact (not_le_of_gt hy.2) (hb ⟨hy.1, hyE⟩)
  · intro hb x hx
    exact hb hx.1

/-- Exact equivalence of least-upper-bound assertions before and after
omitting the finite exceptional projection fibers. No boundedness or
nonemptiness hypothesis is hidden in this equivalence. -/
theorem isLUB_diff_finite_iff {S E : Set ℝ} (hS : IsOpen S)
    (hE : E.Finite) (a : ℝ) : IsLUB (S \ E) a ↔ IsLUB S a := by
  unfold IsLUB
  rw [upperBounds_diff_finite hS hE]

/-- Omitting finite fibers also preserves whether a strict gain set is empty. -/
theorem diff_finite_nonempty_iff {S E : Set ℝ} (hS : IsOpen S)
    (hE : E.Finite) : (S \ E).Nonempty ↔ S.Nonempty := by
  constructor
  · rintro ⟨x, hx, _⟩
    exact ⟨x, hx⟩
  · intro hne
    obtain ⟨x, hx, hxE⟩ := (open_nonempty_infinite hS hne).exists_not_mem_finite hE
    exact ⟨x, hx, hxE⟩

/-- The finite-exception omission theorem applied directly to the strict
continuous gain projection used by the general rational optimization. -/
theorem feasibleGains_isLUB_iff {ι : Type*} [Finite ι]
    (Γ : Set ℝ) (f : ℝ → ℝ → ι → ℝ)
    (hf : ∀ γ ∈ Γ, ∀ i, Continuous (fun k => f γ k i))
    {E : Set ℝ} (hE : E.Finite) (a : ℝ) :
    IsLUB (feasibleGains Γ f \ E) a ↔ IsLUB (feasibleGains Γ f) a :=
  isLUB_diff_finite_iff (feasibleGains_isOpen Γ f hf) hE a

/-- Polynomial dependence on gain is sufficient; no continuity assumption
in the discretization parameter is necessary for this projection argument. -/
theorem polynomial_feasibleGains_isOpen {ι : Type*} [Finite ι]
    (Γ : Set ℝ) (p : ℝ → ι → Polynomial ℝ) :
    IsOpen (feasibleGains Γ (fun γ k i => (p γ i).eval k)) :=
  feasibleGains_isOpen Γ _ (fun γ _ i => (p γ i).continuous)

/-- The finite-fiber omission lemma specialized to the polynomial inequalities
obtained from the Schur recursion. This proves the topological component only;
the projection polynomials and lifting algorithm are not defined here. -/
theorem polynomial_feasibleGains_isLUB_iff {ι : Type*} [Finite ι]
    (Γ : Set ℝ) (p : ℝ → ι → Polynomial ℝ)
    {E : Set ℝ} (hE : E.Finite) (a : ℝ) :
    IsLUB (feasibleGains Γ (fun γ k i => (p γ i).eval k) \ E) a ↔
      IsLUB (feasibleGains Γ (fun γ k i => (p γ i).eval k)) a :=
  isLUB_diff_finite_iff (polynomial_feasibleGains_isOpen Γ p) hE a

end C2.GainProjection
