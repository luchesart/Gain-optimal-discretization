import C2.NGammaDual
import C2.NGammaAllocationRegularity

/-! Differentiability of the dual at clipping transitions.  This proves a
derivative of the actual dual maximum without requiring a derivative of the
clipped coordinate, or of a frequency-dependent multiplier. -/

noncomputable section
open scoped BigOperators Topology
open Filter Set
namespace C2.NGamma.Global

theorem hasDerivAt_clipped_curve {L : ℝ → ℝ → ℝ} {u D : ℝ → ℝ} {w : ℝ}
    (hu : ContinuousAt u w)
    (hzero : HasDerivAt (fun v => L v 0) (D 0) w)
    (hone : HasDerivAt (fun v => L v 1) (D 1) w)
    (hfree : 0 ≤ u w → u w ≤ 1 → HasDerivAt (fun v => L v (u v)) (D (u w)) w) :
    HasDerivAt (fun v => L v (min 1 (max 0 (u v)))) (D (min 1 (max 0 (u w)))) w := by
  rcases lt_trichotomy (u w) 0 with hneg | hzero' | hpos
  · have he : ∀ᶠ v in 𝓝 w, u v < 0 := hu (Iio_mem_nhds hneg)
    simp only [max_eq_left hneg.le, min_eq_right (by norm_num : (0:ℝ) ≤ 1)]
    apply hzero.congr_of_eventuallyEq
    filter_upwards [he] with v hv
    simp [max_eq_left hv.le]
  · have he : ∀ᶠ v in 𝓝 w, u v < 1 := hu (Iio_mem_nhds (by linarith))
    have hf := hfree (by linarith) (by linarith)
    rw [hzero'] at hf
    simp only [hzero',max_self,min_eq_right (by norm_num : (0:ℝ) ≤ 1)]
    apply hasDerivAt_of_eventually_eq_or hzero hf
    · simp [hzero']
    · simp [hzero']
    · filter_upwards [he] with v hv
      by_cases hz : u v ≤ 0
      · exact Or.inl (by simp [max_eq_left hz])
      · exact Or.inr (by simp [max_eq_right (le_of_not_ge hz),min_eq_right hv.le])
  · rcases lt_trichotomy (u w) 1 with hlt | heq | hgt
    · have he0 : ∀ᶠ v in 𝓝 w, 0 < u v := hu (Ioi_mem_nhds hpos)
      have he1 : ∀ᶠ v in 𝓝 w, u v < 1 := hu (Iio_mem_nhds hlt)
      simp only [max_eq_right hpos.le,min_eq_right hlt.le]
      apply (hfree hpos.le hlt.le).congr_of_eventuallyEq
      filter_upwards [he0,he1] with v hv0 hv1
      simp only [max_eq_right hv0.le,min_eq_right hv1.le]
    · have he : ∀ᶠ v in 𝓝 w, 0 < u v := hu (Ioi_mem_nhds hpos)
      have hf := hfree hpos.le heq.le
      rw [heq] at hf
      simp only [heq,max_eq_right (by norm_num : (0:ℝ) ≤ 1),min_self]
      apply hasDerivAt_of_eventually_eq_or hone hf
      · simp [heq]
      · simp [heq]
      · filter_upwards [he] with v hv
        by_cases ho : 1 ≤ u v
        · exact Or.inl (by simp [max_eq_right hv.le,min_eq_left ho])
        · exact Or.inr (by simp [max_eq_right hv.le,min_eq_right (le_of_not_ge ho)])
    · have he : ∀ᶠ v in 𝓝 w, 1 < u v := hu (Ioi_mem_nhds hgt)
      simp only [max_eq_right hpos.le,min_eq_left hgt.le]
      apply hone.congr_of_eventuallyEq
      filter_upwards [he] with v hv
      simp [max_eq_right (by linarith : 0 ≤ u v),min_eq_left hv.le]

theorem frequencyFree_frequency_differentiable (r lam w : ℝ) :
    DifferentiableAt ℝ (fun v => frequencyFree r v lam) w := by
  unfold frequencyFree
  have h : DifferentiableAt ℝ (fun v : ℝ => 1+(1+lam^2)*r^2*v^2) w := by fun_prop
  exact (by fun_prop : DifferentiableAt ℝ (fun v : ℝ => lam*v) w).add
    (((h.sqrt (by positivity)).sub_const 1).div_const r)

theorem clipped_lagrangian_hasDerivAt {r w lam : ℝ} (hr : 0 < r) (hw : 0 < w) :
    HasDerivAt (fun v => allocationLagrangian r v lam (frequencyAllocation r v lam))
      (phaseDerivative r (frequencyAllocation r w lam) w *
        (1+lam*allocationMarginal r (frequencyAllocation r w lam) w)) w := by
  unfold frequencyAllocation
  apply hasDerivAt_clipped_curve (D := fun x => phaseDerivative r x w *
    (1+lam*allocationMarginal r x w))
  · exact (frequencyFree_frequency_differentiable r lam w).continuousAt
  · exact allocationLagrangian_frequency_hasDerivAt hr hw (by norm_num)
  · exact allocationLagrangian_frequency_hasDerivAt hr hw (by positivity)
  · intro h0 h1
    have hd := allocationLagrangian_curve_hasDerivAt hr hw
      (l := lam) (frequencyFree_frequency_differentiable r lam w).hasDerivAt
      (ne_of_gt (frequencyFree_den_pos hr hw))
    simpa only [frequencyFree_marginal hr hw,sub_self,zero_mul,add_zero] using hd

theorem dualValue_hasDerivAt {n : ℕ} (r : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {w lam : ℝ} (hw : 0 < w) :
    HasDerivAt (fun v => dualValue r v lam)
      (envelope r (fun j => frequencyAllocation (r j) w lam) w lam) w := by
  have hd := ((Real.hasDerivAt_arctan w).const_mul (2*lam)).add
    (HasDerivAt.sum (u := Finset.univ) (fun j _ => clipped_lagrangian_hasDerivAt (lam := lam) (hr j) hw))
  unfold dualValue envelope
  convert hd using 1
  have hneg : ∀ j, phaseDerivative (r j) (frequencyAllocation (r j) w lam) w =
      -negPhaseDerivative (r j) (frequencyAllocation (r j) w lam) w := by
    intro j
    unfold phaseDerivative negPhaseDerivative
    ring
  simp_rw [hneg,neg_mul,Finset.sum_neg_distrib]
  simp only [marginal,allocationMarginal]
  ring

/-- Analytic upper-support step for an exactly represented optimum value.
Continuity is discharged separately by the compact dual-minimum theorem. -/
theorem frequency_value_strictAntiOn_of_continuous {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) {F : ℝ → ℝ} {a b : ℝ}
    (hpos : ∀ w ∈ Icc a b, 0 < w)
    (hstrict : ∀ w ∈ Icc a b, (∑ j, allocationPhase (r j) 1 w) < 2*Real.arctan w)
    (hF : ∀ w ∈ Icc a b, ∃ lam,
      frequencyAllocatedPhase r w lam = 2*Real.arctan w ∧
      F w = ∑ j, allocationLogGain (r j) (frequencyAllocation (r j) w lam) w)
    (hcont : ContinuousOn F (Icc a b)) : StrictAntiOn F (Icc a b) := by
  apply strictAntiOn_of_upper_support hcont
  intro w hw
  obtain ⟨lam,hlam,hgain⟩ := hF w hw
  refine ⟨fun v => dualValue r v lam,
    envelope r (fun j => frequencyAllocation (r j) w lam) w lam,
    dualValue_hasDerivAt r hr (hpos w hw),
    clipped_envelope_neg hn r hr (hpos w hw) hlam (hstrict w hw),?_,?_⟩
  · exact (dualValue_eq_gain r hlam).trans hgain.symm
  · intro v hv
    obtain ⟨mu,hmu,hgainv⟩ := hF v hv
    rw [hgainv]
    exact gain_le_dualValue r _ hr (fun j => frequencyAllocation_mem _ _ _)
      (hpos v hv) hmu

end C2.NGamma.Global
