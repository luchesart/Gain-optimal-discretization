import C2.NGammaDual
import C2.NGammaAllocationRegularity
import Mathlib.Topology.Order.Compact

/-! Continuity of the actual constrained optimal value.  The proof minimizes
the continuous dual over an explicit compact interval of multipliers.
It does not assume a continuous or uniquely determined multiplier. -/
noncomputable section
open scoped BigOperators Topology
open Set Filter
namespace C2.NGamma.Global

variable {n : ℕ}

def multiplierLower (r : Fin n → ℝ) (w : ℝ) : ℝ :=
  -(∑ j, |allocationMarginal (r j) 0 w|)-1

def multiplierUpper (r : Fin n → ℝ) (w : ℝ) : ℝ :=
  (∑ j, |allocationMarginal (r j) 1 w|)+1

lemma multiplier_lower_bound (r : Fin n → ℝ) (w : ℝ) (i : Fin n) :
    multiplierLower r w ≤ allocationMarginal (r i) 0 w := by
  have hs := Finset.single_le_sum
    (fun j (_ : j ∈ Finset.univ) => abs_nonneg (allocationMarginal (r j) 0 w))
    (Finset.mem_univ i)
  have ha := neg_abs_le (allocationMarginal (r i) 0 w)
  unfold multiplierLower
  linarith

lemma multiplier_upper_bound (r : Fin n → ℝ) (w : ℝ) (i : Fin n) :
    allocationMarginal (r i) 1 w ≤ multiplierUpper r w := by
  have hs := Finset.single_le_sum
    (fun j (_ : j ∈ Finset.univ) => abs_nonneg (allocationMarginal (r j) 1 w))
    (Finset.mem_univ i)
  have ha := le_abs_self (allocationMarginal (r i) 1 w)
  unfold multiplierUpper
  linarith

lemma multiplier_bounds_lt (r : Fin n → ℝ) (w : ℝ) :
    multiplierLower r w < multiplierUpper r w := by
  have h0 : 0 ≤ ∑ i, |allocationMarginal (r i) 0 w| :=
    Finset.sum_nonneg (fun _ _ => abs_nonneg _)
  have h1 : 0 ≤ ∑ i, |allocationMarginal (r i) 1 w| :=
    Finset.sum_nonneg (fun _ _ => abs_nonneg _)
  unfold multiplierLower multiplierUpper
  linarith

lemma exists_bounded_frequency_multiplier (r : Fin n → ℝ) (hr : ∀ i, 0 < r i)
    {w a : ℝ} (hw : 0 < w)
    (hlo : (∑ i, allocationPhase (r i) 1 w) ≤ a)
    (hhi : a ≤ ∑ i, allocationPhase (r i) 0 w) :
    ∃ l ∈ Icc (multiplierLower r w) (multiplierUpper r w),
      frequencyAllocatedPhase r w l = a := by
  have hL : frequencyAllocatedPhase r w (multiplierLower r w) =
      ∑ i, allocationPhase (r i) 0 w := by
    apply Finset.sum_congr rfl
    intro i _
    rw [frequencyAllocation_zero_of (hr i) hw (multiplier_lower_bound r w i)]
  have hU : frequencyAllocatedPhase r w (multiplierUpper r w) =
      ∑ i, allocationPhase (r i) 1 w := by
    apply Finset.sum_congr rfl
    intro i _
    rw [frequencyAllocation_one_of (hr i) hw (multiplier_upper_bound r w i)]
  exact intermediate_value_Icc' (multiplier_bounds_lt r w).le
    (frequencyAllocatedPhase_continuous r w).continuousOn
    ⟨by simpa [hU] using hlo, by simpa [hL] using hhi⟩

abbrev PositiveFrequency := {w : ℝ // 0 < w}

lemma allocationMarginal_positiveFrequency_continuous {r x : ℝ}
    (hr : 0 < r) (hx : 0 ≤ x) :
    Continuous (fun w : PositiveFrequency => allocationMarginal r x w) := by
  unfold allocationMarginal
  apply Continuous.div
  · fun_prop
  · fun_prop
  · intro w
    have hw : 0 < (w : ℝ) := w.property
    positivity

lemma multiplierLower_continuous (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    Continuous (fun w : PositiveFrequency => multiplierLower r w) := by
  unfold multiplierLower
  apply Continuous.sub _ continuous_const
  apply Continuous.neg
  exact continuous_finset_sum _ fun j _ =>
    (allocationMarginal_positiveFrequency_continuous (hr j) (by norm_num : (0:ℝ) ≤ 0)).abs

lemma multiplierUpper_continuous (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    Continuous (fun w : PositiveFrequency => multiplierUpper r w) := by
  unfold multiplierUpper
  apply Continuous.add _ continuous_const
  exact continuous_finset_sum _ fun j _ =>
    (allocationMarginal_positiveFrequency_continuous (hr j) (by norm_num : (0:ℝ) ≤ 1)).abs

/-- A fixed compact parameter t traverses a sufficient multiplier interval. -/
def normalizedMultiplier (r : Fin n → ℝ) (w t : ℝ) : ℝ :=
  multiplierLower r w + (multiplierUpper r w - multiplierLower r w) * t

lemma normalizedMultiplier_surjective (r : Fin n → ℝ) (w : ℝ) {l : ℝ}
    (hl : l ∈ Icc (multiplierLower r w) (multiplierUpper r w)) :
    ∃ t ∈ Icc (0:ℝ) 1, normalizedMultiplier r w t = l := by
  let L := multiplierLower r w
  let U := multiplierUpper r w
  have hUL : 0 < U-L := sub_pos.mpr (multiplier_bounds_lt r w)
  refine ⟨(l-L)/(U-L), ⟨div_nonneg (sub_nonneg.mpr hl.1) hUL.le, ?_⟩, ?_⟩
  · exact (div_le_one hUL).2 (by dsimp [L,U]; linarith [hl.2])
  · change L+(U-L)*((l-L)/(U-L))=l
    field_simp
    <;> ring

lemma dualValue_joint_continuousAt (r : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {p : ℝ × ℝ} (hw : 0 < p.1) :
    ContinuousAt (fun p : ℝ × ℝ => dualValue r p.1 p.2) p := by
  unfold dualValue
  apply ContinuousAt.add
  · exact (continuousAt_const.mul continuousAt_snd).mul
      (Real.continuous_arctan.continuousAt.comp continuousAt_fst)
  · exact tendsto_finset_sum _ fun j _ =>
      frequencyAllocation_lagrangian_joint_continuousAt (hr j) hw

lemma normalizedDual_continuous (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    Continuous (fun p : PositiveFrequency × ℝ =>
      dualValue r p.1 (normalizedMultiplier r p.1 p.2)) := by
  have hL := (multiplierLower_continuous r hr).comp
    (continuous_fst : Continuous (fun p : PositiveFrequency × ℝ => p.1))
  have hU := (multiplierUpper_continuous r hr).comp
    (continuous_fst : Continuous (fun p : PositiveFrequency × ℝ => p.1))
  have hN : Continuous (fun p : PositiveFrequency × ℝ =>
      normalizedMultiplier r p.1 p.2) := hL.add ((hU.sub hL).mul continuous_snd)
  rw [continuous_iff_continuousAt]
  intro p
  exact (dualValue_joint_continuousAt r hr p.1.property).comp
    ((continuous_subtype_val.comp continuous_fst).continuousAt.prodMk hN.continuousAt)

/-- Compact dual definition, globally continuous on positive frequencies. -/
def compactDualValue (r : Fin n → ℝ) (w : PositiveFrequency) : ℝ :=
  sInf ((fun t : ℝ => dualValue r w (normalizedMultiplier r w t)) '' Icc 0 1)

lemma compactDualValue_continuous (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    Continuous (compactDualValue r) := by
  exact isCompact_Icc.continuous_sInf (normalizedDual_continuous r hr)

/-- At every feasible frequency, the compact dual minimum equals the actual
optimal log gain of every phase-balancing clipped allocation. -/
lemma compactDualValue_eq_gain (r : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    (w : PositiveFrequency) {l : ℝ}
    (hphase : frequencyAllocatedPhase r w l = 2*Real.arctan w) :
    compactDualValue r w =
      ∑ j, allocationLogGain (r j) (frequencyAllocation (r j) w l) w := by
  let v := ∑ j, allocationLogGain (r j) (frequencyAllocation (r j) w l) w
  have hlower : ∀ q : ℝ, v ≤ dualValue r w q := by
    intro q
    exact gain_le_dualValue r _ hr (fun j => frequencyAllocation_mem _ _ _)
      w.property hphase
  have hb := allocation_phase_bounds r hr w.property
    (fun j => frequencyAllocation (r j) w l) (fun j => frequencyAllocation_mem _ _ _)
  change (∑ i, allocationPhase (r i) 1 w) ≤ frequencyAllocatedPhase r w l ∧
    frequencyAllocatedPhase r w l ≤ ∑ i, allocationPhase (r i) 0 w at hb
  rw [hphase] at hb
  obtain ⟨q,hq,hpq⟩ := exists_bounded_frequency_multiplier r hr w.property hb.1 hb.2
  have heq : dualValue r w q = v := by
    rw [dualValue_eq_gain r hpq]
    apply le_antisymm
    · exact frequencyAllocation_log_optimal r hr w.property _
        (fun j => frequencyAllocation_mem _ _ _) (hpq.trans hphase.symm)
    · exact frequencyAllocation_log_optimal r hr w.property _
        (fun j => frequencyAllocation_mem _ _ _) (hphase.trans hpq.symm)
  obtain ⟨t,ht,heqt⟩ := normalizedMultiplier_surjective r w hq
  have hmem : v ∈ (fun t : ℝ => dualValue r w (normalizedMultiplier r w t)) '' Icc 0 1 :=
    ⟨t,ht,by dsimp only; rw [heqt,heq]⟩
  have hlow : ∀ y ∈ (fun t : ℝ => dualValue r w (normalizedMultiplier r w t)) '' Icc 0 1,
      v ≤ y := by
    rintro y ⟨t,ht,rfl⟩
    exact hlower _
  exact le_antisymm (csInf_le ⟨v,hlow⟩ hmem) (le_csInf ⟨v,hmem⟩ hlow)

/-- Any function characterized by attained, phase-balanced optimal allocations
is continuous on every positive-frequency set.  No regularity of its chosen
multipliers is assumed. -/
theorem frequencyValue_continuousOn (r : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    (F : ℝ → ℝ) (s : Set ℝ) (hs : ∀ w ∈ s, 0 < w)
    (hF : ∀ w ∈ s, ∃ l : ℝ,
      frequencyAllocatedPhase r w l = 2*Real.arctan w ∧
      F w = ∑ j, allocationLogGain (r j) (frequencyAllocation (r j) w l) w) :
    ContinuousOn F s := by
  rw [continuousOn_iff_continuous_restrict]
  let g : s → PositiveFrequency := fun w => ⟨w,hs w w.property⟩
  have hg : Continuous g := continuous_subtype_val.subtype_mk _
  have heq : (fun w : s => F w) = fun w : s => compactDualValue r (g w) := by
    funext w
    obtain ⟨l,hl,hval⟩ := hF w w.property
    rw [hval]
    exact (compactDualValue_eq_gain r hr (g w) hl).symm
  change Continuous (fun w : s => F w)
  rw [heq]
  exact (compactDualValue_continuous r hr).comp hg

end C2.NGamma.Global
