import C2.CADDelineability

/-! Finite Boolean combinations of strict factor signs inherit gain-cell
invariance from concrete simple/disjoint polynomial-root regularity. -/

noncomputable section
open Set Filter
open scoped Topology BigOperators
namespace C2.CADDelineability

/-- Independent nonzero constant rescalings preserve concrete root regularity. -/
theorem Regular.scale {ι : Type*} {F : ι → ℝ × ℝ → ℝ} {k : ℝ}
    (hreg : Regular F k) (s : ι → ℝ) (hs : ∀ i, s i ≠ 0) :
    Regular (fun i p => s i * F i p) k := by
  refine ⟨fun i => mul_ne_zero (hs i) (hreg.1 i),
    fun i => mul_ne_zero (hs i) (hreg.2.1 i), ?_, ?_⟩
  · intro x hx i j hij hi hj
    have hi0 : F i (k, x) = 0 := (mul_eq_zero.mp hi).resolve_left (hs i)
    have hj0 : F j (k, x) = 0 := (mul_eq_zero.mp hj).resolve_left (hs j)
    exact hreg.2.2.1 x hx i j hij hi0 hj0
  · intro x hx i hi
    have hi0 : F i (k, x) = 0 := (mul_eq_zero.mp hi).resolve_left (hs i)
    obtain ⟨d, hd, hf⟩ := hreg.2.2.2 x hx i hi0
    exact ⟨s i * d, mul_ne_zero (hs i) hd, hf.const_mul (s i)⟩

def signMultiplier (b : Bool) : ℝ := if b then 1 else -1

theorem signMultiplier_ne_zero (b : Bool) : signMultiplier b ≠ 0 := by
  cases b <;> norm_num [signMultiplier]

theorem signMultiplier_sq (b : Bool) : signMultiplier b * signMultiplier b = 1 := by
  cases b <;> norm_num [signMultiplier]

/-- All strict sign patterns are invariant on a connected regular gain cell. -/
theorem signed_pattern_constant {ι : Type*} [Finite ι]
    (F : ι → ℝ × ℝ → ℝ) (hcont : ∀ i, Continuous (F i))
    (I : Set ℝ) (hI : IsPreconnected I) (hreg : ∀ k ∈ I, Regular F k)
    (σ : ι → Bool) {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) :
    a ∈ patternGains (fun i p => signMultiplier (σ i) * F i p) ↔
    b ∈ patternGains (fun i p => signMultiplier (σ i) * F i p) :=
  pattern_constant_on_preconnected _
    (fun i => continuous_const.mul (hcont i)) I hI
    (fun k hk => (hreg k hk).scale _ (fun i => signMultiplier_ne_zero (σ i))) ha hb

/-- A Boolean acceptance condition on a finite factor-sign pattern. -/
def acceptedPatternGains {ι : Type*} (F : ι → ℝ × ℝ → ℝ)
    (Accept : (ι → Bool) → Prop) : Set ℝ :=
  {k | ∃ σ : ι → Bool, Accept σ ∧
    k ∈ patternGains (fun i p => signMultiplier (σ i) * F i p)}

/-- Exact cell marking for any fixed Boolean combination of strict factor
signs, including the positivity constraints obtained from finite products. -/
theorem accepted_pattern_constant {ι : Type*} [Finite ι]
    (F : ι → ℝ × ℝ → ℝ) (hcont : ∀ i, Continuous (F i))
    (Accept : (ι → Bool) → Prop)
    (I : Set ℝ) (hI : IsPreconnected I) (hreg : ∀ k ∈ I, Regular F k)
    {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) :
    a ∈ acceptedPatternGains F Accept ↔ b ∈ acceptedPatternGains F Accept := by
  constructor
  · rintro ⟨σ, hσ, haσ⟩
    exact ⟨σ, hσ, (signed_pattern_constant F hcont I hI hreg σ ha hb).mp haσ⟩
  · rintro ⟨σ, hσ, hbσ⟩
    exact ⟨σ, hσ, (signed_pattern_constant F hcont I hI hreg σ ha hb).mpr hbσ⟩

/-- Product signs are exactly determined by the factor signs and multiplicities. -/
theorem product_sign_iff {ι : Type*} [Fintype ι]
    (v : ι → ℝ) (e : ι → ℕ) (c : ℝ) (σ : ι → Bool)
    (hσ : ∀ i, 0 < signMultiplier (σ i) * v i) :
    (0 < c * ∏ i, (v i) ^ e i) ↔
    (0 < c * ∏ i, signMultiplier (σ i) ^ e i) := by
  have hv : ∀ i, v i = signMultiplier (σ i) * (signMultiplier (σ i) * v i) := by
    intro i
    rw [← mul_assoc, signMultiplier_sq, one_mul]
  have heq : (∏ i, (v i) ^ e i) =
      (∏ i, signMultiplier (σ i) ^ e i) *
      (∏ i, (signMultiplier (σ i) * v i) ^ e i) := by
    rw [← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro i _
    rw [← mul_pow, ← hv i]
  rw [heq, ← mul_assoc]
  exact mul_pos_iff_of_pos_right (Finset.prod_pos (fun i _ => pow_pos (hσ i) _))

/-- Every nonzero tuple has its actual strict sign vector. -/
theorem exists_sign_pattern {ι : Type*} (v : ι → ℝ) (hv : ∀ i, v i ≠ 0) :
    ∃ σ : ι → Bool, ∀ i, 0 < signMultiplier (σ i) * v i := by
  classical
  refine ⟨fun i => decide (0 < v i), fun i => ?_⟩
  by_cases hi : 0 < v i
  · simpa [signMultiplier, hi] using hi
  · have hn : v i < 0 := lt_of_le_of_ne (le_of_not_gt hi) (hv i)
    simpa [signMultiplier, hi] using neg_pos.mpr hn

/-- A factor that occurs in a strictly positive product cannot vanish. -/
theorem factors_ne_zero_of_positive_products {ι τ : Type*} [Fintype ι]
    (v : ι → ℝ) (c : τ → ℝ) (e : τ → ι → ℕ)
    (hused : ∀ i, ∃ j, e j i ≠ 0)
    (hpos : ∀ j, 0 < c j * ∏ i, (v i) ^ e j i) :
    ∀ i, v i ≠ 0 := by
  intro i hi
  obtain ⟨j, hj⟩ := hused i
  have hz : ∏ i, (v i) ^ e j i = 0 :=
    Finset.prod_eq_zero (Finset.mem_univ i) (by simp [hi, hj])
  simpa [hz] using hpos j

/-- Exact reduction of simultaneous strict product inequalities to a finite
accepted factor-sign pattern. No sign-equivalence premise is assumed. -/
theorem positive_products_iff_pattern {ι τ : Type*} [Fintype ι]
    (v : ι → ℝ) (c : τ → ℝ) (e : τ → ι → ℕ)
    (hused : ∀ i, ∃ j, e j i ≠ 0) :
    (∀ j, 0 < c j * ∏ i, (v i) ^ e j i) ↔
    ∃ σ : ι → Bool,
      (∀ j, 0 < c j * ∏ i, signMultiplier (σ i) ^ e j i) ∧
      (∀ i, 0 < signMultiplier (σ i) * v i) := by
  constructor
  · intro h
    obtain ⟨σ, hσ⟩ := exists_sign_pattern v
      (factors_ne_zero_of_positive_products v c e hused h)
    exact ⟨σ, fun j => (product_sign_iff v (e j) (c j) σ hσ).mp (h j), hσ⟩
  · rintro ⟨σ, ha, hσ⟩ j
    exact (product_sign_iff v (e j) (c j) σ hσ).mpr (ha j)

/-- Exact finite-factor reduction at the level of gain projections. -/
theorem productGains_eq_accepted {ι τ : Type*} [Fintype ι]
    (F : ι → ℝ × ℝ → ℝ) (c : τ → ℝ) (e : τ → ι → ℕ)
    (hused : ∀ i, ∃ j, e j i ≠ 0) :
    patternGains (fun j p => c j * ∏ i, (F i p) ^ e j i) =
    acceptedPatternGains F (fun σ => ∀ j,
      0 < c j * ∏ i, signMultiplier (σ i) ^ e j i) := by
  ext k
  constructor
  · rintro ⟨x, hx, hpos⟩
    obtain ⟨σ, ha, hσ⟩ := (positive_products_iff_pattern (fun i => F i (k, x)) c e hused).mp hpos
    exact ⟨σ, ha, x, hx, hσ⟩
  · rintro ⟨σ, ha, x, hx, hσ⟩
    exact ⟨x, hx, (positive_products_iff_pattern (fun i => F i (k, x)) c e hused).mpr ⟨σ, ha, hσ⟩⟩

/-- The actual simultaneous positivity region of a finite product system has
constant gain-cell feasibility under algebraic regularity of its factor basis. -/
theorem products_constant_on_preconnected {ι τ : Type*} [Fintype ι]
    (F : ι → ℝ × ℝ → ℝ) (hcont : ∀ i, Continuous (F i))
    (c : τ → ℝ) (e : τ → ι → ℕ) (hused : ∀ i, ∃ j, e j i ≠ 0)
    (I : Set ℝ) (hI : IsPreconnected I) (hreg : ∀ k ∈ I, Regular F k)
    {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) :
    a ∈ patternGains (fun j p => c j * ∏ i, (F i p) ^ e j i) ↔
    b ∈ patternGains (fun j p => c j * ∏ i, (F i p) ^ e j i) := by
  rw [productGains_eq_accepted F c e hused]
  exact accepted_pattern_constant F hcont _ I hI hreg ha hb

end C2.CADDelineability
