import C2.NGammaRootClosedness

/-! The actual initial gain margin from the full-cube corollary. -/
noncomputable section
open scoped BigOperators
open Polynomial
namespace C2.NGamma.PolynomialModel
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

def initialStableGains (r x : ι → ℝ) (d : ℕ) : Set ℝ :=
  {c | 0<c ∧ ∀ b : ℝ, 0<b → b<c → SchurStable (characteristic r x d b)}

/-- Real's supremum of the empty set is zero, matching the manuscript's
explicit convention when no positive initial interval is stable. -/
def initialGainMargin (r x : ι → ℝ) (d : ℕ) : ℝ := sSup (initialStableGains r x d)

theorem initialStableGains_eq_of_exact_interval {r x : ι → ℝ} {d : ℕ}
    {B : ℝ} (hB : 0<B)
    (hstable : ∀ b : ℝ, 0≤b → (SchurStable (characteristic r x d b) ↔ b<B)) :
    initialStableGains r x d=Set.Ioc 0 B := by
  ext c
  constructor
  · rintro ⟨hc,hcstable⟩
    refine ⟨hc,?_⟩
    by_contra hnc
    have hbc : B<c := lt_of_not_ge hnc
    have hbad := hcstable B hB hbc
    exact (lt_irrefl B) ((hstable B (le_of_lt hB)).mp hbad)
  · rintro ⟨hc,hcB⟩
    refine ⟨hc,?_⟩
    intro b hb hbc
    exact (hstable b (le_of_lt hb)).mpr (lt_of_lt_of_le hbc hcB)

theorem initialGainMargin_eq_of_exact_interval {r x : ι → ℝ} {d : ℕ}
    {B : ℝ} (hB : 0<B)
    (hstable : ∀ b : ℝ, 0≤b → (SchurStable (characteristic r x d b) ↔ b<B)) :
    initialGainMargin r x d=B := by
  unfold initialGainMargin
  rw [initialStableGains_eq_of_exact_interval hB hstable]
  exact csSup_Ioc hB

theorem initialGainMargin_le_of_not_schur {r x : ι → ℝ} {d : ℕ}
    {b : ℝ} (hb : 0<b) (hnot : ¬SchurStable (characteristic r x d b)) :
    initialGainMargin r x d ≤ b := by
  classical
  unfold initialGainMargin
  by_cases hn : (initialStableGains r x d).Nonempty
  · apply csSup_le hn
    intro c hc
    by_contra hcb
    exact hnot (hc.2 b hb (lt_of_not_ge hcb))
  · rw [Set.not_nonempty_iff_eq_empty.mp hn,Real.sSup_empty]
    exact le_of_lt hb

theorem initialGainMargin_le_of_unit_root {r x : ι → ℝ} {d : ℕ}
    {b : ℝ} (hb : 0<b) {z : ℂ}
    (hz : (characteristic r x d b).eval z=0) (hunit : 1≤‖z‖) :
    initialGainMargin r x d ≤ b := by
  apply initialGainMargin_le_of_not_schur hb
  intro hs
  exact (not_lt_of_ge hunit) (hs z hz)

theorem initialStableGains_empty_of_small_gain_not_schur {r x : ι → ℝ} {d : ℕ}
    (hsmall : ∃ ε : ℝ, 0<ε ∧ ∀ b : ℝ, |b|<ε → ¬SchurStable (characteristic r x d b)) :
    initialStableGains r x d=∅ := by
  obtain ⟨ε,hε,hnot⟩ := hsmall
  apply Set.eq_empty_iff_forall_not_mem.2
  intro c hc
  have hm : 0 < min ε c := lt_min hε hc.1
  have hb : 0 < min ε c/2 := by positivity
  have hbmin : min ε c/2 < min ε c := by linarith
  have hbε : min ε c/2<ε := lt_of_lt_of_le hbmin (min_le_left _ _)
  have hbc : min ε c/2<c := lt_of_lt_of_le hbmin (min_le_right _ _)
  have h := hnot (min ε c/2) (by rwa [abs_of_pos hb])
  exact h (hc.2 _ hb hbc)

theorem initialGainMargin_bad_coordinate_eq_zero {r x : ι → ℝ} {d : ℕ}
    (hr : ∀ i, 0<r i) (hx : ∀ i, -1≤x i) (hd : 1≤d)
    (j : ι) (hbad : x j < -2/r j) :
    initialGainMargin r x d=0 := by
  unfold initialGainMargin
  rw [initialStableGains_empty_of_small_gain_not_schur
    (cube_bad_coordinate_small_gain_not_schur hr hx hd j hbad),Real.sSup_empty]

end C2.NGamma.PolynomialModel
