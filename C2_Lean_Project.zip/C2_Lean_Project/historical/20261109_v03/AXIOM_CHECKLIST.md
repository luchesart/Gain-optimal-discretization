# C2 axiom and coverage checklist — 2026-11-09

- [x] Lean 4.19.0 and the pinned mathlib revision were checked.
- [x] All 156 proof modules compile individually; the complete umbrella import passes.
- [x] The generated standalone file passes an independent Lean check.
- [x] All 1644 explicit public declarations resolve in the axiom audit.
- [x] Transitive axiom dependencies are limited to propext, Classical.choice and Quot.sound.
- [x] No sorryAx, custom axiom, admitted proof or unsafe source declaration is accepted.
- [x] Source inventory handles namespaces, private declarations and same-line attributes.
- [x] All 95 input proof modules remain byte-identical.
- [x] The map contains 44 COMPLETE and 1 PARTIAL numbered results.
- [x] Root counts and Schur predicates concern actual complex roots with multiplicity.
- [x] Initial margins are least upper bounds of actual stable intervals.
- [x] MIACE proofs include the zero-prehistory recurrence, parameter regimes and endpoints.
- [x] The two-parameter optimum includes the full square and uniqueness.
- [x] Integer-delay stability includes all real gains and excludes later stable components.
- [x] The realization theorem explicitly uses the degree-minimal convention.
- [ ] Generic CAD projection/lifting and terminating effective root isolation are formalized.

There are 1355 explicit public theorems and lemmas, not 1355 independent
manuscript claims. Private helper declarations and generated constants are
not counted as public results; their dependencies are checked transitively.
The official collector shares its visited set over all public roots. The
resulting union contains only the three allowed axioms, which is equivalent
to the same condition for every root. Exact per-root lists are not claimed.
The full manuscript is not completely formalized: thm:exact-gain-projection
remains PARTIAL. Its mathematical and algorithmic gaps are documented in
validation/cad_remaining_20261109.md without added axioms or assumed output.

See README.txt for reproduction commands and VERIFICATION.json for the
checks actually run. Older evidence is retained under historical/20261108.
No online live.lean website session or fresh numerical experiment is claimed.
