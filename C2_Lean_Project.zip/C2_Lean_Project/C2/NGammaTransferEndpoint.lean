import C2.NGammaAmplitude

noncomputable section
open scoped BigOperators Topology
open Filter
namespace C2.NGamma.Cayley

theorem exp_nat_pi (d : ℕ) :
    Complex.exp ((((d : ℝ)*Real.pi : ℝ) : ℂ)*Complex.I) = (-1:ℂ)^d := by
  have he : (((d : ℝ)*Real.pi : ℝ) : ℂ)*Complex.I = (d : ℂ)*((Real.pi : ℂ)*Complex.I) := by push_cast; ring
  rw [he, Complex.exp_nat_mul, Complex.exp_pi_mul_I]

theorem transfer_point_tendsto_atTop {n : ℕ} {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) (d : ℕ) :
    Tendsto (fun t => transfer r x d (point t)) atTop
      (𝓝 (((∏ i, (r i+2/x i) : ℝ) : ℂ)*(-1)^d)) := by
  have hp : Tendsto (Phase.totalPhase (fun i => x i+2/r i) x d) atTop
      (𝓝 ((d:ℝ)*Real.pi)) := by
    simpa [ne_of_gt (hx _)] using totalPhase_tendsto_atTop hr (fun i => (hx i).le) d
  have hpc := (Complex.continuous_ofReal.tendsto _).comp hp
  have hexp := Complex.continuous_exp.continuousAt.tendsto.comp (hpc.mul_const Complex.I)
  rw [exp_nat_pi] at hexp
  have ha := (Complex.continuous_ofReal.tendsto _).comp (amplitude_tendsto_atTop hr hx)
  simpa only [transfer_polar (fun i => ne_of_gt (hr i))] using ha.mul hexp

theorem reciprocal_transfer_tendsto_zero_of_zero {n : ℕ} {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) {j : Fin n} (hj : x j = 0)
    (d : ℕ) (b : ℝ) :
    Tendsto (fun t => (b : ℂ)/transfer r x d (point t)) atTop (𝓝 0) := by
  apply tendsto_zero_iff_norm_tendsto_zero.2
  have h := tendsto_inv_atTop_zero.comp (amplitude_tendsto_atTop_of_zero hr hx hj)
  have hm := h.const_mul |b|
  simpa [norm_div, transfer_norm hr, Complex.norm_real, Real.norm_eq_abs, div_eq_mul_inv] using hm

theorem transfer_correction_arg_tendsto_zero_of_zero {n : ℕ} {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) {j : Fin n} (hj : x j = 0)
    (d : ℕ) (b : ℝ) :
    Tendsto (fun t => Complex.arg (1+(b : ℂ)/transfer r x d (point t))) atTop (𝓝 0) := by
  have hc := (reciprocal_transfer_tendsto_zero_of_zero hr hx hj d b).const_add 1
  have ha := (Complex.continuousAt_arg (show (1:ℂ) ∈ Complex.slitPlane from Or.inl (by norm_num))).tendsto
  simpa using ha.comp (by simpa using hc)

theorem transfer_correction_arg_tendsto_zero {n : ℕ} {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) (d : ℕ) {b : ℝ}
    (hb : 0 ≤ b) (hbinf : b < ∏ i, (r i+2/x i)) :
    Tendsto (fun t => Complex.arg (1+(b : ℂ)/transfer r x d (point t))) atTop (𝓝 0) := by
  let B : ℝ := ∏ i, (r i+2/x i)
  have hB : 0 < B := Finset.prod_pos (fun i _ => add_pos (hr i) (div_pos (by norm_num) (hx i)))
  have hBn : (B:ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hB
  have hs : (-1:ℂ)^d ≠ 0 := pow_ne_zero _ (by norm_num)
  let z : ℂ := (b:ℂ)/((B:ℂ)*(-1)^d)
  have hzlim : Tendsto (fun t => (b:ℂ)/transfer r x d (point t)) atTop (𝓝 z) :=
    tendsto_const_nhds.div (transfer_point_tendsto_atTop hr hx d) (mul_ne_zero hBn hs)
  have hzreal : z.im = 0 := by
    have he : z = ((b / (B * (-1)^d) : ℝ) : ℂ) := by simp only [z, Complex.ofReal_div, Complex.ofReal_mul, Complex.ofReal_pow, Complex.ofReal_neg, Complex.ofReal_one]
    rw [he]
    exact Complex.ofReal_im _
  have hznorm : ‖z‖ < 1 := by
    simp only [z, norm_div, norm_mul, norm_pow, norm_neg, norm_one, one_pow, mul_one,
      Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hb, abs_of_pos hB]
    exact (div_lt_one hB).2 hbinf
  have hzpos : 0 < (1+z).re := by
    have hh := Complex.abs_re_le_norm z
    have hhh := neg_abs_le z.re
    simp only [Complex.add_re, Complex.one_re]
    linarith
  have harg : Complex.arg (1+z) = 0 := by
    apply Complex.arg_eq_zero_iff.2
    exact ⟨hzpos.le, by simp [hzreal]⟩
  have h := (Complex.continuousAt_arg (Or.inl hzpos)).tendsto.comp (hzlim.const_add 1)
  simpa only [harg] using h

end C2.NGamma.Cayley
