import C2.CADEffectiveBivariate
import C2.CADEffectiveSearch
import C2.CADProjectionBezout

/-! A terminating producer for exact bivariate Bezout data. The algorithm
searches explicitly encoded rational coefficient lists and checks arithmetic
identities. Generic coprimeness proves that its search succeeds; it is not a
supplied witness oracle. -/
namespace C2.CADEffective.Bivariate
open Polynomial

abbrev BezoutData := Dense.Poly × Poly × Poly

def bezoutCheck (p q : Poly) (w : BezoutData) : Bool :=
  !(Dense.eqb w.1 []) &&
    eqb (add (mul w.2.1 p) (mul w.2.2 q)) (constant w.1)

theorem bezoutCheck_iff (p q : Poly) (w : BezoutData) :
    bezoutCheck p q w = true ↔
      Dense.denote w.1 ≠ 0 ∧
        denote w.2.1 * denote p + denote w.2.2 * denote q = C (Dense.denote w.1) := by
  simp only [bezoutCheck, Bool.and_eq_true, Bool.not_eq_true,
    eqb_eq_true_iff, denote_add, denote_mul, denote_constant]
  constructor
  · rintro ⟨hr, hi⟩
    refine ⟨?_, hi⟩
    intro hz
    have ht : Dense.eqb w.1 [] = true := (Dense.eqb_eq_true_iff _ _).mpr (by simpa using hz)
    rw [ht] at hr
    cases hr
  · rintro ⟨hr, hi⟩
    refine ⟨?_, hi⟩
    cases he : Dense.eqb w.1 [] with
    | false => rfl
    | true =>
        have hz := (Dense.eqb_eq_true_iff _ _).mp he
        exact False.elim (hr (by simpa using hz))

theorem exists_bezoutCheck (p q : Poly)
    (h : IsCoprime ((denote p).map (algebraMap ℚ[X] (RatFunc ℚ)))
      ((denote q).map (algebraMap ℚ[X] (RatFunc ℚ)))) :
    ∃ w : BezoutData, bezoutCheck p q w = true := by
  obtain ⟨r, hr, u, v, hid⟩ := C2.CADProjection.exists_bezout_eliminant
    (F := RatFunc ℚ) (denote p) (denote q) h
  obtain ⟨r', hr'⟩ := Dense.exists_encoding r
  obtain ⟨u', hu'⟩ := exists_encoding u
  obtain ⟨v', hv'⟩ := exists_encoding v
  refine ⟨(r', u', v'), (bezoutCheck_iff _ _ _).mpr ?_⟩
  simpa only [hr', hu', hv'] using And.intro hr hid

/-- Executable exhaustive search. The number of trials is finite because the
previous theorem supplies an accepted dense encoding. -/
def produceBezout (p q : Poly)
    (h : IsCoprime ((denote p).map (algebraMap ℚ[X] (RatFunc ℚ)))
      ((denote q).map (algebraMap ℚ[X] (RatFunc ℚ)))) : BezoutData :=
  C2.CADEffective.search (bezoutCheck p q) (exists_bezoutCheck p q h)

theorem produceBezout_accepted (p q : Poly)
    (h : IsCoprime ((denote p).map (algebraMap ℚ[X] (RatFunc ℚ)))
      ((denote q).map (algebraMap ℚ[X] (RatFunc ℚ)))) :
    bezoutCheck p q (produceBezout p q h) = true :=
  C2.CADEffective.search_accepted _ _

theorem produceBezout_correct (p q : Poly)
    (h : IsCoprime ((denote p).map (algebraMap ℚ[X] (RatFunc ℚ)))
      ((denote q).map (algebraMap ℚ[X] (RatFunc ℚ)))) :
    Dense.denote (produceBezout p q h).1 ≠ 0 ∧
      denote (produceBezout p q h).2.1 * denote p +
        denote (produceBezout p q h).2.2 * denote q = C (Dense.denote (produceBezout p q h).1) :=
  (bezoutCheck_iff _ _ _).mp (produceBezout_accepted p q h)

theorem produceBezout_finite_execution (p q : Poly)
    (h : IsCoprime ((denote p).map (algebraMap ℚ[X] (RatFunc ℚ)))
      ((denote q).map (algebraMap ℚ[X] (RatFunc ℚ)))) :
    ∃ fuel w, C2.CADEffective.scanFrom (bezoutCheck p q) 0 fuel = some w ∧
      bezoutCheck p q w = true := by
  obtain ⟨w, hw, hc⟩ := C2.CADEffective.search_has_finite_execution
    (bezoutCheck p q) (exists_bezoutCheck p q h)
  exact ⟨_, w, hw, hc⟩

end C2.CADEffective.Bivariate
