import C2.NGammaCayley

/-! Complete first-phase classification for one sample of delay.  This is the
analytic and boundary-witness part of the exact gain-interval theorem;
interior/exterior root counting is a separate theorem. -/

noncomputable section
open Set Filter
open scoped Topology BigOperators

namespace C2.NGamma.Phase

def endpointSum {n : ℕ} (r x : Fin n → ℝ) : ℝ :=
  ∑ j, 1 / (x j * (2 + r j * x j))

lemma sumRatio_tendsto_atTop {n : ℕ} {a x : Fin n → ℝ}
    (hx : ∀ j, 0 < x j) (hax : ∀ j, x j < a j) :
    Tendsto (sumRatio a x) atTop (𝓝 (∑ j, (1/x j-1/a j))) := by
  exact tendsto_finset_sum _ (fun j _ => ratio_tendsto_atTop_of_pos (hx j) (hax j))

lemma single_phase_identity {n : ℕ} (a x : Fin n → ℝ) {t : ℝ} (ht : 0 < t) :
    totalPhase a x 1 t - Real.pi = Real.arctan (1/t) * (sumRatio a x t-2) := by
  have hD : Real.arctan (1/t) ≠ 0 := (arctan_pos (one_div_pos.mpr ht)).ne'
  have hi : Real.arctan (1/t) = Real.pi/2-Real.arctan t := by
    simpa only [one_div] using Real.arctan_inv_of_pos ht
  have hsum : sumRatio a x t = (∑ j, contribution (a j) (x j) t)/Real.arctan (1/t) := by
    simp only [sumRatio, ratio, Finset.sum_div]
  rw [hsum]
  unfold totalPhase
  field_simp
  rw [hi]
  norm_num
  ring

lemma single_crossing_exists_of_sumRatio_gt {n : ℕ} (a x : Fin n → ℝ)
    {t : ℝ} (ht : 0 < t) (hs : 2 < sumRatio a x t) :
    ∃ s : ℝ, 0 < s ∧ s < t ∧ totalPhase a x 1 s = Real.pi := by
  have hphase : Real.pi < totalPhase a x 1 t := by
    have hi := single_phase_identity a x ht
    have hp : 0 < Real.arctan (1/t)*(sumRatio a x t-2) :=
      mul_pos (arctan_pos (one_div_pos.mpr ht)) (sub_pos.mpr hs)
    linarith
  have hz : totalPhase a x 1 0 = 0 := by simp [totalPhase, contribution]
  obtain ⟨s, hsI, hsE⟩ := intermediate_value_Icc ht.le
    (totalPhase_continuous a x 1).continuousOn
    (show Real.pi ∈ Icc (totalPhase a x 1 0) (totalPhase a x 1 t) by
      rw [hz]; exact ⟨Real.pi_pos.le, hphase.le⟩)
  refine ⟨s, ?_, ?_, hsE⟩
  · by_contra! hh
    have : s = 0 := le_antisymm hh hsI.1
    subst s
    rw [hz] at hsE
    exact Real.pi_pos.ne hsE
  · by_contra! hh
    have : s = t := le_antisymm hsI.2 hh
    subst s
    linarith

lemma sumRatio_lt_limit {n : ℕ} (hn : 0 < n) {a x : Fin n → ℝ}
    (hx : ∀ j, 0 < x j) (hx1 : ∀ j, x j ≤ 1) (hax : ∀ j, x j < a j)
    {t : ℝ} (ht : 0 < t) : sumRatio a x t < ∑ j, (1/x j-1/a j) := by
  have hm := sumRatio_strictMonoOn hn (fun j => (hx j).le) hx1 hax
  have hmono : sumRatio a x (t+1) ≤ ∑ j, (1/x j-1/a j) := by
    apply ge_of_tendsto (sumRatio_tendsto_atTop hx hax)
    filter_upwards [eventually_ge_atTop (t+1)] with s hs
    exact hm.monotoneOn (show 0 < t+1 by linarith) (show 0 < s by linarith) hs
  exact lt_of_lt_of_le (hm ht (show 0 < t+1 by linarith) (by linarith)) hmono

lemma single_crossing_iff_limit {n : ℕ} (hn : 0 < n) {a x : Fin n → ℝ}
    (hx : ∀ j, 0 < x j) (hx1 : ∀ j, x j ≤ 1) (hax : ∀ j, x j < a j) :
    (∃ t : ℝ, 0 < t ∧ totalPhase a x 1 t = Real.pi) ↔
      2 < ∑ j, (1/x j-1/a j) := by
  constructor
  · rintro ⟨t, ht, he⟩
    have hR : sumRatio a x t = 2 := by
      simpa using (phase_eq_pi_iff_sumRatio a x 1 ht).mp he
    rw [← hR]
    exact sumRatio_lt_limit hn hx hx1 hax ht
  · intro hs
    have he : ∀ᶠ t in atTop, 2 < sumRatio a x t :=
      (tendsto_order.1 (sumRatio_tendsto_atTop hx hax)).1 2 hs
    obtain ⟨t, ht, hR⟩ := (he.and (eventually_gt_atTop (0:ℝ))).exists
    obtain ⟨s, hs, _, he⟩ := single_crossing_exists_of_sumRatio_gt a x hR ht
    exact ⟨s, hs, he⟩

lemma single_crossing_of_zero {n : ℕ} {a x : Fin n → ℝ}
    (hx : ∀ j, 0 ≤ x j) (hax : ∀ j, x j < a j)
    {j : Fin n} (hj : x j = 0) :
    ∃ t : ℝ, 0 < t ∧ totalPhase a x 1 t = Real.pi := by
  have ha : 0 < a j := by rw [← hj]; exact hax j
  have hlim : Tendsto (ratio (a j) (x j)) atTop atTop := by
    rw [hj]
    exact ratio_tendsto_atTop_of_zero ha
  have he : ∀ᶠ t in atTop, 2 < ratio (a j) (x j) t := hlim.eventually (eventually_gt_atTop 2)
  obtain ⟨t, htR, ht⟩ := (he.and (eventually_gt_atTop (0:ℝ))).exists
  have hsum : ratio (a j) (x j) t ≤ sumRatio a x t := by
    apply Finset.single_le_sum (fun i _ => ?_) (Finset.mem_univ j)
    unfold ratio
    exact le_of_lt (div_pos (contribution_pos (hax i) ht) (arctan_pos (one_div_pos.mpr ht)))
  obtain ⟨s, hs, _, hE⟩ := single_crossing_exists_of_sumRatio_gt a x ht (lt_of_lt_of_le htR hsum)
  exact ⟨s, hs, hE⟩

lemma ratio_limit_eq_endpoint_summand {r x : ℝ} (hr : 0 < r) (hx : 0 < x) :
    1/x-1/(x+2/r) = 2*(1/(x*(2+r*x))) := by
  have hrn := ne_of_gt hr
  have hxn := ne_of_gt hx
  have hrx : 2+r*x ≠ 0 := ne_of_gt (by positivity)
  have hax : x+2/r ≠ 0 := ne_of_gt (by positivity)
  field_simp [hrn, hxn, hrx, hax]
  <;> ring

lemma single_sample_phase_crossing_iff {n : ℕ} (hn : 0 < n)
    {r x : Fin n → ℝ} (hr : ∀ j, 0 < r j)
    (hx : ∀ j, 0 ≤ x j) (hx1 : ∀ j, x j ≤ 1) :
    (∃! t : ℝ, 0 < t ∧ totalPhase (fun j => x j+2/r j) x 1 t = Real.pi) ↔
      (∃ j, x j = 0) ∨ 1 < endpointSum r x := by
  have hax : ∀ j, x j < x j+2/r j := fun j => lt_add_of_pos_right _ (div_pos (by norm_num) (hr j))
  have huniq := fun {s t} (hs : 0 < s) (ht : 0 < t) =>
    first_phase_crossing_unique hn (by norm_num : 1 ≤ (1:ℕ)) hx hx1 hax hs ht
  have hiff : (∃ t : ℝ, 0 < t ∧ totalPhase (fun j => x j+2/r j) x 1 t = Real.pi) ↔
      (∃ j, x j = 0) ∨ 1 < endpointSum r x := by
    by_cases hz : ∃ j, x j = 0
    · constructor
      · intro _; exact Or.inl hz
      · intro _
        obtain ⟨j, hj⟩ := hz
        exact single_crossing_of_zero hx hax hj
    · have hxp : ∀ j, 0 < x j := by
        intro j
        have hj : x j ≠ 0 := fun he => hz ⟨j, he⟩
        exact lt_of_le_of_ne (hx j) (Ne.symm hj)
      have hsum : (∑ j, (1/x j-1/(x j+2/r j))) = 2*endpointSum r x := by
        simp_rw [ratio_limit_eq_endpoint_summand (hr _) (hxp _)]
        exact (Finset.mul_sum ..).symm
      rw [single_crossing_iff_limit hn hxp hx1 hax, hsum]
      simp only [hz, false_or]
      constructor <;> intro h <;> linarith
  constructor
  · rintro ⟨t, ht, _⟩
    exact hiff.mp ⟨t, ht⟩
  · intro hh
    obtain ⟨t, ht⟩ := hiff.mpr hh
    exact ⟨t, ht, fun s hs => huniq hs.1 ht.1 hs.2 ht.2⟩

lemma single_phase_below_iff {n : ℕ} (a x : Fin n → ℝ) {t : ℝ} (ht : 0 < t) :
    totalPhase a x 1 t < Real.pi ↔ sumRatio a x t < 2 := by
  have hi := single_phase_identity a x ht
  have hD := arctan_pos (one_div_pos.mpr ht)
  constructor
  · intro h
    by_contra! hh
    have hp := mul_nonneg hD.le (sub_nonneg.mpr hh)
    linarith
  · intro h
    have hp := mul_neg_of_pos_of_neg hD (sub_neg.mpr h)
    linarith

lemma single_phase_above_iff {n : ℕ} (a x : Fin n → ℝ) {t : ℝ} (ht : 0 < t) :
    Real.pi < totalPhase a x 1 t ↔ 2 < sumRatio a x t := by
  have hi := single_phase_identity a x ht
  have hD := arctan_pos (one_div_pos.mpr ht)
  constructor
  · intro h
    by_contra! hh
    have hp := mul_nonpos_of_nonneg_of_nonpos hD.le (sub_nonpos.mpr hh)
    linarith
  · intro h
    have hp := mul_pos hD (sub_pos.mpr h)
    linarith

lemma single_phase_before_after_crossing {n : ℕ} (hn : 0 < n) {a x : Fin n → ℝ}
    (hx : ∀ j, 0 ≤ x j) (hx1 : ∀ j, x j ≤ 1) (hax : ∀ j, x j < a j)
    {s t : ℝ} (hs : 0 < s) (ht : 0 < t) (he : totalPhase a x 1 s = Real.pi) :
    (totalPhase a x 1 t < Real.pi ↔ t < s) ∧
      (Real.pi < totalPhase a x 1 t ↔ s < t) := by
  have hm := sumRatio_strictMonoOn hn hx hx1 hax
  have hR : sumRatio a x s = 2 := by
    simpa using (phase_eq_pi_iff_sumRatio a x 1 hs).mp he
  rw [single_phase_below_iff a x ht, single_phase_above_iff a x ht, ← hR]
  exact ⟨hm.lt_iff_lt ht hs, hm.lt_iff_lt hs ht⟩

lemma single_phase_below_pi_of_endpoint {n : ℕ} (hn : 0 < n)
    {r x : Fin n → ℝ} (hr : ∀ j, 0 < r j) (hx : ∀ j, 0 < x j)
    (hx1 : ∀ j, x j ≤ 1) (hS : endpointSum r x ≤ 1) {t : ℝ} (ht : 0 < t) :
    totalPhase (fun j => x j+2/r j) x 1 t < Real.pi := by
  apply (single_phase_below_iff _ x ht).2
  have hax : ∀ j, x j < x j+2/r j := fun j =>
    lt_add_of_pos_right _ (div_pos (by norm_num) (hr j))
  have h := sumRatio_lt_limit hn hx hx1 hax ht
  have hsum : (∑ j, (1/x j-1/(x j+2/r j))) = 2*endpointSum r x := by
    simp_rw [ratio_limit_eq_endpoint_summand (hr _) (hx _)]
    exact (Finset.mul_sum ..).symm
  rw [hsum] at h
  linarith

lemma totalPhase_pos {n : ℕ} (hn : 0 < n) {a x : Fin n → ℝ}
    (hax : ∀ j, x j < a j) (d : ℕ) {t : ℝ} (ht : 0 < t) :
    0 < totalPhase a x d t := by
  have hs := sum_contribution_pos hn hax ht
  have hd : 0 ≤ 2*(d:ℝ)*Real.arctan t :=
    mul_nonneg (by positivity) (arctan_pos ht).le
  exact add_pos_of_nonneg_of_pos hd hs

end C2.NGamma.Phase
