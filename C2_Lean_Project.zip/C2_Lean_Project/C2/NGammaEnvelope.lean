import C2.NGammaGlobal

/-! Exact sign estimates for the envelope derivative. These are the analytic
core of the outer-monotonicity argument; this module does not assert regularity
of the constrained optimum or identify a derivative of a maximum function. -/

noncomputable section
open scoped BigOperators

namespace C2.NGamma.Global

def envelope {n : ℕ} (r x : Fin n → ℝ) (w lam : ℝ) : ℝ :=
  2*lam/(1+w^2) - ∑ j, negPhaseDerivative (r j) (x j) w *
    (1+lam*marginal (r j) (x j) w)

theorem sin_two_arctan (w : ℝ) :
    Real.sin (2*Real.arctan w) = 2*w/(1+w^2) := by
  rw [Real.sin_two_mul,Real.sin_arctan,Real.cos_arctan]
  have hs := Real.sq_sqrt (show 0 ≤ 1+w^2 by positivity)
  have hne : Real.sqrt (1+w^2) ≠ 0 := ne_of_gt (Real.sqrt_pos.mpr (by positivity))
  have hne' : 1+w^2 ≠ 0 := by positivity
  field_simp

theorem tan_phase {r x w : ℝ} (hr : 0 < r) (hx : 0 ≤ x) (hw : 0 < w) :
    Real.tan (phase r x w) = 2*w/phaseDenom r x w := by
  rw [phase_eq_arctan hr hx hw,Real.tan_arctan]

theorem envelope_neg_positive {n : ℕ} (hn : 0 < n) (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hx : ∀ j, 0 ≤ x j) {w lam : ℝ}
    (hw : 0 < w) (hlam : 0 < lam) (hbound : ∀ j, lam*w < x j)
    (hphase : (∑ j, phase (r j) (x j) w) = 2*Real.arctan w) :
    envelope r x w lam < 0 := by
  have hcomp :
      (∑ j, lam/w * Real.tan (phase (r j) (x j) w)) <
      ∑ j, negPhaseDerivative (r j) (x j) w * (1+lam*marginal (r j) (x j) w) := by
    apply Finset.sum_lt_sum
    · intro j _
      rw [tan_phase (hr j) (hx j) hw]
      exact (positive_multiplier_component (hr j) (hx j) hw hlam (hbound j)).le
    · refine ⟨⟨0,hn⟩,Finset.mem_univ _,?_⟩
      rw [tan_phase (hr _) (hx _) hw]
      exact positive_multiplier_component (hr _) (hx _) hw hlam (hbound _)
  have hsin := sin_sum_lt_sum_tan hn (fun j => phase (r j) (x j) w)
    (fun j => ⟨phase_pos (hr j) hw,phase_lt_pi_div_two (hx j) hw⟩)
  rw [hphase,sin_two_arctan] at hsin
  have hscaled := mul_lt_mul_of_pos_left hsin (div_pos hlam hw)
  rw [Finset.mul_sum] at hscaled
  have heq : lam/w * (2*w/(1+w^2)) = 2*lam/(1+w^2) := by
    field_simp
    <;> ring
  rw [heq] at hscaled
  unfold envelope
  linarith

theorem envelope_neg_nonpositive {n : ℕ} (hn : 0 < n) (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hx : ∀ j, 0 ≤ x j) {w lam : ℝ}
    (hw : 0 < w) (hlam : lam ≤ 0)
    (hprod : ∀ j, 0 ≤ lam*marginal (r j) (x j) w) :
    envelope r x w lam < 0 := by
  have hsum : 0 < ∑ j, negPhaseDerivative (r j) (x j) w *
      (1+lam*marginal (r j) (x j) w) := by
    apply Finset.sum_pos
    · intro j _
      exact mul_pos (negPhaseDerivative_pos (hr j) (hx j) hw) (by have := hprod j; linarith)
    · exact ⟨⟨0,hn⟩,Finset.mem_univ _⟩
  have hfirst : 2*lam/(1+w^2) ≤ 0 :=
    div_nonpos_of_nonpos_of_nonneg (by linarith) (by positivity)
  unfold envelope
  linarith

/-- The scalar stationarity/complementarity conditions, stated for the actual
phase-to-log-gain slope, rather than as assumptions about an optimum value. -/
def KKT {n : ℕ} (r x : Fin n → ℝ) (w lam : ℝ) : Prop :=
  ∀ j, (x j = 0 → lam ≤ marginal (r j) (x j) w) ∧
    (x j = 1 → marginal (r j) (x j) w ≤ lam) ∧
    (0 < x j → x j < 1 → marginal (r j) (x j) w = lam)

theorem marginal_zero {r w : ℝ} (hw : 0 < w) : marginal r 0 w = -r*w/2 := by
  unfold marginal
  field_simp
  <;> ring

theorem kkt_positive_no_zero {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hx : ∀ j, 0 ≤ x j) {w lam : ℝ}
    (hw : 0 < w) (hlam : 0 < lam) (hkkt : KKT r x w lam) :
    ∀ j, 0 < x j := by
  intro j
  by_contra h
  have hz : x j = 0 := le_antisymm (le_of_not_gt h) (hx j)
  have hbound := (hkkt j).1 hz
  rw [hz,marginal_zero hw] at hbound
  have hp := mul_pos (hr j) hw
  linarith

theorem kkt_nonpositive_products {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hx : ∀ j, x j ∈ Set.Icc (0:ℝ) 1) {w lam : ℝ}
    (hw : 0 < w) (hlam : lam ≤ 0) (hkkt : KKT r x w lam) :
    ∀ j, 0 ≤ lam*marginal (r j) (x j) w := by
  intro j
  by_cases hz : x j = 0
  · rw [hz,marginal_zero hw]
    exact mul_nonneg_of_nonpos_of_nonpos hlam (by have := mul_pos (hr j) hw; linarith)
  by_cases ho : x j = 1
  · have h := (hkkt j).2.1 ho
    exact mul_nonneg_of_nonpos_of_nonpos hlam (le_trans h hlam)
  · have h := (hkkt j).2.2 (lt_of_le_of_ne (hx j).1 (Ne.symm hz))
      (lt_of_le_of_ne (hx j).2 ho)
    rw [h]
    exact mul_self_nonneg lam

theorem kkt_positive_coordinate_bounds {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hx : ∀ j, x j ∈ Set.Icc (0:ℝ) 1) {w lam : ℝ}
    (hw : 0 < w) (hlam : 0 < lam) (hkkt : KKT r x w lam)
    (hnotone : ∃ j, x j < 1) :
    ∀ j, lam*w < x j := by
  have hxpos := kkt_positive_no_zero r x hr (fun j => (hx j).1) hw hlam hkkt
  obtain ⟨i,hi⟩ := hnotone
  have hmi := (hkkt i).2.2 (hxpos i) hi
  have hbi := marginal_below_x_div_w (hr i) (hx i).1 hw
  rw [hmi] at hbi
  have hli : lam*w < 1 := by
    have := (lt_div_iff₀ hw).mp hbi
    linarith
  intro j
  by_cases ho : x j = 1
  · simpa [ho] using hli
  · have hmj := (hkkt j).2.2 (hxpos j) (lt_of_le_of_ne (hx j).2 ho)
    have hbj := marginal_below_x_div_w (hr j) (hx j).1 hw
    rw [hmj] at hbj
    exact (lt_div_iff₀ hw).mp hbj

/-- Negativity of the actual envelope expression at any feasible KKT point
away from the all-one endpoint. This establishes both multiplier branches.
The separate regularity theorem needed to integrate this derivative is not
part of this statement. -/
theorem envelope_neg_of_KKT {n : ℕ} (hn : 0 < n) (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hx : ∀ j, x j ∈ Set.Icc (0:ℝ) 1) {w lam : ℝ}
    (hw : 0 < w) (hkkt : KKT r x w lam)
    (hphase : (∑ j, phase (r j) (x j) w) = 2*Real.arctan w)
    (hstrict : (∑ j, phase (r j) 1 w) < 2*Real.arctan w) :
    envelope r x w lam < 0 := by
  by_cases hlam : 0 < lam
  · have hnotone : ∃ j, x j < 1 := by
      by_contra h
      push_neg at h
      have heq : x = fun _ => 1 := funext (fun j => le_antisymm (hx j).2 (h j))
      rw [heq] at hphase
      linarith
    exact envelope_neg_positive hn r x hr (fun j => (hx j).1) hw hlam
      (kkt_positive_coordinate_bounds r x hr hx hw hlam hkkt hnotone) hphase
  · exact envelope_neg_nonpositive hn r x hr (fun j => (hx j).1) hw (le_of_not_gt hlam)
      (kkt_nonpositive_products r x hr hx hw (le_of_not_gt hlam) hkkt)

end C2.NGamma.Global
