import C2.GeneralCompletionFirstMarginCore
import C2.GeneralCompletionBounds
import C2.GeneralBoundaryRootCount
import C2.GeneralBoundaryCandidates

/-! The least finite Chebyshev boundary is the exact initial gain margin
for the actual real rational characteristic. Later stable components are
not excluded or silently merged with the initial component. -/

noncomputable section
open Polynomial Set
namespace C2.GeneralCompletion

/-- Actual complex-root stability of the real affine characteristic. -/
def realGainSchur (H N : ℝ[X]) (k : ℝ) : Prop :=
  C2.NGamma.PolynomialModel.SchurStable
    (C2.GeneralBoundary.gainPolynomial (H.map Complex.ofRealHom) (N.map Complex.ofRealHom) k)

theorem mapped_gain_polynomial (H N : ℝ[X]) (k : ℝ) :
    (H+Polynomial.C k*N).map Complex.ofRealHom =
      C2.GeneralBoundary.gainPolynomial (H.map Complex.ofRealHom) (N.map Complex.ofRealHom) k := by
  simp [C2.GeneralBoundary.gainPolynomial]

theorem evalC_eq_mapped_eval (p : ℝ[X]) (z : ℂ) :
    C2.GeneralBoundaryCandidates.evalC p z = (p.map Complex.ofRealHom).eval z := by
  have he : algebraMap ℝ ℂ = Complex.ofRealHom := by ext r; rfl
  simp [C2.GeneralBoundaryCandidates.evalC,Polynomial.aeval_def,Polynomial.eval_map,he]

theorem realGainSchur_bounded {H N : ℝ[X]} (hN : N ≠ 0)
    (hdeg : N.natDegree < H.natDegree) :
    ∃ B : ℝ, ∀ k : ℝ, 0 < k → realGainSchur H N k → k ≤ B := by
  obtain ⟨B,hB⟩ := stable_gains_bounded hN hdeg
  refine ⟨B,fun k hk hs => hB k hk.le ?_⟩
  intro z hz
  apply hs z
  simpa only [mapped_gain_polynomial] using hz

theorem realGainSchur_not_at_candidate {H N : ℝ[X]} {k : ℝ}
    (hcommon : ∀ z : ℂ, ‖z‖=1 →
      C2.GeneralBoundaryCandidates.evalC N z=0 → C2.GeneralBoundaryCandidates.evalC H z≠0)
    (hk : k ∈ C2.GeneralBoundaryCandidates.candidateGains H N) :
    ¬realGainSchur H N k := by
  intro hs
  have hu := (C2.GeneralBoundaryCandidates.unitCircleRoot_iff_candidate hk.1 hcommon).mpr hk
  have hfree := C2.GeneralBoundary.boundaryFree_of_schur hs
  have hn := (C2.GeneralBoundary.boundaryFree_iff_not_unitCircleRoot
    (H.map Complex.ofRealHom) (N.map Complex.ofRealHom) k).mp hfree
  apply hn
  simpa only [C2.UnitCircleRoot,evalC_eq_mapped_eval] using hu

/-- Stability transports across every positive interval avoiding the actual
finite candidate set. This discharges the constancy hypothesis in the order lemma. -/
theorem realGainSchur_interval_transport {H N : ℝ[X]}
    (hdeg : N.natDegree < H.natDegree)
    (hcommon : ∀ z : ℂ, ‖z‖=1 →
      C2.GeneralBoundaryCandidates.evalC N z=0 → C2.GeneralBoundaryCandidates.evalC H z≠0)
    (a b : ℝ) (ha : 0 < a) (hab : a ≤ b)
    (hno : ∀ k ∈ Icc a b, k ∉ C2.GeneralBoundaryCandidates.candidateGains H N) :
    realGainSchur H N a ↔ realGainSchur H N b := by
  have hdegc : (N.map Complex.ofRealHom).natDegree < (H.map Complex.ofRealHom).natDegree := by
    simpa using hdeg
  have hfree : ∀ k ∈ Icc a b, C2.GeneralBoundary.BoundaryFree
      (C2.GeneralBoundary.gainPolynomial (H.map Complex.ofRealHom) (N.map Complex.ofRealHom) k) := by
    intro k hk
    apply (C2.GeneralBoundary.boundaryFree_iff_not_unitCircleRoot
      (H.map Complex.ofRealHom) (N.map Complex.ofRealHom) k).mpr
    intro hu
    have hu' : C2.UnitCircleRoot (C2.GeneralBoundaryCandidates.evalC H)
        (C2.GeneralBoundaryCandidates.evalC N) k := by
      simpa only [C2.UnitCircleRoot,evalC_eq_mapped_eval] using hu
    exact hno k hk ((C2.GeneralBoundaryCandidates.unitCircleRoot_iff_candidate
      (ha.trans_le hk.1) hcommon).mp hu')
  exact C2.GeneralBoundary.schur_constant_on_preconnected
    (H.map Complex.ofRealHom) (N.map Complex.ofRealHom) hdegc isPreconnected_Icc hfree
    (left_mem_Icc.mpr hab) (right_mem_Icc.mpr hab)

/-- Full zero-connected-margin proposition, including nonemptiness of the
candidate set, its least element, the exact initial stable interval, failure
of strict stability at the boundary, and the supremum characterization. -/
theorem general_first_margin {H N : ℝ[X]} (hN : N ≠ 0)
    (hdeg : N.natDegree < H.natDegree)
    (hQ : C2.GeneralBoundaryCandidates.Q H N ≠ 0)
    (hcommon : ∀ z : ℂ, ‖z‖=1 →
      C2.GeneralBoundaryCandidates.evalC N z=0 → C2.GeneralBoundaryCandidates.evalC H z≠0)
    (hsmall : ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℝ, 0 < k → k < ε → realGainSchur H N k) :
    (C2.GeneralBoundaryCandidates.candidateGains H N).Nonempty ∧
    ∃ c : ℝ, IsLeast (C2.GeneralBoundaryCandidates.candidateGains H N) c ∧ 0 < c ∧
      (∀ k : ℝ, 0 < k → k < c → realGainSchur H N k) ∧ ¬realGainSchur H N c ∧
      IsGreatest (initialIntervalEndpoints (realGainSchur H N)) c ∧
      initialIntervalEndpoints (realGainSchur H N) = Ioc 0 c ∧
      sSup (initialIntervalEndpoints (realGainSchur H N)) = c := by
  have hfinite := C2.GeneralBoundaryCandidates.candidateGains_finite hQ
  have hbound := realGainSchur_bounded hN hdeg
  have htransport := realGainSchur_interval_transport hdeg hcommon
  refine ⟨first_boundary_nonempty hsmall hbound htransport,?_⟩
  exact finite_first_boundary_margin hfinite (fun _ hk => hk.1)
    (fun _ hk => realGainSchur_not_at_candidate hcommon hk) hsmall hbound htransport

end C2.GeneralCompletion
