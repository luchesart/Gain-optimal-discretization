import C2.NGammaRealizationDecay
import Mathlib

/-! A uniform geometric power bound for a compact continuous family of stable
operators. Compactness supplies a common contracting power; Bernoulli's
inequality supplies an explicit geometric ratio without root extraction. -/
noncomputable section
open Filter Set
open scoped Topology
namespace C2.CompactSchur

theorem common_contracting_power
    {X R : Type*} [TopologicalSpace X] [CompactSpace X]
    [NormedRing R] [NormOneClass R] (A : X → R) (hA : Continuous A)
    (hstable : ∀ x, Tendsto (fun n : ℕ => A x ^ n) atTop (𝓝 0)) :
    ∃ N : ℕ, 0 < N ∧ ∀ x, ‖A x ^ N‖ ≤ (1 / 2 : ℝ) := by
  classical
  have hex : ∀ x, ∃ n : ℕ, 0 < n ∧ ‖A x ^ n‖ < (1 / 2 : ℝ) := by
    intro x
    have hnorm : Tendsto (fun n : ℕ => ‖A x ^ n‖) atTop (𝓝 (0 : ℝ)) := by
      simpa using (hstable x).norm
    have he := hnorm.eventually (gt_mem_nhds (by norm_num : (0 : ℝ) < 1 / 2))
    obtain ⟨n, hn, hpos⟩ := (he.and (eventually_gt_atTop (0 : ℕ))).exists
    exact ⟨n, hpos, by simpa using hn⟩
  choose m hm0 hm using hex
  let U : X → Set X := fun x => {y | ‖A y ^ m x‖ < (1 / 2 : ℝ)}
  have hU : ∀ x, IsOpen (U x) := fun x =>
    isOpen_lt ((hA.pow (m x)).norm) continuous_const
  have hcover : (Set.univ : Set X) ⊆ ⋃ x, U x := by
    intro x _
    exact Set.mem_iUnion.mpr ⟨x, hm x⟩
  obtain ⟨s, hs⟩ := isCompact_univ.elim_finite_subcover U hU hcover
  let N := ∏ x ∈ s, m x
  have hN : 0 < N := Finset.prod_pos (fun x _ => hm0 x)
  refine ⟨N, hN, ?_⟩
  intro x
  obtain ⟨y, hy, hxy⟩ := Set.mem_iUnion₂.mp (hs (Set.mem_univ x))
  change ‖A x ^ m y‖ < (1 / 2 : ℝ) at hxy
  obtain ⟨k, hk⟩ := Finset.dvd_prod_of_mem m hy
  have he : N = m y * k := hk
  have hk0 : 0 < k := by
    apply Nat.pos_of_ne_zero
    intro hk0
    rw [hk0, mul_zero] at he
    omega
  rw [he, pow_mul]
  calc
    ‖(A x ^ m y) ^ k‖ ≤ ‖A x ^ m y‖ ^ k := norm_pow_le _ _
    _ ≤ (1 / 2 : ℝ) ^ k := pow_le_pow_left₀ (norm_nonneg _) hxy.le _
    _ ≤ (1 / 2 : ℝ) ^ 1 := pow_le_pow_of_le_one (by norm_num) (by norm_num) (by omega)
    _ = 1 / 2 := pow_one _

theorem geometric_ratio (N : ℕ) (hN : 0 < N) :
    ∃ q : ℝ, 0 < q ∧ q < 1 ∧ (1 / 2 : ℝ) ≤ q ^ N := by
  have hn : (0 : ℝ) < N := by exact_mod_cast hN
  have hn1 : (1 : ℝ) ≤ N := by exact_mod_cast hN
  let q : ℝ := 1 - 1 / (2 * N)
  have hfrac : 0 < 1 / (2 * (N : ℝ)) := by positivity
  have hfrac1 : 1 / (2 * (N : ℝ)) < 1 := (div_lt_one (by positivity)).mpr (by linarith)
  have hq0 : 0 < q := by dsimp [q]; linarith
  have hq1 : q < 1 := by dsimp [q]; linarith
  refine ⟨q, hq0, hq1, ?_⟩
  have hb := one_add_mul_sub_le_pow (show (-1 : ℝ) ≤ q by linarith) N
  have he : 1 + (N : ℝ) * (q - 1) = 1 / 2 := by
    dsimp [q]
    field_simp
    <;> ring
  rwa [he] at hb

theorem geometric_bound_of_block {R : Type*} [NormedRing R] [NormOneClass R]
    (a : R) {B q : ℝ} {N : ℕ} (hB : 1 ≤ B)
    (ha : ‖a‖ ≤ B) (hq0 : 0 < q) (hq1 : q < 1) (hN : 0 < N)
    (hblock : ‖a ^ N‖ ≤ q ^ N) (n : ℕ) :
    ‖a ^ n‖ ≤ (B / q) ^ N * q ^ n := by
  have hr : n % N ≤ N := (Nat.mod_lt n hN).le
  have hB0 : 0 ≤ B := by linarith
  have hratio : 1 ≤ B / q := (le_div_iff₀ hq0).mpr (by linarith)
  have hrest : B ^ (n % N) ≤ (B / q) ^ N * q ^ (n % N) := by
    have h := pow_le_pow_right₀ hratio hr
    rw [div_pow] at h
    exact (div_le_iff₀ (pow_pos hq0 _)).mp h
  have hn : n = N * (n / N) + n % N := (Nat.div_add_mod n N).symm
  calc
    ‖a ^ n‖ = ‖(a ^ N) ^ (n / N) * a ^ (n % N)‖ := by rw [← pow_mul, ← pow_add, ← hn]
    _ ≤ ‖(a ^ N) ^ (n / N)‖ * ‖a ^ (n % N)‖ := norm_mul_le _ _
    _ ≤ (q ^ N) ^ (n / N) * B ^ (n % N) := by
      apply mul_le_mul
      · exact (norm_pow_le _ _).trans (pow_le_pow_left₀ (norm_nonneg _) hblock _)
      · exact (norm_pow_le _ _).trans (pow_le_pow_left₀ (norm_nonneg _) ha _)
      · exact norm_nonneg _
      · positivity
    _ ≤ (q ^ N) ^ (n / N) * ((B / q) ^ N * q ^ (n % N)) :=
      mul_le_mul_of_nonneg_left hrest (by positivity)
    _ = (B / q) ^ N * q ^ n := by
      conv_rhs => rw [hn, pow_add, pow_mul]
      ring

theorem uniform_geometric_of_compact_power_decay
    {X R : Type*} [TopologicalSpace X] [CompactSpace X]
    [NormedRing R] [NormOneClass R] (A : X → R) (hA : Continuous A)
    (hstable : ∀ x, Tendsto (fun n : ℕ => A x ^ n) atTop (𝓝 0)) :
    ∃ C q : ℝ, 0 < C ∧ 0 < q ∧ q < 1 ∧ ∀ x n, ‖A x ^ n‖ ≤ C * q ^ n := by
  obtain ⟨N, hN, hblock⟩ := common_contracting_power A hA hstable
  obtain ⟨q, hq0, hq1, hqN⟩ := geometric_ratio N hN
  obtain ⟨B₀, hB₀⟩ := (isCompact_range hA).isBounded.exists_norm_le
  let B := max 1 B₀
  have hB : 1 ≤ B := le_max_left _ _
  have hAx : ∀ x, ‖A x‖ ≤ B := fun x =>
    (hB₀ (A x) (Set.mem_range_self x)).trans (le_max_right _ _)
  have hBpos : 0 < B := by linarith
  have hCpos : 0 < (B / q) ^ N := by positivity
  refine ⟨(B / q) ^ N, q, hCpos, hq0, hq1, ?_⟩
  intro x n
  exact geometric_bound_of_block (A x) hB (hAx x) hq0 hq1 hN ((hblock x).trans hqN) n

theorem uniform_geometric_of_compact_spectral_radius
    {X R : Type*} [TopologicalSpace X] [CompactSpace X]
    [NormedRing R] [NormOneClass R] [NormedAlgebra ℂ R] [CompleteSpace R]
    (A : X → R) (hA : Continuous A) (hstable : ∀ x, spectralRadius ℂ (A x) < 1) :
    ∃ C q : ℝ, 0 < C ∧ 0 < q ∧ q < 1 ∧ ∀ x n, ‖A x ^ n‖ ≤ C * q ^ n := by
  apply uniform_geometric_of_compact_power_decay A hA
  intro x
  exact C2.NGamma.Realization.powers_tendsto_zero_of_spectralRadius_lt_one (A x) (hstable x)

end C2.CompactSchur
