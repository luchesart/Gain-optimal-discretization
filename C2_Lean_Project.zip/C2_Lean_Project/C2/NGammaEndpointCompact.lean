import C2.NGammaEndpointLimit
import Mathlib.Topology.Sequences

/-! Compactness closes the upper bound at zero frequency.  Every feasible
sequence approaching zero has an actual convergent gain subsequence, whose
limit is the gain of a feasible endpoint allocation. -/
noncomputable section
open scoped BigOperators Topology
open Set Filter
namespace C2.NGamma

variable {ι : Type*} [Fintype ι]

/-- Compactness supplies the cluster point; it is not supplied as a premise. -/
theorem exists_feasible_endpoint_subsequence
    (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    (w : ℕ → ℝ) (x : ℕ → ι → ℝ)
    (hwlim : Tendsto w atTop (𝓝 0))
    (hw : ∀ k, 0 < w k) (hx : ∀ k i, x k i ∈ Icc 0 1)
    (hphase : ∀ k, (∑ i, allocationPhase (r i) (x k i) (w k)) = 2*Real.arctan (w k)) :
    ∃ x₀ : ι → ℝ, ∃ φ : ℕ → ℕ, StrictMono φ ∧
      (∀ i, 0 < x₀ i ∧ x₀ i ≤ 1) ∧ (∑ i, endpointCost (r i) (x₀ i)) = 1 ∧
      Tendsto (fun k => ∏ i, allocationGain (r i) (x (φ k) i) (w (φ k)))
        atTop (𝓝 (∏ i, (r i+2/x₀ i))) := by
  classical
  have hxcube : ∀ k, x k ∈ Icc (0 : ι → ℝ) 1 := by
    intro k
    exact ⟨fun i => (hx k i).1, fun i => (hx k i).2⟩
  obtain ⟨x₀,hx₀,φ,hφ,hlim⟩ :=
    (isCompact_Icc : IsCompact (Icc (0 : ι → ℝ) 1)).tendsto_subseq hxcube
  have hwsub := hwlim.comp hφ.tendsto_atTop
  have hxsub : ∀ i, Tendsto (fun k => x (φ k) i) atTop (𝓝 (x₀ i)) :=
    fun i => (tendsto_pi_nhds.mp hlim) i
  have hcluster := feasible_endpoint_cluster r hr (w ∘ φ) (x ∘ φ) x₀ hwsub hxsub
    (fun k => hw (φ k)) (fun k i => hx (φ k) i) (fun k => hphase (φ k))
  refine ⟨x₀,φ,hφ,hcluster.1,hcluster.2,?_⟩
  apply tendsto_finset_prod
  intro i hi
  have ht := (allocationGain_endpoint_continuousAt (r := r i) (hcluster.1 i).1).tendsto.comp
    ((hxsub i).prodMk_nhds hwsub)
  simpa only [Function.comp_def, allocationGain_endpoint (hr i) (hcluster.1 i).1] using ht

/-- Every eventual lower bound on gains along a feasible zero-frequency
sequence is bounded by every valid global endpoint gain bound. -/
theorem endpoint_bound_of_feasible_sequence
    (r : ι → ℝ) (hr : ∀ i, 0 < r i) (B v : ℝ)
    (hB : ∀ x₀ : ι → ℝ, (∀ i, 0 < x₀ i ∧ x₀ i ≤ 1) →
      (∑ i, endpointCost (r i) (x₀ i)) ≤ 1 → (∏ i, (r i+2/x₀ i)) ≤ B)
    (w : ℕ → ℝ) (x : ℕ → ι → ℝ)
    (hwlim : Tendsto w atTop (𝓝 0))
    (hw : ∀ k, 0 < w k) (hx : ∀ k i, x k i ∈ Icc 0 1)
    (hphase : ∀ k, (∑ i, allocationPhase (r i) (x k i) (w k)) = 2*Real.arctan (w k))
    (hv : ∀ᶠ k in atTop, v ≤ ∏ i, allocationGain (r i) (x k i) (w k)) : v ≤ B := by
  obtain ⟨x₀,φ,hφ,hx₀,hcost,hlim⟩ := exists_feasible_endpoint_subsequence r hr w x hwlim hw hx hphase
  exact le_trans (ge_of_tendsto hlim (hφ.tendsto_atTop.eventually hv))
    (hB x₀ hx₀ hcost.le)

/-- Specialization to the proved strict-regime endpoint optimizer. -/
theorem endpoint_allocation_bound_of_feasible_sequence
    (r : ι → ℝ) (hr : ∀ i, 0 < r i) {c : ℝ} (hc : 0 < c)
    (hbudget : allocatedResource r c = 4) (v : ℝ)
    (w : ℕ → ℝ) (x : ℕ → ι → ℝ)
    (hwlim : Tendsto w atTop (𝓝 0))
    (hw : ∀ k, 0 < w k) (hx : ∀ k i, x k i ∈ Icc 0 1)
    (hphase : ∀ k, (∑ i, allocationPhase (r i) (x k i) (w k)) = 2*Real.arctan (w k))
    (hv : ∀ᶠ k in atTop, v ≤ ∏ i, allocationGain (r i) (x k i) (w k)) :
    v ≤ ∏ i, endpointAllocation (r i) c := by
  exact endpoint_bound_of_feasible_sequence r hr _ v
    (fun x₀ hx₀ hcost => endpointGain_product_optimal r hr hc hbudget x₀ hx₀ hcost)
    w x hwlim hw hx hphase hv

/-- Specialization to the unique all-one design at the endpoint threshold. -/
theorem endpoint_equality_bound_of_feasible_sequence
    (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    (hbase : (∑ i, 1/(r i+2)) = 1) (v : ℝ)
    (w : ℕ → ℝ) (x : ℕ → ι → ℝ)
    (hwlim : Tendsto w atTop (𝓝 0))
    (hw : ∀ k, 0 < w k) (hx : ∀ k i, x k i ∈ Icc 0 1)
    (hphase : ∀ k, (∑ i, allocationPhase (r i) (x k i) (w k)) = 2*Real.arctan (w k))
    (hv : ∀ᶠ k in atTop, v ≤ ∏ i, allocationGain (r i) (x k i) (w k)) :
    v ≤ ∏ i, (r i+2) := by
  apply endpoint_bound_of_feasible_sequence r hr _ v ?_ w x hwlim hw hx hphase hv
  intro x₀ hx₀ hcost
  rw [endpoint_feasible_equality_unique r x₀ hr hx₀ hbase hcost]
  simp

end C2.NGamma
