import C2.Schur
import C2.FirstOrder

namespace C2.FirstOrder

/-- Positive gain and genuine complex-root Schur stability of the complete
one-delay characteristic polynomial. -/
def Stable (r γ a : ℝ) : Prop :=
  0 < a ∧ C2.QuadraticSchur (1 + r * γ)
    (-1 + r * (1 - γ) + a * γ) (a * (1 - γ))

theorem stable_iff_jury {r γ a : ℝ} (hr : 0 ≤ r) (hγ : 0 ≤ γ) :
    Stable r γ a ↔ Jury r γ a := by
  have hL : 0 < 1 + r * γ := by nlinarith [mul_nonneg hr hγ]
  unfold Stable Jury
  rw [C2.quadraticSchur_iff hL]
  constructor
  · rintro ⟨ha, h₁, h₂, h₃⟩
    refine ⟨ha, ?_, ?_⟩ <;> nlinarith
  · rintro ⟨ha, h₁, h₂⟩
    refine ⟨ha, ?_, ?_, ?_⟩ <;> nlinarith

theorem stable_global_gain_bound {r γ a : ℝ} (hr : 0 ≤ r)
    (hγ : 0 ≤ γ) (h : Stable r γ a) : a < aStar r :=
  global_gain_bound hr ((stable_iff_jury hr hγ).1 h)

theorem optimum_stable_iff {r a : ℝ} (hr : 0 ≤ r) :
    Stable r (γStar r) a ↔ 0 < a ∧ a < aStar r := by
  rw [stable_iff_jury hr (γStar_bounds hr).1]
  exact optimum_admissible_iff hr

theorem stable_projection {r a : ℝ} (hr : 0 ≤ r) :
    (∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r γ a) ↔
      0 < a ∧ a < aStar r := by
  constructor
  · rintro ⟨γ, hγ, _, h⟩
    exact ⟨h.1, stable_global_gain_bound hr hγ h⟩
  · intro h
    exact ⟨γStar r, (γStar_bounds hr).1, (γStar_bounds hr).2,
      (optimum_stable_iff hr).2 h⟩

theorem stable_optimal_gain_isLUB {r : ℝ} (hr : 0 ≤ r) :
    IsLUB {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r γ a} (aStar r) := by
  have heq : {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r γ a} =
      {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r γ a} := by
    ext a
    exact (stable_projection hr).trans (admissible_projection hr).symm
  rw [heq]
  exact optimal_gain_isLUB hr

theorem stable_maximizing_parameter_iff {r γ : ℝ}
    (hr : 0 ≤ r) (hγ : 0 ≤ γ) :
    IsLUB {a : ℝ | Stable r γ a} (aStar r) ↔ γ = γStar r := by
  have heq : {a : ℝ | Stable r γ a} = {a : ℝ | Jury r γ a} := by
    ext a
    exact stable_iff_jury hr hγ
  rw [heq]
  exact maximizing_parameter_iff hr

theorem integrator_stable_optimum_iff {a : ℝ} :
    Stable 0 (3 / 4) a ↔ 0 < a ∧ a < 4 := by
  simpa only [integrator_γStar, integrator_aStar] using
    (optimum_stable_iff (r := 0) (by norm_num))

end C2.FirstOrder
