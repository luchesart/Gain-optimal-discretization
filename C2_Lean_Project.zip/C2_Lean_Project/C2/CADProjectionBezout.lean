import Mathlib

/-! Polynomial projection by denominator-cleared Bezout identities.
These results prove nonzero projection cuts from generic coprimeness; no
regularity of specialized roots is assumed. -/

noncomputable section
open Polynomial
namespace C2.CADProjection

section FractionField
variable {R F : Type*} [CommRing R] [IsDomain R] [Field F]
  [Algebra R F] [IsFractionRing R F]

/-- A polynomial over the fraction field has a nonzero common denominator. -/
theorem exists_clear_denominator (p : F[X]) :
    ∃ b : R, b ≠ 0 ∧ ∃ q : R[X],
      q.map (algebraMap R F) = C (algebraMap R F b) * p := by
  obtain ⟨b, hb⟩ := IsLocalization.integerNormalization_map_to_map
    (nonZeroDivisors R) p
  refine ⟨b, nonZeroDivisors.ne_zero b.property, IsLocalization.integerNormalization
    (nonZeroDivisors R) p, ?_⟩
  rw [hb]
  ext n
  simp [Algebra.smul_def]

/-- Coprimeness over the gain fraction field gives an actual nonzero
polynomial in the gain lying in the original polynomial ideal. -/
theorem exists_bezout_eliminant (p q : R[X])
    (h : IsCoprime (p.map (algebraMap R F)) (q.map (algebraMap R F))) :
    ∃ r : R, r ≠ 0 ∧ ∃ u v : R[X], u*p + v*q = C r := by
  obtain ⟨a,b,hab⟩ := h
  obtain ⟨s,hs,a0,ha⟩ := exists_clear_denominator (R:=R) a
  obtain ⟨t,ht,b0,hb⟩ := exists_clear_denominator (R:=R) b
  refine ⟨s*t,mul_ne_zero hs ht,C t*a0,C s*b0,?_⟩
  apply Polynomial.map_injective (f := algebraMap R F) (IsFractionRing.injective R F)
  simp only [Polynomial.map_add,Polynomial.map_mul,Polynomial.map_C]
  rw [ha,hb]
  calc
    C (algebraMap R F t) * (C (algebraMap R F s) * a) * p.map (algebraMap R F) +
        C (algebraMap R F s) * (C (algebraMap R F t) * b) * q.map (algebraMap R F)
        = C (algebraMap R F (s*t)) *
            (a*p.map (algebraMap R F) + b*q.map (algebraMap R F)) := by
              rw [map_mul, Polynomial.C_mul]
              ring
    _ = C (algebraMap R F (s*t)) := by rw [hab,mul_one]

end FractionField

/-- Any specialization away from a Bezout eliminant has no common root. -/
theorem no_common_root_of_bezout {R S : Type*} [CommRing R] [CommRing S]
    {p q u v : R[X]} {r : R} (h : u*p + v*q = C r)
    (f : R →+* S) (hr : f r ≠ 0) (x : S) :
    (p.map f).eval x ≠ 0 ∨ (q.map f).eval x ≠ 0 := by
  by_contra! hh
  have he := congrArg (fun P : R[X] => (P.map f).eval x) h
  simp only [Polynomial.map_add, Polynomial.map_mul, Polynomial.map_C,
    Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_C,
    hh.1,hh.2,mul_zero,add_zero] at he
  exact hr he.symm

/-- Generic coprimeness produces a nonzero cut excluding every collision
under every field specialization away from that cut. -/
theorem exists_collision_cut {R F : Type*} [CommRing R] [IsDomain R] [Field F]
    [Algebra R F] [IsFractionRing R F] (p q : R[X])
    (h : IsCoprime (p.map (algebraMap R F)) (q.map (algebraMap R F))) :
    ∃ r : R, r ≠ 0 ∧ ∀ {S : Type*} [CommRing S] (f : R →+* S),
      f r ≠ 0 → ∀ x : S, (p.map f).eval x ≠ 0 ∨ (q.map f).eval x ≠ 0 := by
  obtain ⟨r,hr,u,v,hid⟩ := exists_bezout_eliminant p q h
  exact ⟨r,hr,fun f hf x => no_common_root_of_bezout hid f hf x⟩

/-- Generic separability supplies a gain cut away from which every actual
specialized root is simple. -/
theorem exists_simple_root_cut {R F : Type*} [CommRing R] [IsDomain R] [Field F]
    [Algebra R F] [IsFractionRing R F] (p : R[X])
    (h : (p.map (algebraMap R F)).Separable) :
    ∃ r : R, r ≠ 0 ∧ ∀ {S : Type*} [CommRing S] (f : R →+* S),
      f r ≠ 0 → ∀ x : S, (p.map f).eval x = 0 →
        (p.map f).derivative.eval x ≠ 0 := by
  have hc : IsCoprime (p.map (algebraMap R F))
      (p.derivative.map (algebraMap R F)) := by
    simpa only [Polynomial.derivative_map] using (Polynomial.separable_def _).mp h
  obtain ⟨r,hr,hcut⟩ := exists_collision_cut p p.derivative hc
  refine ⟨r,hr,fun f hf x hx => ?_⟩
  have hn := (hcut f hf x).resolve_left (not_not.mpr hx)
  simpa only [Polynomial.derivative_map] using hn

end C2.CADProjection
