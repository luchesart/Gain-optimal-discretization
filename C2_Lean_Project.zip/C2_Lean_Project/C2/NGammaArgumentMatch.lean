import C2.NGammaCayley
import Mathlib.Topology.Piecewise

/-! Branch matching at the unique amplitude crossing. -/

noncomputable section
open scoped Topology

namespace C2.NGamma.ArgumentMatch

lemma exp_sub_turns (u : ℝ) (k : ℤ) :
    Complex.exp (((u-2*Real.pi*k : ℝ) : ℂ)*Complex.I) =
      Complex.exp ((u : ℂ)*Complex.I) := by
  push_cast
  rw [sub_mul, Complex.exp_sub]
  have h : (2*(Real.pi : ℂ)*(k : ℂ))*Complex.I = (k : ℂ)*(2*Real.pi*Complex.I) := by ring
  rw [h, Complex.exp_int_mul_two_pi_mul_I, div_one]

lemma one_add_exp_half (u : ℝ) :
    1 + Complex.exp ((u : ℂ)*Complex.I) =
      (2*Real.cos (u/2) : ℝ) * Complex.exp (((u/2 : ℝ) : ℂ)*Complex.I) := by
  have hcos := Real.cos_two_mul (u/2)
  have hsin := Real.sin_two_mul (u/2)
  have he : 2*(u/2) = u := by ring
  rw [he] at hcos hsin
  simp only [Complex.exp_mul_I, ← Complex.ofReal_cos, ← Complex.ofReal_sin]
  apply Complex.ext <;> simp only [Complex.add_re, Complex.add_im, Complex.one_re,
    Complex.one_im, Complex.mul_re, Complex.mul_im, Complex.ofReal_re, Complex.ofReal_im,
    Complex.I_re, Complex.I_im, mul_zero, zero_mul, add_zero, zero_add, sub_zero, mul_one]
  · nlinarith
  · nlinarith

lemma arg_one_add_exp {u : ℝ} (hlo : -Real.pi < u) (hhi : u < Real.pi) :
    Complex.arg (1+Complex.exp ((u : ℂ)*Complex.I)) = u/2 := by
  have hc : 0 < 2*Real.cos (u/2) := by
    apply mul_pos (by norm_num)
    exact Real.cos_pos_of_mem_Ioo ⟨by linarith, by linarith⟩
  rw [one_add_exp_half, Complex.arg_real_mul _ hc, Complex.exp_mul_I]
  exact Complex.arg_cos_add_sin_mul_I ⟨by linarith [Real.pi_pos], by linarith [Real.pi_pos]⟩

lemma arg_one_add_exp_neg {u : ℝ} (hlo : -Real.pi < u) (hhi : u < Real.pi) :
    Complex.arg (1+Complex.exp (-(u : ℂ)*Complex.I)) = -(u/2) := by
  have h := arg_one_add_exp (u := -u) (by linarith) (by linarith)
  simpa only [Complex.ofReal_neg, neg_div] using h

lemma amplitude_crossing_branch_match {b : ℝ} (hb : 0 < b) (u : ℝ) (k : ℤ)
    (hlo : -Real.pi < u-2*Real.pi*k) (hhi : u-2*Real.pi*k < Real.pi) :
    Complex.arg ((b : ℂ)*Complex.exp ((u : ℂ)*Complex.I)+b) =
      u + Complex.arg (1+(b : ℂ)/((b : ℂ)*Complex.exp ((u : ℂ)*Complex.I))) - 2*Real.pi*k := by
  have hbn : (b : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hb
  have hfac : (b : ℂ)*Complex.exp ((u : ℂ)*Complex.I)+b =
      (b : ℂ)*(1+Complex.exp ((u : ℂ)*Complex.I)) := by ring
  have hquot : (b : ℂ)/((b : ℂ)*Complex.exp ((u : ℂ)*Complex.I)) =
      Complex.exp (-(u : ℂ)*Complex.I) := by
    rw [neg_mul, Complex.exp_neg]
    field_simp
  have hperiod := exp_sub_turns u k
  have hnegperiod : Complex.exp (-((u-2*Real.pi*k : ℝ) : ℂ)*Complex.I) =
      Complex.exp (-(u : ℂ)*Complex.I) := by
    simp only [neg_mul, Complex.exp_neg]
    rw [hperiod]
  rw [hfac, Complex.arg_real_mul _ hb, hquot, ← hperiod, ← hnegperiod,
    arg_one_add_exp hlo hhi, arg_one_add_exp_neg hlo hhi]
  ring

end C2.NGamma.ArgumentMatch
