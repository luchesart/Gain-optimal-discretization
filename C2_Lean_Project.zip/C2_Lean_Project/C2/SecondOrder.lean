import Mathlib
import C2.CubicSchur

/-!
# Exact global optimization for a stable second-order rational factor

The parameter is `t = 2 * gamma - 1`, the normalized denominator coefficients
are `u = a₁ T > 0`, `v = a₀ T² > 0`, and the gain is `b = k T²`.
The algebraic feasible set uses the cubic Schur/Jury inequalities, including
one redundant positive Cayley coefficient.  The complex-root bridge is stated
separately; this file does not define stability as an optimizer condition.
-/
noncomputable section
namespace C2.SecondOrder

def gamma (t : ℝ) : ℝ := (1+t)/2

def L (u v t : ℝ) : ℝ := 1 + u*(1+t)/2 + v*(1+t)^2/4

def c (t : ℝ) : ℝ := (1-t)^2/4

def D (t b : ℝ) : ℝ := b*c t

def A0 (v b : ℝ) : ℝ := b+v

def A1 (u v t b : ℝ) : ℝ := 2*t*(b+v)+2*u+v-b

def A2 (u v t b : ℝ) : ℝ := t^2*(b+v)+2*t*(u+v-b)+2*u+4

def A3 (u v t b : ℝ) : ℝ := 4+2*u*t+(v-b)*t^2

def R (u v t b : ℝ) : ℝ := A1 u v t b * A2 u v t b - A0 v b * A3 u v t b

def f (u v t : ℝ) : ℝ := v*t^3+2*u*t^2+(4-u)*t-4

def optimum (u r : ℝ) : ℝ := (4+u*r)/r^3

def rootV (u r : ℝ) : ℝ := 4*(1-r)/r^3+u*(1-2*r)/r^2

def Feasible (u v t b : ℝ) : Prop :=
  0 < A1 u v t b ∧ D t b < L u v t ∧ 0 < A3 u v t b ∧ 0 < R u v t b

def UD (u v t : ℝ) : ℝ := L u v t / c t

def UM (u v t : ℝ) : ℝ := (4+2*u*t+v*t^2)/t^2

theorem root_identity {u v r : ℝ} (hr : 0 < r) (hf : f u v r = 0) :
    v = rootV u r := by
  unfold rootV
  field_simp [ne_of_gt hr]
  unfold f at hf
  nlinarith [hf]

-- The following polynomial identities are proved by field normalization and ring arithmetic.
theorem optimum_boundary_identity (u r : ℝ) (hr : r ≠ 0) :
    A3 u (rootV u r) r (optimum u r) = 0 := by
  unfold A3 rootV optimum
  field_simp
  ring

theorem third_root_gap (u r : ℝ) (hr : r ≠ 0) :
    L u (rootV u r) r - D r (optimum u r) =
      (6-4*r+u*r*(1-r))/(2*r^2) := by
  unfold L D c rootV optimum
  field_simp
  ring

theorem a1_at_optimum (u r : ℝ) (hr : r ≠ 0) :
    A1 u (rootV u r) r (optimum u r) =
      2*(u*r*(1-r)+6-4*r)/r^2 := by
  unfold A1 rootV optimum
  field_simp
  ring

theorem a3_at_optimum (u r t : ℝ) (hr : r ≠ 0) :
    A3 u (rootV u r) t (optimum u r) =
      2*(r-t)*(r*t*u+2*r+2*t)/r^2 := by
  unfold A3 rootV optimum
  field_simp
  ring

theorem determinant_below_optimum (u r e : ℝ) (hr : r ≠ 0) :
    R u (rootV u r) r (optimum u r-e) =
      2*(1-r)*(u*r*(1-r)+8-4*r)/r*e + 2*r*(1-r)^2*e^2 := by
  unfold R A0 A1 A2 A3 rootV optimum
  field_simp
  ring

def q0 (u r : ℝ) : ℝ :=
  4/r^4*(r^2*u^2*(1-r)+2*r*u*(2-r^2)+8)

def q1 (u r : ℝ) : ℝ :=
  2/r^4*(r^3*u^2*(1-r)+2*r^2*u*(2-r)+8*((1-r)^2+1))

def q2 (u r : ℝ) : ℝ :=
  4/r^4*(r^2*u^2*(1-r)^2+4*r*u*(1-r)*(3-2*r)+
    8*(2*(1-r)^2+2*(1-r)+1))

def Q (u r t : ℝ) : ℝ :=
  q0 u r*(1-t/r)^2 + 2*q1 u r*(t/r)*(1-t/r) + q2 u r*(t/r)^2

theorem bernstein_identity (u r t : ℝ) (hr : r ≠ 0) :
    R u (rootV u r) t (optimum u r) = (t-r)*Q u r t := by
  unfold R A0 A1 A2 A3 rootV optimum Q q0 q1 q2
  field_simp
  ring

theorem bernstein_coefficients_positive {u r : ℝ}
    (hu : 0 < u) (hr : 0 < r) (hr1 : r < 1) :
    0 < q0 u r ∧ 0 < q1 u r ∧ 0 < q2 u r := by
  have h1 : 0 < 1-r := sub_pos.mpr hr1
  have h2 : 0 < 2-r := by linarith
  have h3 : 0 < 3-2*r := by linarith
  have h4 : 0 < 2-r^2 := by nlinarith [mul_pos hr h1]
  unfold q0 q1 q2
  constructor
  · positivity
  constructor <;> positivity

theorem bernstein_positive {u r t : ℝ}
    (hu : 0 < u) (hr : 0 < r) (hr1 : r < 1) (ht : 0 < t) (htr : t < r) :
    0 < Q u r t := by
  obtain ⟨h0,h1,h2⟩ := bernstein_coefficients_positive hu hr hr1
  have hx : 0 < t/r := div_pos ht hr
  have hx1 : t/r < 1 := (div_lt_one hr).mpr htr
  have hrem : 0 < 1-t/r := sub_pos.mpr hx1
  unfold Q
  positivity

theorem determinant_at_optimum_negative {u v r t : ℝ}
    (hu : 0 < u) (hr : 0 < r) (hr1 : r < 1) (hf : f u v r = 0)
    (ht : 0 < t) (htr : t < r) : R u v t (optimum u r) < 0 := by
  rw [root_identity hr hf, bernstein_identity u r t (ne_of_gt hr)]
  exact mul_neg_of_neg_of_pos (sub_neg.mpr htr) (bernstein_positive hu hr hr1 ht htr)

theorem root_sign_identity (u v r t : ℝ) (hr : r ≠ 0) (ht : t ≠ 0) :
    f u v t/t = f u v r/r + (t-r)*(v*(t+r)+2*u+4/(t*r)) := by
  unfold f
  field_simp
  ring

theorem root_sign_below {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hf : f u v r = 0)
    (ht : 0 < t) (htr : t < r) : f u v t/t < 0 := by
  rw [root_sign_identity u v r t (ne_of_gt hr) (ne_of_gt ht), hf]
  simp only [zero_div, zero_add]
  apply mul_neg_of_neg_of_pos (sub_neg.mpr htr)
  positivity

theorem optimum_positive {u r : ℝ} (hu : 0 < u) (hr : 0 < r) :
    0 < optimum u r := by unfold optimum; positivity


theorem feasible_below_optimum {u v r b : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (hb : 0 < b) (hbopt : b < optimum u r) :
    Feasible u v r b := by
  have hvr := root_identity hr hf
  have he : 0 < optimum u r-b := sub_pos.mpr hbopt
  have hrem : 0 < 1-r := sub_pos.mpr hr1
  have h68 : 0 < 6-4*r := by linarith
  have h88 : 0 < 8-4*r := by linarith
  have hA1star : 0 < A1 u v r (optimum u r) := by
    rw [hvr, a1_at_optimum u r (ne_of_gt hr)]
    have hn : 0 < u*r*(1-r)+6-4*r := by nlinarith [mul_pos (mul_pos hu hr) hrem]
    positivity
  have hA1 : 0 < A1 u v r b := by
    by_cases hs : 0 ≤ 2*r-1
    · unfold A1
      have : 0 ≤ (2*r-1)*b := mul_nonneg hs (le_of_lt hb)
      have : 0 < (2*r+1)*v := mul_pos (by linarith) hv
      nlinarith
    · have hs' : 2*r-1 < 0 := lt_of_not_ge hs
      have hprod := mul_neg_of_neg_of_pos hs' he
      unfold A1 at hA1star ⊢
      nlinarith
  have hgap : 0 < L u v r-D r (optimum u r) := by
    rw [hvr, third_root_gap u r (ne_of_gt hr)]
    positivity
  have hcc : 0 ≤ c r := by unfold c; positivity
  have hD : D r b ≤ D r (optimum u r) := by
    unfold D
    exact mul_le_mul_of_nonneg_right (le_of_lt hbopt) hcc
  have hA3star : A3 u v r (optimum u r) = 0 := by
    rw [hvr, optimum_boundary_identity u r (ne_of_gt hr)]
  have hA3 : 0 < A3 u v r b := by
    have hrr : 0 < r^2 := sq_pos_of_pos hr
    have hh := mul_pos he hrr
    unfold A3 at hA3star ⊢
    nlinarith
  have hR : 0 < R u v r b := by
    have hid := determinant_below_optimum u r (optimum u r-b) (ne_of_gt hr)
    have hbident : optimum u r-(optimum u r-b)=b := by ring
    rw [hbident] at hid
    rw [hvr,hid]
    have hn : 0 < u*r*(1-r)+8-4*r := by nlinarith [mul_pos (mul_pos hu hr) hrem]
    positivity
  exact ⟨hA1,by linarith,hA3,hR⟩

theorem upper_bounds {u v t b : ℝ} (ht : 0 < t) (ht1 : t < 1)
    (hD : D t b < L u v t) (hA3 : 0 < A3 u v t b) :
    b < UD u v t ∧ b < UM u v t := by
  have hc : 0 < c t := by
    have hh : 0 < 1-t := sub_pos.mpr ht1
    unfold c
    positivity
  have htt : 0 < t^2 := sq_pos_of_pos ht
  constructor
  · unfold UD
    apply (lt_div_iff₀ hc).mpr
    exact hD
  · unfold UM
    apply (lt_div_iff₀ htt).mpr
    unfold A3 at hA3
    nlinarith

theorem a3_nonnegative_of_le_um {u v t b : ℝ} (ht : 0 < t)
    (hb : b ≤ UM u v t) : 0 ≤ A3 u v t b := by
  unfold UM at hb
  have hh := (le_div_iff₀ (sq_pos_of_pos ht)).mp hb
  unfold A3
  nlinarith

theorem d_le_of_le_ud {u v t b : ℝ} (ht1 : t < 1)
    (hb : b ≤ UD u v t) : D t b ≤ L u v t := by
  have hc : 0 < c t := by
    have hh : 0 < 1-t := sub_pos.mpr ht1
    unfold c
    positivity
  exact (le_div_iff₀ hc).mp hb

theorem r_at_ud (u v t : ℝ) (ht1 : t ≠ 1) :
    R u v t (UD u v t) = -8*L u v t*A3 u v t (UD u v t) := by
  have hh : 1-t ≠ 0 := sub_ne_zero.mpr (Ne.symm ht1)
  unfold R A0 A1 A2 A3 UD L c
  field_simp [hh]
  ring

theorem r_at_um (u v t : ℝ) (ht : t ≠ 0) :
    R u v t (UM u v t) =
      8*(L u v t-D t (UM u v t))*(f u v t/t) := by
  unfold R A0 A1 A2 A3 UM L D c f
  field_simp
  ring

theorem determinant_chord (u v t x y z : ℝ) :
    (z-x)*R u v t y = (z-y)*R u v t x + (y-x)*R u v t z -
      (2*t*(1-t)^2)*(y-x)*(z-y)*(z-x) := by
  unfold R A0 A1 A2 A3
  ring

theorem determinant_nonpositive_between {u v t x y z : ℝ}
    (ht : 0 ≤ t) (hxz : x < z) (hxy : x ≤ y) (hyz : y ≤ z)
    (hx : R u v t x ≤ 0) (hz : R u v t z ≤ 0) : R u v t y ≤ 0 := by
  have h0 : 0 ≤ z-y := sub_nonneg.mpr hyz
  have h1 : 0 ≤ y-x := sub_nonneg.mpr hxy
  have h2 : 0 < z-x := sub_pos.mpr hxz
  have hleft : (z-y)*R u v t x ≤ 0 := mul_nonpos_of_nonneg_of_nonpos h0 hx
  have hright : (y-x)*R u v t z ≤ 0 := mul_nonpos_of_nonneg_of_nonpos h1 hz
  have hterm : 0 ≤ (2*t*(1-t)^2)*(y-x)*(z-y)*(z-x) := by positivity
  have hid := determinant_chord u v t x y z
  have htotal : (z-x)*R u v t y ≤ 0 := by linarith
  by_contra hn
  have hp := mul_pos h2 (lt_of_not_ge hn)
  linarith

theorem global_gain_bound {u v r t b : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (hfeas : Feasible u v t b) : b < optimum u r := by
  obtain ⟨hA1,hD,hA3,hR⟩ := hfeas
  by_contra hb
  have hb : optimum u r ≤ b := le_of_not_gt hb
  have hbpos : 0 < b := lt_of_lt_of_le (optimum_positive hu hr) hb
  have hvr := root_identity hr hf
  have hrem : 0 < 1-r := sub_pos.mpr hr1
  have hdelta : 2*u+v-optimum u r < 0 := by
    have hid : 2*u+v-optimum u r = (2*u*r^3-2*u*r^2-4*r)/r^3 := by
      rw [hvr]
      unfold rootV optimum
      field_simp
      ring
    rw [hid]
    have hneg : 2*u*r^3-2*u*r^2-4*r < 0 := by
      have hh : 0 < 2*u*r^2*(1-r)+4*r := by positivity
      nlinarith
    exact div_neg_of_neg_of_pos hneg (pow_pos hr 3)
  have ht : 0 < t := by
    by_contra ht
    have ht : t ≤ 0 := le_of_not_gt ht
    have hprod : 2*t*(b+v) ≤ 0 := mul_nonpos_of_nonpos_of_nonneg (by linarith) (by linarith)
    unfold A1 at hA1
    linarith
  have htr : t < r := by
    by_contra htr
    have hrt : r ≤ t := le_of_not_gt htr
    have hbound : A3 u v t (optimum u r) ≤ 0 := by
      rw [hvr,a3_at_optimum u r t (ne_of_gt hr)]
      apply div_nonpos_of_nonpos_of_nonneg
      · apply mul_nonpos_of_nonpos_of_nonneg
        · nlinarith
        · positivity
      · positivity
    have hdecrease : A3 u v t b ≤ A3 u v t (optimum u r) := by
      have hprod := mul_nonneg (sub_nonneg.mpr hb) (sq_nonneg t)
      unfold A3
      nlinarith
    linarith
  have ht1 : t < 1 := lt_trans htr hr1
  have hL : 0 < L u v t := by unfold L; positivity
  obtain ⟨hbUD,hbUM⟩ := upper_bounds ht ht1 hD hA3
  let U := min (UD u v t) (UM u v t)
  have hbU : b < U := lt_min hbUD hbUM
  have hoptU : optimum u r < U := lt_of_le_of_lt hb hbU
  have hRU : R u v t U ≤ 0 := by
    by_cases hcase : UD u v t ≤ UM u v t
    · have hU : U = UD u v t := min_eq_left hcase
      rw [hU,r_at_ud u v t (ne_of_lt ht1)]
      have hn := a3_nonnegative_of_le_um ht hcase
      exact mul_nonpos_of_nonpos_of_nonneg (by nlinarith) hn
    · have hcase : UM u v t ≤ UD u v t := le_of_lt (lt_of_not_ge hcase)
      have hU : U = UM u v t := min_eq_right hcase
      rw [hU,r_at_um u v t (ne_of_gt ht)]
      have hgap := d_le_of_le_ud ht1 hcase
      have hsign := root_sign_below hu hv hr hf ht htr
      exact mul_nonpos_of_nonneg_of_nonpos (by nlinarith) (le_of_lt hsign)
  have hRopt := determinant_at_optimum_negative hu hr hr1 hf ht htr
  have hnonpos := determinant_nonpositive_between (le_of_lt ht) hoptU hb
    (le_of_lt hbU) (le_of_lt hRopt) hRU
  linarith


theorem exists_unique_optimal_root {u v : ℝ} (hu : 0 < u) (hv : 0 < v) :
    ∃! r : ℝ, 0 < r ∧ r < 1 ∧ f u v r = 0 := by
  have hc : Continuous (fun t : ℝ => f u v t) := by unfold f; fun_prop
  have htarget : (0:ℝ) ∈ Set.Icc (f u v 0) (f u v 1) := by
    constructor <;> unfold f <;> norm_num; linarith
  obtain ⟨r,hr,hfr⟩ := intermediate_value_Icc (show (0:ℝ) ≤ 1 by norm_num)
    hc.continuousOn htarget
  have hr0 : 0 < r := by
    have hneq : r ≠ 0 := by intro h; subst r; norm_num [f] at hfr
    exact lt_of_le_of_ne hr.1 (Ne.symm hneq)
  have hr1 : r < 1 := by
    have hneq : r ≠ 1 := by intro h; subst r; norm_num [f] at hfr; linarith
    exact lt_of_le_of_ne hr.2 hneq
  refine ⟨r,⟨hr0,hr1,hfr⟩,?_⟩
  intro y hy
  by_contra hne
  rcases lt_or_gt_of_ne hne with hyr | hry
  · have hh := root_sign_below hu hv hr0 hfr hy.1 hyr
    rw [hy.2.2,zero_div] at hh
    linarith
  · have hh := root_sign_below hu hv hy.1 hy.2.2 hr0 hry
    change f u v r = 0 at hfr
    rw [hfr,zero_div] at hh
    linarith

theorem scaled_cubicSchur_iff (l b c d : ℝ) (hl : 0 < l) :
    C2.CubicSchur (b/l) (c/l) (d/l) ↔
      |d| < l ∧ 0 < l+b+c+d ∧ 0 < l-b+c-d ∧ 0 < l^2-l*c+b*d-d^2 := by
  rw [C2.cubicSchur_iff]
  have h0 : |d/l| = |d|/l := by rw [abs_div,abs_of_pos hl]
  have h1 : 1+b/l+c/l+d/l = (l+b+c+d)/l := by field_simp
  have h2 : 1-b/l+c/l-d/l = (l-b+c-d)/l := by field_simp
  have h3 : 1-c/l+(b/l)*(d/l)-(d/l)^2 = (l^2-l*c+b*d-d^2)/l^2 := by
    field_simp
    ring
  rw [h0,h1,h2,h3,div_lt_one hl,div_pos_iff_of_pos_right hl,
    div_pos_iff_of_pos_right hl,div_pos_iff_of_pos_right (sq_pos_of_pos hl)]

-- The real coefficients of the paper's characteristic polynomial.
def B (u v t b : ℝ) : ℝ := (A0 v b-A3 u v t b)/2-D t b

def C (u v t b : ℝ) : ℝ := (A0 v b+A3 u v t b)/2-L u v t

def Schur (u v t b : ℝ) : Prop :=
  C2.CubicSchur (B u v t b/L u v t) (C u v t b/L u v t) (D t b/L u v t)

theorem plus_endpoint_identity (u v t b : ℝ) :
    L u v t+B u v t b+C u v t b+D t b = b+v := by
  unfold B C A0
  ring

theorem minus_endpoint_identity (u v t b : ℝ) :
    L u v t-B u v t b+C u v t b-D t b = A3 u v t b := by
  unfold B C A0
  ring

theorem jury_determinant_identity (u v t b : ℝ) :
    8*(L u v t^2-L u v t*C u v t b+B u v t b*D t b-D t b^2) = R u v t b := by
  unfold B C L D c R A0 A1 A2 A3
  ring

theorem cayley_sum_identity (u v t b : ℝ) :
    A1 u v t b+A2 u v t b = 6*L u v t-2*C u v t b := by
  unfold C L A1 A2 A0 A3
  ring

theorem schur_iff_feasible {u v t b : ℝ}
    (hu : 0 < u) (hv : 0 < v) (ht : -1 ≤ t) (hb : 0 < b) :
    Schur u v t b ↔ Feasible u v t b := by
  have htp : 0 ≤ 1+t := by linarith
  have hl : 0 < L u v t := by unfold L; positivity
  have hd : 0 ≤ D t b := by unfold D c; positivity
  have hp : 0 < b+v := by linarith
  have he := jury_determinant_identity u v t b
  unfold Schur
  rw [scaled_cubicSchur_iff _ _ _ _ hl,abs_of_nonneg hd,
    plus_endpoint_identity,minus_endpoint_identity]
  constructor
  · rintro ⟨hD,hplus,hminus,hJ⟩
    have hR : 0 < R u v t b := by linarith
    have hsum : 0 < A1 u v t b+A2 u v t b := by
      have hm := minus_endpoint_identity u v t b
      have hdm : 0 ≤ D t b * A3 u v t b := mul_nonneg hd (le_of_lt hminus)
      have hprod : (L u v t-D t b)*(L u v t+2*D t b-C u v t b) > 0 := by
        nlinarith [he]
      have hc : C u v t b < L u v t+2*D t b := by
        by_contra hh
        have hh : L u v t+2*D t b-C u v t b ≤ 0 := by linarith
        have hbad := mul_nonpos_of_nonneg_of_nonpos (sub_nonneg.mpr (le_of_lt hD)) hh
        linarith
      rw [cayley_sum_identity]
      linarith
    have hA1 : 0 < A1 u v t b := by
      have hprod : 0 < A1 u v t b*A2 u v t b := by
        unfold R A0 at hR
        have hh := mul_pos hp hminus
        linarith
      by_contra hh
      have hh : A1 u v t b ≤ 0 := le_of_not_gt hh
      have hh2 : 0 < A2 u v t b := by linarith
      have hbad := mul_nonpos_of_nonpos_of_nonneg hh (le_of_lt hh2)
      linarith
    exact ⟨hA1,hD,hminus,hR⟩
  · rintro ⟨hA1,hD,hminus,hR⟩
    exact ⟨hD,hp,hminus,by linarith⟩

theorem schur_below_optimum {u v r b : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (hb : 0 < b) (hbopt : b < optimum u r) :
    Schur u v r b := by
  apply (schur_iff_feasible hu hv (by linarith) hb).mpr
  exact feasible_below_optimum hu hv hr hr1 hf hb hbopt

theorem schur_global_gain_bound {u v r t b : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (ht : -1 ≤ t) (hb : 0 < b)
    (hs : Schur u v t b) : b < optimum u r := by
  exact global_gain_bound hu hv hr hr1 hf ((schur_iff_feasible hu hv ht hb).mp hs)

theorem schur_at_optimal_parameter_iff {u v r b : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (hb : 0 < b) :
    Schur u v r b ↔ b < optimum u r := by
  constructor
  · exact schur_global_gain_bound hu hv hr hr1 hf (by linarith) hb
  · exact schur_below_optimum hu hv hr hr1 hf hb

/-- At the global gain boundary, the closed necessary Schur inequalities
can hold only at the uniquely optimizing parameter. -/
theorem closed_boundary_unique {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0)
    (hA1 : 0 ≤ A1 u v t (optimum u r))
    (hA3 : 0 ≤ A3 u v t (optimum u r))
    (hR : 0 ≤ R u v t (optimum u r)) : t = r := by
  have hvr := root_identity hr hf
  have hrem : 0 < 1-r := sub_pos.mpr hr1
  have hdelta : 2*u+v-optimum u r < 0 := by
    have hid : 2*u+v-optimum u r = (2*u*r^3-2*u*r^2-4*r)/r^3 := by
      rw [hvr]
      unfold rootV optimum
      field_simp
      ring
    rw [hid]
    have hneg : 2*u*r^3-2*u*r^2-4*r < 0 := by
      have hh : 0 < 2*u*r^2*(1-r)+4*r := by positivity
      nlinarith
    exact div_neg_of_neg_of_pos hneg (pow_pos hr 3)
  have ht : 0 < t := by
    by_contra ht
    have ht : t ≤ 0 := le_of_not_gt ht
    have hbpos := optimum_positive hu hr
    have hprod : 2*t*(optimum u r+v) ≤ 0 :=
      mul_nonpos_of_nonpos_of_nonneg (by linarith) (by linarith)
    unfold A1 at hA1
    linarith
  rcases lt_trichotomy t r with htr | heq | hrt
  · have hneg := determinant_at_optimum_negative hu hr hr1 hf ht htr
    linarith
  · exact heq
  · have hneg : A3 u v t (optimum u r) < 0 := by
      rw [hvr,a3_at_optimum u r t (ne_of_gt hr)]
      apply div_neg_of_neg_of_pos
      · apply mul_neg_of_neg_of_pos
        · nlinarith
        · positivity
      · positivity
    linarith

/-- Closed global result: the unique cubic root exists for every stable
second-order denominator, and its parameter attains the sharp global supremum. -/
theorem second_order_global_optimum {u v : ℝ} (hu : 0 < u) (hv : 0 < v) :
    ∃ r : ℝ, 0 < r ∧ r < 1 ∧ f u v r = 0 ∧
      (∀ b : ℝ, 0 < b → (Schur u v r b ↔ b < optimum u r)) ∧
      (∀ t b : ℝ, -1 ≤ t → 0 < b → Schur u v t b → b < optimum u r) := by
  obtain ⟨r,⟨hr,hr1,hf⟩,_⟩ := exists_unique_optimal_root hu hv
  exact ⟨r,hr,hr1,hf,
    fun _ hb => schur_at_optimal_parameter_iff hu hv hr hr1 hf hb,
    fun _ _ ht hb hs => schur_global_gain_bound hu hv hr hr1 hf ht hb hs⟩

/-- All positive stable gains, including every connected component. -/
def stableGains (u v t : ℝ) : Set ℝ := {b | 0 < b ∧ Schur u v t b}

theorem stableGains_at_optimum {u v r : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) : stableGains u v r = Set.Ioo 0 (optimum u r) := by
  ext b
  constructor
  · rintro ⟨hb,hs⟩
    exact ⟨hb,(schur_at_optimal_parameter_iff hu hv hr hr1 hf hb).mp hs⟩
  · rintro ⟨hb,hbo⟩
    exact ⟨hb,schur_below_optimum hu hv hr hr1 hf hb hbo⟩

theorem optimal_gain_isLUB {u v r : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) : IsLUB (stableGains u v r) (optimum u r) := by
  rw [stableGains_at_optimum hu hv hr hr1 hf]
  exact isLUB_Ioo (optimum_positive hu hr)

/-- Uniqueness is about the supremum of every stable gain, not a grid
search and not merely the first stability interval. -/
theorem optimal_parameter_unique {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (ht : -1 ≤ t)
    (hsup : IsLUB (stableGains u v t) (optimum u r)) : t = r := by
  have hcl := hsup.mem_closure hsup.nonempty
  have hclosed : IsClosed {b : ℝ | 0 ≤ A1 u v t b ∧ 0 ≤ A3 u v t b ∧ 0 ≤ R u v t b} := by
    apply IsClosed.inter
    · apply isClosed_le (f := fun _ : ℝ => (0:ℝ)) (g := fun b : ℝ => A1 u v t b) continuous_const
      unfold A1
      fun_prop
    · apply IsClosed.inter
      · apply isClosed_le (f := fun _ : ℝ => (0:ℝ)) (g := fun b : ℝ => A3 u v t b) continuous_const
        unfold A3
        fun_prop
      · apply isClosed_le (f := fun _ : ℝ => (0:ℝ)) (g := fun b : ℝ => R u v t b) continuous_const
        unfold R A0 A1 A2 A3
        fun_prop
  have hsubset : stableGains u v t ⊆
      {b : ℝ | 0 ≤ A1 u v t b ∧ 0 ≤ A3 u v t b ∧ 0 ≤ R u v t b} := by
    intro b hb
    obtain ⟨h1,_,h3,hR⟩ := (schur_iff_feasible hu hv ht hb.1).mp hb.2
    exact ⟨le_of_lt h1,le_of_lt h3,le_of_lt hR⟩
  obtain ⟨h1,h3,hR⟩ := closure_minimal hsubset hclosed hcl
  exact closed_boundary_unique hu hv hr hr1 hf h1 h3 hR

/-- At any other admissible parameter with a nonempty stable set,
the entire stable-gain supremum is strictly smaller. -/
theorem suboptimal_parameter_strict {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (ht : -1 ≤ t) (hne : t ≠ r)
    (hset : (stableGains u v t).Nonempty) :
    sSup (stableGains u v t) < optimum u r := by
  have hbound : ∀ b ∈ stableGains u v t, b ≤ optimum u r := by
    intro b hb
    exact le_of_lt (schur_global_gain_bound hu hv hr hr1 hf ht hb.1 hb.2)
  have hbdd : BddAbove (stableGains u v t) := ⟨optimum u r,hbound⟩
  have hle : sSup (stableGains u v t) ≤ optimum u r := csSup_le hset hbound
  apply lt_of_le_of_ne hle
  intro heq
  have his := isLUB_csSup hset hbdd
  rw [heq] at his
  exact hne (optimal_parameter_unique hu hv hr hr1 hf ht his)

/-- Complete existence and uniqueness of the maximizing discretization,
expressed through the genuine root stability predicate. -/
theorem exists_unique_global_optimizer {u v : ℝ} (hu : 0 < u) (hv : 0 < v) :
    ∃ r : ℝ, 0 < r ∧ r < 1 ∧ f u v r = 0 ∧
      ∃! t : ℝ, -1 ≤ t ∧ t ≤ 1 ∧ IsLUB (stableGains u v t) (optimum u r) := by
  obtain ⟨r,⟨hr,hr1,hf⟩,_⟩ := exists_unique_optimal_root hu hv
  refine ⟨r,hr,hr1,hf,r,⟨by linarith,by linarith,optimal_gain_isLUB hu hv hr hr1 hf⟩,?_⟩
  intro t ht
  exact optimal_parameter_unique hu hv hr hr1 hf ht.1 ht.2.2

theorem root_sign_above {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hf : f u v r = 0)
    (ht : 0 < t) (hrt : r < t) : 0 < f u v t/t := by
  rw [root_sign_identity u v r t (ne_of_gt hr) (ne_of_gt ht), hf]
  simp only [zero_div, zero_add]
  apply mul_pos (sub_pos.mpr hrt)
  positivity

theorem root_lt_iff {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hf : f u v r = 0)
    (ht : 0 < t) : r < t ↔ 0 < f u v t := by
  constructor
  · intro hrt
    exact (div_pos_iff_of_pos_right ht).mp (root_sign_above hu hv hr hf ht hrt)
  · intro hp
    by_contra hrt
    rcases lt_or_eq_of_le (le_of_not_gt hrt) with htr | heq
    · have hh := root_sign_below hu hv hr hf ht htr
      have hh2 := div_pos hp ht
      linarith
    · rw [heq,hf] at hp
      linarith

theorem root_gt_iff {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hf : f u v r = 0)
    (ht : 0 < t) : t < r ↔ f u v t < 0 := by
  constructor
  · intro htr
    have hh := root_sign_below hu hv hr hf ht htr
    by_contra hn
    have hn := div_nonneg (le_of_not_gt hn) (le_of_lt ht)
    linarith
  · intro hn
    by_contra htr
    rcases lt_or_eq_of_le (le_of_not_gt htr) with hrt | heq
    · have hh := (root_lt_iff hu hv hr hf ht).mp hrt
      linarith
    · rw [← heq,hf] at hn
      linarith

/-- The sharp transition at gamma = 3/4 depends only on v = a₀ T². -/
theorem three_quarter_regime {u v r : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hf : f u v r = 0) :
    (gamma r < 3/4 ↔ 16 < v) ∧
    (gamma r = 3/4 ↔ v = 16) ∧
    (3/4 < gamma r ↔ v < 16) := by
  have he : f u v (1/2) = v/8-2 := by unfold f; ring
  have hlo := root_lt_iff hu hv hr hf (show (0:ℝ) < 1/2 by norm_num)
  have hhi := root_gt_iff hu hv hr hf (show (0:ℝ) < 1/2 by norm_num)
  rw [he] at hlo hhi
  unfold gamma
  constructor
  · constructor
    · intro h
      have hh := hlo.mp (by linarith)
      linarith
    · intro h
      have hh := hlo.mpr (by linarith)
      linarith
  constructor
  · constructor
    · intro h
      have heq : r = 1/2 := by linarith
      rw [heq,he] at hf
      linarith
    · intro h
      have hnlo : ¬r < 1/2 := by rw [hlo,h]; norm_num
      have hnhi : ¬(1:ℝ)/2 < r := by rw [hhi,h]; norm_num
      linarith
  · constructor
    · intro h
      have hh := hhi.mp (by linarith)
      linarith
    · intro h
      have hh := hhi.mpr (by linarith)
      linarith

theorem optimum_difference (u x y : ℝ) (hx : x ≠ 0) (hy : y ≠ 0) :
    optimum u x-optimum u y =
      (y-x)*(4*(x^2+x*y+y^2)+u*x*y*(x+y))/(x^3*y^3) := by
  unfold optimum
  field_simp
  ring

theorem optimum_strict_antitone {u x y : ℝ}
    (hu : 0 < u) (hx : 0 < x) (hxy : x < y) : optimum u y < optimum u x := by
  have hy : 0 < y := lt_trans hx hxy
  have hh : 0 < optimum u x-optimum u y := by
    rw [optimum_difference u x y (ne_of_gt hx) (ne_of_gt hy)]
    have hdiff : 0 < y-x := sub_pos.mpr hxy
    positivity
  linarith

/-- Any valid positive root bracket immediately gives rigorous parameter
and gain brackets. The bisection algorithm itself is separate from this lemma. -/
theorem root_bracket_enclosures {u r lo hi : ℝ}
    (hu : 0 < u) (hlo : 0 < lo) (hlr : lo ≤ r) (hrh : r ≤ hi) :
    gamma lo ≤ gamma r ∧ gamma r ≤ gamma hi ∧
    optimum u hi ≤ optimum u r ∧ optimum u r ≤ optimum u lo := by
  have hr : 0 < r := lt_of_lt_of_le hlo hlr
  refine ⟨by unfold gamma; linarith,by unfold gamma; linarith,?_,?_⟩
  · rcases eq_or_lt_of_le hrh with h | h
    · rw [h]
    · exact le_of_lt (optimum_strict_antitone hu hr h)
  · rcases eq_or_lt_of_le hlr with h | h
    · rw [h]
    · exact le_of_lt (optimum_strict_antitone hu hlo h)

theorem optimum_formula {u v r : ℝ} (hr : 0 < r) (hf : f u v r = 0) :
    optimum u r = v+2*u/r+4/r^2 := by
  rw [root_identity hr hf]
  unfold optimum rootV
  field_simp
  ring

theorem optimal_gamma_range {r : ℝ} (hr : 0 < r) (hr1 : r < 1) :
    1/2 < gamma r ∧ gamma r < 1 := by
  unfold gamma
  constructor <;> linarith

/-- The same unique optimizer in the paper's gamma-coordinate. -/
theorem exists_unique_global_gamma_optimizer {u v : ℝ} (hu : 0 < u) (hv : 0 < v) :
    ∃ r : ℝ, 0 < r ∧ r < 1 ∧ f u v r = 0 ∧
      ∃! g : ℝ, 0 ≤ g ∧ g ≤ 1 ∧
        IsLUB (stableGains u v (2*g-1)) (optimum u r) := by
  obtain ⟨r,⟨hr,hr1,hf⟩,_⟩ := exists_unique_optimal_root hu hv
  have hgamma := optimal_gamma_range hr hr1
  have hg : 2*gamma r-1 = r := by unfold gamma; ring
  refine ⟨r,hr,hr1,hf,gamma r,⟨by linarith,by linarith,?_⟩,?_⟩
  · rw [hg]
    exact optimal_gain_isLUB hu hv hr hr1 hf
  · intro g h
    have heq := optimal_parameter_unique hu hv hr hr1 hf (t := 2*g-1) (by linarith [h.1]) h.2.2
    unfold gamma
    linarith

/-- Exact sign tests suffice to enclose the unique positive root. -/
theorem root_bracket_of_signs {u v r lo hi : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hf : f u v r = 0)
    (hlo : 0 < lo) (hhi : 0 < hi)
    (hfl : f u v lo ≤ 0) (hfh : 0 ≤ f u v hi) : lo ≤ r ∧ r ≤ hi := by
  constructor
  · by_contra h
    have hh := (root_lt_iff hu hv hr hf hlo).mp (lt_of_not_ge h)
    linarith
  · by_contra h
    have hh := (root_gt_iff hu hv hr hf hhi).mp (lt_of_not_ge h)
    linarith

theorem root_enclosures {u v r lo hi : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hf : f u v r = 0)
    (hlo : 0 < lo) (hhi : 0 < hi)
    (hfl : f u v lo ≤ 0) (hfh : 0 ≤ f u v hi) :
    gamma lo ≤ gamma r ∧ gamma r ≤ gamma hi ∧
    optimum u hi ≤ optimum u r ∧ optimum u r ≤ optimum u lo := by
  obtain ⟨hlr,hrh⟩ := root_bracket_of_signs hu hv hr hf hlo hhi hfl hfh
  exact root_bracket_enclosures hu hlo hlr hrh

theorem quarter_regime_gain (u : ℝ) : optimum u (1/2) = 32+4*u := by
  unfold optimum
  norm_num
  ring

end C2.SecondOrder
