import C2.TwoGammaExplicit
import C2.TwoGammaConnected
import C2.NGammaGlobalTheorems

/-! Actual-root global initial-margin theorem with the explicit two-factor
square-root formula. -/
noncomputable section
open scoped BigOperators
open Set
namespace C2.TwoGamma
open NGamma NGamma.PolynomialModel

def optimalVector (r₁ r₂ : ℝ) : Fin 2 → ℝ := ![optimalX r₁ r₂, optimalX r₂ r₁]

theorem two_factor_endpoint_sum_lt_one {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    Global.endpointSum (poles r₁ r₂) < 1 := by
  have ha : 1/(r₁+2) < (1:ℝ)/2 :=
    one_div_lt_one_div_of_lt (by norm_num) (by linarith)
  have hb : 1/(r₂+2) < (1:ℝ)/2 :=
    one_div_lt_one_div_of_lt (by norm_num) (by linarith)
  simpa [Global.endpointSum, poles, Fin.sum_univ_two] using (show 1/(r₁+2)+1/(r₂+2)<1 by linarith)

theorem optimalVector_eq_parameters {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    optimalVector r₁ r₂ = fun i => endpointParameter (poles r₁ r₂ i) (scalar r₁ r₂) := by
  funext i
  fin_cases i
  · simpa [optimalVector,poles] using optimalX_eq_parameter h₁ h₂
  · simpa [optimalVector,poles,scalar_comm] using optimalX_eq_parameter h₂ h₁

theorem optimal_allocation_product {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    (∏ i, endpointAllocation (poles r₁ r₂ i) (scalar r₁ r₂)) = gain r₁ r₂ := by
  simp only [Fin.prod_univ_two, poles, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons]
  rw [allocation_eq_endpoint h₁ h₂, ← scalar_comm r₁ r₂, allocation_eq_endpoint h₂ h₁]
  exact allocation_mul h₁ h₂

/-- Explicit full-square initial-margin optimum. The assertion about arbitrary
stable components outside the half-square is handled separately. -/
theorem explicit_initial_margin_optimum {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    initialGainMargin (poles r₁ r₂) (optimalVector r₁ r₂) 1 = gain r₁ r₂ ∧
    (∀ b : ℝ, 0 ≤ b →
      (SchurStable (PolynomialModel.characteristic (poles r₁ r₂) (optimalVector r₁ r₂) 1 b)
        ↔ b < gain r₁ r₂)) ∧
    (∃ z : ℂ, ‖z‖ = 1 ∧
      (PolynomialModel.characteristic (poles r₁ r₂) (optimalVector r₁ r₂) 1 (gain r₁ r₂)).eval z = 0) ∧
    ∀ x : Fin 2 → ℝ, (∀ i, x i ∈ Icc (-1:ℝ) 1) →
      initialGainMargin (poles r₁ r₂) x 1 ≤ gain r₁ r₂ ∧
      (initialGainMargin (poles r₁ r₂) x 1 = gain r₁ r₂ ↔ x = optimalVector r₁ r₂) := by
  have hr := poles_pos h₁ h₂
  obtain ⟨xs,Bs,hxs,hBs,hd,hm,hs,hroot,hfull⟩ :=
    Global.full_cube_initial_margin_global_theorem (by norm_num : 0 < (2:ℕ)) (poles r₁ r₂) hr
  have hsmall := two_factor_endpoint_sum_lt_one h₁ h₂
  obtain ⟨c,hc,hbudget,hxc,hBc⟩ := hd.2.2 hsmall
  obtain ⟨c₀,hc₀,hunique⟩ := existsUnique_endpoint_scalar (poles r₁ r₂) hr hsmall
  have he : c = scalar r₁ r₂ :=
    (hunique c ⟨hc,hbudget⟩).trans (hunique _ ⟨scalar_pos h₁ h₂,scalar_budget h₁ h₂⟩).symm
  have hx : xs = optimalVector r₁ r₂ := by
    rw [hxc,he,optimalVector_eq_parameters h₁ h₂]
  have hB : Bs = gain r₁ r₂ := by
    rw [hBc,he]
    exact optimal_allocation_product h₁ h₂
  simpa only [hx,hB] using And.intro hm (And.intro hs (And.intro hroot hfull))

theorem optimal_coordinates {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    coordinates (optimalGamma r₁ r₂) (optimalGamma r₂ r₁) = optimalVector r₁ r₂ := by
  funext i
  fin_cases i <;> simp [coordinates,optimalVector,optimalGamma,Parameterization.xOfGamma] <;> ring

/-- Exact interval for the displayed optimal gamma pair, including gain zero
and the exclusion of the boundary itself. -/
theorem optimal_pair_stable_iff {r₁ r₂ b : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂) (hb : 0 ≤ b) :
    SchurStable (characteristic r₁ r₂ (optimalGamma r₁ r₂) (optimalGamma r₂ r₁) b)
      ↔ b < gain r₁ r₂ := by
  rw [characteristic_eq_generic,optimal_coordinates h₁ h₂]
  exact (explicit_initial_margin_optimum h₁ h₂).2.1 b hb

theorem half_square_gain_bound {r₁ r₂ γ₁ γ₂ b : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂)
    (hg₁ : γ₁ ∈ Icc (1/2:ℝ) 1) (hg₂ : γ₂ ∈ Icc (1/2:ℝ) 1)
    (hb : 0 ≤ b) (hs : SchurStable (characteristic r₁ r₂ γ₁ γ₂ b)) : b < gain r₁ r₂ := by
  have hr := poles_pos h₁ h₂
  have hx := coordinates_in_half_cube hg₁ hg₂
  obtain ⟨B,hB⟩ := Global.criticalGain_exists (by norm_num : 0 < (2:ℕ))
    (poles r₁ r₂) (coordinates γ₁ γ₂) hr hx
  rw [characteristic_eq_generic] at hs
  have hbB := (Global.criticalGain_exact_interval (by norm_num) _ _ hr hx hB hb).mp hs
  have hle := ((explicit_initial_margin_optimum h₁ h₂).2.2.2 (coordinates γ₁ γ₂)
    (fun i => ⟨by linarith [(hx i).1],(hx i).2⟩)).1
  rw [Global.criticalGain_eq_initialMargin (by norm_num) _ _ hr hx hB] at hle
  exact lt_of_lt_of_le hbB hle

theorem optimalX_equal_iff {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    optimalX r₁ r₂ = optimalX r₂ r₁ ↔ r₁ = r₂ := by
  have hd : gain r₁ r₂+r₁*r₂ ≠ 0 := by have := gain_pos h₁ h₂; positivity
  unfold optimalX
  rw [gain_comm r₁ r₂]
  have hp : r₂*r₁ = r₁*r₂ := by ring
  rw [hp]
  rw [div_left_inj' hd]
  constructor <;> intro h <;> linarith

end C2.TwoGamma
