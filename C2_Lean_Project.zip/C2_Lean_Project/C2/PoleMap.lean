import Mathlib

/-! The actual complex-norm pole map for the common discretization parameter.
No stability predicate is replaced by a coefficient inequality in this file. -/

namespace C2

noncomputable def poleMap (T γ : ℝ) (ζ : ℂ) : ℂ :=
  (1 + (T * (1 - γ) : ℝ) * ζ) / (1 - (T * γ : ℝ) * ζ)

theorem norm_lt_one_iff_normSq_lt_one (z : ℂ) :
    ‖z‖ < 1 ↔ Complex.normSq z < 1 := by
  have hn := norm_nonneg z
  have hs := Complex.sq_norm z
  constructor <;> intro h <;> nlinarith

theorem poleMap_normSq_difference (T γ : ℝ) (ζ : ℂ) :
    Complex.normSq (1 + (T * (1 - γ) : ℝ) * ζ) -
      Complex.normSq (1 - (T * γ : ℝ) * ζ) =
      T * (2 * ζ.re + (1 - 2 * γ) * T * Complex.normSq ζ) := by
  simp [Complex.normSq_apply, Complex.add_re, Complex.add_im,
    Complex.sub_re, Complex.sub_im, Complex.mul_re, Complex.mul_im]
  ring

theorem poleMap_mem_unitDisk_iff (T γ : ℝ) (ζ : ℂ) (hT : 0 < T)
    (hd : (1 - (T * γ : ℝ) * ζ : ℂ) ≠ 0) :
    ‖poleMap T γ ζ‖ < 1 ↔
      2 * ζ.re + (1 - 2 * γ) * T * Complex.normSq ζ < 0 := by
  rw [norm_lt_one_iff_normSq_lt_one, poleMap, Complex.normSq_div]
  have hp : 0 < Complex.normSq (1 - (T * γ : ℝ) * ζ : ℂ) :=
    Complex.normSq_pos.mpr hd
  rw [div_lt_one hp, ← sub_neg, poleMap_normSq_difference]
  constructor
  · intro h
    by_contra h'
    have hp := mul_nonneg hT.le (le_of_not_gt h')
    linarith
  · intro h
    exact mul_neg_of_pos_of_neg hT h

theorem poleMap_denominator_ne_zero (T γ : ℝ) (ζ : ℂ)
    (hT : 0 < T) (hγ : 0 ≤ γ) (hζ : ζ.re < 0) :
    (1 - (T * γ : ℝ) * ζ : ℂ) ≠ 0 := by
  intro he
  have hr := congrArg Complex.re he
  simp only [Complex.sub_re, Complex.one_re, Complex.mul_re,
    Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero,
    Complex.zero_re] at hr
  have hp : 0 ≤ T * γ := mul_nonneg hT.le hγ
  have hnonpos : T * γ * ζ.re ≤ 0 := mul_nonpos_of_nonneg_of_nonpos hp hζ.le
  linarith

theorem poleMap_preserves_leftHalfPlane (T γ : ℝ) (ζ : ℂ)
    (hT : 0 < T) (hγ : 1 / 2 ≤ γ) (hζ : ζ.re < 0) :
    ‖poleMap T γ ζ‖ < 1 := by
  have hg : 0 ≤ γ := by linarith
  apply (poleMap_mem_unitDisk_iff T γ ζ hT
    (poleMap_denominator_ne_zero T γ ζ hT hg hζ)).mpr
  have hc : 1 - 2 * γ ≤ 0 := by linarith
  have hs := Complex.normSq_nonneg ζ
  have ht : (1 - 2 * γ) * T * Complex.normSq ζ ≤ 0 :=
    mul_nonpos_of_nonpos_of_nonneg (mul_nonpos_of_nonpos_of_nonneg hc hT.le) hs
  linarith

end C2
