import C2.GeneralBoundaryCandidates
import C2.GeneralBoundaryChebyshevDegree

/-! At most L+1 candidate points and retained gains for deg H=L. -/
noncomputable section
open Polynomial Set

namespace C2.GeneralBoundaryCandidates

theorem real_zero_set_ncard_le {p : ℝ[X]} (hp : p ≠ 0) :
    ({x : ℝ | p.eval x = 0} : Set ℝ).ncard ≤ p.natDegree := by
  classical
  have he : ({x : ℝ | p.eval x = 0} : Set ℝ) = (p.roots.toFinset : Set ℝ) := by
    ext x
    simp only [Set.mem_setOf_eq, Finset.mem_coe, Multiset.mem_toFinset,
      Polynomial.mem_roots hp, Polynomial.IsRoot]
  rw [he, Set.ncard_coe_Finset]
  exact (Multiset.toFinset_card_le _).trans (Polynomial.card_roots' p)

theorem candidatePoints_ncard_le (H N : ℝ[X]) (hQ : Q H N ≠ 0) :
    (candidatePoints H N).ncard ≤ (Q H N).natDegree + 2 := by
  have hroots : ({x : ℝ | (Q H N).eval x = 0} : Set ℝ).Finite := by
    simpa only [Polynomial.IsRoot] using Polynomial.finite_setOf_isRoot hQ
  have hinter : (Ioo (-1 : ℝ) 1 ∩ {x | (Q H N).eval x = 0}).Finite :=
    hroots.inter_of_right _
  have himage := Set.ncard_image_le (f := upperPoint) hinter
  have hinter := Set.ncard_inter_le_ncard_right (Ioo (-1 : ℝ) 1)
    {x | (Q H N).eval x = 0} hroots
  have hzero := real_zero_set_ncard_le hQ
  have hpair : ({(1 : ℂ), -1} : Set ℂ).ncard = 2 := Set.ncard_pair (by norm_num)
  unfold candidatePoints
  have hu := Set.ncard_union_le ({(1 : ℂ), -1} : Set ℂ)
    (upperPoint '' (Ioo (-1 : ℝ) 1 ∩ {x | (Q H N).eval x = 0}))
  rw [hpair] at hu
  omega

theorem candidateGains_ncard_le_points (H N : ℝ[X]) (hQ : Q H N ≠ 0) :
    (candidateGains H N).ncard ≤ (candidatePoints H N).ncard := by
  have hp := candidatePoints_finite hQ
  have hsub : candidateGains H N ⊆ gainAt H N '' candidatePoints H N := by
    rintro k ⟨_, z, hz, _, hk⟩
    exact ⟨z, hz, hk.symm⟩
  exact (Set.ncard_le_ncard hsub (hp.image _)).trans (Set.ncard_image_le hp)

theorem candidate_cardinality_bound (H N : ℝ[X])
    (hN : N.natDegree ≤ H.natDegree) (hL : 0 < H.natDegree) (hQ : Q H N ≠ 0) :
    (candidatePoints H N).ncard ≤ H.natDegree + 1 ∧
      (candidateGains H N).ncard ≤ H.natDegree + 1 := by
  have hd := Q_natDegree_le H N hN
  have hp := candidatePoints_ncard_le H N hQ
  have hg := candidateGains_ncard_le_points H N hQ
  constructor <;> omega

end C2.GeneralBoundaryCandidates
