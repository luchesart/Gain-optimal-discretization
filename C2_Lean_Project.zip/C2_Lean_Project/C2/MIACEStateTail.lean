import C2.MIACETail

/-! The manuscript's exact remainder constant from a state-space envelope. -/

noncomputable section

namespace C2.MIACE

theorem state_output_tail_bound {V : Type*} [NormedAddCommGroup V] [NormedSpace ℝ V]
    (x : ℕ → V) (ce cu : V →L[ℝ] ℝ)
    {T Tmax C E U q η : ℝ} (hT : 0 ≤ T) (hTmax : T ≤ Tmax)
    (hq0 : 0 < q) (hq1 : q < 1) (hη : 0 ≤ η)
    (hx : ∀ n, ‖x n‖ ≤ C * q ^ n) (he : ‖ce‖ ≤ E) (hu : ‖cu‖ ≤ U) (N : ℕ) :
    0 ≤ cost η (area T (fun n => ce (x n))) (area T (fun n => cu (x n))) -
      cost η (partialArea T (fun n => ce (x n)) N) (partialArea T (fun n => cu (x n)) N) ∧
    cost η (area T (fun n => ce (x n))) (area T (fun n => cu (x n))) -
      cost η (partialArea T (fun n => ce (x n)) N) (partialArea T (fun n => cu (x n)) N) ≤
        (Tmax * C * q ^ N / (1 - q)) * Real.sqrt (E ^ 2 + η * U ^ 2) := by
  have hC : 0 ≤ C := by simpa using (norm_nonneg (x 0)).trans (hx 0)
  have hE : 0 ≤ E := (norm_nonneg ce).trans he
  have hU : 0 ≤ U := (norm_nonneg cu).trans hu
  have hbe : ∀ n, |ce (x n)| ≤ (C * E) * q ^ n := by
    intro n
    calc
      |ce (x n)| = ‖ce (x n)‖ := (Real.norm_eq_abs _).symm
      _ ≤ ‖ce‖ * ‖x n‖ := ce.le_opNorm _
      _ ≤ E * (C * q ^ n) := mul_le_mul he (hx n) (norm_nonneg _) hE
      _ = (C * E) * q ^ n := by ring
  have hbu : ∀ n, |cu (x n)| ≤ (C * U) * q ^ n := by
    intro n
    calc
      |cu (x n)| = ‖cu (x n)‖ := (Real.norm_eq_abs _).symm
      _ ≤ ‖cu‖ * ‖x n‖ := cu.le_opNorm _
      _ ≤ U * (C * q ^ n) := mul_le_mul hu (hx n) (norm_nonneg _) hU
      _ = (C * U) * q ^ n := by ring
  obtain ⟨hl, hr⟩ := miace_tail_bound hT hTmax (mul_nonneg hC hE) (mul_nonneg hC hU)
    hq0.le hq1 hη hbe hbu N
  refine ⟨hl, ?_⟩
  have hcost : Real.sqrt ((C * E) ^ 2 + η * (C * U) ^ 2) =
      C * Real.sqrt (E ^ 2 + η * U ^ 2) := cost_mul hC E U
  rw [hcost] at hr
  convert hr using 1 <;> ring

end C2.MIACE
