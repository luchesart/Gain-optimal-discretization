import C2.NGammaGainBridge
import C2.NGammaSinglePhase

/-! Strict improvement of the critical boundary gain after reflecting negative
coordinates. The phase crossing is an actual arctangent identity; the gain is
the actual Cayley amplitude of the characteristic polynomial. -/
noncomputable section
open scoped BigOperators Topology
open Set Filter
namespace C2.NGamma.Global

theorem reflected_phase_below_at_crossing {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hzero : ∀ j, -(2/r j) ≤ x j)
    (hneg : ∃ j, x j < 0) {t : ℝ} (ht : 0 < t)
    (hcross : Phase.totalPhase (fun j => x j+2/r j) x 1 t = Real.pi) :
    Phase.totalPhase (fun j => |x j|+2/r j) (fun j => |x j|) 1 t < Real.pi := by
  have hs := reflected_phase_sum_strict r x hr hzero hneg ht
  unfold Phase.totalPhase at hcross ⊢
  linarith

theorem reflected_finite_critical_gain_strict {n : ℕ} (hn : 0 < n)
    (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    (hx : ∀ j, |x j| ≤ 1) (hzero : ∀ j, -(2/r j) ≤ x j)
    (hneg : ∃ j, x j < 0) {s t : ℝ} (hs : 0 < s) (ht : 0 < t)
    (hold : Phase.totalPhase (fun j => x j+2/r j) x 1 s = Real.pi)
    (hnew : Phase.totalPhase (fun j => |x j|+2/r j) (fun j => |x j|) 1 t = Real.pi) :
    s < t ∧ Cayley.amplitude r x s < Cayley.amplitude r (fun j => |x j|) t := by
  have hbelow := reflected_phase_below_at_crossing r x hr hzero hneg hs hold
  have horder : s < t :=
    (Phase.single_phase_before_after_crossing hn (fun j => abs_nonneg (x j)) hx
      (fun j => lt_add_of_pos_right _ (div_pos (by norm_num) (hr j))) ht hs hnew).1.mp hbelow
  refine ⟨horder,?_⟩
  exact lt_trans (reflected_amplitude_strict r x hr hneg hs)
    (Cayley.amplitude_strictMonoOn hn hr (fun j => abs_nonneg (x j)) hs.le ht.le horder)

theorem amplitude_strictly_below_endpoint {n : ℕ} (hn : 0 < n)
    (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hx : ∀ j, 0 < x j)
    {t : ℝ} (ht : 0 ≤ t) :
    Cayley.amplitude r x t < ∏ j, (r j+2/x j) := by
  have hm := Cayley.amplitude_strictMonoOn hn hr (fun j => (hx j).le)
  have hupper : Cayley.amplitude r x (t+1) ≤ ∏ j, (r j+2/x j) := by
    apply ge_of_tendsto (Cayley.amplitude_tendsto_atTop hr hx)
    filter_upwards [eventually_ge_atTop (t+1)] with s hs
    exact hm.monotoneOn (show 0 ≤ t+1 by linarith) (show 0 ≤ s by linarith) hs
  exact lt_of_lt_of_le (hm ht (show 0 ≤ t+1 by linarith) (by linarith)) hupper

theorem reflected_endpoint_critical_gain_strict {n : ℕ} (hn : 0 < n)
    (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hx : ∀ j, 0 < |x j|)
    (hneg : ∃ j, x j < 0) {t : ℝ} (ht : 0 < t) :
    Cayley.amplitude r x t < ∏ j, (r j+2/|x j|) := by
  exact lt_trans (reflected_amplitude_strict r x hr hneg ht)
    (amplitude_strictly_below_endpoint hn r (fun j => |x j|) hr hx ht.le)

end C2.NGamma.Global
