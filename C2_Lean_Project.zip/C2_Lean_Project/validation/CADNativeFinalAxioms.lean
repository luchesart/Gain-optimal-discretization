import C2.CADNativeTheorem
#print axioms C2.CADNative.native_gain_projection_correct
#print axioms C2.CADNative.run_nonempty_supremum
#print axioms C2.CADNative.run_none_iff_empty
#print axioms C2.CADNative.run_some_correct
#print C2.CADNative.native_gain_projection_correct
