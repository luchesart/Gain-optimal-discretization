import C2.IntegratorDelayPhase
import C2.IntegratorDelayTwo
import C2.IntegratorDelaySampling

noncomputable section
namespace C2.IntegratorDelay

def criticalGain (n : ℕ) (γ : ℝ) : ℝ :=
  boundaryGain n (frequency n (2 * γ - 1))

theorem frequency_one {n : ℕ} (hn : 2 ≤ n) :
    frequency n 1 = upperFrequency n := by
  have hf := frequency_spec hn (x := 1) (by norm_num) (by norm_num)
  have hm : upperFrequency n ∈ Set.Icc (lowerFrequency n) (upperFrequency n) :=
    ⟨frequency_interval_order hn, le_rfl⟩
  have hb := frequency_bounds hn hm
  have he : lowPhase n 1 (upperFrequency n) = Real.pi / 2 := by
    unfold lowPhase
    rw [one_mul, Real.arctan_tan (by linarith [hb.1, Real.pi_pos])
      (by linarith [hb.2.1, Real.pi_pos])]
    unfold upperFrequency
    have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
    have hd : 2 * (n : ℝ) - 1 ≠ 0 := by linarith
    field_simp
    ring
  obtain ⟨w, hw, hu⟩ := existsUnique_low_frequency hn (x := 1) (by norm_num) (by norm_num)
  exact (hu _ hf).trans (hu _ ⟨hm, he⟩).symm

theorem criticalGain_pos {n : ℕ} (hn : 2 ≤ n) {γ : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) : 0 < criticalGain n γ := by
  have hf := frequency_spec hn (x := 2 * γ - 1) (by linarith) (by linarith)
  obtain ⟨hw0, hwpi, hnw0, hnwpi, _⟩ := frequency_bounds hn hf.1
  unfold criticalGain boundaryGain
  exact mul_pos (mul_pos (by norm_num)
    (Real.tan_pos_of_pos_of_lt_pi_div_two (by linarith) (by linarith [Real.pi_pos])))
    (Real.sin_pos_of_pos_of_lt_pi hnw0 hnwpi)

theorem criticalGain_strictMonoOn {n : ℕ} (hn : 2 ≤ n) :
    StrictMonoOn (criticalGain n) (Set.Icc 0 1) := by
  intro γ hγ δ hδ hlt
  have hx : 2 * γ - 1 ∈ Set.Icc (-1) 1 := by constructor <;> linarith [hγ.1, hγ.2]
  have hy : 2 * δ - 1 ∈ Set.Icc (-1) 1 := by constructor <;> linarith [hδ.1, hδ.2]
  exact boundaryGain_strictMonoOn hn
    (frequency_spec hn hx.1 hx.2).1 (frequency_spec hn hy.1 hy.2).1
    (frequency_strictMonoOn hn hx hy (by linarith))

theorem boundaryGain_upper {n : ℕ} (hn : 2 ≤ n) :
    boundaryGain n (upperFrequency n) = 2 * Real.sin (Real.pi / (4 * (n : ℝ) - 2)) := by
  have hm : upperFrequency n ∈ Set.Icc (lowerFrequency n) (upperFrequency n) :=
    ⟨frequency_interval_order hn, le_rfl⟩
  have hb := frequency_bounds hn hm
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  have hd : 2 * (n : ℝ) - 1 ≠ 0 := by linarith
  have he : (n : ℝ) * upperFrequency n = Real.pi / 2 + upperFrequency n / 2 := by
    unfold upperFrequency
    field_simp
    ring
  have hhalf : upperFrequency n / 2 = Real.pi / (4 * (n : ℝ) - 2) := by
    unfold upperFrequency
    rw [show 4 * (n : ℝ) - 2 = (2 * (n : ℝ) - 1) * 2 by ring,
      div_mul_eq_div_div]
  have hc : Real.cos (upperFrequency n / 2) ≠ 0 :=
    (Real.cos_pos_of_mem_Ioo
      ⟨by linarith [hb.1, Real.pi_pos], by linarith [hb.2.1, Real.pi_pos]⟩).ne'
  unfold boundaryGain
  rw [he, Real.sin_add, Real.sin_pi_div_two, Real.cos_pi_div_two]
  simp only [one_mul, zero_mul, add_zero, Real.tan_eq_sin_div_cos]
  rw [← hhalf]
  field_simp

theorem criticalGain_one {n : ℕ} (hn : 2 ≤ n) :
    criticalGain n 1 = 2 * Real.sin (Real.pi / (4 * (n : ℝ) - 2)) := by
  norm_num only [criticalGain, mul_one, show (2 : ℝ) - 1 = 1 by norm_num]
  rw [frequency_one hn, boundaryGain_upper hn]

theorem criticalGain_unique_max {n : ℕ} (hn : 2 ≤ n) {γ : ℝ}
    (hγ : γ ∈ Set.Icc 0 1) :
    criticalGain n γ ≤ criticalGain n 1 ∧
      (criticalGain n γ = criticalGain n 1 ↔ γ = 1) := by
  have h1 : (1 : ℝ) ∈ Set.Icc 0 1 := by norm_num
  exact ⟨(criticalGain_strictMonoOn hn).monotoneOn hγ h1 hγ.2,
    ⟨(criticalGain_strictMonoOn hn).injOn hγ h1, fun h => by rw [h]⟩⟩

theorem physicalThreshold_eq_criticalGain {n : ℕ} (hn : 2 ≤ n) :
    physicalThreshold n = (n : ℝ) * criticalGain n 1 := by
  rw [criticalGain_one hn]
  unfold physicalThreshold
  ring

/-- A nonpositive gain has an actual real root at or beyond one. -/
theorem exists_exterior_real_root_of_nonpos_gain {n : ℕ} (hn : 1 ≤ n)
    {γ a : ℝ} (hγ : γ ≤ 1) (ha : a ≤ 0) :
    ∃ r : ℝ, 1 ≤ r ∧ characteristic n γ a (r : ℂ) = 0 := by
  let R : ℝ := 1 - a
  let f : ℝ → ℝ := fun r => r ^ n * (r - 1) + a * (γ * r + 1 - γ)
  have hR : 1 ≤ R := by dsimp [R]; linarith
  have hpow : R ≤ R ^ n := le_self_pow₀ hR (by omega)
  have hq : γ * R + 1 - γ ≤ R := by nlinarith
  have hprod : 0 ≤ (-a) * (R ^ n - (γ * R + 1 - γ)) :=
    mul_nonneg (by linarith) (by linarith)
  have hfR : 0 ≤ f R := by
    have he : f R = (-a) * (R ^ n - (γ * R + 1 - γ)) := by dsimp [f, R]; ring
    rw [he]
    exact hprod
  have hf1 : f 1 ≤ 0 := by simpa [f] using ha
  have hcont : ContinuousOn f (Set.Icc 1 R) := (by fun_prop : Continuous f).continuousOn
  obtain ⟨r, hr, he⟩ := intermediate_value_Icc hR hcont ⟨hf1, hfR⟩
  refine ⟨r, hr.1, ?_⟩
  have hc : characteristic n γ a (r : ℂ) = (f r : ℝ) := by
    simp only [characteristic, f]
    push_cast
    ring
  rw [hc, he, Complex.ofReal_zero]

theorem stable_gain_pos {n : ℕ} (hn : 1 ≤ n) {γ a : ℝ}
    (hγ : γ ≤ 1) (hs : Stable n γ a) : 0 < a := by
  by_contra! ha
  obtain ⟨r, hr, he⟩ := exists_exterior_real_root_of_nonpos_gain hn hγ ha
  have h := hs (r : ℂ) he
  have hrnorm : 1 ≤ ‖(r : ℂ)‖ := by
    simpa only [Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (show 0 ≤ r by linarith)] using hr
  exact (not_lt_of_ge hrnorm) h

end C2.IntegratorDelay
