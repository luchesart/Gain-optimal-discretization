import C2.CADNativeProgram

-- The real public native entry point executes its zero-input branch.
#eval (C2.CADNative.run [[]] 1 (by norm_num)).isNone
-- Semantic zero detection ignores inner and outer trailing zero coefficients.
#eval (C2.CADNative.run [[[0, 0], [0]]] 1 (by norm_num)).isNone
