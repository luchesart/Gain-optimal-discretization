import C2.CubicSchur
import C2.NGammaEqualBoundary

/-! Actual Schur stability of the n=3 all-backward-Euler design. -/
noncomputable section
namespace C2.NGammaEqual

def cubicB (a b : ℝ) : ℝ := (b - 3 * a ^ 2) / a ^ 3
def cubicC (a : ℝ) : ℝ := 3 / a ^ 2
def cubicD (a : ℝ) : ℝ := -1 / a ^ 3

lemma cubic_jury_plus {a : ℝ} (ha : a ≠ 0) (b : ℝ) :
    1 + cubicB a b + cubicC a + cubicD a = ((a - 1) ^ 3 + b) / a ^ 3 := by
  unfold cubicB cubicC cubicD
  field_simp
  <;> ring

lemma cubic_jury_minus {a : ℝ} (ha : a ≠ 0) (b : ℝ) :
    1 - cubicB a b + cubicC a - cubicD a = ((a + 1) ^ 3 - b) / a ^ 3 := by
  unfold cubicB cubicC cubicD
  field_simp
  <;> ring

lemma cubic_jury_final {a : ℝ} (ha : a ≠ 0) (b : ℝ) :
    1 - cubicC a + cubicB a b * cubicD a - cubicD a ^ 2 =
      ((a ^ 2 - 1) ^ 3 - b) / a ^ 6 := by
  unfold cubicB cubicC cubicD
  field_simp
  <;> ring

lemma cubic_backward_schur_iff {a b : ℝ} (ha : 1 < a) (hb : 0 ≤ b) :
    C2.CubicSchur (cubicB a b) (cubicC a) (cubicD a) ↔
      b < (a + 1) ^ 3 ∧ b < (a ^ 2 - 1) ^ 3 := by
  have ha0 : 0 < a := by linarith
  have ha3 : 0 < a ^ 3 := pow_pos ha0 _
  have ha6 : 0 < a ^ 6 := pow_pos ha0 _
  have ha1 : 1 < a ^ 3 := by nlinarith [sq_nonneg (a - 1)]
  have hd : |cubicD a| < 1 := by
    unfold cubicD
    rw [abs_div, abs_neg, abs_one, abs_of_pos ha3]
    exact (div_lt_one ha3).2 ha1
  have hplus : 0 < 1 + cubicB a b + cubicC a + cubicD a := by
    rw [cubic_jury_plus (ne_of_gt ha0)]
    apply div_pos _ ha3
    have hp : 0 < (a - 1) ^ 3 := pow_pos (sub_pos.mpr ha) _
    linarith
  rw [C2.cubicSchur_iff, cubic_jury_minus (ne_of_gt ha0),
    cubic_jury_final (ne_of_gt ha0)]
  constructor
  · rintro ⟨_, _, hm, hf⟩
    exact ⟨sub_pos.mp ((div_pos_iff_of_pos_right ha3).mp hm),
      sub_pos.mp ((div_pos_iff_of_pos_right ha6).mp hf)⟩
  · rintro ⟨hm, hf⟩
    exact ⟨hd, hplus, div_pos (sub_pos.mpr hm) ha3, div_pos (sub_pos.mpr hf) ha6⟩

lemma order_three_characteristic_factor {r : ℝ} (hr : 0 < r) (b : ℝ) (z : ℂ) :
    backwardCharacteristic 3 r b z =
      z * ((r : ℂ) + 1) ^ 3 *
        (z ^ 3 + (cubicB (r + 1) b : ℂ) * z ^ 2 +
          (cubicC (r + 1) : ℂ) * z + (cubicD (r + 1) : ℂ)) := by
  have ha : (r : ℂ) + 1 ≠ 0 := by
    have hh : r + 1 ≠ 0 := by linarith
    exact_mod_cast hh
  unfold backwardCharacteristic cubicB cubicC cubicD
  push_cast
  field_simp
  <;> ring

/-- Exact actual-root statement: stability is never defined as the Jury inequalities. -/
lemma order_three_backward_stable_iff {r b : ℝ} (hr : 0 < r) (hr1 : r < 1) (hb : 0 ≤ b) :
    (∀ z : ℂ, backwardCharacteristic 3 r b z = 0 → ‖z‖ < 1) ↔
      b < (r * (r + 2)) ^ 3 := by
  have ha : 1 < r + 1 := by linarith
  have hab : (r + 1) ^ 2 - 1 < (r + 1) + 1 := by nlinarith
  have hbase : 0 ≤ (r + 1) ^ 2 - 1 := by nlinarith
  have hcube : ((r + 1) ^ 2 - 1) ^ 3 ≤ (r + 1 + 1) ^ 3 := by
    exact pow_le_pow_left₀ hbase hab.le _
  have halg : (r + 1) ^ 2 - 1 = r * (r + 2) := by ring
  have hcoeff : C2.CubicSchur (cubicB (r + 1) b) (cubicC (r + 1)) (cubicD (r + 1)) ↔
      b < (r * (r + 2)) ^ 3 := by
    rw [cubic_backward_schur_iff ha hb, ← halg]
    exact ⟨And.right, fun h => ⟨lt_of_lt_of_le h hcube, h⟩⟩
  rw [← hcoeff]
  constructor
  · intro h z hz
    apply h z
    rw [order_three_characteristic_factor hr]
    rw [hz, mul_zero]
  · intro h z hz
    rw [order_three_characteristic_factor hr] at hz
    rcases mul_eq_zero.mp hz with hz | hp
    · rcases mul_eq_zero.mp hz with hz | ha0
      · subst z; norm_num
      · have hn : ((r : ℂ) + 1) ^ 3 ≠ 0 := by
          apply pow_ne_zero
          exact_mod_cast (show r + 1 ≠ 0 by linarith)
        exact (hn ha0).elim
    · exact h z hp

end C2.NGammaEqual
