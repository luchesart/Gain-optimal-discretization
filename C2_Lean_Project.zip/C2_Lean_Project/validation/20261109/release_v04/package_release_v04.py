"""Package C2 v0.4.0 only after the final verification and PDF gates pass.

This script does not run Lean, LaTeX, or numerical experiments.  Invoke it
explicitly after root has written VERIFICATION.json and frozen the release.
`--check-only` performs the complete read-only preflight and writes nothing.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import collections
import csv
import hashlib
import json
import shutil
import tempfile
import zipfile

R = Path(__file__).resolve().parents[1]
P = R / 'unpacked/C2_Lean_Project/C2_Lean_Project'
M = R / 'unpacked/C2_Rational_Delay_Project/C2_Rational_Delay_Project'
O = R / 'output'
VERSION = '0.4.0'
COUNTS = {'modules': 208, 'proofs': 1741, 'public': 2176, 'results': 45}
PDF_REL = Path('validation/20261109_v04_pdf')
RELEASE_REL = Path('validation/20261109')
MODULAR_LOG = RELEASE_REL / 'final_modular_v04.log'
SINGLE_LOG = RELEASE_REL / 'final_single_file_v04.log'
ALLOWED_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def included(path, base):
    rel = path.relative_to(base)
    if any(part in {'.lake', '.git', '__pycache__'} for part in rel.parts):
        return False
    if path.name.endswith(('.pyc', '.olean', '.ilean', '.fls', '.fdb_latexmk',
                           '.synctex.gz', '.aux', '.out', '.toc', '.blg')):
        return False
    return path.is_file()


def files(base):
    return sorted(path for path in base.rglob('*') if included(path, base))


def manifest(base):
    target = base / 'MANIFEST_SHA256.json'
    dump(target, {str(path.relative_to(base)): sha(path)
                  for path in files(base) if path != target})


def preserve_existing(path):
    """Retain a previous artifact or record before changing its current copy."""
    if path.exists():
        rel = path.relative_to(R)
        destination = R / 'historical/package_before_v04' / rel.parent
        destination.mkdir(parents=True, exist_ok=True)
        backup = destination / (path.name + '.' + sha(path)[:16])
        if backup.exists():
            require(sha(backup) == sha(path), f'Historical copy conflict: {backup}')
        else:
            shutil.copy2(path, backup)


def zipdir(base, target, prefix):
    entries = files(base)
    require(entries, f'Empty archive source: {base}')
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + '.v04.tmp')
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in entries:
            archive.write(path, str(Path(prefix) / path.relative_to(base)))
    with zipfile.ZipFile(temporary) as archive:
        require(archive.testzip() is None, f'ZIP CRC failure: {temporary}')
        require(len(archive.namelist()) == len(entries), 'Duplicate archive names')
        for path in entries:
            name = str(Path(prefix) / path.relative_to(base))
            require(hashlib.sha256(archive.read(name)).hexdigest() == sha(path), name)
        require(not any('.lake' in Path(name).parts or
                        name.endswith(('.olean', '.ilean', '.pyc'))
                        for name in archive.namelist()), 'Compiled cache in source archive')
    preserve_existing(target)
    temporary.replace(target)
    return {'file': target.name, 'sha256': sha(target),
            'bytes': target.stat().st_size, 'entries': len(entries)}


def preflight():
    v = read_json(P / 'VERIFICATION.json')
    require(v['date_utc'] == '2026-11-09' and v['project_version'] == VERSION,
            'Root must write the final v0.4.0 VERIFICATION.json first')
    require(v['modules'] == COUNTS['modules'] and
            v['public_theorems_and_lemmas'] == COUNTS['proofs'] and
            v['all_explicit_public_declarations_audited'] == COUNTS['public'],
            'Unexpected release counts')
    require(v['whole_article_formalized'] is True, 'Whole-article verdict is not complete')
    require(v['paper_coverage'].get('COMPLETE') == COUNTS['results'] and
            sum(v['paper_coverage'].values()) == COUNTS['results'], 'Incomplete paper coverage')
    for field in ['remaining_partial_label', 'remaining_scope']:
        require(field in v and v[field] in (None, '', [], 'none', 'None'),
                f'An explicit empty {field} is required')
    require(v['original_proof_modules_unchanged'] == 156 and
            v['new_modules_since_input_release'] == 52 and
            v['new_public_proofs_since_input_release'] == 386,
            'v0.3 to v0.4 provenance counts do not match')
    require(v['original_preservation_evidence'] ==
            'validation/20261109/v03_module_preservation.json', 'Wrong preservation baseline')
    require(v['modular_build_passed'] and v['modular_import_check']['exit_code'] == 0 and
            v['modular_import_check']['log'] == str(MODULAR_LOG), 'Final modular gate failed')
    require(v['single_file_check']['passed'] and v['single_file_check']['exit_code'] == 0 and
            v['single_file_check']['log'] == str(SINGLE_LOG), 'Final standalone gate failed')
    require(v['axiom_audit_passed'] and v['axiom_audit_exit_code'] == 0 and
            v['axiom_audit_validation_exit_code'] == 0 and
            v['sorry_or_custom_axioms'] is False, 'Final axiom gate failed')
    for rel in [MODULAR_LOG, SINGLE_LOG, Path('work/SharedAxiomAudit.log')]:
        require((P / rel).is_file(), f'Missing final log: {rel}')
    require(sha(P / 'live/C2_Live_Lean419.lean') == v['single_file_check']['sha256'],
            'Standalone source changed after checking')

    inv_path = P / 'work/lean_inventory_draft.json'
    inv = read_json(inv_path)
    require((inv['module_count'], inv['public_proof_count'], inv['public_declaration_count']) ==
            (208, 1741, 2176), 'Inventory does not describe v0.4.0')
    require(len(inv['modules']) == 208, 'Inventory module list is incomplete')
    module_sources = {row['source'] for row in inv['modules']}
    require(module_sources == {str(path.relative_to(P)) for path in (P / 'C2').glob('*.lean')},
            'Inventory and module source tree differ')
    for row in inv['modules']:
        require(row['sha256'] == sha(P / row['source']), f"Changed module: {row['source']}")
    public = [row for row in inv['declarations'] if not row['private']]
    names = {row['name'] for row in public}
    modules = {row['module'] for row in inv['modules']}
    require(len(public) == len(names) == 2176, 'Public inventory names are not unique/complete')
    require(sum(row['kind'] in {'theorem', 'lemma'} for row in public) == 1741,
            'Public proof inventory mismatch')
    rows = list(csv.DictReader((P / 'PROOF_MAP_EN.csv').open()))
    require(len(rows) == len({row['Label'] for row in rows}) == 45, 'Proof map labels/count differ')
    require(collections.Counter(row['Lean_status'] for row in rows) == {'COMPLETE': 45},
            'All 45 proof-map rows must be COMPLETE')
    for row in rows:
        for name in row['Lean_declarations'].split(';'):
            require(name.strip() in names, f"Unknown map declaration {row['Label']}: {name}")
        for module in row['Lean_modules'].split(';'):
            require(module.strip() in modules, f"Unknown map module {row['Label']}: {module}")
    require((M / 'PROOF_MAP_EN.csv').read_bytes() == (P / 'PROOF_MAP_EN.csv').read_bytes(),
            'Manuscript and Lean proof maps differ')

    audit = read_json(P / 'work/axiom_audit.json')
    require(audit['passed'] and all(audit['checks'].values()), 'Incomplete axiom audit checks')
    require(all(audit[key] == 2176 for key in ['expected_count', 'reported_count', 'checked_root_count']),
            'Axiom audit does not cover all 2176 public roots')
    require(len(audit['roots']) == 2176 and set(audit['roots']) == names,
            'Audit roots do not equal the current inventory')
    require(not audit['missing_declarations'] and not audit['unexpected_axioms'] and
            set(audit['axiom_union']) <= ALLOWED_AXIOMS and
            set(audit['axiom_union']) == set(v['axiom_union']), 'Unexpected axiom dependency')
    require(audit['execution']['lean_exit_code'] == 0 and
            audit['execution']['inventory_sha256'] == sha(inv_path), 'Stale axiom audit inventory')
    require(audit['execution']['source_sha256'] == sha(P / 'work/SharedAxiomAudit.lean'),
            'Axiom collector source changed after checking')

    preservation = read_json(P / v['original_preservation_evidence'])
    require(preservation['passed'] and preservation['all_byte_identical'] and
            preservation['old_module_count'] == 156 and preservation['new_module_count'] == 52,
            'v0.3 preservation record failed')
    previous_sources = set()
    with zipfile.ZipFile(R / 'cad_work/input_v03/C2_Lean_Project.zip') as archive:
        old_v = json.loads(archive.read('C2_Lean_Project/VERIFICATION.json'))
        require(old_v['project_version'] == '0.3.0' and
                old_v['modules'] == 156 and old_v['public_theorems_and_lemmas'] == 1355,
                'Unexpected v0.3 input package')
        for name in archive.namelist():
            rel = Path(name).relative_to('C2_Lean_Project')
            if len(rel.parts) == 2 and rel.parts[0] == 'C2' and rel.suffix == '.lean':
                previous_sources.add(str(rel))
                require(archive.read(name) == (P / rel).read_bytes(), f'Changed v0.3 module: {rel}')
    require(len(previous_sources) == 156 and len(module_sources - previous_sources) == 52,
            'Incorrect module delta from v0.3')
    require(sum(row['public_proof_count'] for row in inv['modules']
                if row['source'] not in previous_sources) == 386, 'Incorrect new-proof count')
    for row in preservation['modules']:
        require(row['source'] in previous_sources and row['sha256'] == sha(P / row['source']),
                f"Stale preservation hash: {row['source']}")

    native = read_json(P / 'validation/cad_native_theorem_completion_20261109.json')
    require(native['status'] == 'compiled_kernel_checked' and
            set(native['main_theorems']) <= names, 'Native completion evidence missing')
    for row in native['module_files']:
        require(row['compile_exit_code'] == 0 and row['sha256'] == sha(P / row['path']),
                f"Stale native theorem evidence: {row['path']}")
    review_cad = read_json(P / 'validation/cad_end_to_end_review_20261109.json')
    require(review_cad['status'] == 'accepted' and not review_cad['open_semantic_gaps'],
            'Independent CAD audit has unresolved gaps')
    for row in review_cad['source_snapshots']:
        require(row['sha256'] == sha(P / row['source']), f"Stale independent review: {row['source']}")

    review_dir = R / 'integration/pdf_review_v04'
    review = read_json(review_dir / 'review_20261109.json')
    require(review['status'] == 'PASS' and review['compile']['exit_code'] == 0 and
            review['pdf_sha256'] == sha(M / 'main.pdf'), 'Final PDF review gate failed')
    require((R / 'integration/latex_v04_build.log').is_file(), 'Missing v0.4 LaTeX build log')
    tex_inputs = review['current_tex_inputs_sha256']
    require({'main.tex', 'general_gain_projection.tex', 'formalization_scope.tex'} <= set(tex_inputs),
            'Review must cover the revised theorem and formalization scope')
    for name, digest in tex_inputs.items():
        require(sha(M / name) == digest, f'Reviewed TeX source changed: {name}')
    for name, digest in review.get('png_sha256', {}).items():
        require(sha(review_dir / Path(name).name) == digest, f'Reviewed PNG changed: {name}')

    export_pairs = [
        (O / 'C2_Live_Lean419.lean', P / 'live/C2_Live_Lean419.lean'),
        (O / 'C2_Proof_Map_EN.csv', P / 'PROOF_MAP_EN.csv'),
        (O / 'STATUS_AND_NEXT_STEPS_BG.md', P / 'STATUS_AND_NEXT_STEPS_BG.md'),
        (O / 'C2_Rational_Delay_Development_Draft.pdf', M / 'main.pdf'),
    ]
    for target, source in export_pairs:
        require(target.is_file() and sha(target) == sha(source), f'Export is not current: {target}')

    # Freeze every current project/evidence input, except the generated index and
    # manifest that this script owns. New copied evidence is checked separately.
    generated_dirs = [PDF_REL, RELEASE_REL / 'release_v04']
    frozen = {str(path.relative_to(R)): sha(path) for path in files(P)
              if path.relative_to(P) not in {Path('MANIFEST_SHA256.json'), Path('validation/README.md')}
              and not any(path.relative_to(P).is_relative_to(directory) for directory in generated_dirs)}
    for path in files(M):
        rel = path.relative_to(M)
        if rel.parts[0] != 'Lean' and rel not in {Path('MANIFEST_SHA256.json'), Path('RELEASE_CHECKS.json')}:
            frozen[str(path.relative_to(R))] = sha(path)
    for path in files(review_dir) + [R / 'integration/latex_v04_build.log']:
        frozen[str(path.relative_to(R))] = sha(path)
    return v, inv, review, frozen, export_pairs


def check_freeze(frozen):
    for name, digest in frozen.items():
        require((R / name).is_file() and sha(R / name) == digest,
                f'Frozen release input changed during packaging: {name}')


def package():
    v, inv, review, frozen, export_pairs = preflight()
    validation = P / RELEASE_REL
    pdf_evidence = P / PDF_REL
    shutil.copytree(R / 'integration/pdf_review_v04', pdf_evidence / 'pdf_review', dirs_exist_ok=True)
    shutil.copy2(R / 'integration/latex_v04_build.log', pdf_evidence / 'latex_build.log')
    packaging_evidence = validation / 'release_v04'
    packaging_evidence.mkdir(parents=True, exist_ok=True)
    for name in ['package_release_v04.py', 'prepare_v04.py',
                 'single_file_generation_v04.json', 'final_exit_codes_v04.json']:
        require((R / 'integration' / name).is_file(), f'Missing integration evidence: {name}')
        shutil.copy2(R / 'integration' / name, packaging_evidence / name)
    dump(packaging_evidence / 'current_source_and_map_check.json', {
        'passed': True, 'version': VERSION, 'module_source_hashes_verified': 208,
        'public_proof_count': 1741, 'public_declarations_audited': 2176,
        'map_reference_rows_verified': 45, 'all_map_rows_complete': True,
        'unchanged_v03_modules': 156, 'new_modules': 52, 'new_public_proofs': 386,
        'pdf_source_hashes_verified': len(review['current_tex_inputs_sha256']),
        'numerical_experiments_rerun': False,
    })
    dump(packaging_evidence / 'final_input_hash_freeze.json', {
        'version': VERSION, 'passed_at_preflight': True,
        'scope': 'All release project inputs, final proofs/audit/logs, manuscript sources, PDF and review inputs; generated package indexes/manifests excluded.',
        'sha256': frozen,
    })
    index = P / 'validation/README.md'
    preserve_existing(index)
    index.write_text('''# Evidence index — C2 v0.4.0, 9 November 2026

The current verdict is ../VERIFICATION.json: all 45 numbered manuscript
results are COMPLETE and the whole article is formalized. The release has
208 source modules, 1741 public theorems/lemmas and 2176 audited public
declarations. There is no remaining partial manuscript result.

Current final checks:
- 20261109/final_modular_v04.log: complete C2 umbrella import;
- 20261109/final_single_file_v04.log: generated standalone source;
- ../work/axiom_audit.json and ../work/SharedAxiomAudit.log: every explicit
  public inventory root, with only propext, Classical.choice and Quot.sound;
- ../work/lean_inventory_draft.json: exact current module/source hashes;
- 20261109/v03_module_preservation.json: all 156 v0.3 modules byte-identical,
  with 52 new modules and 386 new public proofs;
- 20261109/release_v04/: packaging checks, final hash freeze and release scripts.

Current Theorem 3 evidence is cad_native_theorem_completion_20261109.json
and the accepted independent cad_end_to_end_review_20261109.json. The
effective, projection, factor, isolation and delineability records document
their individual proved stages. The native theorem discharges those stages
for the actual returned output of CADNative.run. Its runtime uses finite
rational coefficient lists, terminating data searches, dyadic isolation and
rational samples. No practical complexity claim or verification of the
separate SymPy/resultant implementation is made.

The current PDF review is
20261109_v04_pdf/pdf_review/review_20261109.json, with reviewed page images
in that directory and the successful build log at
20261109_v04_pdf/latex_build.log. The review binds the PDF to the current
TeX input hashes. Existing numerical experiments were not rerun.

Historical evidence is retained, not used as the current completion verdict.
In particular, independent_scope_review_20261109.json is the earlier v0.3
scope review, superseded by cad_end_to_end_review_20261109.json; the entire
20261109/pdf_review/ directory and 20261109/latex_build.log describe the v0.3
PDF, superseded by 20261109_v04_pdf/. The unversioned final_modular.log and
final_single_file.log under 20261109/ are also earlier release checks.
Any v0.3 final_validation_summary.json records 44 COMPLETE / 1 PARTIAL as
historical scope only. Intermediate stage records may retain their then-open
integration obligations; they do not supersede the final native theorem or
VERIFICATION.json. Earlier release documents and the former CAD obligations
are retained under ../historical/20261109_v03/ and older historical directories.
Resource-contention and abandoned attempts remain marked under attempts/.
''')
    check_freeze(frozen)
    manifest(P)

    # Replace only the generated embedded package, preserving its old snapshot.
    embedded = M / 'Lean'
    staging = Path(tempfile.mkdtemp(prefix='Lean_v04_', dir=M.parent))
    for path in files(P):
        target = staging / path.relative_to(P)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
    if embedded.exists():
        old_version = read_json(embedded / 'VERIFICATION.json').get('project_version', 'unknown')
        snapshots = M / 'historical/embedded_Lean_snapshots'
        snapshots.mkdir(parents=True, exist_ok=True)
        destination = snapshots / ('v' + old_version + '_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
        embedded.rename(destination)
    staging.rename(embedded)
    for path in files(P):
        require(sha(path) == sha(embedded / path.relative_to(P)), 'Embedded Lean copy differs')
    checks = {
        'date_utc': '2026-11-09', 'version': VERSION,
        'paper_coverage': {'COMPLETE': 45, 'PARTIAL': 0},
        'whole_article_formalized': True, 'remaining_partial': None, 'remaining_scope': None,
        'lean_modules': 208, 'lean_public_proofs': 1741, 'public_declarations_audited': 2176,
        'original_v03_modules_unchanged': 156, 'new_modules_since_v03': 52,
        'new_public_proofs_since_v03': 386,
        'lean_verification': 'Lean/VERIFICATION.json', 'proof_map': 'PROOF_MAP_EN.csv',
        'latex_exit_code': 0, 'pdf_pages': review['page_count'], 'pdf_sha256': sha(M / 'main.pdf'),
        'pdf_review': 'Lean/' + str(PDF_REL / 'pdf_review/review_20261109.json'),
        'latex_build_log': 'Lean/' + str(PDF_REL / 'latex_build.log'),
        'source_hash_freeze': 'Lean/' + str(RELEASE_REL / 'release_v04/final_input_hash_freeze.json'),
        'numerical_experiments_rerun': False,
        'prior_release_lean_verdict': 'Lean/historical/20261109_v03/VERIFICATION.json',
        'source_scope': 'Theorem 3 explicitly states the verified finite rational factor/Bezout-data search, squarefree dyadic isolation and rational sampling procedure. All original assumptions, global supremum conclusion, strict uniform bound and numerical results are retained. Separate SymPy/resultant code is not claimed formally verified; exhaustive search has no practical running-time claim.',
    }
    preserve_existing(M / 'RELEASE_CHECKS.json')
    dump(M / 'RELEASE_CHECKS.json', checks)
    manifest(M)

    (R / 'staging').mkdir(parents=True, exist_ok=True)
    E = Path(tempfile.mkdtemp(prefix='C2_Formalization_Evidence_v04_', dir=R / 'staging'))
    for path in files(P):
        if path == P / 'MANIFEST_SHA256.json':
            continue
        target = E / path.relative_to(P)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
    (E / 'README_EVIDENCE.md').write_text('''# C2 formalization evidence — v0.4.0, 9 November 2026

All 45 numbered manuscript results are COMPLETE. The package contains
208 source modules, the checked standalone source, 1741 public proofs and
the complete audit of 2176 public declarations. Only propext,
Classical.choice and Quot.sound occur. VERIFICATION.json is the current
machine-readable verdict; validation/README.md distinguishes current final
checks from preserved historical evidence. All 156 v0.3 modules are unchanged;
52 modules and 386 public proofs are new. No compiled Lean/dependency cache
is included. The exact native CAD procedure is verified; the separate
SymPy/resultant implementation and practical search complexity are not
claimed verified. Existing numerical results were preserved, not rerun.
''')
    manifest(E)
    check_freeze(frozen)
    archives = [zipdir(P, O / 'C2_Lean_Project.zip', 'C2_Lean_Project'),
                zipdir(M, O / 'C2_Rational_Delay_Project.zip', 'C2_Rational_Delay_Project'),
                zipdir(E, O / 'C2_Formalization_Evidence.zip', 'C2_Formalization_Evidence')]
    for target, source in export_pairs:
        require(sha(target) == sha(source), f'Export changed during packaging: {target}')
        archives.append({'file': target.name, 'sha256': sha(target), 'bytes': target.stat().st_size})
    check_freeze(frozen)
    receipt = {'date': datetime.now(timezone.utc).isoformat(), 'version': VERSION,
               'passed': True, 'final_hash_freeze_passed': True,
               'whole_article_formalized': True, 'remaining_scope': None,
               'paper_coverage': {'COMPLETE': 45, 'PARTIAL': 0},
               'counts': COUNTS, 'numerical_experiments_rerun': False,
               'artifacts': archives, 'evidence_staging': str(E.relative_to(R))}
    dump(R / 'integration/release_artifacts_v04.json', receipt)
    preserve_existing(R / 'integration/release_artifacts.json')
    dump(R / 'integration/release_artifacts.json', receipt)
    print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true', help='Read-only final-gate validation')
    args = parser.parse_args()
    if args.check_only:
        _, _, _, frozen, _ = preflight()
        check_freeze(frozen)
        print(json.dumps({'passed': True, 'version': VERSION,
                          'mode': 'read-only preflight', 'frozen_input_count': len(frozen)}))
    else:
        package()
