import C2.NGammaGlobal
import C2.NGammaPhase

/-! Actual phase and magnitude comparisons for componentwise reflection.
No statement about a stable gain interval is assumed or encoded here. -/

noncomputable section
open scoped BigOperators

namespace C2.NGamma.Global

def magnitudeFactor (r x t : ℝ) : ℝ :=
  r * Real.sqrt ((1+(x+2/r)^2*t^2)/(1+x^2*t^2))

theorem magnitudeFactor_pos {r x t : ℝ} (hr : 0 < r) :
    0 < magnitudeFactor r x t := by
  unfold magnitudeFactor
  positivity

theorem negative_reflection_phase {r x t : ℝ} (hr : 0 < r)
    (hx : x < 0) (hzero : -(2/r) ≤ x) (ht : 0 < t) :
    Phase.contribution (|x|+2/r) |x| t < Phase.contribution (x+2/r) x t := by
  rw [abs_of_neg hx]
  unfold Phase.contribution
  have h := reflection_phase_strict (c := 2/r) (u := -x) (t := t)
    (by linarith) (by linarith) ht
  rw [neg_mul,Real.arctan_neg] at h
  convert h using 1 <;> congr 1 <;> congr 1 <;> ring <;> simp only [Real.arctan_neg]

theorem reflection_phase_le {r x t : ℝ} (hr : 0 < r)
    (hzero : -(2/r) ≤ x) (ht : 0 < t) :
    Phase.contribution (|x|+2/r) |x| t ≤ Phase.contribution (x+2/r) x t := by
  by_cases hx : x < 0
  · exact (negative_reflection_phase hr hx hzero ht).le
  · rw [abs_of_nonneg (le_of_not_gt hx)]

theorem negative_reflection_magnitude {r x t : ℝ} (hr : 0 < r)
    (hx : x < 0) (ht : 0 < t) :
    magnitudeFactor r x t < magnitudeFactor r |x| t := by
  rw [abs_of_neg hx]
  unfold magnitudeFactor
  have h := reflection_magnitude_strict (r := r) (c := 2/r) (u := -x) (t := t)
    hr (by positivity) (by linarith) ht
  convert h using 1 <;> congr 1 <;> congr 1 <;> congr 1 <;> ring

theorem reflection_magnitude_le {r x t : ℝ} (hr : 0 < r) (ht : 0 < t) :
    magnitudeFactor r x t ≤ magnitudeFactor r |x| t := by
  by_cases hx : x < 0
  · exact (negative_reflection_magnitude hr hx ht).le
  · rw [abs_of_nonneg (le_of_not_gt hx)]

/-- Reflecting every negative component strictly reduces the sum of the
actual phase contributions whenever at least one component is negative. -/
theorem reflected_phase_sum_strict {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hzero : ∀ j, -(2/r j) ≤ x j)
    (hneg : ∃ j, x j < 0) {t : ℝ} (ht : 0 < t) :
    (∑ j, Phase.contribution (|x j|+2/r j) |x j| t) <
      ∑ j, Phase.contribution (x j+2/r j) (x j) t := by
  apply Finset.sum_lt_sum
  · intro j _
    exact reflection_phase_le (hr j) (hzero j) ht
  · obtain ⟨j,hj⟩ := hneg
    exact ⟨j,Finset.mem_univ _,negative_reflection_phase (hr j) hj (hzero j) ht⟩

/-- The magnitude product of the reflected parameter vector is strictly
larger at every positive frequency. This is an all-order statement. -/
theorem reflected_magnitude_product_strict {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hneg : ∃ j, x j < 0) {t : ℝ} (ht : 0 < t) :
    (∏ j, magnitudeFactor (r j) (x j) t) <
      ∏ j, magnitudeFactor (r j) |x j| t := by
  apply Finset.prod_lt_prod
  · intro j _
    exact magnitudeFactor_pos (hr j)
  · intro j _
    exact reflection_magnitude_le (hr j) ht
  · obtain ⟨j,hj⟩ := hneg
    exact ⟨j,Finset.mem_univ _,negative_reflection_magnitude (hr j) hj ht⟩

end C2.NGamma.Global
