import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Tactic

/-! The actual unit-circle polynomial zero for the identical-factor angle equation. -/
noncomputable section
namespace C2.NGammaEqual

/-- Evaluation of z*ΠD+b*Πq when every q=z and every positive factor is r. -/
def backwardCharacteristic (n : ℕ) (r b : ℝ) (z : ℂ) : ℂ :=
  z * (((r : ℂ) + 1) * z - 1) ^ n + (b : ℂ) * z ^ n

lemma backward_boundary_algebra (n : ℕ) (r A : ℝ) (w : ℂ) (hw : w ≠ 0)
    (hfactor : (r : ℂ) + 1 + w ^ n = (A : ℂ) * w) :
    backwardCharacteristic n r (A ^ n) (-(w ^ n)⁻¹) = 0 := by
  let z : ℂ := -(w ^ n)⁻¹
  have hwn : w ^ n ≠ 0 := pow_ne_zero n hw
  have hz : z * w ^ n = -1 := by dsimp [z]; simp [hwn]
  have hd : ((r : ℂ) + 1) * z - 1 = z * ((A : ℂ) * w) := by
    rw [← hfactor]
    calc
      ((r : ℂ) + 1) * z - 1 = z * ((r : ℂ) + 1) + z * w ^ n := by rw [hz]; ring
      _ = _ := by ring
  change z * (((r : ℂ) + 1) * z - 1) ^ n + ((A ^ n : ℝ) : ℂ) * z ^ n = 0
  rw [hd, Complex.ofReal_pow, mul_pow, mul_pow]
  calc
    z * (z ^ n * ((A : ℂ) ^ n * w ^ n)) + (A : ℂ) ^ n * z ^ n =
      z ^ n * (A : ℂ) ^ n * (z * w ^ n + 1) := by ring
    _ = 0 := by rw [hz]; ring

lemma equal_angle_factor {n : ℕ} {r φ : ℝ} (hs : Real.sin φ ≠ 0)
    (hangle : r + 1 = Real.sin (((n : ℝ) - 1) * φ) / Real.sin φ) :
    (r : ℂ) + 1 + Complex.exp ((φ : ℂ) * Complex.I) ^ n =
      ((Real.sin ((n : ℝ) * φ) / Real.sin φ : ℝ) : ℂ) *
        Complex.exp ((φ : ℂ) * Complex.I) := by
  have hsin : (r + 1) * Real.sin φ =
      Real.sin ((n : ℝ) * φ) * Real.cos φ -
      Real.cos ((n : ℝ) * φ) * Real.sin φ := by
    have hh := (eq_div_iff hs).mp hangle
    have harg : ((n : ℝ) - 1) * φ = (n : ℝ) * φ - φ := by ring
    rw [harg, Real.sin_sub] at hh
    exact hh
  have hexp : Complex.exp ((φ : ℂ) * Complex.I) ^ n =
      Complex.exp ((((n : ℝ) * φ : ℝ) : ℂ) * Complex.I) := by
    rw [← Complex.exp_nat_mul]
    congr 1
    push_cast
    ring
  rw [hexp]
  apply Complex.ext
  · simp only [Complex.add_re, Complex.ofReal_re, Complex.one_re,
      Complex.exp_ofReal_mul_I_re, Complex.mul_re, Complex.ofReal_im,
      zero_mul, sub_zero]
    field_simp
    nlinarith [hsin]
  · simp only [Complex.add_im, Complex.ofReal_im, Complex.one_im,
      Complex.exp_ofReal_mul_I_im, zero_add, Complex.mul_im,
      zero_mul, add_zero]
    exact (div_mul_cancel₀ _ hs).symm

lemma equal_finite_boundary {n : ℕ} {r φ : ℝ} (hs : Real.sin φ ≠ 0)
    (hangle : r + 1 = Real.sin (((n : ℝ) - 1) * φ) / Real.sin φ) :
    backwardCharacteristic n r ((Real.sin ((n : ℝ) * φ) / Real.sin φ) ^ n)
      (Complex.exp (((Real.pi - (n : ℝ) * φ : ℝ) : ℂ) * Complex.I)) = 0 := by
  have hz : Complex.exp (((Real.pi - (n : ℝ) * φ : ℝ) : ℂ) * Complex.I) =
      -(Complex.exp ((φ : ℂ) * Complex.I) ^ n)⁻¹ := by
    push_cast
    rw [sub_mul, Complex.exp_sub, Complex.exp_pi_mul_I]
    have hh : Complex.exp (((n : ℂ) * φ) * Complex.I) =
        Complex.exp ((φ : ℂ) * Complex.I) ^ n := by
      rw [← Complex.exp_nat_mul]
      congr 1
      ring
    rw [hh]
    simp [div_eq_mul_inv]
  rw [hz]
  exact backward_boundary_algebra n r _ _ (Complex.exp_ne_zero _) (equal_angle_factor hs hangle)

lemma equal_finite_boundary_norm (n : ℕ) (φ : ℝ) :
    ‖Complex.exp (((Real.pi - (n : ℝ) * φ : ℝ) : ℂ) * Complex.I)‖ = 1 := by
  rw [Complex.norm_exp]
  simp

lemma backwardCharacteristic_conjugate (n : ℕ) (r b : ℝ) (z : ℂ) :
    backwardCharacteristic n r b (starRingEnd ℂ z) =
      starRingEnd ℂ (backwardCharacteristic n r b z) := by
  simp [backwardCharacteristic]

lemma equal_finite_boundary_pair {n : ℕ} {r φ : ℝ} (hs : Real.sin φ ≠ 0)
    (hangle : r + 1 = Real.sin (((n : ℝ) - 1) * φ) / Real.sin φ) :
    backwardCharacteristic n r ((Real.sin ((n : ℝ) * φ) / Real.sin φ) ^ n)
      (Complex.exp (((Real.pi - (n : ℝ) * φ : ℝ) : ℂ) * Complex.I)) = 0 ∧
    backwardCharacteristic n r ((Real.sin ((n : ℝ) * φ) / Real.sin φ) ^ n)
      (Complex.exp (-(((Real.pi - (n : ℝ) * φ : ℝ) : ℂ) * Complex.I))) = 0 := by
  have hz := equal_finite_boundary hs hangle
  refine ⟨hz, ?_⟩
  have hconj := congrArg (starRingEnd ℂ) hz
  rw [← backwardCharacteristic_conjugate, ← Complex.exp_conj] at hconj
  simpa using hconj

lemma finite_gain_pos {n : ℕ} (hn : 0 < n) {φ : ℝ}
    (hφ : φ ∈ Set.Ioo 0 (Real.pi / (n : ℝ))) :
    0 < (Real.sin ((n : ℝ) * φ) / Real.sin φ) ^ n := by
  have hnR : 0 < (n : ℝ) := by exact_mod_cast hn
  have hnp : (n : ℝ) * φ < Real.pi := by
    have h := (lt_div_iff₀ hnR).mp hφ.2
    nlinarith
  have ht : φ < Real.pi := by
    have hn1 : 1 ≤ (n : ℝ) := by exact_mod_cast hn
    nlinarith [hφ.1]
  have hnum := Real.sin_pos_of_pos_of_lt_pi (mul_pos hnR hφ.1) hnp
  have hden := Real.sin_pos_of_pos_of_lt_pi hφ.1 ht
  exact pow_pos (div_pos hnum hden) n

end C2.NGammaEqual
