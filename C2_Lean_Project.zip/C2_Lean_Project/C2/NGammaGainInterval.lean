import C2.NGammaGainIntervalCore
import C2.NGammaRootCountHighGainAll

/-! Complete exact Schur gain intervals for one or several samples of delay.
The middle-gain implication uses the proved polynomial root count; small gains
use a direct norm inequality and all gains above the finite amplitude endpoint
are excluded by the proved high-gain root count. -/
noncomputable section
open scoped BigOperators
namespace C2.NGamma.Cayley
open PolynomialModel

/-- Exact endpoint interval, including the equality S=1 in its assumptions. -/
theorem single_sample_endpoint_interval {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) (hx1 : ∀ i, x i ≤ 1)
    (hS : Phase.endpointSum r x ≤ 1) {b : ℝ} (hb : 0 ≤ b) :
    SchurStable (characteristic r x 1 b) ↔ b < ∏ i, (r i+2/x i) := by
  constructor
  · intro hs
    by_contra! hbig
    exact not_schur_of_endpoint_le_all_delays hn (le_refl 1) hr hx hbig hs
  · exact single_sample_endpoint_stable hn hr hx hx1 hS hb

/-- The first phase crossing determines the entire stable interval for every
positive integer delay, with no possibility of later stability reentry. -/
theorem interior_exact_gain_interval {n d : ℕ} (hn : 0 < n) (hd : 1 ≤ d)
    {r x : Fin n → ℝ} (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i)
    (hx1 : ∀ i, x i ≤ 1) {s : ℝ} (hs : 0 < s)
    (hphase : Phase.totalPhase (fun i => x i+2/r i) x d s = Real.pi)
    {b : ℝ} (hb : 0 ≤ b) :
    SchurStable (characteristic r x d b) ↔ b < amplitude r x s := by
  by_cases hbound : (∃ j, x j = 0) ∨ b < ∏ i, (r i+2/x i)
  · exact interior_interval_below_endpoint hn hd hr hx hx1 hs hphase hb hbound
  · have hz : ¬ ∃ j, x j = 0 := fun h => hbound (Or.inl h)
    have hxp : ∀ i, 0 < x i := fun i =>
      lt_of_le_of_ne (hx i) (Ne.symm (fun he => hz ⟨i, he⟩))
    have hbig : (∏ i, (r i+2/x i)) ≤ b := by
      by_contra! hh
      exact hbound (Or.inr hh)
    have hBstar := amplitude_lt_endpoint hn hr hxp hs.le
    exact iff_of_false (not_schur_of_endpoint_le_all_delays hn hd hr hxp hbig)
      (not_lt_of_ge (le_trans hBstar.le hbig))

/-- Full one-sample interior alternative of the exact interval theorem. -/
theorem single_sample_interior_interval {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) (hx1 : ∀ i, x i ≤ 1)
    (hcase : (∃ i, x i = 0) ∨ 1 < Phase.endpointSum r x) :
    ∃! s : ℝ, 0 < s ∧
      Phase.totalPhase (fun i => x i+2/r i) x 1 s = Real.pi ∧
      (∀ b : ℝ, 0 ≤ b → (SchurStable (characteristic r x 1 b) ↔ b < amplitude r x s)) ∧
      (characteristic r x 1 (amplitude r x s)).eval (point s) = 0 ∧ ‖point s‖ = 1 := by
  obtain ⟨s, ⟨hs, hphase⟩, huniq⟩ := (Phase.single_sample_phase_crossing_iff hn hr hx hx1).2 hcase
  have hroot := first_crossing_gives_unit_root hr x 1 s hphase
  refine ⟨s, ⟨hs, hphase, ?_, hroot⟩, ?_⟩
  · intro b hb
    exact interior_exact_gain_interval hn (le_refl 1) hr hx hx1 hs hphase hb
  · intro t ht
    exact huniq t ⟨ht.1, ht.2.1⟩

/-- The two alternatives of the paper's exact one-sample gain theorem. -/
theorem single_sample_exact_gain_interval {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) (hx1 : ∀ i, x i ≤ 1) :
    ((∀ i, 0 < x i) ∧ Phase.endpointSum r x ≤ 1 ∧
      (∀ b : ℝ, 0 ≤ b → (SchurStable (characteristic r x 1 b) ↔ b < ∏ i, (r i+2/x i))) ∧
      (characteristic r x 1 (∏ i, (r i+2/x i))).eval (-1) = 0) ∨
    (∃! s : ℝ, 0 < s ∧
      Phase.totalPhase (fun i => x i+2/r i) x 1 s = Real.pi ∧
      (∀ b : ℝ, 0 ≤ b → (SchurStable (characteristic r x 1 b) ↔ b < amplitude r x s)) ∧
      (characteristic r x 1 (amplitude r x s)).eval (point s) = 0 ∧ ‖point s‖ = 1) := by
  by_cases hcase : (∃ i, x i = 0) ∨ 1 < Phase.endpointSum r x
  · exact Or.inr (single_sample_interior_interval hn hr hx hx1 hcase)
  · have hz : ¬ ∃ i, x i = 0 := fun h => hcase (Or.inl h)
    have hxp : ∀ i, 0 < x i := fun i =>
      lt_of_le_of_ne (hx i) (Ne.symm (fun he => hz ⟨i, he⟩))
    have hS : Phase.endpointSum r x ≤ 1 := by
      by_contra! hh
      exact hcase (Or.inr hh)
    exact Or.inl ⟨hxp, hS, fun b hb => single_sample_endpoint_interval hn hr hxp hx1 hS hb,
      endpoint_is_root (fun i => ne_of_gt (hxp i))⟩

/-- Full multiple-delay corollary: unique first phase crossing, strict frequency
bound, exact stable gain interval, and an actual unit-circle boundary root. -/
theorem multiple_delay_exact_gain_interval {n d : ℕ} (hn : 0 < n) (hd : 2 ≤ d)
    {r x : Fin n → ℝ} (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) (hx1 : ∀ i, x i ≤ 1) :
    ∃! s : ℝ, 0 < s ∧ s < Real.tan (Real.pi/(2*(d:ℝ))) ∧
      Phase.totalPhase (fun i => x i+2/r i) x d s = Real.pi ∧
      (∀ b : ℝ, 0 ≤ b → (SchurStable (characteristic r x d b) ↔ b < amplitude r x s)) ∧
      (characteristic r x d (amplitude r x s)).eval (point s) = 0 ∧ ‖point s‖ = 1 := by
  have hax : ∀ i, x i < x i+2/r i := fun i =>
    lt_add_of_pos_right _ (div_pos (by norm_num) (hr i))
  obtain ⟨s, ⟨hs, hbound, hphase⟩, huniq⟩ := Phase.multiple_delay_unique_phase_crossing hn hd hx hx1 hax
  have hroot := first_crossing_gives_unit_root hr x d s hphase
  refine ⟨s, ⟨hs, hbound, hphase, ?_, hroot⟩, ?_⟩
  · intro b hb
    exact interior_exact_gain_interval hn (by omega) hr hx hx1 hs hphase hb
  · intro t ht
    exact huniq t ⟨ht.1, ht.2.1, ht.2.2.1⟩

end C2.NGamma.Cayley
