import C2.IntegratorDelayPhase
import C2.NGammaPhaseEndpoint

noncomputable section
namespace C2.IntegratorDelay
open NGamma.PolynomialModel NGamma.Cayley

def chordPhase (γ w : ℝ) : ℝ :=
  Complex.arg ((1 - (γ : ℂ)) + (γ : ℂ) * Complex.exp ((w : ℂ) * Complex.I))

theorem chordPhase_eq_centered {γ w : ℝ} (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1)
    (hw0 : 0 ≤ w) (hwpi : w < Real.pi) :
    chordPhase γ w = w / 2 + Real.arctan ((2 * γ - 1) * Real.tan (w / 2)) := by
  let x := 2 * γ - 1
  let t := Real.tan (w / 2)
  have ht : 0 ≤ t := Real.tan_nonneg_of_nonneg_of_le_pi_div_two (by linarith) (by linarith)
  have hat : Real.arctan t = w / 2 :=
    Real.arctan_tan (by linarith [Real.pi_pos]) (by linarith)
  have hx0 : -1 ≤ x := by dsimp [x]; linarith
  have hx1 : x ≤ 1 := by dsimp [x]; linarith
  have hleft : -t ≤ x * t := by nlinarith
  have hright : x * t ≤ t := by nlinarith
  have halo := Real.arctan_le_arctan hleft
  have hahi := Real.arctan_le_arctan hright
  rw [Real.arctan_neg, hat] at halo
  rw [hat] at hahi
  have hangle : qPhase x t ∈ Set.Ioc (-Real.pi) Real.pi := by
    unfold qPhase
    rw [hat]
    constructor <;> linarith [Real.pi_pos]
  have hpoint : point t = Complex.exp ((w : ℂ) * Complex.I) := by
    rw [point_exp, hat]
    congr 2
    ring
  have hq : (q x).eval (point t) = (1 - (γ : ℂ)) +
      (γ : ℂ) * Complex.exp ((w : ℂ) * Complex.I) := by
    rw [q_eval, hpoint]
    dsimp [x]
    push_cast
    ring
  have harg : Complex.arg ((q x).eval (point t)) = qPhase x t := by
    rw [q_polar, Complex.exp_mul_I]
    exact Complex.arg_mul_cos_add_sin_mul_I (qAmplitude_pos x t) hangle
  rw [hq] at harg
  simpa only [chordPhase, qPhase, hat, x, t] using harg

theorem manuscript_phase_eq_lowPhase {n : ℕ} {γ w : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (hw0 : 0 ≤ w) (hwpi : w < Real.pi) :
    ((n : ℝ) + 1 / 2) * w - chordPhase γ w = lowPhase n (2 * γ - 1) w := by
  rw [chordPhase_eq_centered hγ0 hγ1 hw0 hwpi]
  unfold lowPhase
  ring

/-- The exact phase equation as printed in `lem:phase`, with the chord's
actual principal complex argument. -/
theorem existsUnique_manuscript_frequency {n : ℕ} (hn : 2 ≤ n) {γ : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    ∃! w : ℝ, w ∈ Set.Icc (lowerFrequency n) (upperFrequency n) ∧
      ((n : ℝ) + 1 / 2) * w - chordPhase γ w = Real.pi / 2 := by
  have hx0 : -1 ≤ 2 * γ - 1 := by linarith
  have hx1 : 2 * γ - 1 ≤ 1 := by linarith
  have he (w : ℝ) (hw : w ∈ Set.Icc (lowerFrequency n) (upperFrequency n)) :
      ((n : ℝ) + 1 / 2) * w - chordPhase γ w = lowPhase n (2 * γ - 1) w := by
    have hb := frequency_bounds hn hw
    exact manuscript_phase_eq_lowPhase hγ0 hγ1 hb.1.le (by linarith [hb.2.1, Real.pi_pos])
  obtain ⟨w, hw, hu⟩ := existsUnique_low_frequency hn hx0 hx1
  refine ⟨w, ⟨hw.1, ?_⟩, ?_⟩
  · rw [he w hw.1]
    exact hw.2
  · intro v hv
    apply hu v
    refine ⟨hv.1, ?_⟩
    rw [← he v hv.1]
    exact hv.2

theorem manuscript_frequency_strictMonoOn {n : ℕ} (hn : 2 ≤ n) :
    StrictMonoOn (fun γ : ℝ => frequency n (2 * γ - 1)) (Set.Icc 0 1) := by
  intro γ hγ δ hδ hlt
  exact frequency_strictMonoOn hn
    ⟨by linarith [hγ.1], by linarith [hγ.2]⟩
    ⟨by linarith [hδ.1], by linarith [hδ.2]⟩ (by linarith)

end C2.IntegratorDelay
