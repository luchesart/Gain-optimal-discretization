import C2.NGammaGainBridge
import C2.NGammaSinglePhase

/-! A single critical-gain relation, with the endpoint and finite-frequency
cases stated using the actual amplitude and phase. Its global optimizer is
unique. The relation is translated to Schur stability in a separate module. -/
noncomputable section
open scoped BigOperators
open Set
namespace C2.NGamma.Global

def CriticalGain {n : ℕ} (r x : Fin n → ℝ) (B : ℝ) : Prop :=
  ((∀ j, 0 < x j) ∧ (∑ j, endpointCost (r j) (x j)) ≤ 1 ∧ B = ∏ j, (r j+2/x j)) ∨
    ∃ t : ℝ, 0 < t ∧ Phase.totalPhase (fun j => x j+2/r j) x 1 t = Real.pi ∧
      B = Cayley.amplitude r x t

/-- The explicit parameter prescription in the three regimes of the paper. -/
def OptimalParameterDescription {n : ℕ} (r x : Fin n → ℝ) : Prop :=
  (1 < endpointSum r → x = fun _ => 1) ∧
  (endpointSum r = 1 → x = fun _ => 1) ∧
  (endpointSum r < 1 → ∃ c : ℝ, 0 < c ∧ allocatedResource r c = 4 ∧
    x = fun j => endpointParameter (r j) c)

theorem criticalGain_pos {n : ℕ} {r x : Fin n → ℝ} (hr : ∀ j, 0 < r j)
    {B : ℝ} (hB : CriticalGain r x B) : 0 < B := by
  rcases hB with ⟨hx,hS,rfl⟩ | ⟨t,ht,hp,rfl⟩
  · exact Finset.prod_pos (fun j _ => by have := hr j; have := hx j; positivity)
  · exact Cayley.amplitude_pos hr x t

theorem criticalGain_of_frequency {n : ℕ} (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {w : ℝ} (hw : 0 < w)
    (hp : (∑ j, allocationPhase (r j) (x j) w) = 2*Real.arctan w) :
    CriticalGain r x (∏ j, allocationGain (r j) (x j) w) := by
  exact Or.inr ⟨1/w,one_div_pos.mpr hw,(phase_balance_iff_totalPhase r x hw).mp hp,
    allocationProduct_eq_amplitude r x hr hw⟩

theorem finite_critical_to_frequency {n : ℕ} (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {t B : ℝ} (ht : 0 < t)
    (hp : Phase.totalPhase (fun j => x j+2/r j) x 1 t = Real.pi)
    (hB : B = Cayley.amplitude r x t) :
    ∃ w : ℝ, 0 < w ∧ (∑ j, allocationPhase (r j) (x j) w) = 2*Real.arctan w ∧
      B = ∏ j, allocationGain (r j) (x j) w := by
  refine ⟨1/t,one_div_pos.mpr ht,?_,?_⟩
  · apply (phase_balance_iff_totalPhase r x (one_div_pos.mpr ht)).mpr
    simpa only [one_div_one_div] using hp
  · rw [allocationProduct_eq_amplitude r x hr (one_div_pos.mpr ht),one_div_one_div]
    exact hB

theorem criticalGain_exists {n : ℕ} (hn : 0 < n) (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hx : ∀ j, x j ∈ Icc (0:ℝ) 1) :
    ∃ B : ℝ, CriticalGain r x B := by
  by_cases hc : (∃ j, x j = 0) ∨ 1 < Phase.endpointSum r x
  · obtain ⟨t,ht,_⟩ := (Phase.single_sample_phase_crossing_iff hn hr
      (fun j => (hx j).1) (fun j => (hx j).2)).mpr hc
    exact ⟨Cayley.amplitude r x t,Or.inr ⟨t,ht.1,ht.2,rfl⟩⟩
  · push_neg at hc
    exact ⟨∏ j, (r j+2/x j),Or.inl
      ⟨fun j => lt_of_le_of_ne (hx j).1 (Ne.symm (hc.1 j)),hc.2,rfl⟩⟩

theorem criticalGain_unique {n : ℕ} (hn : 0 < n) (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    {A B : ℝ} (hA : CriticalGain r x A) (hB : CriticalGain r x B) : A = B := by
  rcases hA with ⟨ha,hS,hA⟩ | ⟨s,hs,hps,hA⟩
  · rcases hB with ⟨hb,hT,hB⟩ | ⟨t,ht,hpt,hB⟩
    · exact hA.trans hB.symm
    · have hlt := Phase.single_phase_below_pi_of_endpoint hn hr ha (fun j => (hx j).2) hS ht
      exact False.elim ((ne_of_lt hlt) hpt)
  · rcases hB with ⟨hb,hT,hB⟩ | ⟨t,ht,hpt,hB⟩
    · have hlt := Phase.single_phase_below_pi_of_endpoint hn hr hb (fun j => (hx j).2) hT hs
      exact False.elim ((ne_of_lt hlt) hps)
    · have hst := Phase.first_phase_crossing_unique hn (by norm_num : 1 ≤ (1:ℕ))
        (fun j => (hx j).1) (fun j => (hx j).2)
        (fun j => lt_add_of_pos_right _ (div_pos (by norm_num) (hr j))) hs ht hps hpt
      rw [hA,hB,hst]

theorem log_gain_product {n : ℕ} (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {w : ℝ} (hw : 0 < w) :
    Real.log (∏ j, allocationGain (r j) (x j) w) = ∑ j, allocationLogGain (r j) (x j) w := by
  rw [Real.log_prod _ _ (fun j _ => ne_of_gt (allocationGain_pos (hr j) hw _))]
  exact Finset.sum_congr rfl (fun j _ => log_allocationGain (hr j) hw (x j))

/-- Unified global gain optimizer, with no assumed maximizing vector, scalar,
or regularity. The explicit three regimes are proved by the imported allocation
and outer-monotonicity theorems. -/
theorem exists_unique_global_critical_gain_classified {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    ∃ xstar : Fin n → ℝ, ∃ Bstar : ℝ,
      (∀ j, xstar j ∈ Icc (0:ℝ) 1) ∧ CriticalGain r xstar Bstar ∧
      OptimalParameterDescription r xstar ∧
      ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) → ∀ B : ℝ, CriticalGain r x B →
        B ≤ Bstar ∧ (B = Bstar ↔ x = xstar) := by
  by_cases hlarge : 1 < endpointSum r
  · obtain ⟨wm,hwm,hp,hopt⟩ := positive_endpoint_unique_global_maximum hn r hr hlarge
    let Bstar := ∏ j, allocationGain (r j) 1 wm
    have hstar : CriticalGain r (fun _ => 1) Bstar := criticalGain_of_frequency r _ hr hwm hp
    refine ⟨fun _ => 1,Bstar,fun _ => by norm_num,hstar,?_,?_⟩
    · exact ⟨fun _ => rfl,fun _ => rfl,fun hsmall => False.elim (not_lt_of_ge hlarge.le hsmall)⟩
    intro x hx B hB
    have hleuniq : B ≤ Bstar ∧ (B = Bstar → x = fun _ => 1) := by
      rcases hB with ⟨hxp,hS,hBeq⟩ | ⟨t,ht,hpt,hBeq⟩
      · have hbase := (endpoint_feasible_iff r hr).mp ⟨x,fun j => ⟨hxp j,(hx j).2⟩,hS⟩
        exact False.elim (not_lt_of_ge hbase hlarge)
      · obtain ⟨w,hw,hphase,hgain⟩ := finite_critical_to_frequency r x hr ht hpt hBeq
        have hoptx := hopt w hw x hx hphase
        have hBP : 0 < B := hgain ▸ Finset.prod_pos (fun j _ => allocationGain_pos (hr j) hw _)
        have hSP : 0 < Bstar := Finset.prod_pos (fun j _ => allocationGain_pos (hr j) hwm _)
        have hlogs : Real.log B ≤ Real.log Bstar := by
          rw [hgain,log_gain_product r x hr hw]
          change _ ≤ Real.log (∏ j, allocationGain (r j) 1 wm)
          rw [log_gain_product r (fun _ => 1) hr hwm]
          exact hoptx.1
        refine ⟨(Real.log_le_log_iff hBP hSP).mp hlogs,?_⟩
        intro heq
        have hlogeq := congrArg Real.log heq
        rw [hgain,log_gain_product r x hr hw] at hlogeq
        change _ = Real.log (∏ j, allocationGain (r j) 1 wm) at hlogeq
        rw [log_gain_product r (fun _ => 1) hr hwm] at hlogeq
        exact ((hoptx.2).mp hlogeq).2
    refine ⟨hleuniq.1,hleuniq.2,?_⟩
    intro heq
    subst x
    exact criticalGain_unique hn r _ hr hx hB hstar
  by_cases hsmall : endpointSum r < 1
  · obtain ⟨c,hc,hbudget,hparam,hcost,hopt,hfinite⟩ := exists_unique_global_endpoint_optimizer hn r hr hsmall
    let xstar : Fin n → ℝ := fun j => endpointParameter (r j) c
    let Bstar : ℝ := ∏ j, endpointAllocation (r j) c
    have hxstar : ∀ j, xstar j ∈ Icc (0:ℝ) 1 := fun j => ⟨(hparam j).1.le,(hparam j).2⟩
    have hstar : CriticalGain r xstar Bstar := Or.inl
      ⟨fun j => (hparam j).1,hcost.le,(Finset.prod_congr rfl (fun j _ => endpointParameter_inverse (r j) c)).symm⟩
    refine ⟨xstar,Bstar,hxstar,hstar,?_,?_⟩
    · exact ⟨fun hlarge => False.elim (not_lt_of_ge hlarge.le hsmall),
        fun hequal => False.elim ((ne_of_lt hsmall) hequal),fun _ => ⟨c,hc,hbudget,rfl⟩⟩
    intro x hx B hB
    have hleuniq : B ≤ Bstar ∧ (B = Bstar → x = xstar) := by
      rcases hB with ⟨hxp,hS,hBeq⟩ | ⟨t,ht,hpt,hBeq⟩
      · rw [hBeq]
        exact ⟨(hopt x (fun j => ⟨hxp j,(hx j).2⟩) hS).1,
          (hopt x (fun j => ⟨hxp j,(hx j).2⟩) hS).2.mp⟩
      · obtain ⟨w,hw,hphase,hgain⟩ := finite_critical_to_frequency r x hr ht hpt hBeq
        have hlt : B < Bstar := by rw [hgain]; exact hfinite w hw x hx hphase
        exact ⟨hlt.le,fun heq => False.elim ((ne_of_lt hlt) heq)⟩
    refine ⟨hleuniq.1,hleuniq.2,?_⟩
    intro heq
    subst x
    exact criticalGain_unique hn r _ hr hx hB hstar
  · have hequal : endpointSum r = 1 := le_antisymm (le_of_not_gt hlarge) (le_of_not_gt hsmall)
    let Bstar : ℝ := ∏ j, (r j+2)
    have hcost : (∑ j, endpointCost (r j) 1) = 1 := by
      simpa [endpointSum,endpointCost,add_comm] using hequal
    have hstar : CriticalGain r (fun _ => 1) Bstar := Or.inl
      ⟨fun _ => by norm_num,hcost.le,by simp [Bstar]⟩
    refine ⟨fun _ => 1,Bstar,fun _ => by norm_num,hstar,?_,?_⟩
    · exact ⟨fun _ => rfl,fun _ => rfl,fun hsmall => False.elim ((ne_of_lt hsmall) hequal)⟩
    intro x hx B hB
    have hleuniq : B ≤ Bstar ∧ (B = Bstar → x = fun _ => 1) := by
      rcases hB with ⟨hxp,hS,hBeq⟩ | ⟨t,ht,hpt,hBeq⟩
      · have hxone := endpoint_feasible_equality_unique r x hr (fun j => ⟨hxp j,(hx j).2⟩) hequal hS
        have hBB : B = Bstar := by rw [hBeq,hxone]; simp [Bstar]
        exact ⟨hBB.le,fun _ => hxone⟩
      · obtain ⟨w,hw,hphase,hgain⟩ := finite_critical_to_frequency r x hr ht hpt hBeq
        have hlt : B < Bstar := by rw [hgain]; exact positive_frequency_below_endpoint_equality hn r x hr hequal hw hx hphase
        exact ⟨hlt.le,fun heq => False.elim ((ne_of_lt hlt) heq)⟩
    refine ⟨hleuniq.1,hleuniq.2,?_⟩
    intro heq
    subst x
    exact criticalGain_unique hn r _ hr hx hB hstar

/-- The unclassified interface used by subsequent stability wrappers. -/
theorem exists_unique_global_critical_gain {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    ∃ xstar : Fin n → ℝ, ∃ Bstar : ℝ,
      (∀ j, xstar j ∈ Icc (0:ℝ) 1) ∧ CriticalGain r xstar Bstar ∧
      ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) → ∀ B : ℝ, CriticalGain r x B →
        B ≤ Bstar ∧ (B = Bstar ↔ x = xstar) := by
  obtain ⟨xstar,Bstar,hx,hB,hdescription,hopt⟩ := exists_unique_global_critical_gain_classified hn r hr
  exact ⟨xstar,Bstar,hx,hB,hopt⟩

end C2.NGamma.Global
