import C2.NGammaRootCountHighGain
import C2.NGammaCharacteristicLift
import C2.NGammaPolynomialDegree
import C2.NGammaAmplitudeOrder

/-! Above the finite magnitude endpoint, the translated transfer curve lies in
an open right half-plane. Its argument has zero endpoint change, so exactly d
roots are exterior whenever the endpoint itself is nonzero. -/
noncomputable section
open scoped BigOperators ComplexConjugate Topology
open Set Complex Polynomial Filter
namespace C2.NGamma.Cayley
open PolynomialModel RootCountBridge ArgumentMatch
variable {n : ℕ} {r x : Fin n → ℝ}

def highGainAngle (r x : Fin n → ℝ) (d : ℕ) (b t : ℝ) : ℝ :=
  (∑ i, qPhase (x i) t) + Complex.arg (transfer r x d (point t)+b)

theorem high_gain_count_from_endpoint (hn : 0 < n) {d : ℕ} (hd : 1 ≤ d)
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) {b : ℝ}
    (hb : (∏ i, (r i+2/x i)) ≤ b)
    (hend : (characteristic r x d b).eval (-1) ≠ 0) :
    countOutside (characteristic r x d b) = d := by
  let B : ℝ := ∏ i, (r i+2/x i)
  have hB : 0 < B := Finset.prod_pos (fun i _ => add_pos (hr i) (div_pos (by norm_num) (hx i)))
  have hbpos : 0 < b := lt_of_lt_of_le hB hb
  have hW : Continuous (fun t => transfer r x d (point t)) := by
    have hh := polarCurve_continuous (amplitude_continuous r x)
      (Phase.totalPhase_continuous (fun i => x i+2/r i) x d)
    change Continuous (fun t => polarCurve (amplitude r x)
      (Phase.totalPhase (fun i => x i+2/r i) x d) t) at hh
    simpa only [polarCurve, ← transfer_polar (fun i => ne_of_gt (hr i))] using hh
  have hRe : ∀ t : ℝ, 0 ≤ t → 0 < (transfer r x d (point t)+(b:ℂ)).re := by
    intro t ht
    apply add_re_pos_of_norm_lt
    rw [transfer_norm hr]
    exact lt_of_lt_of_le (amplitude_lt_endpoint hn hr hx ht) hb
  have hfinite : ∀ t : ℝ, 0 ≤ t → (characteristic r x d b).eval (point t) ≠ 0 := by
    intro t ht
    rw [characteristic_eval_point]
    apply mul_ne_zero (Finset.prod_ne_zero_iff.2 (fun i _ => q_eval_point_ne_zero (x i) t))
    intro he
    have hh := hRe t ht
    rw [he] at hh
    exact lt_irrefl 0 hh
  have hroots := no_unit_roots_of_cayley_nonzero (characteristic_eval_conj r x d b) hfinite hend
  have hcont : ContinuousOn (highGainAngle r x d b) (Set.Ici 0) := by
    apply (continuous_finset_sum _ (fun i _ => qPhase_continuous (x i))).continuousOn.add
    intro t ht
    exact ContinuousAt.comp_continuousWithinAt
      (f := fun u => transfer r x d (point u)+(b:ℂ))
      (Complex.continuousAt_arg (Or.inl (hRe t ht)))
      (hW.add continuous_const).continuousAt.continuousWithinAt
  have hpolar : ∀ t ∈ Set.Ici (0:ℝ), (characteristic r x d b).eval (point t) =
      (‖(characteristic r x d b).eval (point t)‖:ℂ)*
      Complex.exp ((highGainAngle r x d b t:ℂ)*I) := by
    intro t ht
    rw [characteristic_eval_point]
    exact polar_mul (q_product_polar x t) (Complex.norm_mul_exp_arg_mul_I _).symm
  let C : ℝ := B*(-1)^d+b
  have hCnonneg : 0 ≤ C := by
    have hh : |(-1:ℝ)^d| = 1 := by simp
    have hl := neg_abs_le ((-1:ℝ)^d)
    dsimp [C]
    nlinarith
  have hCne : C ≠ 0 := by
    intro he
    apply hend
    rw [characteristic_neg_one_factorized hx]
    have hh : (-1:ℂ)^d*((∏ i, (r i+2/x i):ℝ):ℂ)+(b:ℂ) = (C:ℂ) := by
      dsimp [C,B]
      push_cast
      ring
    rw [hh, he, Complex.ofReal_zero, mul_zero]
  have hCpos : 0 < C := lt_of_le_of_ne hCnonneg (Ne.symm hCne)
  have hWlim : Tendsto (fun t => transfer r x d (point t)+(b:ℂ)) atTop (𝓝 (C:ℂ)) := by
    convert (transfer_point_tendsto_atTop hr hx d).add_const (b:ℂ) using 1
    dsimp [C,B]
    push_cast
    ring
  have hargLim : Tendsto (fun t => Complex.arg (transfer r x d (point t)+(b:ℂ))) atTop (𝓝 0) := by
    have h := (Complex.continuousAt_arg (Or.inl (show 0 < (C:ℂ).re from hCpos))).tendsto.comp hWlim
    simpa only [Complex.arg_ofReal_of_nonneg hCpos.le] using h
  have hqLim : Tendsto (fun t => ∑ i, qPhase (x i) t) atTop (𝓝 ((n:ℝ)*Real.pi)) := by
    simpa [ne_of_gt (hx _)] using sum_qPhase_tendsto_atTop (fun i => (hx i).le)
  have hlim : Tendsto (highGainAngle r x d b) atTop (𝓝 ((n:ℝ)*Real.pi)) := by
    simpa only [add_zero] using hqLim.add hargLim
  have hzero : highGainAngle r x d b 0 = 0 := by
    simp only [highGainAngle, qPhase, mul_zero, Real.arctan_zero, add_zero,
      Finset.sum_const_zero, zero_add]
    have hWzero : transfer r x d (point 0) = ((∏ i, r i : ℝ):ℂ) := by
      simp [transfer, point, q_eval_one, factor_eval_one]
    rw [hWzero, ← Complex.ofReal_add]
    apply Complex.arg_ofReal_of_nonneg
    exact (add_pos (Finset.prod_pos (fun i _ => hr i)) hbpos).le
  have hc := polynomial_argument_principle_cayley
    (characteristic_ne_zero hr (fun i => (hx i).le) hd b)
    (characteristic_eval_conj r x d b) hroots hcont hpolar hlim
  rw [hzero, sub_zero] at hc
  have hi : countInside (characteristic r x d b) = n := by
    have hh : (countInside (characteristic r x d b):ℝ) = n :=
      mul_right_cancel₀ Real.pi_ne_zero hc.symm
    exact_mod_cast hh
  have hp := count_partition (characteristic r x d b) hroots
  rw [hi, characteristic_natDegree hr (fun i => (hx i).le) hd b, Fintype.card_fin] at hp
  omega

theorem not_schur_of_endpoint_le_all_delays (hn : 0 < n) {d : ℕ} (hd : 1 ≤ d)
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) {b : ℝ}
    (hb : (∏ i, (r i+2/x i)) ≤ b) :
    ¬ SchurStable (characteristic r x d b) := by
  intro hs
  by_cases hend : (characteristic r x d b).eval (-1) = 0
  · have hh := hs (-1) hend
    simpa using hh
  · have hcount := high_gain_count_from_endpoint hn hd hr hx hb hend
    have hp := characteristic_ne_zero hr (fun i => (hx i).le) hd b
    have hroots : ∀ a ∈ (characteristic r x d b).roots, ‖a‖ ≠ 1 := by
      intro a ha
      exact ne_of_lt (hs a ((Polynomial.mem_roots hp).1 ha))
    have hz := (schur_iff_countOutside_zero hp hroots).1 hs
    omega

end C2.NGamma.Cayley
