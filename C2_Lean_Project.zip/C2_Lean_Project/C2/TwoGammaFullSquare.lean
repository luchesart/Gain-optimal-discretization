import C2.TwoGammaCubic
import C2.TwoGammaOptimum

/-! Algebraic exclusion of large-gain stability outside the positive half
square. This argument does not assume connected stable components there. -/
noncomputable section
open scoped BigOperators
open Set
namespace C2.TwoGamma
open NGamma NGamma.PolynomialModel

/-- Full-square global exclusion for every stable gain, including any isolated
stable component. -/
theorem full_square_gain_bound {r₁ r₂ γ₁ γ₂ b : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂)
    (hg₁ : γ₁ ∈ Icc (0:ℝ) 1) (hg₂ : γ₂ ∈ Icc (0:ℝ) 1)
    (hb : 0 ≤ b) (hs : SchurStable (characteristic r₁ r₂ γ₁ γ₂ b)) : b < gain r₁ r₂ := by
  by_contra! hbig
  have hx := (Parameterization.full_cube_coordinate γ₁).mp hg₁
  have hy := (Parameterization.full_cube_coordinate γ₂).mp hg₂
  have hs' : SchurStable (PolynomialModel.characteristic (poles r₁ r₂)
      ![Parameterization.xOfGamma γ₁,Parameterization.xOfGamma γ₂] 1 b) := by
    simpa only [characteristic_eq_generic,coordinates] using hs
  obtain ⟨ha₁,ha₂,ha₃,hH⟩ := stable_necessary h₁ h₂ hx hy hb hs'
  have hxpos : 0 < Parameterization.xOfGamma γ₁ := by
    by_contra! hn
    exact closed_high_gain_exclusion_left h₁ h₂ hbig hn ha₁.le ha₂.le hH.le
  have hypos : 0 < Parameterization.xOfGamma γ₂ := by
    by_contra! hn
    exact closed_high_gain_exclusion_right h₁ h₂ hbig hn ha₁.le ha₂.le hH.le
  have hh₁ : γ₁ ∈ Icc (1/2:ℝ) 1 :=
    (Parameterization.half_cube_coordinate γ₁).mpr ⟨hxpos.le,hx.2⟩
  have hh₂ : γ₂ ∈ Icc (1/2:ℝ) 1 :=
    (Parameterization.half_cube_coordinate γ₂).mpr ⟨hypos.le,hy.2⟩
  exact not_lt_of_ge hbig (half_square_gain_bound h₁ h₂ hh₁ hh₂ hb hs)

end C2.TwoGamma
