import C2.IntegratorDelayTwo

/-! Algebraic transversality for unit roots of the delayed integrator.
The constant-term restriction is used only as an explicit strict inequality.
All norm and logarithmic-derivative identities concern the actual complex
characteristic, not a surrogate stability predicate. -/

noncomputable section
namespace C2.IntegratorDelay

def feedback (γ : ℝ) (z : ℂ) : ℂ := (γ : ℂ) * z + 1 - γ

def logSlope (n : ℕ) (γ : ℝ) (z : ℂ) : ℂ :=
  n + z / (z - 1) - (γ : ℂ) * z / feedback γ z

theorem unit_feedback_norm {γ : ℝ} {z : ℂ} (hz : ‖z‖ = 1) :
    Complex.normSq (feedback γ z) =
      γ ^ 2 + (1 - γ) ^ 2 + 2 * γ * (1 - γ) * z.re := by
  have hu : z.re ^ 2 + z.im ^ 2 = 1 := by
    have h := Complex.sq_norm z
    rw [hz, Complex.normSq_apply] at h
    nlinarith
  simp only [feedback, Complex.normSq_apply, Complex.add_re, Complex.sub_re,
    Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, Complex.one_re,
    Complex.add_im, Complex.sub_im, Complex.mul_im, Complex.one_im]
  linear_combination γ ^ 2 * hu

theorem unit_feedback_norm_lower {γ : ℝ} {z : ℂ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (hz : ‖z‖ = 1) :
    (2 * γ - 1) ^ 2 ≤ Complex.normSq (feedback γ z) := by
  have hx : -1 ≤ z.re := by
    have h : |z.re| ≤ 1 := by simpa [hz] using Complex.abs_re_le_norm z
    exact (abs_le.mp h).1
  rw [unit_feedback_norm hz]
  nlinarith [mul_nonneg (mul_nonneg hγ0 (show 0 ≤ 1 - γ by linarith))
    (show 0 ≤ z.re + 1 by linarith)]

theorem unit_root_feedback_ne_zero {n : ℕ} {γ a : ℝ} {z : ℂ}
    (ha : 0 < a) (hz : ‖z‖ = 1) (hp : characteristic n γ a z = 0) :
    z ≠ 1 ∧ feedback γ z ≠ 0 := by
  have hz0 : z ≠ 0 := by intro h; simpa [h] using hz
  have hz1 : z ≠ 1 := by
    intro h
    subst z
    simp only [characteristic, one_pow, sub_self, mul_zero, mul_one,
      add_sub_cancel_left, mul_one, zero_add] at hp
    have : a = 0 := by exact_mod_cast hp
    linarith
  refine ⟨hz1, ?_⟩
  intro hq
  have h : z ^ n * (z - 1) = 0 := by
    change z ^ n * (z - 1) + (a : ℂ) * feedback γ z = 0 at hp
    simpa only [hq, mul_zero, add_zero] using hp
  exact (mul_ne_zero (pow_ne_zero n hz0) (sub_ne_zero.mpr hz1)) h

theorem unit_root_norm_identity {n : ℕ} {γ a : ℝ} {z : ℂ}
    (hz : ‖z‖ = 1) (hp : characteristic n γ a z = 0) :
    Complex.normSq (feedback γ z) * (1 + a ^ 2 * γ * (1 - γ)) = 1 := by
  have hu : Complex.normSq z = 1 := by rw [Complex.normSq_eq_norm_sq, hz]; norm_num
  have he : z ^ n * (z - 1) = -(a : ℂ) * feedback γ z := by
    unfold characteristic at hp
    unfold feedback
    linear_combination hp
  have hn := congrArg Complex.normSq he
  simp only [map_mul, map_pow, hu, one_pow, one_mul, Complex.normSq_neg,
    Complex.normSq_ofReal, Complex.normSq_sub, Complex.normSq_one,
    map_one, mul_one] at hn
  have hR := unit_feedback_norm (γ := γ) hz
  linear_combination hR - γ * (1 - γ) * hn

/-- A sharpened scalar form of the constant-term barrier argument. -/
theorem constant_term_barrier {γ a R : ℝ} (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1)
    (ha : 0 < a) (hc : a * (1 - γ) < 1) (hR : 0 < R)
    (hlower : (2 * γ - 1) ^ 2 ≤ R)
    (heq : R * (1 + a ^ 2 * γ * (1 - γ)) = 1) :
    2 * γ - 1 < 2 * R := by
  by_cases ht : 2 * γ - 1 ≤ 0
  · linarith
  have hγ : 0 < γ := by linarith
  have hc0 : 0 ≤ a * (1 - γ) := mul_nonneg ha.le (by linarith)
  have hc2 : (a * (1 - γ)) ^ 2 < 1 := by nlinarith
  have he : 1 - γ = R * (1 - γ) + R * γ * (a * (1 - γ)) ^ 2 := by
    linear_combination -(1 - γ) * heq
  have hmul := mul_lt_mul_of_pos_left hc2 (mul_pos hR hγ)
  have hRlower : 1 - γ < R := by nlinarith
  by_contra! hbad
  have htpos : 0 < 2 * γ - 1 := by linarith
  have hthalf : 0 < (2 * γ - 1) - 1 / 2 := by linarith
  have hprod := mul_pos htpos hthalf
  nlinarith

theorem unit_div_sub_one_re {z : ℂ} (hz : ‖z‖ = 1) (hne : z ≠ 1) :
    (z / (z - 1)).re = 1 / 2 := by
  have hu : z.re ^ 2 + z.im ^ 2 = 1 := by
    have h := Complex.sq_norm z
    rw [hz, Complex.normSq_apply] at h
    nlinarith
  have hd : Complex.normSq (z - 1) ≠ 0 :=
    (Complex.normSq_pos.mpr (sub_ne_zero.mpr hne)).ne'
  rw [Complex.div_re, ← add_div]
  apply (div_eq_iff hd).2
  simp only [Complex.sub_re, Complex.sub_im, Complex.one_re, Complex.one_im,
    Complex.normSq_apply]
  nlinarith

theorem unit_feedback_div_re {γ : ℝ} {z : ℂ} (hz : ‖z‖ = 1)
    (hq : feedback γ z ≠ 0) :
    ((γ : ℂ) * z / feedback γ z).re =
      1 / 2 + (2 * γ - 1) / (2 * Complex.normSq (feedback γ z)) := by
  have hu : z.re ^ 2 + z.im ^ 2 = 1 := by
    have h := Complex.sq_norm z
    rw [hz, Complex.normSq_apply] at h
    nlinarith
  have hd : Complex.normSq (feedback γ z) ≠ 0 := (Complex.normSq_pos.mpr hq).ne'
  have hnum : ((γ : ℂ) * z).re * (feedback γ z).re +
      ((γ : ℂ) * z).im * (feedback γ z).im =
      (Complex.normSq (feedback γ z) + (2 * γ - 1)) / 2 := by
    rw [unit_feedback_norm hz]
    simp only [feedback, Complex.add_re, Complex.sub_re,
      Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, Complex.one_re,
      Complex.add_im, Complex.sub_im, Complex.mul_im, Complex.one_im]
    linear_combination γ ^ 2 * hu
  rw [Complex.div_re, ← add_div, hnum]
  field_simp [hd] <;> ring

theorem logSlope_re {n : ℕ} {γ a : ℝ} {z : ℂ}
    (ha : 0 < a) (hz : ‖z‖ = 1) (hp : characteristic n γ a z = 0) :
    (logSlope n γ z).re =
      (n : ℝ) - (2 * γ - 1) / (2 * Complex.normSq (feedback γ z)) := by
  obtain ⟨hz1, hq⟩ := unit_root_feedback_ne_zero ha hz hp
  simp only [logSlope, Complex.sub_re, Complex.add_re, Complex.natCast_re,
    unit_div_sub_one_re hz hz1, unit_feedback_div_re hz hq]
  ring

/-- Every unit root below the strict constant-term barrier has positive
real logarithmic slope. This holds even for one delay sample. -/
theorem logSlope_re_pos {n : ℕ} {γ a : ℝ} {z : ℂ}
    (hn : 1 ≤ n) (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1)
    (ha : 0 < a) (hc : a * (1 - γ) < 1)
    (hz : ‖z‖ = 1) (hp : characteristic n γ a z = 0) :
    0 < (logSlope n γ z).re := by
  have hq := (unit_root_feedback_ne_zero ha hz hp).2
  have hR := Complex.normSq_pos.mpr hq
  have ht := constant_term_barrier hγ0 hγ1 ha hc hR
    (unit_feedback_norm_lower hγ0 hγ1 hz) (unit_root_norm_identity hz hp)
  have hdiv : (2 * γ - 1) / (2 * Complex.normSq (feedback γ z)) < 1 :=
    (div_lt_one (by positivity)).mpr ht
  rw [logSlope_re ha hz hp]
  have hn' : (1 : ℝ) ≤ n := by exact_mod_cast hn
  linarith

theorem inverse_logSlope_re_pos {n : ℕ} {γ a : ℝ} {z : ℂ}
    (hn : 1 ≤ n) (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1)
    (ha : 0 < a) (hc : a * (1 - γ) < 1)
    (hz : ‖z‖ = 1) (hp : characteristic n γ a z = 0) :
    0 < (logSlope n γ z)⁻¹.re := by
  have hre := logSlope_re_pos hn hγ0 hγ1 ha hc hz hp
  have hne : logSlope n γ z ≠ 0 := by intro h; simpa [h] using hre
  rw [Complex.inv_re]
  exact div_pos hre (Complex.normSq_pos.mpr hne)

def characteristicDerivative (n : ℕ) (γ a : ℝ) (z : ℂ) : ℂ :=
  (n : ℂ) * z ^ (n - 1) * (z - 1) + z ^ n + (a : ℂ) * γ

theorem characteristic_hasDerivAt (n : ℕ) (γ a : ℝ) (z : ℂ) :
    HasDerivAt (characteristic n γ a) (characteristicDerivative n γ a z) z := by
  have h1 := ((hasDerivAt_id z).pow n).mul ((hasDerivAt_id z).sub_const 1)
  have h2 := ((((hasDerivAt_id z).const_mul (γ : ℂ)).add_const 1).sub_const
    (γ : ℂ)).const_mul (a : ℂ)
  convert h1.add h2 using 1 <;> simp [characteristic, characteristicDerivative] <;> ring

theorem root_derivative_logSlope {n : ℕ} {γ a : ℝ} {z : ℂ}
    (hn : 1 ≤ n) (ha : 0 < a) (hz : ‖z‖ = 1)
    (hp : characteristic n γ a z = 0) :
    z * characteristicDerivative n γ a z =
      z ^ n * (z - 1) * logSlope n γ z := by
  obtain ⟨hz1, hq⟩ := unit_root_feedback_ne_zero ha hz hp
  have hz1' := sub_ne_zero.mpr hz1
  have he : z ^ n * (z - 1) = -(a : ℂ) * feedback γ z := by
    unfold characteristic at hp
    unfold feedback
    linear_combination hp
  have hpow : z * z ^ (n - 1) = z ^ n := by
    rw [← pow_succ', Nat.sub_add_cancel hn]
  have hfirst : z ^ n * (z - 1) * (z / (z - 1)) = z ^ n * z := by
    field_simp <;> ring
  have hlast : z ^ n * (z - 1) * ((γ : ℂ) * z / feedback γ z) =
      -(a : ℂ) * γ * z := by
    rw [he]
    field_simp <;> ring
  rw [logSlope, mul_sub, mul_add, hfirst, hlast]
  unfold characteristicDerivative
  linear_combination (n : ℂ) * (z - 1) * hpow

/-- Simplicity and the strictly positive radial logarithmic velocity at every
unit root below the constant-term barrier (the content of `lem:outward`). -/
theorem unit_root_transversality {n : ℕ} {γ a : ℝ} {z : ℂ}
    (hn : 1 ≤ n) (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1)
    (ha : 0 < a) (hc : a * (1 - γ) < 1)
    (hz : ‖z‖ = 1) (hp : characteristic n γ a z = 0) :
    characteristicDerivative n γ a z ≠ 0 ∧
      0 < (-(a : ℂ) * feedback γ z /
        (z * characteristicDerivative n γ a z)).re := by
  obtain ⟨hz1, hq⟩ := unit_root_feedback_ne_zero ha hz hp
  have hz0 : z ≠ 0 := by intro h; simpa [h] using hz
  have hB : logSlope n γ z ≠ 0 := by
    have h := logSlope_re_pos hn hγ0 hγ1 ha hc hz hp
    intro he
    simpa [he] using h
  have hder := root_derivative_logSlope hn ha hz hp
  have hD : characteristicDerivative n γ a z ≠ 0 := by
    intro he
    rw [he, mul_zero] at hder
    exact (mul_ne_zero (mul_ne_zero (pow_ne_zero n hz0) (sub_ne_zero.mpr hz1)) hB)
      hder.symm
  refine ⟨hD, ?_⟩
  have he : z ^ n * (z - 1) = -(a : ℂ) * feedback γ z := by
    unfold characteristic at hp
    unfold feedback
    linear_combination hp
  have hid : -(a : ℂ) * feedback γ z /
      (z * characteristicDerivative n γ a z) = (logSlope n γ z)⁻¹ := by
    rw [hder, he]
    have ha' : (a : ℂ) ≠ 0 := by exact_mod_cast ha.ne'
    field_simp
  rw [hid]
  exact inverse_logSlope_re_pos hn hγ0 hγ1 ha hc hz hp

/-- If a differentiable root branch has tangent `w`, implicit differentiation
gives the displayed linear equation; its radial velocity is strictly outward. -/
theorem root_tangent_outward {n : ℕ} {γ a : ℝ} {z w : ℂ}
    (hn : 1 ≤ n) (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1)
    (ha : 0 < a) (hc : a * (1 - γ) < 1)
    (hz : ‖z‖ = 1) (hp : characteristic n γ a z = 0)
    (htangent : characteristicDerivative n γ a z * w + feedback γ z = 0) :
    0 < ((a : ℂ) * w / z).re := by
  obtain ⟨hD, hv⟩ := unit_root_transversality hn hγ0 hγ1 ha hc hz hp
  have hw : w = -feedback γ z / characteristicDerivative n γ a z := by
    apply (eq_div_iff hD).2
    linear_combination htangent
  rw [hw]
  convert hv using 1 <;> congr 1 <;> field_simp <;> ring

end C2.IntegratorDelay
