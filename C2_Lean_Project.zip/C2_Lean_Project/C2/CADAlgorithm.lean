import C2.GainProjection

/-!
# Finite marked-cell output for the gain projection algorithm

The list maximum and marked-endpoint selection are executable for any supplied
linear order. Their recursion is structural; no numerical tolerance, unbounded
loop, or choice operator occurs in these definitions. The real interpretation
below proves exact least-upper-bound and algebraicity conclusions once the CAD
projection/lifting stage supplies its finite cell decomposition. That stage is
an explicit interface hypothesis here, not an assumed output optimum.
-/

namespace C2.CADAlgorithm

/-- A gain cell with its rational test point and the result of its finite
parameter sign tests. Correct sample placement and marking are separate proof
obligations of projection/lifting. -/
structure Cell (α : Type*) where
  left : α
  right : α
  sample : ℚ
  marked : Bool

/-- Exact maximum of a finite list, with no value assigned to an empty list. -/
def maximum? {α : Type*} [LinearOrder α] : List α → Option α
  | [] => none
  | a :: rest =>
      match maximum? rest with
      | none => some a
      | some b => some (max a b)

/-- The endpoints tested by the final finite maximum step. -/
def markedEndpoints {α : Type*} (cells : List (Cell α)) : List α :=
  (cells.filter fun c => c.marked).map Cell.right

/-- The final output: empty feasible collection or its largest right endpoint. -/
def output {α : Type*} [LinearOrder α] (cells : List (Cell α)) : Option α :=
  maximum? (markedEndpoints cells)

theorem maximum_eq_none_iff {α : Type*} [LinearOrder α] (xs : List α) :
    maximum? xs = none ↔ xs = [] := by
  cases xs with
  | nil => simp [maximum?]
  | cons a rest =>
      cases h : maximum? rest <;> simp [maximum?, h]

theorem maximum_some_spec {α : Type*} [LinearOrder α]
    {xs : List α} {b : α} (h : maximum? xs = some b) :
    b ∈ xs ∧ ∀ a ∈ xs, a ≤ b := by
  induction xs generalizing b with
  | nil => simp [maximum?] at h
  | cons a rest ih =>
      cases ht : maximum? rest with
      | none =>
          have hr : rest = [] := (maximum_eq_none_iff rest).mp ht
          subst rest
          simp [maximum?] at h
          subst b
          simp
      | some m =>
          have hm := ih ht
          simp only [maximum?, ht, Option.some.injEq] at h
          subst b
          constructor
          · by_cases ham : a ≤ m
            · rw [max_eq_right ham]
              exact List.mem_cons_of_mem a hm.1
            · rw [max_eq_left (le_of_not_ge ham)]
              exact List.mem_cons_self
          · intro x hx
            rcases List.mem_cons.mp hx with rfl | hx
            · exact le_max_left _ _
            · exact (hm.2 x hx).trans (le_max_right _ _)

theorem maximum_some_of_nonempty {α : Type*} [LinearOrder α]
    {xs : List α} (h : xs ≠ []) : ∃ b, maximum? xs = some b := by
  cases hmax : maximum? xs with
  | none => exact False.elim (h ((maximum_eq_none_iff xs).mp hmax))
  | some b => exact ⟨b, rfl⟩

theorem mem_markedEndpoints {α : Type*} {cells : List (Cell α)} {a : α} :
    a ∈ markedEndpoints cells ↔
      ∃ c ∈ cells, c.marked = true ∧ c.right = a := by
  simp [markedEndpoints, List.mem_filter, and_assoc]

theorem output_none_iff {α : Type*} [LinearOrder α] (cells : List (Cell α)) :
    output cells = none ↔ ∀ c ∈ cells, c.marked = false := by
  rw [output, maximum_eq_none_iff]
  constructor
  · intro h c hc
    cases hm : c.marked with
    | false => rfl
    | true =>
      have he : c.right ∈ markedEndpoints cells :=
        mem_markedEndpoints.mpr ⟨c, hc, hm, rfl⟩
      simpa [h] using he
  · intro h
    apply List.eq_nil_iff_forall_not_mem.mpr
    intro a ha
    obtain ⟨c, hc, hm, _⟩ := mem_markedEndpoints.mp ha
    have := h c hc
    simp [hm] at this

theorem output_some_spec {α : Type*} [LinearOrder α]
    {cells : List (Cell α)} {b : α} (h : output cells = some b) :
    (∃ c ∈ cells, c.marked = true ∧ c.right = b) ∧
      ∀ c ∈ cells, c.marked = true → c.right ≤ b := by
  obtain ⟨hb, hupper⟩ := maximum_some_spec h
  refine ⟨mem_markedEndpoints.mp hb, ?_⟩
  intro c hc hm
  exact hupper c.right (mem_markedEndpoints.mpr ⟨c, hc, hm, rfl⟩)

theorem output_some_iff {α : Type*} [LinearOrder α]
    {cells : List (Cell α)} {b : α} :
    output cells = some b ↔
      (∃ c ∈ cells, c.marked = true ∧ c.right = b) ∧
        ∀ c ∈ cells, c.marked = true → c.right ≤ b := by
  constructor
  · exact output_some_spec
  · rintro ⟨⟨c, hc, hm, hcb⟩, hb⟩
    have hne : markedEndpoints cells ≠ [] := by
      intro hnil
      have : c.right ∈ markedEndpoints cells :=
        mem_markedEndpoints.mpr ⟨c, hc, hm, rfl⟩
      simpa [hnil] using this
    obtain ⟨a, ha⟩ := maximum_some_of_nonempty hne
    have hoa : output cells = some a := ha
    obtain ⟨⟨d, hd, hdm, hda⟩, haupper⟩ := output_some_spec hoa
    have hab : a ≤ b := hda ▸ hb d hd hdm
    have hba : b ≤ a := hcb ▸ haupper c hc hm
    have : a = b := le_antisymm hab hba
    simpa [this] using hoa

/-- Exact rational tests at one parameter/gain point. In the application the
functions are evaluations of the supplied rational polynomial inequalities. -/
def testPoint (tests : List (ℚ → ℚ → ℚ)) (parameter gain : ℚ) : Bool :=
  tests.all fun f => decide (0 < f parameter gain)

/-- A gain cell is marked iff one of the finitely many rational parameter
samples satisfies all inequalities. Both loops are over explicit lists. -/
def markAtGain (tests : List (ℚ → ℚ → ℚ))
    (parameterSamples : List ℚ) (gain : ℚ) : Bool :=
  parameterSamples.any fun parameter => testPoint tests parameter gain

theorem testPoint_eq_true_iff (tests : List (ℚ → ℚ → ℚ)) (parameter gain : ℚ) :
    testPoint tests parameter gain = true ↔
      ∀ f ∈ tests, 0 < f parameter gain := by
  simp [testPoint, List.all_eq_true]

theorem markAtGain_eq_true_iff (tests : List (ℚ → ℚ → ℚ))
    (parameterSamples : List ℚ) (gain : ℚ) :
    markAtGain tests parameterSamples gain = true ↔
      ∃ parameter ∈ parameterSamples, ∀ f ∈ tests, 0 < f parameter gain := by
  simp [markAtGain, List.any_eq_true, testPoint_eq_true_iff]

/-- Data produced by gain-root and parameter-root isolation, before testing
the signs. The numerical values are rational, rather than approximations. -/
structure SampledCell (α : Type*) where
  left : α
  right : α
  gainSample : ℚ
  parameterSamples : List ℚ

def SampledCell.test {α : Type*} (c : SampledCell α)
    (tests : List (ℚ → ℚ → ℚ)) : Cell α where
  left := c.left
  right := c.right
  sample := c.gainSample
  marked := markAtGain tests c.parameterSamples c.gainSample

/-- Complete finite testing/selection stage, after isolation has returned its
finite lists. It does not call a black-box feasible-set or supremum oracle. -/
def testAndSelect {α : Type*} [LinearOrder α]
    (tests : List (ℚ → ℚ → ℚ)) (cells : List (SampledCell α)) : Option α :=
  output (cells.map fun c => c.test tests)

theorem testAndSelect_none_iff {α : Type*} [LinearOrder α]
    (tests : List (ℚ → ℚ → ℚ)) (cells : List (SampledCell α)) :
    testAndSelect tests cells = none ↔
      ∀ c ∈ cells, ¬∃ parameter ∈ c.parameterSamples,
        ∀ f ∈ tests, 0 < f parameter c.gainSample := by
  rw [testAndSelect, output_none_iff]
  simp only [List.forall_mem_map, SampledCell.test]
  simp only [Bool.eq_false_iff, ne_eq, markAtGain_eq_true_iff]

theorem testAndSelect_some_spec {α : Type*} [LinearOrder α]
    {tests : List (ℚ → ℚ → ℚ)} {cells : List (SampledCell α)} {b : α}
    (h : testAndSelect tests cells = some b) :
    (∃ c ∈ cells, (∃ parameter ∈ c.parameterSamples,
      ∀ f ∈ tests, 0 < f parameter c.gainSample) ∧ c.right = b) ∧
    ∀ c ∈ cells, (∃ parameter ∈ c.parameterSamples,
      ∀ f ∈ tests, 0 < f parameter c.gainSample) → c.right ≤ b := by
  obtain ⟨hsel, hupper⟩ := output_some_spec h
  constructor
  · obtain ⟨c, hc, hm, hcb⟩ := hsel
    obtain ⟨d, hd, rfl⟩ := List.mem_map.mp hc
    exact ⟨d, hd, (markAtGain_eq_true_iff _ _ _).mp hm, hcb⟩
  · intro c hc htest
    exact hupper (c.test tests) (List.mem_map.mpr ⟨c, hc, rfl⟩)
      ((markAtGain_eq_true_iff _ _ _).mpr htest)

section RealInterpretation

open Set

/-- The union represented by marked open gain cells. -/
def representedGains (cells : List (Cell ℝ)) : Set ℝ :=
  {k | ∃ c ∈ cells, c.marked = true ∧ c.left < k ∧ k < c.right}

/-- Cell validity is geometric and does not include any optimizer assertion. -/
def ValidCells (cells : List (Cell ℝ)) : Prop :=
  ∀ c ∈ cells, c.left < c.right

theorem representedGains_empty_iff {cells : List (Cell ℝ)}
    (hvalid : ValidCells cells) :
    representedGains cells = ∅ ↔ output cells = none := by
  rw [output_none_iff]
  constructor
  · intro he c hc
    cases hm : c.marked with
    | false => rfl
    | true =>
      have hab := hvalid c hc
      have hw : (c.left + c.right) / 2 ∈ representedGains cells := by
        exact ⟨c, hc, hm, by linarith, by linarith⟩
      simpa [he] using hw
  · intro h
    apply Set.eq_empty_iff_forall_not_mem.mpr
    rintro k ⟨c, hc, hm, _⟩
    have := h c hc
    simp [hm] at this

theorem output_isLUB {cells : List (Cell ℝ)} {b : ℝ}
    (hvalid : ValidCells cells) (hout : output cells = some b) :
    IsLUB (representedGains cells) b := by
  obtain ⟨⟨c, hc, hm, hcb⟩, hupper⟩ := output_some_spec hout
  constructor
  · rintro k ⟨d, hd, hdm, _, hk⟩
    exact hk.le.trans (hupper d hd hdm)
  · intro u hu
    have hub : u ∈ upperBounds (Ioo c.left c.right) := by
      intro k hk
      exact hu ⟨c, hc, hm, hk.1, hk.2⟩
    rw [← hcb]
    exact (isLUB_Ioo (hvalid c hc)).2 hub

theorem output_algebraic {cells : List (Cell ℝ)} {b : ℝ}
    (halg : ∀ c ∈ cells, IsAlgebraic ℚ c.right)
    (hout : output cells = some b) : IsAlgebraic ℚ b := by
  obtain ⟨⟨c, hc, _, hcb⟩, _⟩ := output_some_spec hout
  exact hcb ▸ halg c hc

/-- The cell-output theorem for the actual open gain projection. The equality
`hcover` is the precise projection/lifting correctness obligation: it concerns
all nonexceptional feasible gains, including components away from zero. -/
theorem output_isLUB_of_decomposition {cells : List (Cell ℝ)} {S E : Set ℝ}
    {b : ℝ} (hS : IsOpen S) (hE : E.Finite)
    (hvalid : ValidCells cells) (hcover : S \ E = representedGains cells)
    (hout : output cells = some b) : IsLUB S b := by
  apply (C2.GainProjection.isLUB_diff_finite_iff hS hE b).mp
  rw [hcover]
  exact output_isLUB hvalid hout

theorem output_none_iff_empty_of_decomposition {cells : List (Cell ℝ)}
    {S E : Set ℝ} (hS : IsOpen S) (hE : E.Finite)
    (hvalid : ValidCells cells) (hcover : S \ E = representedGains cells) :
    output cells = none ↔ S = ∅ := by
  rw [← representedGains_empty_iff hvalid, ← hcover]
  rw [← Set.not_nonempty_iff_eq_empty, ← Set.not_nonempty_iff_eq_empty]
  exact not_congr (C2.GainProjection.diff_finite_nonempty_iff hS hE)

end RealInterpretation
end C2.CADAlgorithm
