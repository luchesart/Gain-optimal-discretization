import C2.CADAlgorithmLifting
import C2.CADCells

/-!
# Assembly of finite gain cells, exact tests, and the algebraic supremum

Finite projection cuts determine the actual adjacent cells. This module
connects their rational lifting tests to the executable finite output stage.
The polynomial projection theorem must supply constancy of feasibility on a
gain cell; root isolation/lifting must supply the test correctness at its
rational gain sample. Those are explicit obligations, not an optimizer oracle.
-/

noncomputable section
open Set
namespace C2.CADAlgorithm

def sampledPair (c : ℝ × ℝ) (gainSamples : (ℝ × ℝ) → ℚ)
    (parameterSamples : (ℝ × ℝ) → List ℚ) : SampledCell ℝ where
  left := c.1
  right := c.2
  gainSample := gainSamples c
  parameterSamples := parameterSamples c

/-- Semantic interpretation of the finite adjacent cells. Effective root
encodings supply this list and its samples; `testAndSelect` itself is the
structurally recursive computation, independent of this real interpretation. -/
def adjacentSampledCells (cuts : Finset ℝ) (gainSamples : (ℝ × ℝ) → ℚ)
    (parameterSamples : (ℝ × ℝ) → List ℚ) : List (SampledCell ℝ) :=
  (C2.CADCells.cells cuts).toList.map fun c => sampledPair c gainSamples parameterSamples

theorem adjacent_tested_cells_valid (cuts : Finset ℝ)
    (gainSamples : (ℝ × ℝ) → ℚ) (parameterSamples : (ℝ × ℝ) → List ℚ)
    (tests : List (ℚ → ℚ → ℚ)) :
    ValidCells ((adjacentSampledCells cuts gainSamples parameterSamples).map
      fun c => c.test tests) := by
  intro c hc
  obtain ⟨d, hd, rfl⟩ := List.mem_map.mp hc
  obtain ⟨p, hp, rfl⟩ := List.mem_map.mp hd
  have hp' : p ∈ C2.CADCells.cells cuts := Finset.mem_toList.mp hp
  exact ((C2.CADCells.mem_cells_iff cuts p.1 p.2).mp hp').2.2.1

/-- Exact representation of all nonexceptional gains by the marked cells,
derived from geometric adjacent-cell coverage and sample-test correctness. -/
theorem tested_adjacent_decomposition {S : Set ℝ} {cuts : Finset ℝ} {K : ℝ}
    (hzero : 0 ∈ cuts) (hK : K ∈ cuts)
    (hbound : ∀ c ∈ cuts, c ∈ Icc 0 K)
    (hsupport : S ⊆ Ioo 0 K)
    (gainSamples : (ℝ × ℝ) → ℚ) (parameterSamples : (ℝ × ℝ) → List ℚ)
    (tests : List (ℚ → ℚ → ℚ))
    (hconstant : ∀ c ∈ C2.CADCells.cells cuts, ∀ k ∈ Ioo c.1 c.2,
      k ∈ S ↔ (gainSamples c : ℝ) ∈ S)
    (htest : ∀ c ∈ C2.CADCells.cells cuts,
      markAtGain tests (parameterSamples c) (gainSamples c) = true ↔
        (gainSamples c : ℝ) ∈ S) :
    S \ (cuts : Set ℝ) = representedGains
      ((adjacentSampledCells cuts gainSamples parameterSamples).map fun c => c.test tests) := by
  ext k
  constructor
  · rintro ⟨hkS, hkcut⟩
    obtain ⟨p, hp, hkp⟩ :=
      (C2.CADCells.finite_cell_cover hzero hK hbound).mpr ⟨hsupport hkS, hkcut⟩
    have hm := (htest p hp).mpr ((hconstant p hp k hkp).mp hkS)
    refine ⟨(sampledPair p gainSamples parameterSamples).test tests, ?_, hm, hkp⟩
    apply List.mem_map.mpr
    refine ⟨sampledPair p gainSamples parameterSamples, ?_, rfl⟩
    exact List.mem_map.mpr ⟨p, Finset.mem_toList.mpr hp, rfl⟩
  · rintro ⟨c, hc, hm, hkleft, hkright⟩
    obtain ⟨d, hd, rfl⟩ := List.mem_map.mp hc
    obtain ⟨p, hp, rfl⟩ := List.mem_map.mp hd
    have hp' : p ∈ C2.CADCells.cells cuts := Finset.mem_toList.mp hp
    have hkp : k ∈ Ioo p.1 p.2 := ⟨hkleft, hkright⟩
    have hsamp := (htest p hp').mp hm
    exact ⟨(hconstant p hp' k hkp).mpr hsamp,
      (C2.CADCells.finite_cell_cover hzero hK hbound).mp ⟨p, hp', hkp⟩ |>.2⟩

theorem tested_adjacent_empty_iff {S : Set ℝ} {cuts : Finset ℝ} {K : ℝ}
    (hS : IsOpen S) (hzero : 0 ∈ cuts) (hK : K ∈ cuts)
    (hbound : ∀ c ∈ cuts, c ∈ Icc 0 K) (hsupport : S ⊆ Ioo 0 K)
    (gainSamples : (ℝ × ℝ) → ℚ) (parameterSamples : (ℝ × ℝ) → List ℚ)
    (tests : List (ℚ → ℚ → ℚ))
    (hconstant : ∀ c ∈ C2.CADCells.cells cuts, ∀ k ∈ Ioo c.1 c.2,
      k ∈ S ↔ (gainSamples c : ℝ) ∈ S)
    (htest : ∀ c ∈ C2.CADCells.cells cuts,
      markAtGain tests (parameterSamples c) (gainSamples c) = true ↔
        (gainSamples c : ℝ) ∈ S) :
    testAndSelect tests (adjacentSampledCells cuts gainSamples parameterSamples) = none ↔
      S = ∅ := by
  exact output_none_iff_empty_of_decomposition hS cuts.finite_toSet
    (adjacent_tested_cells_valid cuts gainSamples parameterSamples tests)
    (tested_adjacent_decomposition hzero hK hbound hsupport
      gainSamples parameterSamples tests hconstant htest)

theorem tested_adjacent_supremum {S : Set ℝ} {cuts : Finset ℝ} {K b : ℝ}
    (hS : IsOpen S) (hzero : 0 ∈ cuts) (hK : K ∈ cuts)
    (hbound : ∀ c ∈ cuts, c ∈ Icc 0 K) (hsupport : S ⊆ Ioo 0 K)
    (gainSamples : (ℝ × ℝ) → ℚ) (parameterSamples : (ℝ × ℝ) → List ℚ)
    (tests : List (ℚ → ℚ → ℚ))
    (hconstant : ∀ c ∈ C2.CADCells.cells cuts, ∀ k ∈ Ioo c.1 c.2,
      k ∈ S ↔ (gainSamples c : ℝ) ∈ S)
    (htest : ∀ c ∈ C2.CADCells.cells cuts,
      markAtGain tests (parameterSamples c) (gainSamples c) = true ↔
        (gainSamples c : ℝ) ∈ S)
    (hout : testAndSelect tests (adjacentSampledCells cuts gainSamples parameterSamples) = some b) :
    IsLUB S b := by
  exact output_isLUB_of_decomposition hS cuts.finite_toSet
    (adjacent_tested_cells_valid cuts gainSamples parameterSamples tests)
    (tested_adjacent_decomposition hzero hK hbound hsupport
      gainSamples parameterSamples tests hconstant htest) hout

theorem tested_adjacent_output_mem_cuts {cuts : Finset ℝ} {b : ℝ}
    (gainSamples : (ℝ × ℝ) → ℚ) (parameterSamples : (ℝ × ℝ) → List ℚ)
    (tests : List (ℚ → ℚ → ℚ))
    (hout : testAndSelect tests (adjacentSampledCells cuts gainSamples parameterSamples) = some b) :
    b ∈ cuts := by
  obtain ⟨⟨c, hc, _, hcb⟩, _⟩ := testAndSelect_some_spec hout
  obtain ⟨p, hp, rfl⟩ := List.mem_map.mp hc
  have hp' : p ∈ C2.CADCells.cells cuts := Finset.mem_toList.mp hp
  have hb := ((C2.CADCells.mem_cells_iff cuts p.1 p.2).mp hp').2.1
  exact hcb ▸ hb

theorem tested_adjacent_output_algebraic {cuts : Finset ℝ} {b : ℝ}
    (gainSamples : (ℝ × ℝ) → ℚ) (parameterSamples : (ℝ × ℝ) → List ℚ)
    (tests : List (ℚ → ℚ → ℚ))
    (halgebraic : ∀ c ∈ cuts, IsAlgebraic ℚ c)
    (hout : testAndSelect tests (adjacentSampledCells cuts gainSamples parameterSamples) = some b) :
    IsAlgebraic ℚ b := by
  exact halgebraic b (tested_adjacent_output_mem_cuts gainSamples parameterSamples tests hout)

theorem supremum_strict_search_bound {S : Set ℝ} {b K₀ K : ℝ}
    (hb : IsLUB S b) (hbound : ∀ k ∈ S, k ≤ K₀) (hstrict : K₀ < K) : b < K :=
  (hb.2 hbound).trans_lt hstrict

end C2.CADAlgorithm
