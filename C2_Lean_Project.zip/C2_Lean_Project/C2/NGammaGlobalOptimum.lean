import C2.NGammaEndpointSequence
import C2.NGammaEndpointCompact

/-! Global optimization of the actual frequency-domain gain, including its
zero-frequency endpoint. Schur stability is a separate root-count interface. -/
noncomputable section
open scoped BigOperators Topology
open Set Filter
namespace C2.NGamma.Global

theorem gain_product_le_exp_frequencyValue {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) {w : ℝ} (hw : 0 < w)
    (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    (hp : (∑ j, allocationPhase (r j) (x j) w) = 2*Real.arctan w) :
    (∏ j, allocationGain (r j) (x j) w) ≤ Real.exp (frequencyValue r w) := by
  obtain ⟨lam,hlam⟩ := exists_balancing_multiplier r hr hw ⟨x,hx,hp⟩
  rw [exp_frequencyValue_eq_product r hr hw hlam]
  exact frequencyAllocation_gain_optimal r hr hw x hx (hp.trans hlam.symm)

/-- Every positive-frequency optimum is strictly below any valid endpoint
maximum when the endpoint is feasible. The strictness uses a smaller positive
frequency before taking a compact subsequence tending to zero. -/
theorem positive_frequency_below_endpoint_bound {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hS : endpointSum r ≤ 1) (B : ℝ)
    (hB : ∀ x : Fin n → ℝ, (∀ j, 0 < x j ∧ x j ≤ 1) →
      (∑ j, endpointCost (r j) (x j)) ≤ 1 → (∏ j, (r j+2/x j)) ≤ B)
    {w : ℝ} (hw : 0 < w) (hf : feasible r w) :
    Real.exp (frequencyValue r w) < B := by
  obtain ⟨wp,hwp,hcross,hsmall,hlarge⟩ := feasible_frequency_interval hn r hr
  have hmidpos : 0 < w/2 := by positivity
  have hmidlt : w/2 < w := by linarith
  have hmidf : feasible r (w/2) := (hsmall hS (w/2) hmidpos).2
    (le_trans hmidlt.le ((hsmall hS w hw).1 hf))
  obtain ⟨ws,xs,hlim,hdata,hevent⟩ := exists_optimizing_endpoint_sequence hn r hr hS
  have hupper : Real.exp (frequencyValue r (w/2)) ≤ B :=
    endpoint_bound_of_feasible_sequence r hr B _ hB ws xs hlim
      (fun k => (hdata k).1) (fun k => (hdata k).2.1)
      (fun k => (hdata k).2.2.1)
      ((hevent (w/2) hmidpos hmidf).mono fun k hk => hk.le)
  have hstrict : Real.exp (frequencyValue r w) < Real.exp (frequencyValue r (w/2)) :=
    Real.exp_lt_exp.mpr
      (frequencyValue_strictAntiOn_feasible hn r hr ⟨hmidpos,hmidf⟩ ⟨hw,hf⟩ hmidlt)
  exact lt_of_lt_of_le hstrict hupper

theorem positive_frequency_below_endpoint_allocation {n : ℕ} (hn : 0 < n)
    (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hS : endpointSum r ≤ 1)
    {c w : ℝ} (hc : 0 < c) (hbudget : allocatedResource r c = 4)
    (hw : 0 < w) (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    (hp : (∑ j, allocationPhase (r j) (x j) w) = 2*Real.arctan w) :
    (∏ j, allocationGain (r j) (x j) w) < ∏ j, endpointAllocation (r j) c := by
  exact lt_of_le_of_lt (gain_product_le_exp_frequencyValue r x hr hw hx hp)
    (positive_frequency_below_endpoint_bound hn r hr hS _
      (fun y hy hcost => endpointGain_product_optimal r hr hc hbudget y hy hcost)
      hw ⟨x,hx,hp⟩)

theorem positive_frequency_below_endpoint_equality {n : ℕ} (hn : 0 < n)
    (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hS : endpointSum r = 1)
    {w : ℝ} (hw : 0 < w) (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    (hp : (∑ j, allocationPhase (r j) (x j) w) = 2*Real.arctan w) :
    (∏ j, allocationGain (r j) (x j) w) < ∏ j, (r j+2) := by
  apply lt_of_le_of_lt (gain_product_le_exp_frequencyValue r x hr hw hx hp)
  apply positive_frequency_below_endpoint_bound hn r hr hS.le _ ?_ hw ⟨x,hx,hp⟩
  intro y hy hcost
  rw [endpoint_feasible_equality_unique r y hr hy hS hcost]
  simp

/-- Constructive global endpoint optimizer in the strict endpoint regime.
All positive-frequency competitors are strictly inferior, and the endpoint
comparison is unique. No stability conclusion is hidden in the statement. -/
theorem exists_unique_global_endpoint_optimizer {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hS : endpointSum r < 1) :
    ∃ c : ℝ, 0 < c ∧ allocatedResource r c = 4 ∧
      (∀ j, 0 < endpointParameter (r j) c ∧ endpointParameter (r j) c ≤ 1) ∧
      (∑ j, endpointCost (r j) (endpointParameter (r j) c)) = 1 ∧
      (∀ x : Fin n → ℝ, (∀ j, 0 < x j ∧ x j ≤ 1) →
        (∑ j, endpointCost (r j) (x j)) ≤ 1 →
          (∏ j, (r j+2/x j)) ≤ (∏ j, endpointAllocation (r j) c) ∧
          ((∏ j, (r j+2/x j)) = (∏ j, endpointAllocation (r j) c) ↔
            x = fun j => endpointParameter (r j) c)) ∧
      ∀ w : ℝ, 0 < w → ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) →
        (∑ j, allocationPhase (r j) (x j) w) = 2*Real.arctan w →
        (∏ j, allocationGain (r j) (x j) w) < ∏ j, endpointAllocation (r j) c := by
  letI : Nonempty (Fin n) := ⟨⟨0,hn⟩⟩
  obtain ⟨c,hc,hbudget,hparam,hcost,hopt⟩ := exists_endpoint_optimizer r hr hS
  refine ⟨c,hc,hbudget,hparam,hcost,?_,?_⟩
  · intro x hx hxcost
    refine ⟨(hopt x hx hxcost).1,?_⟩
    constructor
    · intro heq
      by_contra hne
      exact (ne_of_lt ((hopt x hx hxcost).2 hne)) heq
    · intro heq
      subst x
      exact Finset.prod_congr rfl (fun j _ => endpointParameter_inverse (r j) c)
  · intro w hw x hx hp
    exact positive_frequency_below_endpoint_allocation hn r x hr hS.le hc hbudget hw hx hp

end C2.NGamma.Global
