import C2.CADAlgorithm
import C2.ProjectionCompletionWitness

/-!
# Exact finite lifting tests, including closed parameter endpoints

This module connects sign-invariant open parameter cells to the finite
rational tests used in the output stage. The geometric cover and sign
invariance are explicit inputs to be supplied by the polynomial CAD lemmas.
No feasible parameter at an exceptional root or at 0 or 1 is lost.
-/

noncomputable section
open Set
namespace C2.CADAlgorithm

theorem closed_parameter_feasibility_iff_cell_test
    {ι : Type*} [Finite ι] (f : ℝ → ι → ℝ)
    (hf : ∀ i, Continuous (fun γ => f γ i))
    (cells : List (Cell ℝ)) (E : Set ℝ) (hE : E.Finite)
    (hcover : ∀ γ ∈ Ioo (0 : ℝ) 1, γ ∉ E →
      ∃ c ∈ cells, γ ∈ Ioo c.left c.right)
    (hbounded : ∀ c ∈ cells, 0 ≤ c.left ∧ c.right ≤ 1)
    (hsample : ∀ c ∈ cells, (c.sample : ℝ) ∈ Ioo c.left c.right)
    (hconstant : ∀ c ∈ cells, ∀ γ ∈ Ioo c.left c.right,
      (∀ i, 0 < f γ i) ↔ ∀ i, 0 < f c.sample i) :
    (∃ γ ∈ Icc (0 : ℝ) 1, ∀ i, 0 < f γ i) ↔
      ∃ c ∈ cells, ∀ i, 0 < f c.sample i := by
  constructor
  · rintro ⟨γ, hγ, hpos⟩
    obtain ⟨q, hq0, hq1, hqpos⟩ :=
      C2.GainProjection.exists_rational_interior_witness f hf hγ hpos
    let S : Set ℝ := (⋂ i, {x | 0 < f x i}) ∩ Ioo 0 1
    have hopen : IsOpen S :=
      (isOpen_iInter_of_finite (fun i => isOpen_lt continuous_const (hf i))).inter
        isOpen_Ioo
    have hne : S.Nonempty := by
      exact ⟨q, by simpa [S] using And.intro hqpos (And.intro hq0 hq1)⟩
    obtain ⟨x, hx, hxE⟩ :=
      (C2.GainProjection.diff_finite_nonempty_iff hopen hE).mpr hne
    have hxpos : ∀ i, 0 < f x i := by simpa using hx.1
    obtain ⟨c, hc, hxc⟩ := hcover x hx.2 hxE
    exact ⟨c, hc, (hconstant c hc x hxc).mp hxpos⟩
  · rintro ⟨c, hc, hpos⟩
    have hs := hsample c hc
    have hb := hbounded c hc
    exact ⟨c.sample, ⟨hb.1.trans hs.1.le, hs.2.le.trans hb.2⟩, hpos⟩

theorem testPoint_ofFn_iff {n : ℕ}
    (tests : Fin n → ℚ → ℚ → ℚ) (parameter gain : ℚ) :
    testPoint (List.ofFn tests) parameter gain = true ↔
      ∀ i, 0 < tests i parameter gain := by
  simp [testPoint_eq_true_iff, List.mem_ofFn]

theorem markAtGain_ofFn_iff {n : ℕ}
    (tests : Fin n → ℚ → ℚ → ℚ) (samples : List ℚ) (gain : ℚ) :
    markAtGain (List.ofFn tests) samples gain = true ↔
      ∃ parameter ∈ samples, ∀ i, 0 < tests i parameter gain := by
  simp [markAtGain, List.any_eq_true, testPoint_ofFn_iff]

/-- Rational arithmetic sign testing agrees exactly with the real
interpretation. This is an equality bridge, not a floating-point claim. -/
theorem markAtGain_real_interpretation {n : ℕ}
    (tests : Fin n → ℚ → ℚ → ℚ) (f : ℝ → ℝ → Fin n → ℝ)
    (hcast : ∀ q k i, ((tests i q k : ℚ) : ℝ) = f q k i)
    (samples : List ℚ) (gain : ℚ) :
    markAtGain (List.ofFn tests) samples gain = true ↔
      ∃ parameter ∈ samples, ∀ i, 0 < f parameter gain i := by
  rw [markAtGain_ofFn_iff]
  have heq : ∀ q i, 0 < tests i q gain ↔ 0 < f q gain i := by
    intro q i
    rw [← hcast q gain i]
    exact Rat.cast_pos.symm
  simp_rw [heq]

/-- The exact list of cell samples suffices at a fixed rational gain, including
feasible closed-domain endpoints and omitted finite parameter cuts. -/
theorem finite_lifting_mark_correct {n : ℕ}
    (tests : Fin n → ℚ → ℚ → ℚ) (f : ℝ → ℝ → Fin n → ℝ)
    (hcast : ∀ q k i, ((tests i q k : ℚ) : ℝ) = f q k i)
    (gain : ℚ) (hf : ∀ i, Continuous (fun γ => f γ gain i))
    (cells : List (Cell ℝ)) (E : Set ℝ) (hE : E.Finite)
    (hcover : ∀ γ ∈ Ioo (0 : ℝ) 1, γ ∉ E →
      ∃ c ∈ cells, γ ∈ Ioo c.left c.right)
    (hbounded : ∀ c ∈ cells, 0 ≤ c.left ∧ c.right ≤ 1)
    (hsample : ∀ c ∈ cells, (c.sample : ℝ) ∈ Ioo c.left c.right)
    (hconstant : ∀ c ∈ cells, ∀ γ ∈ Ioo c.left c.right,
      (∀ i, 0 < f γ gain i) ↔ ∀ i, 0 < f c.sample gain i) :
    markAtGain (List.ofFn tests) (cells.map Cell.sample) gain = true ↔
      ∃ γ ∈ Icc (0 : ℝ) 1, ∀ i, 0 < f γ gain i := by
  rw [markAtGain_real_interpretation tests f hcast]
  rw [closed_parameter_feasibility_iff_cell_test
    (fun γ i => f γ gain i) hf cells E hE hcover hbounded hsample hconstant]
  simp only [List.mem_map]
  constructor
  · rintro ⟨q, ⟨c, hc, rfl⟩, hq⟩
    exact ⟨c, hc, hq⟩
  · rintro ⟨c, hc, hq⟩
    exact ⟨c.sample, ⟨c, hc, rfl⟩, hq⟩

end C2.CADAlgorithm
