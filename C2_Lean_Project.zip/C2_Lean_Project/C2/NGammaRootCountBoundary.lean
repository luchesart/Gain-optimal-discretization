import C2.NGammaRootCountCayley

/-! Coverage of the unit circle by the upper Cayley semicircle, its conjugate,
and the point -1. This connects concrete frequency nonvanishing to root counts. -/
noncomputable section
open scoped BigOperators ComplexConjugate Topology
open Set Complex Polynomial Filter
namespace C2.NGamma.RootCountBridge

theorem upper_unit_circle_cayley {z : ℂ} (hz : ‖z‖ = 1)
    (him : 0 ≤ z.im) (hne : z ≠ -1) :
    ∃ t : ℝ, 0 ≤ t ∧ Cayley.point t = z := by
  have harg0 : 0 ≤ z.arg := Complex.arg_nonneg_iff.2 him
  have hargπ : z.arg < Real.pi := by
    apply lt_of_le_of_ne (Complex.arg_le_pi z)
    intro heq
    apply hne
    have hp := Complex.norm_mul_exp_arg_mul_I z
    rw [hz, Complex.ofReal_one, one_mul, heq, Complex.exp_pi_mul_I] at hp
    exact hp.symm
  have hargn : -(Real.pi / 2) < z.arg / 2 := by nlinarith [Real.pi_pos]
  have hargp : z.arg / 2 < Real.pi / 2 := by linarith
  refine ⟨Real.tan (z.arg / 2), ?_, ?_⟩
  · exact Real.tan_nonneg_of_nonneg_of_le_pi_div_two (by positivity) hargp.le
  · rw [Cayley.point_exp, Real.arctan_tan hargn hargp]
    have heq : 2 * (z.arg / 2) = z.arg := by ring
    rw [heq]
    simpa [hz] using Complex.norm_mul_exp_arg_mul_I z

theorem unit_circle_cayley_or_conj {z : ℂ} (hz : ‖z‖ = 1) (hne : z ≠ -1) :
    ∃ t : ℝ, 0 ≤ t ∧ (Cayley.point t = z ∨ conj (Cayley.point t) = z) := by
  by_cases him : 0 ≤ z.im
  · obtain ⟨t, ht, he⟩ := upper_unit_circle_cayley hz him hne
    exact ⟨t, ht, Or.inl he⟩
  · have hcNorm : ‖conj z‖ = 1 := by simpa using hz
    have hcIm : 0 ≤ (conj z).im := by simp only [Complex.conj_im]; linarith
    have hcNe : conj z ≠ -1 := by
      intro he
      have hh := congrArg conj he
      simp only [Complex.conj_conj, map_neg, map_one] at hh
      exact hne hh
    obtain ⟨t, ht, he⟩ := upper_unit_circle_cayley hcNorm hcIm hcNe
    refine ⟨t, ht, Or.inr ?_⟩
    rw [he, Complex.conj_conj]

theorem no_unit_roots_of_cayley_nonzero {p : Polynomial ℂ}
    (hconj : ∀ z : ℂ, p.eval (conj z) = conj (p.eval z))
    (hfinite : ∀ t : ℝ, 0 ≤ t → p.eval (Cayley.point t) ≠ 0)
    (hend : p.eval (-1) ≠ 0) :
    ∀ a ∈ p.roots, ‖a‖ ≠ 1 := by
  intro z hz hnorm
  have hzero : p.eval z = 0 := (Polynomial.mem_roots (by
    intro hp; simpa [hp] using hend)).1 hz
  have hne : z ≠ -1 := by intro he; subst z; exact hend hzero
  obtain ⟨t, ht, he | he⟩ := unit_circle_cayley_or_conj hnorm hne
  · exact hfinite t ht (he ▸ hzero)
  · have hh : conj (p.eval (Cayley.point t)) = 0 := by
      rw [← hconj, he]
      exact hzero
    apply hfinite t ht
    have hc := congrArg conj hh
    simpa only [Complex.conj_conj, map_zero] using hc

end C2.NGamma.RootCountBridge
