import C2.CADProjectionWitness
import C2.CADFactorClearing

/-! Rational finite data derived from the common fraction-field factor basis.
The exported validity conditions are only finite exact polynomial identities
and nonzero tests; generic coprimeness is proved while constructing the data. -/
noncomputable section
open Polynomial
namespace C2.CADProjection

structure FactorData (ι : Type*) (n : ℕ) where
  factors : Fin n → Bivariate
  left : ι → ℚ[X]
  right : ι → ℚ[X]
  zeroPower : ι → ℕ
  onePower : ι → ℕ
  powers : ι → Fin n → ℕ

def ValidFactorData {ι : Type*} {n : ℕ} (F : ι → Bivariate)
    (w : FactorData ι n) : Prop :=
  (∀ i, w.left i ≠ 0 ∧ w.right i ≠ 0) ∧
  (∀ j, ∃ i, w.powers i j ≠ 0) ∧
  ∀ i, C (w.left i) * F i = C (w.right i) * X ^ w.zeroPower i *
    (X-1) ^ w.onePower i * ∏ j, (w.factors j) ^ w.powers i j

/-- Clearing a nonzero scalar denominator preserves the factor's concrete
properties over the generic gain field and its endpoint exclusions. -/
theorem cleared_factor_properties (q : (RatFunc ℚ)[X]) (b : ℚ[X]) (P : Bivariate)
    (hb : b ≠ 0)
    (hP : P.map (algebraMap ℚ[X] (RatFunc ℚ)) =
      C (algebraMap ℚ[X] (RatFunc ℚ) b) * q)
    (hsep : q.Separable) (h0 : q.eval 0 ≠ 0) (h1 : q.eval 1 ≠ 0) :
    P ≠ 0 ∧ (P.map (algebraMap ℚ[X] (RatFunc ℚ))).Separable ∧
      P.eval 0 ≠ 0 ∧ P.eval 1 ≠ 0 := by
  let a := algebraMap ℚ[X] (RatFunc ℚ)
  have hbmap : a b ≠ 0 := by
    simpa only [map_zero] using (IsFractionRing.injective ℚ[X] (RatFunc ℚ)).ne hb
  have he0 : (P.map a).eval 0 = a (P.eval 0) := by
    rw [Polynomial.eval_map]
    simpa only [map_zero] using Polynomial.eval₂_at_apply (p:=P) a (0:ℚ[X])
  have he1 : (P.map a).eval 1 = a (P.eval 1) := by
    rw [Polynomial.eval_map]
    exact Polynomial.eval₂_at_one a
  have hP0 : P.eval 0 ≠ 0 := by
    intro hh
    have hz : (P.map a).eval 0 = 0 := by rw [he0,hh,map_zero]
    rw [hP,Polynomial.eval_mul,Polynomial.eval_C] at hz
    exact (mul_ne_zero hbmap h0) hz
  have hP1 : P.eval 1 ≠ 0 := by
    intro hh
    have hz : (P.map a).eval 1 = 0 := by rw [he1,hh,map_zero]
    rw [hP,Polynomial.eval_mul,Polynomial.eval_C] at hz
    exact (mul_ne_zero hbmap h1) hz
  refine ⟨?_,?_,hP0,hP1⟩
  · intro hh
    exact hP0 (by simp [hh])
  · rw [hP]
    exact Polynomial.Separable.unit_mul (Polynomial.isUnit_C.mpr
      (isUnit_iff_ne_zero.mpr hbmap)) hsep

/-- Constant unit rescalings preserve pairwise generic coprimeness. -/
theorem cleared_factors_coprime (q₁ q₂ : (RatFunc ℚ)[X])
    (b₁ b₂ : ℚ[X]) (P₁ P₂ : Bivariate) (hb₁ : b₁ ≠ 0) (hb₂ : b₂ ≠ 0)
    (h₁ : P₁.map (algebraMap ℚ[X] (RatFunc ℚ)) =
      C (algebraMap ℚ[X] (RatFunc ℚ) b₁) * q₁)
    (h₂ : P₂.map (algebraMap ℚ[X] (RatFunc ℚ)) =
      C (algebraMap ℚ[X] (RatFunc ℚ) b₂) * q₂)
    (h : IsCoprime q₁ q₂) :
    IsCoprime (P₁.map (algebraMap ℚ[X] (RatFunc ℚ)))
      (P₂.map (algebraMap ℚ[X] (RatFunc ℚ))) := by
  rw [h₁,h₂]
  apply (isCoprime_mul_units_left ?_ ?_ q₁ q₂).mpr h
  · apply Polynomial.isUnit_C.mpr
    apply isUnit_iff_ne_zero.mpr
    simpa only [map_zero] using (IsFractionRing.injective ℚ[X] (RatFunc ℚ)).ne hb₁
  · apply Polynomial.isUnit_C.mpr
    apply isUnit_iff_ne_zero.mpr
    simpa only [map_zero] using (IsFractionRing.injective ℚ[X] (RatFunc ℚ)).ne hb₂

/-- Every finite nonzero rational polynomial system has finite rational
factorization and projection data satisfying only exact algebraic checks.
This existence theorem provides witnesses needed to prove termination of exhaustive finite-data search;
it does not identify the noncomputable factorization with executable code. -/
theorem exists_factor_projection_data {ι : Type*} [Fintype ι]
    (F : ι → Bivariate) (hF : ∀ i, F i ≠ 0) :
    ∃ n : ℕ, ∃ w : FactorData ι n, ∃ v : ProjectionData (Fin n),
      ValidFactorData F w ∧ ValidProjectionData w.factors v := by
  classical
  letI : CharZero (RatFunc ℚ) := charZero_of_injective_algebraMap
    (IsFractionRing.injective ℚ[X] (RatFunc ℚ))
  let f : ι → (RatFunc ℚ)[X] := fun i => (F i).map (algebraMap ℚ[X] (RatFunc ℚ))
  have hf : ∀ i, f i ≠ 0 := by
    intro i hi
    apply hF i
    apply Polynomial.map_injective (f:=algebraMap ℚ[X] (RatFunc ℚ))
      (IsFractionRing.injective ℚ[X] (RatFunc ℚ))
    simpa only [Polynomial.map_zero] using hi
  obtain ⟨S,a,b,m,u,hu,hS,hcop,hactive,hid⟩ :=
    C2.CADFactor.exists_finite_interior_factor_basis f hf
  let n := Fintype.card S
  let e : Fin n ≃ S := (Fintype.equivFin S).symm
  let q : Fin n → (RatFunc ℚ)[X] := fun j => (e j).val
  have hq (j : Fin n) : (q j).Monic ∧ (q j).Separable ∧
      (q j).eval 0 ≠ 0 ∧ (q j).eval 1 ≠ 0 := hS (q j) (e j).property
  have hqcop (i j : Fin n) (hne : i ≠ j) : IsCoprime (q i) (q j) := by
    apply hcop (q i) (e i).property (q j) (e j).property
    intro heq
    apply hne
    apply e.injective
    exact Subtype.ext heq
  have hexpr (i : ι) : (F i).map (algebraMap ℚ[X] (RatFunc ℚ)) =
      C (u i) * X ^ a i * (X-1) ^ b i * ∏ j : Fin n, (q j) ^ m i (q j) := by
    have heq : (∏ r ∈ S, r ^ m i r) = ∏ j : Fin n, (q j) ^ m i (q j) := by
      rw [← Finset.prod_coe_sort]
      exact (e.prod_comp (fun r : S => (r.val) ^ m i r.val)).symm
    simpa only [heq] using hid i
  have hclear : ∀ j : Fin n, ∃ d : ℚ[X], d ≠ 0 ∧ ∃ P : Bivariate,
      P.map (algebraMap ℚ[X] (RatFunc ℚ)) = C (algebraMap ℚ[X] (RatFunc ℚ) d) * q j := by
    intro j
    exact exists_clear_denominator (R:=ℚ[X]) (q j)
  choose d hd P hP using hclear
  have hprops (j : Fin n) : P j ≠ 0 ∧
      ((P j).map (algebraMap ℚ[X] (RatFunc ℚ))).Separable ∧
      (P j).eval 0 ≠ 0 ∧ (P j).eval 1 ≠ 0 :=
    cleared_factor_properties (q j) (d j) (P j) (hd j) (hP j)
      (hq j).2.1 (hq j).2.2.1 (hq j).2.2.2
  have hpcop : ∀ i j : Fin n, i ≠ j → IsCoprime
      ((P i).map (algebraMap ℚ[X] (RatFunc ℚ)))
      ((P j).map (algebraMap ℚ[X] (RatFunc ℚ))) := by
    intro i j hne
    exact cleared_factors_coprime (q i) (q j) (d i) (d j) (P i) (P j)
      (hd i) (hd j) (hP i) (hP j) (hqcop i j hne)
  have hids : ∀ i, ∃ r s : ℚ[X], r ≠ 0 ∧ s ≠ 0 ∧
      C r * F i = C s * X ^ a i * (X-1) ^ b i * ∏ j : Fin n, (P j) ^ m i (q j) := by
    intro i
    exact C2.CADFactor.exists_clear_factor_identity (F i) q P d hd hP
      (a i) (b i) (fun j => m i (q j)) (hu i) (hexpr i)
  choose r s hr hs hidentity using hids
  obtain ⟨v,hv⟩ := exists_valid_projection_data P (fun j => (hprops j).1)
    (fun j => (hprops j).2.1) hpcop (fun j => (hprops j).2.2.1)
    (fun j => (hprops j).2.2.2)
  refine ⟨n,⟨P,r,s,a,b,fun i j => m i (q j)⟩,v,?_,hv⟩
  refine ⟨fun i => ⟨hr i,hs i⟩,?_,hidentity⟩
  intro j
  obtain ⟨i,hi⟩ := hactive (q j) (e j).property
  exact ⟨i,Nat.ne_of_gt hi⟩

end C2.CADProjection
