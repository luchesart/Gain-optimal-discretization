import C2.FirstOrder

/-!
# A broader first-order pole-zero family

The normalized characteristic polynomial is
  (1+rγ) z² + [-1+r(1-γ)+a(γ+η)] z + a(1-γ-η).
For v=1-rη>0 its Jury inequalities reduce exactly to the lag problem by
γ' = γ+η, r'=r/v, a'=a/v.  This file proves the global optimizer when the
unconstrained maximizing parameter lies in [0,1].  Endpoint-clamped and
v≤0 regimes are separate claims and are not hidden in this scope.
-/

noncomputable section

namespace C2.PoleZero

def Jury (r η γ a : ℝ) : Prop :=
  0 < a ∧ 0 < 2 + r * (2 * γ - 1) + a * (1 - 2 * γ - 2 * η) ∧
    0 < 1 + r * γ - a * (1 - γ - η)

def v (r η : ℝ) : ℝ := 1 - r * η

def γInterior (r η : ℝ) : ℝ := FirstOrder.γStar (r / v r η) - η

def aInterior (r η : ℝ) : ℝ := v r η * FirstOrder.aStar (r / v r η)

theorem first_identity {r η γ a : ℝ} (hv : 0 < v r η) :
    v r η * (2 + (2 * (γ + η) - 1) * (r / v r η - a / v r η)) =
      2 + r * (2 * γ - 1) + a * (1 - 2 * γ - 2 * η) := by
  have hn : v r η ≠ 0 := ne_of_gt hv
  field_simp [hn]
  dsimp [v]
  ring

theorem second_identity {r η γ a : ℝ} (hv : 0 < v r η) :
    v r η * (1 + (r / v r η) * (γ + η) - (a / v r η) * (1 - (γ + η))) =
      1 + r * γ - a * (1 - γ - η) := by
  have hn : v r η ≠ 0 := ne_of_gt hv
  field_simp [hn]
  dsimp [v]
  ring

theorem jury_scaling {r η γ a : ℝ} (hv : 0 < v r η) :
    Jury r η γ a ↔ FirstOrder.Jury (r / v r η) (γ + η) (a / v r η) := by
  constructor
  · rintro ⟨ha, h₁, h₂⟩
    refine ⟨div_pos ha hv, ?_, ?_⟩
    · have hh := first_identity (γ := γ) (a := a) hv
      by_contra hn
      have hnon := mul_nonpos_of_nonneg_of_nonpos (le_of_lt hv) (le_of_not_gt hn)
      linarith
    · have hh := second_identity (γ := γ) (a := a) hv
      by_contra hn
      have hnon := mul_nonpos_of_nonneg_of_nonpos (le_of_lt hv) (le_of_not_gt hn)
      linarith
  · rintro ⟨ha, h₁, h₂⟩
    have hap := mul_pos hv ha
    have hvn : v r η ≠ 0 := ne_of_gt hv
    have hac : v r η * (a / v r η) = a := by field_simp
    rw [hac] at hap
    refine ⟨hap, ?_, ?_⟩
    · have := mul_pos hv h₁
      rwa [first_identity hv] at this
    · have := mul_pos hv h₂
      rwa [second_identity hv] at this

theorem global_gain_bound {r η γ a : ℝ} (hr : 0 ≤ r) (hv : 0 < v r η)
    (h : Jury r η γ a) : a < aInterior r η := by
  have hscaled := (jury_scaling hv).1 h
  have hb := FirstOrder.global_gain_bound (div_nonneg hr (le_of_lt hv)) hscaled
  unfold aInterior
  have hm := (div_lt_iff₀ hv).1 hb
  simpa only [mul_comm] using hm

theorem interior_parameter_bounds {r η : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η)
    (hv : 0 < v r η) (hint : η ≤ FirstOrder.γStar (r / v r η)) :
    0 ≤ γInterior r η ∧ γInterior r η ≤ 1 := by
  have hb := FirstOrder.γStar_bounds (div_nonneg hr (le_of_lt hv))
  unfold γInterior
  constructor <;> linarith

theorem interior_admissible_iff {r η a : ℝ} (hr : 0 ≤ r)
    (hv : 0 < v r η) :
    Jury r η (γInterior r η) a ↔ 0 < a ∧ a < aInterior r η := by
  rw [jury_scaling hv]
  have heq : γInterior r η + η = FirstOrder.γStar (r / v r η) := by
    unfold γInterior
    ring
  rw [heq, FirstOrder.optimum_admissible_iff (div_nonneg hr (le_of_lt hv))]
  constructor
  · rintro ⟨ha, hb⟩
    have hap := (lt_div_iff₀ hv).1 ha
    have hbp := (div_lt_iff₀ hv).1 hb
    refine ⟨?_, ?_⟩
    · simpa using hap
    · simpa only [aInterior, mul_comm] using hbp
  · rintro ⟨ha, hb⟩
    refine ⟨div_pos ha hv, ?_⟩
    apply (div_lt_iff₀ hv).2
    simpa only [aInterior, mul_comm] using hb

theorem admissible_projection {r η a : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η)
    (hv : 0 < v r η) (hint : η ≤ FirstOrder.γStar (r / v r η)) :
    (∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r η γ a) ↔
      0 < a ∧ a < aInterior r η := by
  constructor
  · rintro ⟨γ, _, _, h⟩
    exact ⟨h.1, global_gain_bound hr hv h⟩
  · intro h
    have hg := interior_parameter_bounds hr hη hv hint
    exact ⟨γInterior r η, hg.1, hg.2, (interior_admissible_iff hr hv).2 h⟩

theorem interior_gain_pos {r η : ℝ} (hr : 0 ≤ r) (hv : 0 < v r η) :
    0 < aInterior r η :=
  mul_pos hv (FirstOrder.aStar_pos (div_nonneg hr (le_of_lt hv)))

theorem interior_gain_isLUB {r η : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η)
    (hv : 0 < v r η) (hint : η ≤ FirstOrder.γStar (r / v r η)) :
    IsLUB {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r η γ a}
      (aInterior r η) := by
  constructor
  · intro a ha
    exact le_of_lt ((admissible_projection hr hη hv hint).1 ha).2
  · intro b hb
    by_contra hn
    have hbA : b < aInterior r η := lt_of_not_ge hn
    have hA := interior_gain_pos hr hv
    let a : ℝ := (max b 0 + aInterior r η) / 2
    have hmax : max b 0 < aInterior r η := max_lt_iff.mpr ⟨hbA, hA⟩
    have ha : 0 < a := by dsimp [a]; nlinarith [le_max_right b 0]
    have haA : a < aInterior r η := by dsimp [a]; linarith
    have hba : b < a := by dsimp [a]; nlinarith [le_max_left b 0]
    have hmem : a ∈ {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r η γ a} :=
      (admissible_projection hr hη hv hint).2 ⟨ha, haA⟩
    have := hb hmem
    linarith

theorem interior_gain_closed_form {r η : ℝ} (hr : 0 ≤ r) (hv : 0 < v r η) :
    aInterior r η = (Real.sqrt (v r η) + Real.sqrt (v r η + r)) ^ 2 := by
  have hr' : 0 ≤ r / v r η := div_nonneg hr (le_of_lt hv)
  have hs := Real.sq_sqrt (le_of_lt hv)
  have ht := Real.sq_sqrt (show 0 ≤ v r η + r by linarith)
  have hu := Real.sq_sqrt (show 0 ≤ 1 + r / v r η by linarith)
  have heq : Real.sqrt (v r η + r) =
      Real.sqrt (v r η) * Real.sqrt (1 + r / v r η) := by
    apply (sq_eq_sq₀ (Real.sqrt_nonneg _)
      (mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _))).1
    rw [mul_pow, hs, hu, ht]
    field_simp [ne_of_gt hv]
  rw [heq]
  unfold aInterior FirstOrder.aStar
  calc
    v r η * (1 + Real.sqrt (1 + r / v r η)) ^ 2 =
        (Real.sqrt (v r η)) ^ 2 * (1 + Real.sqrt (1 + r / v r η)) ^ 2 := by
      rw [hs]
    _ = _ := by ring

theorem interior_maximizing_parameter_unique {r η γ : ℝ}
    (hr : 0 ≤ r) (hv : 0 < v r η)
    (hS : IsLUB {a : ℝ | Jury r η γ a} (aInterior r η)) :
    γ = γInterior r η := by
  have h₁ := FirstOrder.affine_nonneg_at_lub
    (b := 2 + r * (2 * γ - 1)) (c := 1 - 2 * γ - 2 * η) hS (by
      intro a ha
      simpa only [mul_comm] using ha.2.1)
  have h₂ := FirstOrder.affine_nonneg_at_lub
    (b := 1 + r * γ) (c := -(1 - γ - η)) hS (by
      intro a ha
      have := ha.2.2
      nlinarith)
  have hc₁ := first_identity (γ := γ) (a := aInterior r η) hv
  have hc₂ := second_identity (γ := γ) (a := aInterior r η) hv
  have hscale : aInterior r η / v r η = FirstOrder.aStar (r / v r η) := by
    unfold aInterior
    field_simp [ne_of_gt hv]
  rw [hscale] at hc₁ hc₂
  have hb : FirstOrder.closedJury (r / v r η) (γ + η)
      (FirstOrder.aStar (r / v r η)) := by
    constructor
    · by_contra hn
      have hneg := mul_neg_of_pos_of_neg hv (lt_of_not_ge hn)
      nlinarith [hc₁]
    · by_contra hn
      have hneg := mul_neg_of_pos_of_neg hv (lt_of_not_ge hn)
      nlinarith [hc₂]
  have hγ := FirstOrder.optimal_boundary_unique
    (div_nonneg hr (le_of_lt hv)) hb
  unfold γInterior
  linarith

theorem zero_numerator_parameter {r : ℝ} (hr : 0 ≤ r) :
    γInterior r 0 = FirstOrder.γStar r ∧
      aInterior r 0 = FirstOrder.aStar r := by
  simp [γInterior, aInterior, v]

end C2.PoleZero
