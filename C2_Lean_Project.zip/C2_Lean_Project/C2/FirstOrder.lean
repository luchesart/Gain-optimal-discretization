import Mathlib

/-!
# Exact one-delay first-order gain optimization

The predicate `Jury` is deliberately an algebraic predicate.  The equivalence
with complex-root Schur stability is connected in a separate theorem once
the quadratic Schur criterion is imported.  No analytical statement is
hidden in this definition.
-/

noncomputable section

namespace C2.FirstOrder

def Jury (r γ a : ℝ) : Prop :=
  0 < a ∧ 0 < 2 + (2 * γ - 1) * (r - a) ∧
    0 < 1 + r * γ - a * (1 - γ)

def closedJury (r γ a : ℝ) : Prop :=
  0 ≤ 2 + (2 * γ - 1) * (r - a) ∧
    0 ≤ 1 + r * γ - a * (1 - γ)

def γParam (u : ℝ) : ℝ := (u + 2) / (2 * (u + 1))

def aParam (u : ℝ) : ℝ := (u + 1) ^ 2

def γStar (r : ℝ) : ℝ := 1 / 2 + 1 / (2 * (1 + Real.sqrt (1 + r)))

def aStar (r : ℝ) : ℝ := (1 + Real.sqrt (1 + r)) ^ 2

theorem γParam_bounds {u : ℝ} (hu : 1 ≤ u) :
    0 ≤ γParam u ∧ γParam u ≤ 1 := by
  have hd : 0 < 2 * (u + 1) := by linarith
  constructor
  · exact div_nonneg (by linarith) (le_of_lt hd)
  · unfold γParam
    apply (div_le_one hd).2
    linarith

theorem aParam_pos {u : ℝ} (hu : 1 ≤ u) : 0 < aParam u := by
  unfold aParam
  have hp : 0 < u + 1 := by linarith
  positivity

theorem γParam_first_identity {u a : ℝ} (hu : 1 ≤ u) :
    2 + (2 * γParam u - 1) * (u ^ 2 - 1 - a) =
      (aParam u - a) / (u + 1) := by
  have hn : u + 1 ≠ 0 := by linarith
  unfold γParam aParam
  field_simp [hn]
  <;> ring

theorem γParam_second_identity {u a : ℝ} (hu : 1 ≤ u) :
    1 + (u ^ 2 - 1) * γParam u - a * (1 - γParam u) =
      u * (aParam u - a) / (2 * (u + 1)) := by
  have hn : u + 1 ≠ 0 := by linarith
  unfold γParam aParam
  field_simp [hn]
  <;> ring

theorem param_subcritical {u a : ℝ} (hu : 1 ≤ u)
    (ha : 0 < a) (hbound : a < aParam u) :
    Jury (u ^ 2 - 1) (γParam u) a := by
  refine ⟨ha, ?_, ?_⟩
  · rw [γParam_first_identity hu]
    exact div_pos (sub_pos.mpr hbound) (by linarith)
  · rw [γParam_second_identity hu]
    exact div_pos (mul_pos (by linarith) (sub_pos.mpr hbound)) (by linarith)

/-- Every algebraically admissible gain is strictly below the claimed optimum.
This proof does not assume a parameter grid or local optimality. -/
theorem param_global_bound {u γ a : ℝ} (hu : 1 ≤ u)
    (h : Jury (u ^ 2 - 1) γ a) : a < aParam u := by
  rcases h with ⟨ha, h₁, h₂⟩
  by_contra hn
  have hab : aParam u ≤ a := le_of_not_gt hn
  have hp : 0 < u ^ 2 - 1 + a := by
    have : 0 ≤ u ^ 2 - 1 := by nlinarith
    linarith
  have hm : 0 ≤ 2 * (a - (u ^ 2 - 1)) := by
    unfold aParam at hab
    nlinarith
  have hc₁ := mul_pos hp h₁
  have hc₂ := mul_nonneg hm (le_of_lt h₂)
  have hcomb : 0 < 4 * a - (a - (u ^ 2 - 1)) ^ 2 := by
    nlinarith [hc₁, hc₂]
  have hlow : 0 ≤ a - (u - 1) ^ 2 := by
    unfold aParam at hab
    nlinarith
  have hprod := mul_nonneg (sub_nonneg.mpr hab) hlow
  unfold aParam at hprod
  nlinarith [hprod]

/-- The weak boundary inequalities at the globally largest gain uniquely
determine the discretization parameter. -/
theorem param_boundary_unique {u γ : ℝ} (hu : 1 ≤ u)
    (h : closedJury (u ^ 2 - 1) γ (aParam u)) : γ = γParam u := by
  rcases h with ⟨h₁, h₂⟩
  let x : ℝ := 2 * (u + 1) * γ - (u + 2)
  have hx₁ : x ≤ 0 := by
    dsimp [x]
    unfold aParam at h₁
    nlinarith [h₁]
  have hfactor : 1 + (u ^ 2 - 1) * γ - aParam u * (1 - γ) = u * x := by
    dsimp [x, aParam]
    ring
  rw [hfactor] at h₂
  have hx₂ : 0 ≤ x := by
    by_contra hn
    have hx : x < 0 := lt_of_not_ge hn
    have hneg := mul_neg_of_pos_of_neg (show 0 < u by linarith) hx
    linarith
  have hx : x = 0 := le_antisymm hx₁ hx₂
  unfold γParam
  apply (eq_div_iff (show 2 * (u + 1) ≠ 0 by nlinarith)).2
  dsimp [x] at hx
  nlinarith

theorem param_boundary_not_admissible {u γ : ℝ} (hu : 1 ≤ u) :
    ¬ Jury (u ^ 2 - 1) γ (aParam u) := by
  intro h
  exact (lt_irrefl _) (param_global_bound hu h)

theorem sqrt_param {r : ℝ} (hr : 0 ≤ r) :
    1 ≤ Real.sqrt (1 + r) ∧ r = (Real.sqrt (1 + r)) ^ 2 - 1 := by
  have hs : (Real.sqrt (1 + r)) ^ 2 = 1 + r := Real.sq_sqrt (by linarith)
  have hn := Real.sqrt_nonneg (1 + r)
  constructor
  · nlinarith
  · linarith

theorem γStar_eq_param {r : ℝ} (hr : 0 ≤ r) :
    γStar r = γParam (Real.sqrt (1 + r)) := by
  have hu := (sqrt_param hr).1
  have hn : 1 + Real.sqrt (1 + r) ≠ 0 := by linarith
  have hn' : Real.sqrt (1 + r) + 1 ≠ 0 := by linarith
  unfold γStar γParam
  field_simp [hn, hn']
  <;> ring

theorem aStar_eq_param (r : ℝ) : aStar r = aParam (Real.sqrt (1 + r)) := by
  unfold aStar aParam
  ring

theorem γStar_bounds {r : ℝ} (hr : 0 ≤ r) :
    0 ≤ γStar r ∧ γStar r ≤ 1 := by
  rw [γStar_eq_param hr]
  exact γParam_bounds (sqrt_param hr).1

theorem aStar_pos {r : ℝ} (hr : 0 ≤ r) : 0 < aStar r := by
  rw [aStar_eq_param]
  exact aParam_pos (sqrt_param hr).1

theorem global_gain_bound {r γ a : ℝ} (hr : 0 ≤ r)
    (h : Jury r γ a) : a < aStar r := by
  obtain ⟨hu, hr'⟩ := sqrt_param hr
  rw [hr'] at h
  rw [aStar_eq_param]
  exact param_global_bound hu h

theorem optimum_admissible_iff {r a : ℝ} (hr : 0 ≤ r) :
    Jury r (γStar r) a ↔ 0 < a ∧ a < aStar r := by
  constructor
  · intro h
    exact ⟨h.1, global_gain_bound hr h⟩
  · rintro ⟨ha, hb⟩
    obtain ⟨hu, hr'⟩ := sqrt_param hr
    rw [aStar_eq_param] at hb
    have hp := param_subcritical hu ha hb
    simpa only [← hr', ← γStar_eq_param hr] using hp

theorem admissible_projection {r a : ℝ} (hr : 0 ≤ r) :
    (∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r γ a) ↔
      0 < a ∧ a < aStar r := by
  constructor
  · rintro ⟨γ, _, _, h⟩
    exact ⟨h.1, global_gain_bound hr h⟩
  · intro h
    exact ⟨γStar r, (γStar_bounds hr).1, (γStar_bounds hr).2,
      (optimum_admissible_iff hr).2 h⟩

theorem optimal_boundary_unique {r γ : ℝ} (hr : 0 ≤ r)
    (h : closedJury r γ (aStar r)) : γ = γStar r := by
  obtain ⟨hu, hr'⟩ := sqrt_param hr
  have hp : closedJury ((Real.sqrt (1 + r)) ^ 2 - 1) γ
      (aParam (Real.sqrt (1 + r))) := by
    rw [← hr', ← aStar_eq_param]
    exact h
  rw [γStar_eq_param hr]
  exact param_boundary_unique hu hp

theorem optimal_gain_isLUB {r : ℝ} (hr : 0 ≤ r) :
    IsLUB {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r γ a} (aStar r) := by
  constructor
  · intro a ha
    exact le_of_lt ((admissible_projection hr).1 ha).2
  · intro b hb
    by_contra hn
    have hbA : b < aStar r := lt_of_not_ge hn
    have hA := aStar_pos hr
    let a : ℝ := (max b 0 + aStar r) / 2
    have hmax : max b 0 < aStar r := max_lt_iff.mpr ⟨hbA, hA⟩
    have ha : 0 < a := by dsimp [a]; nlinarith [le_max_right b 0]
    have haA : a < aStar r := by dsimp [a]; linarith
    have hba : b < a := by dsimp [a]; nlinarith [le_max_left b 0]
    have hmem : a ∈ {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r γ a} :=
      (admissible_projection hr).2 ⟨ha, haA⟩
    have := hb hmem
    linarith

/-- A linear inequality valid on a set persists at its finite supremum.
The proof uses only ordered-field properties and the defining property of
`IsLUB`; it does not assume that the supremum is in the original set. -/
theorem affine_nonneg_at_lub {S : Set ℝ} {A b c : ℝ}
    (hS : IsLUB S A) (h : ∀ a ∈ S, 0 < b + c * a) :
    0 ≤ b + c * A := by
  have hne : S.Nonempty := by
    by_contra hn
    have hb : A - 1 ∈ upperBounds S := by
      intro x hx
      exact False.elim (hn ⟨x, hx⟩)
    have := hS.2 hb
    linarith
  by_cases hc : 0 ≤ c
  · obtain ⟨x, hx⟩ := hne
    have hxA := hS.1 hx
    have hf := h x hx
    have hm := mul_nonneg hc (sub_nonneg.mpr hxA)
    nlinarith
  · have hc' : c < 0 := lt_of_not_ge hc
    have hb : (-b / c) ∈ upperBounds S := by
      intro x hx
      apply (le_div_iff_of_neg hc').2
      have := h x hx
      nlinarith
    have hAb := hS.2 hb
    have hi := (le_div_iff_of_neg hc').1 hAb
    nlinarith

/-- Uniqueness concerns the supremum of the strict stable-gain interval,
not an inadmissible gain declared to be an attained stable maximum. -/
theorem maximizing_parameter_unique {r γ : ℝ} (hr : 0 ≤ r)
    (hS : IsLUB {a : ℝ | Jury r γ a} (aStar r)) : γ = γStar r := by
  apply optimal_boundary_unique hr
  have h₁ := affine_nonneg_at_lub (b := 2 + (2 * γ - 1) * r)
    (c := -(2 * γ - 1)) hS (by
      intro a ha
      have := ha.2.1
      nlinarith)
  have h₂ := affine_nonneg_at_lub (b := 1 + r * γ)
    (c := -(1 - γ)) hS (by
      intro a ha
      have := ha.2.2
      nlinarith)
  constructor <;> nlinarith

theorem optimum_parameter_isLUB {r : ℝ} (hr : 0 ≤ r) :
    IsLUB {a : ℝ | Jury r (γStar r) a} (aStar r) := by
  have heq : {a : ℝ | Jury r (γStar r) a} =
      {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r γ a} := by
    ext a
    exact (optimum_admissible_iff hr).trans (admissible_projection hr).symm
  rw [heq]
  exact optimal_gain_isLUB hr

theorem maximizing_parameter_iff {r γ : ℝ} (hr : 0 ≤ r) :
    IsLUB {a : ℝ | Jury r γ a} (aStar r) ↔ γ = γStar r := by
  constructor
  · exact maximizing_parameter_unique hr
  · rintro rfl
    exact optimum_parameter_isLUB hr

theorem param_boundary_coefficients {u : ℝ} (hu : 1 ≤ u) :
    -1 + (u ^ 2 - 1) * (1 - γParam u) + aParam u * γParam u =
        2 * (1 + (u ^ 2 - 1) * γParam u) ∧
      aParam u * (1 - γParam u) = 1 + (u ^ 2 - 1) * γParam u := by
  have h₁ := γParam_first_identity (a := aParam u) hu
  have h₂ := γParam_second_identity (a := aParam u) hu
  rw [sub_self, zero_div] at h₁
  rw [sub_self, mul_zero, zero_div] at h₂
  constructor <;> nlinarith

theorem boundary_coefficients {r : ℝ} (hr : 0 ≤ r) :
    -1 + r * (1 - γStar r) + aStar r * γStar r =
        2 * (1 + r * γStar r) ∧
      aStar r * (1 - γStar r) = 1 + r * γStar r := by
  obtain ⟨hu, heq⟩ := sqrt_param hr
  have h := param_boundary_coefficients hu
  simpa only [← heq, ← γStar_eq_param hr, ← aStar_eq_param] using h

/-- At the optimum the characteristic polynomial has a double root at -1.
This is an identity on the complex plane, not a numerical root calculation. -/
theorem boundary_polynomial_factorization {r : ℝ} (hr : 0 ≤ r) (z : ℂ) :
    ((1 + r * γStar r : ℝ) : ℂ) * z ^ 2 +
        ((-1 + r * (1 - γStar r) + aStar r * γStar r : ℝ) : ℂ) * z +
        ((aStar r * (1 - γStar r) : ℝ) : ℂ) =
      ((1 + r * γStar r : ℝ) : ℂ) * (z + 1) ^ 2 := by
  obtain ⟨hb, hc⟩ := boundary_coefficients hr
  rw [hb, hc]
  push_cast
  ring

theorem γStar_strict_decrease {r₁ r₂ : ℝ} (h₁ : 0 ≤ r₁) (h₁₂ : r₁ < r₂) :
    γStar r₂ < γStar r₁ := by
  have h₂ : 0 ≤ r₂ := le_trans h₁ (le_of_lt h₁₂)
  obtain ⟨hu₁, hr₁⟩ := sqrt_param h₁
  obtain ⟨hu₂, hr₂⟩ := sqrt_param h₂
  have hu : Real.sqrt (1 + r₁) < Real.sqrt (1 + r₂) := by
    apply (sq_lt_sq₀ (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)).1
    linarith
  have hd₁ : 0 < 2 * (1 + Real.sqrt (1 + r₁)) := by linarith
  have hd₂ : 0 < 2 * (1 + Real.sqrt (1 + r₂)) := by linarith
  have hf : (1 : ℝ) / (2 * (1 + Real.sqrt (1 + r₂))) <
      1 / (2 * (1 + Real.sqrt (1 + r₁))) := by
    apply (div_lt_div_iff₀ hd₂ hd₁).2
    nlinarith
  unfold γStar
  linarith

theorem integrator_γStar : γStar 0 = 3 / 4 := by norm_num [γStar]

theorem integrator_aStar : aStar 0 = 4 := by norm_num [aStar]

theorem integrator_optimum_iff {a : ℝ} :
    Jury 0 (3 / 4) a ↔ 0 < a ∧ a < 4 := by
  simpa only [integrator_γStar, integrator_aStar] using
    (optimum_admissible_iff (r := 0) (by norm_num))

end C2.FirstOrder
