import C2.NGammaMarginOptimization
import C2.NGammaCriticalBoundary

/-! Complete global optimization statements, including the explicit regimes,
the supremal stable gain, strict stability below it, and the boundary root.
The full-cube statement concerns the initial stable interval adjacent to zero. -/
noncomputable section
open scoped BigOperators
open Set
namespace C2.NGamma.Global
open PolynomialModel

def OptimalGainDescription {n : ℕ} (r x : Fin n → ℝ) (B : ℝ) : Prop :=
  (1 < endpointSum r → x = (fun _ => 1) ∧ ∃ t : ℝ, 0 < t ∧
    Phase.totalPhase (fun j => 1+2/r j) (fun _ => 1) 1 t = Real.pi ∧
      B = Cayley.amplitude r (fun _ => 1) t) ∧
  (endpointSum r = 1 → x = (fun _ => 1) ∧ B = ∏ j, (r j+2)) ∧
  (endpointSum r < 1 → ∃ c : ℝ, 0 < c ∧ allocatedResource r c = 4 ∧
    x = (fun j => endpointParameter (r j) c) ∧ B = ∏ j, endpointAllocation (r j) c)

theorem optimalGainDescription_of_parameters {n : ℕ} (hn : 0 < n)
    (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    {B : ℝ} (hB : CriticalGain r x B) (hd : OptimalParameterDescription r x) :
    OptimalGainDescription r x B := by
  refine ⟨?_,?_,?_⟩
  · intro hS
    have hxone := hd.1 hS
    refine ⟨hxone,?_⟩
    rcases hB with ⟨hxp,hcost,hgain⟩ | ⟨t,ht,hp,hgain⟩
    · have hbase := (endpoint_feasible_iff r hr).mp ⟨x,fun j => ⟨hxp j,(hx j).2⟩,hcost⟩
      exact False.elim (not_lt_of_ge hbase hS)
    · refine ⟨t,ht,?_,?_⟩
      · simpa only [hxone] using hp
      · simpa only [hxone] using hgain
  · intro hS
    have hxone := hd.2.1 hS
    refine ⟨hxone,?_⟩
    have hcost : (∑ j, endpointCost (r j) 1) ≤ 1 := by
      have heq : (∑ j, endpointCost (r j) 1) = 1 := by simpa [endpointCost,endpointSum,add_comm] using hS
      exact heq.le
    have hE : CriticalGain r x (∏ j, (r j+2)) := by
      rw [hxone]
      exact Or.inl ⟨fun _ => by norm_num,hcost,by simp⟩
    exact criticalGain_unique hn r x hr hx hB hE
  · intro hS
    obtain ⟨c,hc,hbudget,hxc⟩ := hd.2.2 hS
    refine ⟨c,hc,hbudget,hxc,?_⟩
    have hE : CriticalGain r x (∏ j, endpointAllocation (r j) c) := by
      rw [hxc]
      exact Or.inl ⟨fun j => endpointParameter_pos _ _,(endpointParameter_budget r hr hbudget).le,
        (Finset.prod_congr rfl (fun j _ => endpointParameter_inverse (r j) c)).symm⟩
    exact criticalGain_unique hn r x hr hx hB hE

/-- Complete full-cube result, with the same explicit unique design as the
half-cube theorem and the actual supremum definition of the initial margin. -/
theorem full_cube_initial_margin_global_theorem {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    ∃ xstar : Fin n → ℝ, ∃ Bstar : ℝ,
      (∀ j, xstar j ∈ Icc (0:ℝ) 1) ∧ 0 < Bstar ∧
      OptimalGainDescription r xstar Bstar ∧
      initialGainMargin r xstar 1 = Bstar ∧
      (∀ b : ℝ, 0 ≤ b → (SchurStable (characteristic r xstar 1 b) ↔ b < Bstar)) ∧
      (∃ z : ℂ, ‖z‖ = 1 ∧ (characteristic r xstar 1 Bstar).eval z = 0) ∧
      ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (-1:ℝ) 1) →
        initialGainMargin r x 1 ≤ Bstar ∧ (initialGainMargin r x 1 = Bstar ↔ x = xstar) := by
  obtain ⟨xs,Bs,hxs,hBs,hmargin,hstable,hfull⟩ := exists_unique_full_cube_margin_optimizer hn r hr
  obtain ⟨xc,Bc,hxc,hBc,hdescription,hcritical⟩ := exists_unique_global_critical_gain_classified hn r hr
  have hxcfull : ∀ j, xc j ∈ Icc (-1:ℝ) 1 := fun j => ⟨by linarith [(hxc j).1],(hxc j).2⟩
  have hBc_le : Bc ≤ Bs := by
    have h := (hfull xc hxcfull).1
    rw [criticalGain_eq_initialMargin hn r xc hr hxc hBc] at h
    exact h
  have hBs_le : Bs ≤ Bc := (hcritical xs hxs Bs hBs).1
  have heq : Bs = Bc := le_antisymm hBs_le hBc_le
  have hxeq : xs = xc := (hcritical xs hxs Bs hBs).2.mp heq
  have hd : OptimalParameterDescription r xs := hxeq ▸ hdescription
  exact ⟨xs,Bs,hxs,criticalGain_pos hr hBs,
    optimalGainDescription_of_parameters hn r xs hr hxs hBs hd,
    hmargin,hstable,criticalGain_has_unit_root hr hBs,hfull⟩

/-- The full half-cube theorem: explicit unique global critical gain,
strict stability of every smaller nonnegative gain, and unit-circle roots
at its supremum. The stronger full-cube theorem supplies its optimization. -/
theorem half_cube_global_gain_theorem {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    ∃ xstar : Fin n → ℝ, ∃ Bstar : ℝ,
      (∀ j, xstar j ∈ Icc (0:ℝ) 1) ∧ 0 < Bstar ∧
      OptimalGainDescription r xstar Bstar ∧
      initialGainMargin r xstar 1 = Bstar ∧
      (∀ b : ℝ, 0 ≤ b → (SchurStable (characteristic r xstar 1 b) ↔ b < Bstar)) ∧
      (∃ z : ℂ, ‖z‖ = 1 ∧ (characteristic r xstar 1 Bstar).eval z = 0) ∧
      ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) →
        initialGainMargin r x 1 ≤ Bstar ∧ (initialGainMargin r x 1 = Bstar ↔ x = xstar) := by
  obtain ⟨xs,Bs,hxs,hB,hd,hm,hs,hroot,hfull⟩ := full_cube_initial_margin_global_theorem hn r hr
  refine ⟨xs,Bs,hxs,hB,hd,hm,hs,hroot,?_⟩
  intro x hx
  exact hfull x (fun j => ⟨by linarith [(hx j).1],(hx j).2⟩)

end C2.NGamma.Global
