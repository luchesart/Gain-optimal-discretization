#!/usr/bin/env python3
"""Build C2 proof modules in dependency order with bounded parallelism.

Restore the pinned mathlib cache with `lake exe cache get` first.
This changes neither theorem sources nor the proof checker.
"""
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parents[1]
modules = {f'C2.{p.stem}': p for p in (root / 'C2').glob('*.lean')}
order, visiting, visited = [], set(), set()

def visit(name):
    if name in visited:
        return
    if name in visiting:
        raise RuntimeError(f'Cyclic project import: {name}')
    visiting.add(name)
    for dependency in re.findall(r'^import\s+(C2\.\S+)\s*$', modules[name].read_text(), re.M):
        visit(dependency)
    visiting.remove(name)
    visited.add(name)
    order.append(name)

for name in sorted(modules):
    visit(name)
for index, name in enumerate(order, 1):
    print(f'[{index}/{len(order)}] {name}', flush=True)
    subprocess.run(['lake', 'build', name], cwd=root, check=True)
subprocess.run(['lake', 'build', 'C2'], cwd=root, check=True)
