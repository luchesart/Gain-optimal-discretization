import C2.CADEffectiveSquarefree
import C2.CADEffectiveRootOutput

/-! The concrete executable isolation stage of the CAD driver. Endpoints are
inserted as polynomial roots before square-free reduction. All computed data
are dense rational coefficients, mesh indices, and ordered natural ranks. -/

namespace C2.CADDriver
open Polynomial Set
open C2.CADEffective

def product : List Dense.Poly → Dense.Poly
  | [] => [1]
  | p :: ps => Dense.mul p (product ps)

theorem denote_product (ps : List Dense.Poly) :
    Dense.denote (product ps) = (ps.map Dense.denote).prod := by
  induction ps with
  | nil => simp [product]
  | cons p ps ih => simp [product, ih]

theorem product_nonzero (ps : List Dense.Poly)
    (h : ∀ p ∈ ps, Dense.denote p ≠ 0) : Dense.denote (product ps) ≠ 0 := by
  induction ps with
  | nil => simp [product]
  | cons p ps ih =>
    simp only [product, Dense.denote_mul]
    exact mul_ne_zero (h p (List.mem_cons_self))
      (ih fun q hq => h q (List.mem_cons_of_mem p hq))

def anyZero (ps : List Dense.Poly) : Bool := ps.any fun p => Dense.eqb p []

theorem anyZero_eq_false_iff (ps : List Dense.Poly) :
    anyZero ps = false ↔ ∀ p ∈ ps, Dense.denote p ≠ 0 := by
  simp [anyZero, Bool.eq_false_iff, ne_eq, List.any_eq_true,
    Dense.eqb_eq_true_iff]

def augmented (p : Dense.Poly) (a b : ℚ) : Dense.Poly :=
  Dense.mul p (Dense.mul [-a, 1] [-b, 1])

theorem denote_linear (a : ℚ) : Dense.denote [-a, 1] = X - C a := by
  simp
  ring

theorem denote_augmented (p : Dense.Poly) (a b : ℚ) :
    Dense.denote (augmented p a b) = Dense.denote p * ((X - C a) * (X - C b)) := by
  unfold augmented
  rw [Dense.denote_mul, Dense.denote_mul, denote_linear, denote_linear]

theorem augmented_nonzero (p : Dense.Poly) (hp : Dense.denote p ≠ 0) (a b : ℚ) :
    Dense.denote (augmented p a b) ≠ 0 := by
  rw [denote_augmented]
  exact mul_ne_zero hp (mul_ne_zero (X_sub_C_ne_zero a) (X_sub_C_ne_zero b))

theorem reduced_nondegenerate (p : Dense.Poly) (hp : Dense.denote p ≠ 0) (a b : ℚ) :
    ∀ x ∈ Icc (a : ℝ) (b : ℝ),
      CADIsolation.realEval (Dense.denote (Dense.reducedPoly p hp)) x ≠ 0 ∨
        CADIsolation.realEval (Dense.denote (Dense.reducedPoly p hp)).derivative x ≠ 0 := by
  intro x hx
  by_cases hz : CADIsolation.realEval (Dense.denote (Dense.reducedPoly p hp)) x = 0
  · exact Or.inr ((Dense.reducedPoly_correct.{0} p hp).1.eval₂_derivative_ne_zero
      (algebraMap ℚ ℝ) hz)
  · exact Or.inl hz

structure Isolation where
  polynomial : Dense.Poly
  mesh : ℕ
  ranks : List ℕ

/-- Total executable isolation, including both rational interval endpoints.
The searches evaluate only dense rational identities and mesh inequalities. -/
def isolate (p : Dense.Poly) (hp : Dense.denote p ≠ 0)
    (a b : ℚ) (hab : a ≤ b) : Isolation :=
  let ap := augmented p a b
  let hap := augmented_nonzero p hp a b
  let q := Dense.reducedPoly ap hap
  let n := Dense.meshIndex q hab (reduced_nondegenerate ap hap a b)
  ⟨q, n, Dense.rootRanks q a b n⟩

theorem isolate_mesh_certified (p : Dense.Poly) (hp : Dense.denote p ≠ 0)
    (a b : ℚ) (hab : a ≤ b) :
    CADIsolation.certifiedMesh (Dense.denote (isolate p hp a b hab).polynomial) a b
      (isolate p hp a b hab).mesh := by
  dsimp only [isolate]
  exact Dense.meshIndex_certified _ hab (reduced_nondegenerate _ _ a b)

theorem isolate_polynomial_nonzero (p : Dense.Poly) (hp : Dense.denote p ≠ 0)
    (a b : ℚ) (hab : a ≤ b) :
    Dense.denote (isolate p hp a b hab).polynomial ≠ 0 :=
  (Dense.reducedPoly_correct.{0} _ (augmented_nonzero p hp a b)).2.1

theorem isolate_root_iff (p : Dense.Poly) (hp : Dense.denote p ≠ 0)
    (a b : ℚ) (hab : a ≤ b) (x : ℝ) :
    CADIsolation.realEval (Dense.denote (isolate p hp a b hab).polynomial) x = 0 ↔
      CADIsolation.realEval (Dense.denote p) x = 0 ∨ x = (a : ℝ) ∨ x = (b : ℝ) := by
  change CADIsolation.realEval (Dense.denote (Dense.reducedPoly (augmented p a b)
    (augmented_nonzero p hp a b))) x = 0 ↔ _
  simp only [CADIsolation.realEval]
  rw [(Dense.reducedPoly_correct _ (augmented_nonzero p hp a b)).2.2 (algebraMap ℚ ℝ) x]
  simp [CADIsolation.realEval, denote_augmented, mul_eq_zero, sub_eq_zero, or_assoc]

theorem isolate_ranks_sorted (p : Dense.Poly) (hp : Dense.denote p ≠ 0)
    (a b : ℚ) (hab : a ≤ b) :
    List.Pairwise (· < ·) (isolate p hp a b hab).ranks :=
  Dense.rootRanks_sorted _ _ _ _

theorem isolate_unique_root (p : Dense.Poly) (hp : Dense.denote p ≠ 0)
    (a b : ℚ) (hab : a < b) {r : ℕ}
    (hr : r ∈ (isolate p hp a b hab.le).ranks) :
    ∃! x, Dense.rootAtRank (isolate p hp a b hab.le).polynomial a b
      (isolate p hp a b hab.le).mesh r x :=
  Dense.rootRanks_unique_root _ hab (isolate_mesh_certified p hp a b hab.le) hr

theorem isolate_complete (p : Dense.Poly) (hp : Dense.denote p ≠ 0)
    (a b : ℚ) (hab : a < b) {x : ℝ} (hx : x ∈ Icc (a : ℝ) (b : ℝ))
    (hroot : CADIsolation.realEval (Dense.denote p) x = 0 ∨ x = (a : ℝ) ∨ x = (b : ℝ)) :
    ∃ r ∈ (isolate p hp a b hab.le).ranks,
      Dense.rootAtRank (isolate p hp a b hab.le).polynomial a b
        (isolate p hp a b hab.le).mesh r x := by
  exact Dense.rootRanks_complete _ hab (isolate_mesh_certified p hp a b hab.le) hx
    ((isolate_root_iff p hp a b hab.le x).mpr hroot)

end C2.CADDriver
