import C2.CADProjectionFamily

/-! Finite algebraic projection data. Validity consists of rational polynomial
identities and nonzero tests, suitable for exact verification of finite data. -/
noncomputable section
open Polynomial
namespace C2.CADProjection

structure ProjectionData (ι : Type*) where
  simple : ι → ℚ[X]
  simpleU : ι → Bivariate
  simpleV : ι → Bivariate
  pair : ι → ι → ℚ[X]
  pairU : ι → ι → Bivariate
  pairV : ι → ι → Bivariate

def ValidProjectionData {ι : Type*} (p : ι → Bivariate) (w : ProjectionData ι) : Prop :=
  (∀ i, (p i).leadingCoeff ≠ 0 ∧ (p i).eval 0 ≠ 0 ∧ (p i).eval 1 ≠ 0 ∧
    w.simple i ≠ 0 ∧ w.simpleU i * p i + w.simpleV i * (p i).derivative = C (w.simple i)) ∧
  (∀ i j, w.pair i j ≠ 0 ∧ (i ≠ j →
    w.pairU i j * p i + w.pairV i j * p j = C (w.pair i j)))

def projectionCut {ι : Type*} [Fintype ι] (p : ι → Bivariate) (w : ProjectionData ι) : ℚ[X] :=
  (∏ i, (p i).leadingCoeff * (p i).eval 0 * (p i).eval 1 * w.simple i) *
    ∏ i, ∏ j, w.pair i j

/-- Generic separability and coprimeness yield finite algebraic data; neither
root regularity nor algorithm output correctness is an assumption. -/
theorem exists_valid_projection_data {ι : Type*} (p : ι → Bivariate)
    (hp : ∀ i, p i ≠ 0)
    (hsep : ∀ i, ((p i).map (algebraMap ℚ[X] (RatFunc ℚ))).Separable)
    (hpair : ∀ i j, i ≠ j → IsCoprime
      ((p i).map (algebraMap ℚ[X] (RatFunc ℚ)))
      ((p j).map (algebraMap ℚ[X] (RatFunc ℚ))))
    (hzero : ∀ i, (p i).eval 0 ≠ 0) (hone : ∀ i, (p i).eval 1 ≠ 0) :
    ∃ w : ProjectionData ι, ValidProjectionData p w := by
  classical
  have hsi : ∀ i, ∃ r : ℚ[X], r ≠ 0 ∧ ∃ u v : Bivariate,
      u*p i + v*(p i).derivative = C r := by
    intro i
    apply exists_bezout_eliminant (F:=RatFunc ℚ)
    simpa only [Polynomial.derivative_map] using (Polynomial.separable_def _).mp (hsep i)
  choose s hs su sv hid using hsi
  have hpi : ∀ i j, ∃ r : ℚ[X], r ≠ 0 ∧ ∃ u v : Bivariate,
      i ≠ j → u*p i + v*p j = C r := by
    intro i j
    by_cases hij : i = j
    · exact ⟨1,one_ne_zero,0,0,fun h => False.elim (h hij)⟩
    · obtain ⟨r,hr,u,v,hid⟩ := exists_bezout_eliminant (p i) (p j) (hpair i j hij)
      exact ⟨r,hr,u,v,fun _ => hid⟩
  choose r hr ru rv hpid using hpi
  refine ⟨⟨s,su,sv,r,ru,rv⟩,?_,?_⟩
  · intro i
    exact ⟨Polynomial.leadingCoeff_ne_zero.mpr (hp i),hzero i,hone i,hs i,hid i⟩
  · intro i j
    exact ⟨hr i j,hpid i j⟩

/-- Exact validity of the finite data proves its projection polynomial nonzero. -/
theorem ValidProjectionData.cut_ne_zero {ι : Type*} [Fintype ι]
    {p : ι → Bivariate} {w : ProjectionData ι} (h : ValidProjectionData p w) :
    projectionCut p w ≠ 0 := by
  apply mul_ne_zero
  · apply Finset.prod_ne_zero_iff.mpr
    intro i _
    exact mul_ne_zero (mul_ne_zero (mul_ne_zero (h.1 i).1 (h.1 i).2.1)
      (h.1 i).2.2.1) (h.1 i).2.2.2.1
  · apply Finset.prod_ne_zero_iff.mpr
    intro i _
    exact Finset.prod_ne_zero_iff.mpr (fun j _ => (h.2 i j).1)

/-- The accepted finite identities imply concrete simple/disjoint roots at
every gain outside the actual computed product of their cuts. -/
theorem ValidProjectionData.regular {ι : Type*} [Fintype ι]
    {p : ι → Bivariate} {w : ProjectionData ι} (h : ValidProjectionData p w)
    (k : ℝ) (hk : (projectionCut p w).eval₂ (algebraMap ℚ ℝ) k ≠ 0) :
    RegularFamilyAt p k := by
  let f : ℚ[X] →+* ℝ := Polynomial.eval₂RingHom (algebraMap ℚ ℝ) k
  have hfk : f (projectionCut p w) ≠ 0 := hk
  have hprod :
      (∏ i, f (p i).leadingCoeff * f ((p i).eval 0) *
        f ((p i).eval 1) * f (w.simple i)) ≠ 0 ∧
      (∏ i, ∏ j, f (w.pair i j)) ≠ 0 := by
    simpa only [projectionCut,map_mul,map_prod,mul_ne_zero_iff] using hfk
  have hi : ∀ i, f (p i).leadingCoeff ≠ 0 ∧ f ((p i).eval 0) ≠ 0 ∧
      f ((p i).eval 1) ≠ 0 ∧ f (w.simple i) ≠ 0 := by
    intro i
    have hh := Finset.prod_ne_zero_iff.mp hprod.1 i (Finset.mem_univ i)
    simpa only [mul_ne_zero_iff,and_assoc] using hh
  refine ⟨fun i => ⟨⟨?_,?_⟩,?_,?_⟩,?_⟩
  · exact Polynomial.natDegree_map_eq_iff.mpr (Or.inl (hi i).1)
  · intro x hx
    have hh := no_common_root_of_bezout (h.1 i).2.2.2.2 f (hi i).2.2.2 x
    have hd := hh.resolve_left (not_not.mpr hx)
    change ((p i).map f).derivative.eval x ≠ 0
    simpa only [Polynomial.derivative_map] using hd
  · simpa only [value_zero] using (hi i).2.1
  · simpa only [value_one] using (hi i).2.2.1
  · intro i j hij x
    have hn := Finset.prod_ne_zero_iff.mp
      (Finset.prod_ne_zero_iff.mp hprod.2 i (Finset.mem_univ i)) j (Finset.mem_univ j)
    exact no_common_root_of_bezout ((h.2 i j).2 hij) f hn x

/-- All exceptional gains of valid projection data form a finite algebraic set. -/
theorem ValidProjectionData.finite_algebraic_exceptions {ι : Type*} [Fintype ι]
    {p : ι → Bivariate} {w : ProjectionData ι} (h : ValidProjectionData p w) :
    Set.Finite {k : ℝ | (projectionCut p w).eval₂ (algebraMap ℚ ℝ) k = 0} ∧
    ∀ k : ℝ, (projectionCut p w).eval₂ (algebraMap ℚ ℝ) k = 0 → IsAlgebraic ℚ k :=
  ⟨rational_zero_set_finite _ h.cut_ne_zero,
    fun _ hk => rational_zero_isAlgebraic _ h.cut_ne_zero hk⟩

end C2.CADProjection
