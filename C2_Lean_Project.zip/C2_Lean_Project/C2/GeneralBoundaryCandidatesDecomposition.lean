import C2.GeneralBoundaryCandidates
import C2.GeneralBoundaryRootCount

/-! Complete fixed-parameter gain decomposition: finite explicit candidates,
actual boundary equivalence, multiplicity-count constancy and exact stability
constancy on every connected gain component. -/
noncomputable section
open scoped BigOperators
open Polynomial Set
namespace C2.GeneralBoundaryCandidates

def actualPolynomial (H N : ℝ[X]) (k : ℝ) : ℂ[X] :=
  GeneralBoundary.gainPolynomial (H.map (algebraMap ℝ ℂ)) (N.map (algebraMap ℝ ℂ)) k

theorem actualPolynomial_eval (H N : ℝ[X]) (k : ℝ) (z : ℂ) :
    (actualPolynomial H N k).eval z=evalC H z+(k:ℂ)*evalC N z := by
  simp [actualPolynomial,GeneralBoundary.gainPolynomial,evalC,aeval_def,Polynomial.eval_map]

theorem actual_boundary_iff_candidate {H N : ℝ[X]} {k : ℝ} (hk : 0 < k)
    (hcommon : ∀ z : ℂ, ‖z‖=1 → evalC N z=0 → evalC H z≠0) :
    (∃ z : ℂ, ‖z‖=1 ∧ (actualPolynomial H N k).eval z=0) ↔ k ∈ candidateGains H N := by
  simpa only [C2.UnitCircleRoot,actualPolynomial_eval] using unitCircleRoot_iff_candidate hk hcommon

theorem boundaryFree_of_not_candidate {H N : ℝ[X]} {k : ℝ} (hk : 0 < k)
    (hcommon : ∀ z : ℂ, ‖z‖=1 → evalC N z=0 → evalC H z≠0)
    (hn : k ∉ candidateGains H N) : GeneralBoundary.BoundaryFree (actualPolynomial H N k) := by
  intro z hz he
  exact hn ((actual_boundary_iff_candidate hk hcommon).mp ⟨z,hz,he⟩)

/-- Complete numbered theorem `thm:general-boundaries`. Connected components
are covered by the stronger assertion for every preconnected subset of the
positive gain axis after removing the explicit candidate set. -/
theorem complete_fixed_parameter_decomposition {H N : ℝ[X]}
    (hQ : Q H N ≠ 0) (hdeg : N.natDegree < H.natDegree)
    (hcommon : ∀ z : ℂ, ‖z‖=1 → evalC N z=0 → evalC H z≠0) :
    (candidateGains H N).Finite ∧
    (∀ k : ℝ, 0 < k →
      ((∃ z : ℂ, ‖z‖=1 ∧ (actualPolynomial H N k).eval z=0) ↔ k ∈ candidateGains H N)) ∧
    (∀ S : Set ℝ, IsPreconnected S → S ⊆ Ioi 0 \ candidateGains H N →
      ∀ k ∈ S, ∀ l ∈ S,
        C2.NGamma.RootCountBridge.countInside (actualPolynomial H N k) =
          C2.NGamma.RootCountBridge.countInside (actualPolynomial H N l) ∧
        (C2.NGamma.PolynomialModel.SchurStable (actualPolynomial H N k) ↔
          C2.NGamma.PolynomialModel.SchurStable (actualPolynomial H N l))) ∧
    ∀ k ∈ candidateGains H N, ¬C2.NGamma.PolynomialModel.SchurStable (actualPolynomial H N k) := by
  refine ⟨candidateGains_finite hQ,fun k hk => actual_boundary_iff_candidate hk hcommon,?_,?_⟩
  · intro S hconn hS k hk l hl
    have hf : ∀ b ∈ S, GeneralBoundary.BoundaryFree (actualPolynomial H N b) := fun b hb =>
      boundaryFree_of_not_candidate (hS hb).1 hcommon (hS hb).2
    have hd : (N.map (algebraMap ℝ ℂ)).natDegree < (H.map (algebraMap ℝ ℂ)).natDegree := by
      simpa only [Polynomial.natDegree_map] using hdeg
    exact ⟨GeneralBoundary.count_constant_on_preconnected _ _ hconn hf hk hl,
      GeneralBoundary.schur_constant_on_preconnected _ _ hd hconn hf hk hl⟩
  · intro k hk
    exact GeneralBoundary.boundary_point_not_schur _ ((actual_boundary_iff_candidate hk.1 hcommon).mpr hk)

end C2.GeneralBoundaryCandidates
