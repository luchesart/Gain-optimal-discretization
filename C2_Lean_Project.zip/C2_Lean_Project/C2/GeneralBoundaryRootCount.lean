import C2.Boundary
import C2.NGammaRootCountBridge
import C2.NGammaRootCountConsequences
import Mathlib

/-!
# Root-count constancy for a general affine polynomial gain family

A local comparison uses the continuous argument of the quotient of nearby
polynomials. Its real part is positive on the circle, so its total argument
increment is zero. Compactness then supplies a gain neighborhood, and local
constancy gives constancy on every preconnected boundary-free gain set.
-/

noncomputable section
open scoped Topology
open Filter Set Complex Polynomial C2.NGamma.RootCountBridge

namespace C2.GeneralBoundary

def BoundaryFree (p : Polynomial ℂ) : Prop :=
  ∀ z : ℂ, ‖z‖ = 1 → p.eval z ≠ 0

def gainPolynomial (H N : Polynomial ℂ) (k : ℝ) : Polynomial ℂ :=
  H + C (k : ℂ) * N

theorem boundaryFree_iff_not_unitCircleRoot (H N : Polynomial ℂ) (k : ℝ) :
    BoundaryFree (gainPolynomial H N k) ↔
      ¬ C2.UnitCircleRoot (fun z => H.eval z) (fun z => N.eval z) k := by
  simp only [BoundaryFree, gainPolynomial, eval_add, eval_mul, eval_C,
    C2.UnitCircleRoot, not_exists, not_and]

theorem boundaryFree_ne_zero {p : Polynomial ℂ} (h : BoundaryFree p) : p ≠ 0 := by
  intro hp
  have hn := h 1 (by simp)
  simpa [hp] using hn

theorem boundaryFree_roots {p : Polynomial ℂ} (h : BoundaryFree p) :
    ∀ z ∈ p.roots, ‖z‖ ≠ 1 := by
  intro z hz hnorm
  exact h z hnorm (isRoot_of_mem_roots hz)

theorem quotient_re_pos_of_close {p q : Polynomial ℂ} (hp : BoundaryFree p)
    (hclose : ∀ z : ℂ, ‖z‖ = 1 → ‖q.eval z - p.eval z‖ < ‖p.eval z‖)
    (z : ℂ) (hz : ‖z‖ = 1) : 0 < (q.eval z / p.eval z).re := by
  have hpn := hp z hz
  have hnorm : ‖(q.eval z - p.eval z) / p.eval z‖ < 1 := by
    rw [norm_div]
    exact (div_lt_one (norm_pos_iff.mpr hpn)).mpr (hclose z hz)
  have he : q.eval z / p.eval z = 1 + (q.eval z - p.eval z) / p.eval z := by
    field_simp [hpn]
  rw [he, Complex.add_re, Complex.one_re]
  have hb := (abs_le.mp (Complex.abs_re_le_norm ((q.eval z - p.eval z) / p.eval z))).1
  linarith

theorem boundaryFree_of_close {p q : Polynomial ℂ} (hp : BoundaryFree p)
    (hclose : ∀ z : ℂ, ‖z‖ = 1 → ‖q.eval z - p.eval z‖ < ‖p.eval z‖) :
    BoundaryFree q := by
  intro z hz hq
  have h := quotient_re_pos_of_close hp hclose z hz
  simp [hq] at h

/-- A polynomial Rouché comparison on the unit circle, retaining actual root
multiplicities. The proof uses the previously verified polynomial argument
principle, rather than assuming continuity of enumerated roots. -/
theorem countInside_eq_of_close {p q : Polynomial ℂ} (hp : BoundaryFree p)
    (hclose : ∀ z : ℂ, ‖z‖ = 1 → ‖q.eval z - p.eval z‖ < ‖p.eval z‖) :
    countInside q = countInside p := by
  have hq := boundaryFree_of_close hp hclose
  let r : ℝ → ℂ := fun t => q.eval (circle t) / p.eval (circle t)
  have hr : Continuous r :=
    (q.continuous.comp continuous_circle).div (p.continuous.comp continuous_circle)
      (fun t => hp _ (norm_circle t))
  have hrpos : ∀ t, 0 < (r t).re := fun t =>
    quotient_re_pos_of_close hp hclose _ (norm_circle t)
  have harg : Continuous (fun t => Complex.arg (r t)) := by
    apply continuous_iff_continuousAt.mpr
    intro t
    exact (Complex.continuousAt_arg (Or.inl (hrpos t))).comp hr.continuousAt
  let α : ℝ → ℝ := fun t => polynomialAngle p t + Complex.arg (r t)
  have hα : Continuous α := (continuous_polynomialAngle p (boundaryFree_roots hp)).add harg
  have hfac : ∀ t, q.eval (circle t) = p.eval (circle t) * r t := by
    intro t
    dsimp [r]
    field_simp [hp _ (norm_circle t)]
  have hpolar : ∀ t, q.eval (circle t) = (‖q.eval (circle t)‖ : ℂ) *
      Complex.exp ((α t : ℂ) * Complex.I) := by
    intro t
    rw [hfac t, norm_mul, Complex.ofReal_mul]
    dsimp [α]
    rw [Complex.ofReal_add, add_mul, Complex.exp_add]
    calc
      p.eval (circle t) * r t =
          ((‖p.eval (circle t)‖ : ℂ) * Complex.exp ((polynomialAngle p t : ℂ) * I)) *
          ((‖r t‖ : ℂ) * Complex.exp ((Complex.arg (r t) : ℂ) * I)) := by
        rw [← polynomial_polar p (boundaryFree_roots hp) t, Complex.norm_mul_exp_arg_mul_I]
      _ = _ := by ring
  have hi := polynomial_argument_principle (boundaryFree_ne_zero hq) (boundaryFree_roots hq)
    hα.continuousOn (fun t _ => hpolar t)
  have hend : r (2 * Real.pi) = r 0 := by simp [r]
  dsimp [α] at hi
  rw [hend] at hi
  have hpinc := polynomialAngle_increment p
  have hc : (countInside q : ℝ) = (countInside p : ℝ) := by
    have hpipos : 0 < Real.pi := Real.pi_pos
    nlinarith
  exact_mod_cast hc

theorem gain_eval_sub (H N : Polynomial ℂ) (k k₀ : ℝ) (z : ℂ) :
    (gainPolynomial H N k).eval z - (gainPolynomial H N k₀).eval z =
      ((k - k₀ : ℝ) : ℂ) * N.eval z := by
  simp only [gainPolynomial, eval_add, eval_mul, eval_C, Complex.ofReal_sub]
  ring

/-- Compactness of the circle provides an actual open gain neighborhood on
which both boundary-freeness and the root count persist. -/
theorem local_gain_count (H N : Polynomial ℂ) {k₀ : ℝ}
    (hp : BoundaryFree (gainPolynomial H N k₀)) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℝ, |k - k₀| < ε →
      BoundaryFree (gainPolynomial H N k) ∧
      countInside (gainPolynomial H N k) = countInside (gainPolynomial H N k₀) := by
  let p := gainPolynomial H N k₀
  have hs : IsCompact (Metric.sphere (0 : ℂ) 1) := isCompact_sphere _ _
  have hne : (Metric.sphere (0 : ℂ) 1).Nonempty := ⟨1, by simp⟩
  obtain ⟨z₀, hz₀, hmin⟩ := hs.exists_isMinOn hne p.continuous.norm.continuousOn
  have hz₀norm : ‖z₀‖ = 1 := by simpa using hz₀
  have hm : 0 < ‖p.eval z₀‖ := norm_pos_iff.mpr (hp z₀ hz₀norm)
  obtain ⟨M₀, hM₀⟩ := hs.exists_bound_of_continuousOn N.continuous.continuousOn
  let M := max 1 M₀
  have hM : 0 < M + 1 := by dsimp [M]; linarith [le_max_left (1 : ℝ) M₀]
  let ε := ‖p.eval z₀‖ / (M + 1)
  have hε : 0 < ε := div_pos hm hM
  refine ⟨ε, hε, ?_⟩
  intro k hk
  have hclose : ∀ z : ℂ, ‖z‖ = 1 →
      ‖(gainPolynomial H N k).eval z - p.eval z‖ < ‖p.eval z‖ := by
    intro z hz
    have hzs : z ∈ Metric.sphere (0 : ℂ) 1 := by simpa using hz
    have hNb : ‖N.eval z‖ ≤ M + 1 := by
      have hn := hM₀ z hzs
      have hmax : M₀ ≤ M := le_max_right _ _
      linarith
    rw [gain_eval_sub, norm_mul, Complex.norm_real, Real.norm_eq_abs]
    calc
      |k - k₀| * ‖N.eval z‖ ≤ |k - k₀| * (M + 1) :=
        mul_le_mul_of_nonneg_left hNb (abs_nonneg _)
      _ < ε * (M + 1) := mul_lt_mul_of_pos_right hk hM
      _ = ‖p.eval z₀‖ := div_mul_cancel₀ _ (ne_of_gt hM)
      _ ≤ ‖p.eval z‖ := hmin hzs
  exact ⟨boundaryFree_of_close hp hclose, countInside_eq_of_close hp hclose⟩

theorem boundaryFree_gains_isOpen (H N : Polynomial ℂ) :
    IsOpen {k : ℝ | BoundaryFree (gainPolynomial H N k)} := by
  apply Metric.isOpen_iff.mpr
  intro k hk
  obtain ⟨ε, hε, he⟩ := local_gain_count H N hk
  refine ⟨ε, hε, ?_⟩
  intro l hl
  exact (he l (by simpa only [Metric.mem_ball, Real.dist_eq] using hl)).1

theorem count_locallyConstant_on (H N : Polynomial ℂ) (S : Set ℝ)
    (hS : ∀ k ∈ S, BoundaryFree (gainPolynomial H N k)) :
    IsLocallyConstant (fun k : S => countInside (gainPolynomial H N k)) := by
  apply (IsLocallyConstant.iff_eventually_eq _).mpr
  intro k
  obtain ⟨ε, hε, he⟩ := local_gain_count H N (hS k k.property)
  have ht : ∀ᶠ l : S in 𝓝 k, |(l : ℝ) - k| < ε := by
    have hc : Continuous (fun l : S => |(l : ℝ) - k|) :=
      (continuous_subtype_val.sub continuous_const).abs
    have hn : (fun l : S => |(l : ℝ) - k|) k < ε := by simpa using hε
    exact hc.continuousAt.eventually (gt_mem_nhds hn)
  filter_upwards [ht] with l hl
  exact (he l hl).2

/-- The inside-root count is constant on every preconnected gain set without
a unit-circle zero, including all connected components of the complement of
the finite candidate set. -/
theorem count_constant_on_preconnected (H N : Polynomial ℂ) {S : Set ℝ}
    (hconn : IsPreconnected S) (hS : ∀ k ∈ S, BoundaryFree (gainPolynomial H N k))
    {k l : ℝ} (hk : k ∈ S) (hl : l ∈ S) :
    countInside (gainPolynomial H N k) = countInside (gainPolynomial H N l) := by
  letI : PreconnectedSpace S := isPreconnected_iff_preconnectedSpace.mp hconn
  exact (count_locallyConstant_on H N S hS).apply_eq_of_preconnectedSpace ⟨k, hk⟩ ⟨l, hl⟩

theorem gainPolynomial_natDegree (H N : Polynomial ℂ)
    (hdeg : N.natDegree < H.natDegree) (k : ℝ) :
    (gainPolynomial H N k).natDegree = H.natDegree := by
  unfold gainPolynomial
  exact natDegree_add_eq_left_of_natDegree_lt ((natDegree_C_mul_le _ _).trans_lt hdeg)

theorem schur_iff_insideCount_degree {p : Polynomial ℂ} (hp : BoundaryFree p) :
    C2.NGamma.PolynomialModel.SchurStable p ↔ countInside p = p.natDegree := by
  rw [schur_iff_countOutside_zero (boundaryFree_ne_zero hp) (boundaryFree_roots hp)]
  have hc := count_partition p (boundaryFree_roots hp)
  omega

theorem schur_constant_on_preconnected (H N : Polynomial ℂ)
    (hdeg : N.natDegree < H.natDegree) {S : Set ℝ} (hconn : IsPreconnected S)
    (hS : ∀ k ∈ S, BoundaryFree (gainPolynomial H N k))
    {k l : ℝ} (hk : k ∈ S) (hl : l ∈ S) :
    C2.NGamma.PolynomialModel.SchurStable (gainPolynomial H N k) ↔
      C2.NGamma.PolynomialModel.SchurStable (gainPolynomial H N l) := by
  rw [schur_iff_insideCount_degree (hS k hk), schur_iff_insideCount_degree (hS l hl),
    gainPolynomial_natDegree H N hdeg k, gainPolynomial_natDegree H N hdeg l,
    count_constant_on_preconnected H N hconn hS hk hl]

theorem boundaryFree_of_schur {p : Polynomial ℂ}
    (hs : C2.NGamma.PolynomialModel.SchurStable p) : BoundaryFree p := by
  intro z hz he
  have hlt := hs z he
  rw [hz] at hlt
  exact (lt_irrefl (1 : ℝ)) hlt

theorem schur_gains_isOpen (H N : Polynomial ℂ)
    (hdeg : N.natDegree < H.natDegree) :
    IsOpen {k : ℝ | C2.NGamma.PolynomialModel.SchurStable (gainPolynomial H N k)} := by
  apply Metric.isOpen_iff.mpr
  intro k hk
  have hkfree := boundaryFree_of_schur hk
  obtain ⟨ε, hε, he⟩ := local_gain_count H N hkfree
  refine ⟨ε, hε, ?_⟩
  intro l hl
  obtain ⟨hlfree, hc⟩ := he l (by simpa only [Metric.mem_ball, Real.dist_eq] using hl)
  change C2.NGamma.PolynomialModel.SchurStable (gainPolynomial H N l)
  rw [schur_iff_insideCount_degree hlfree, hc, gainPolynomial_natDegree H N hdeg l]
  have hkcount := (schur_iff_insideCount_degree hkfree).mp hk
  simpa only [gainPolynomial_natDegree H N hdeg k] using hkcount

theorem boundary_point_not_schur (p : Polynomial ℂ)
    (h : ∃ z : ℂ, ‖z‖ = 1 ∧ p.eval z = 0) :
    ¬ C2.NGamma.PolynomialModel.SchurStable p := by
  rintro hs
  obtain ⟨z, hz, he⟩ := h
  have hn := hs z he
  rw [hz] at hn
  exact (lt_irrefl (1 : ℝ)) hn

end C2.GeneralBoundary
