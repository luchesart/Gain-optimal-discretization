import C2.CADIsolationMesh
import C2.CADFactorSquarefree

/-! Completeness and separation of root points and open isolating cells.
The selectors use only exact rational evaluations. -/
namespace C2.CADIsolation
open Polynomial Set

theorem gridPoint_strictMono {a b : ℚ} (hab : a < b) (n : ℕ) :
    StrictMono (gridPoint a b n) := by
  intro i j hij
  dsimp [gridPoint]
  exact add_lt_add_left (div_lt_div_of_pos_right
    (mul_lt_mul_of_pos_left (by exact_mod_cast hij) (sub_pos.mpr hab))
    (pow_pos (by norm_num) n)) a

/-- Successive cells of a finite monotone grid cover its whole interval. -/
theorem successive_cells_cover (v : ℕ → ℝ) (hm : Monotone v) (N : ℕ)
    (hN : 0 < N) {x : ℝ} (hx : x ∈ Icc (v 0) (v N)) :
    ∃ i < N, x ∈ Icc (v i) (v (i+1)) := by
  induction N with
  | zero => omega
  | succ N ih =>
    by_cases hzero : N = 0
    · subst N
      exact ⟨0,by omega,hx⟩
    by_cases hle : x ≤ v N
    · obtain ⟨i,hi,hcell⟩ := ih (by omega) ⟨hx.1,hle⟩
      exact ⟨i,by omega,hcell⟩
    · exact ⟨N,Nat.lt_succ_self N,⟨(lt_of_not_ge hle).le,hx.2⟩⟩

theorem grid_cells_cover {a b : ℚ} (hab : a ≤ b) (n : ℕ) {x : ℝ}
    (hx : x ∈ Icc (a:ℝ) (b:ℝ)) :
    ∃ i < 2^n, x ∈ Icc (gridPoint a b n i:ℝ) (gridPoint a b n (i+1):ℝ) := by
  apply successive_cells_cover (fun i => (gridPoint a b n i:ℝ))
    (fun i j hij => by
      change (gridPoint a b n i:ℝ) ≤ (gridPoint a b n j:ℝ)
      exact_mod_cast gridPoint_mono hab n hij) (2^n) (by positivity)
  simpa using hx

/-- Exact endpoint sign tests characterize open-cell roots after certification. -/
theorem root_in_cell_iff_crossing (p : ℚ[X]) {a b l u : ℚ}
    (hal : a ≤ l) (hlu : l < u) (hub : u ≤ b)
    (ht : certifiedCell p a b l u) :
    (∃ x ∈ Ioo (l:ℝ) (u:ℝ), realEval p x = 0) ↔ p.eval l * p.eval u < 0 := by
  have hlu' : (l:ℝ) < (u:ℝ) := by exact_mod_cast hlu
  constructor
  · rintro ⟨x,hx,hpx⟩
    rcases ht with hz | hm
    · exact (zeroFreeTest_sound p hal hlu.le hub hz x ⟨hx.1.le,hx.2.le⟩ hpx).elim
    · have hp : realEval p (l:ℝ) * realEval p (u:ℝ) < 0 := by
        rcases monotoneTest_sound p hal hlu.le hub hm with h | h
        · have hl := h (left_mem_Icc.mpr hlu'.le) ⟨hx.1.le,hx.2.le⟩ hx.1
          have hu := h ⟨hx.1.le,hx.2.le⟩ (right_mem_Icc.mpr hlu'.le) hx.2
          rw [hpx] at hl hu
          exact mul_neg_of_neg_of_pos hl hu
        · have hl := h (left_mem_Icc.mpr hlu'.le) ⟨hx.1.le,hx.2.le⟩ hx.1
          have hu := h ⟨hx.1.le,hx.2.le⟩ (right_mem_Icc.mpr hlu'.le) hx.2
          rw [hpx] at hl hu
          exact mul_neg_of_pos_of_neg hl hu
      rw [realEval_rat,realEval_rat] at hp
      exact_mod_cast hp
  · intro hp
    have hp' : realEval p (l:ℝ) * realEval p (u:ℝ) < 0 := by
      rw [realEval_rat,realEval_rat]
      exact_mod_cast hp
    have hcont : ContinuousOn (realEval p) (Icc (l:ℝ) (u:ℝ)) := (realEval_continuous p).continuousOn
    have hroot : ∃ x ∈ Icc (l:ℝ) (u:ℝ), realEval p x = 0 := by
      rcases mul_neg_iff.mp hp' with h | h
      · exact intermediate_value_Icc' hlu'.le hcont ⟨h.2.le,h.1.le⟩
      · exact intermediate_value_Icc hlu'.le hcont ⟨h.1.le,h.2.le⟩
    obtain ⟨x,hx,hpx⟩ := hroot
    refine ⟨x,⟨?_,?_⟩,hpx⟩
    · by_contra hn
      have he : x = (l:ℝ) := le_antisymm (not_lt.mp hn) hx.1
      rw [he] at hpx
      rw [hpx,zero_mul] at hp'
      exact (lt_irrefl 0) hp'
    · by_contra hn
      have he : x = (u:ℝ) := le_antisymm hx.2 (not_lt.mp hn)
      rw [he] at hpx
      rw [hpx,mul_zero] at hp'
      exact (lt_irrefl 0) hp'

/-- A selected open cell isolates exactly one distinct real root. -/
theorem selected_cell_unique_root (p : ℚ[X]) {a b l u : ℚ}
    (hal : a ≤ l) (hlu : l < u) (hub : u ≤ b)
    (ht : certifiedCell p a b l u) (hp : p.eval l*p.eval u < 0) :
    ∃! x, x ∈ Ioo (l:ℝ) (u:ℝ) ∧ realEval p x = 0 := by
  obtain ⟨x,hx,hpx⟩ := (root_in_cell_iff_crossing p hal hlu hub ht).mpr hp
  refine ⟨x,⟨hx,hpx⟩,fun y hy => ?_⟩
  exact certifiedCell_at_most_one p hal hlu.le hub ht
    ⟨hy.1.1.le,hy.1.2.le⟩ ⟨hx.1.le,hx.2.le⟩ hy.2 hpx

/-- Output selectors: rational root points and intervals with opposite signs. -/
noncomputable def selectedPoint (p : ℚ[X]) (a b : ℚ) (n j : ℕ) : Prop :=
  j ≤ 2^n ∧ p.eval (gridPoint a b n j) = 0

noncomputable def selectedInterval (p : ℚ[X]) (a b : ℚ) (n i : ℕ) : Prop :=
  i < 2^n ∧ p.eval (gridPoint a b n i) * p.eval (gridPoint a b n (i+1)) < 0

/-- Every real root in the target interval occurs in the finite output. -/
theorem certifiedMesh_covers_roots (p : ℚ[X]) {a b : ℚ} (hab : a < b)
    {n : ℕ} (hm : certifiedMesh p a b n) {x : ℝ}
    (hx : x ∈ Icc (a:ℝ) (b:ℝ)) (hpx : realEval p x = 0) :
    (∃ j, selectedPoint p a b n j ∧ x = (gridPoint a b n j:ℝ)) ∨
    (∃ i, selectedInterval p a b n i ∧
      x ∈ Ioo (gridPoint a b n i:ℝ) (gridPoint a b n (i+1):ℝ)) := by
  obtain ⟨i,hi,hcell⟩ := grid_cells_cover hab.le n hx
  by_cases hl : x = (gridPoint a b n i:ℝ)
  · left
    refine ⟨i,⟨hi.le,?_⟩,hl⟩
    rw [hl,realEval_rat] at hpx
    exact_mod_cast hpx
  by_cases hu : x = (gridPoint a b n (i+1):ℝ)
  · left
    refine ⟨i+1,⟨Nat.succ_le_iff.mpr hi,?_⟩,hu⟩
    rw [hu,realEval_rat] at hpx
    exact_mod_cast hpx
  · right
    have hxopen : x ∈ Ioo (gridPoint a b n i:ℝ) (gridPoint a b n (i+1):ℝ) :=
      ⟨lt_of_le_of_ne hcell.1 (Ne.symm hl),lt_of_le_of_ne hcell.2 hu⟩
    have hb := grid_cell_bounds hab.le hi
    refine ⟨i,⟨hi,?_⟩,hxopen⟩
    apply (root_in_cell_iff_crossing p hb.1 (gridPoint_strictMono hab n (Nat.lt_succ_self i))
      hb.2.2 (hm i (Finset.mem_range.mpr hi))).mp
    exact ⟨x,hxopen,hpx⟩

/-- Distinct open output cells are disjoint; root points are handled separately. -/
theorem grid_open_cells_disjoint {a b : ℚ} (hab : a ≤ b) (n : ℕ) {i j : ℕ}
    (hij : i < j) :
    Disjoint (Ioo (gridPoint a b n i:ℝ) (gridPoint a b n (i+1):ℝ))
      (Ioo (gridPoint a b n j:ℝ) (gridPoint a b n (j+1):ℝ)) := by
  rw [Set.disjoint_left]
  intro x hi hj
  have h : (gridPoint a b n (i+1):ℝ) ≤ (gridPoint a b n j:ℝ) := by
    exact_mod_cast gridPoint_mono hab n (Nat.succ_le_iff.mpr hij)
  linarith [hi.2,hj.1]

/-- Square-free reduction supplies the simple-root hypothesis without losing
any real root, including roots of even multiplicity in the original input. -/
theorem squarefree_reduction_isolatable (p : ℚ[X]) (hp : p ≠ 0)
    {a b : ℚ} (hab : a ≤ b) :
    (∀ x : ℝ, realEval (C2.CADFactor.squarefreePart p) x = 0 ↔ realEval p x = 0) ∧
    ∃ n, certifiedMesh (C2.CADFactor.squarefreePart p) a b n := by
  classical
  constructor
  · intro x
    exact C2.CADFactor.squarefreePart_eval₂_zero_iff (algebraMap ℚ ℝ) hp x
  · apply exists_certifiedMesh _ hab
    intro x hx
    by_cases hz : realEval (C2.CADFactor.squarefreePart p) x = 0
    · right
      exact (C2.CADFactor.squarefreePart_separable hp).eval₂_derivative_ne_zero
        (algebraMap ℚ ℝ) hz
    · exact Or.inl hz

/-- A selected rational point is an actual target-interval root. -/
theorem selectedPoint_sound (p : ℚ[X]) {a b : ℚ} (hab : a ≤ b)
    {n j : ℕ} (hp : selectedPoint p a b n j) :
    (gridPoint a b n j:ℝ) ∈ Icc (a:ℝ) (b:ℝ) ∧
      realEval p (gridPoint a b n j:ℝ) = 0 := by
  refine ⟨?_,?_⟩
  · have h := gridPoint_mem hab hp.1
    exact ⟨by exact_mod_cast h.1,by exact_mod_cast h.2⟩
  · rw [realEval_rat,hp.2]
    norm_num

/-- A selected mesh interval has exactly one real root in its open interior. -/
theorem selectedInterval_sound (p : ℚ[X]) {a b : ℚ} (hab : a < b)
    {n i : ℕ} (hm : certifiedMesh p a b n) (hi : selectedInterval p a b n i) :
    ∃! x, x ∈ Ioo (gridPoint a b n i:ℝ) (gridPoint a b n (i+1):ℝ) ∧
      realEval p x = 0 := by
  have hb := grid_cell_bounds hab.le hi.1
  exact selected_cell_unique_root p hb.1
    (gridPoint_strictMono hab n (Nat.lt_succ_self i)) hb.2.2
    (hm i (Finset.mem_range.mpr hi.1)) hi.2

/-- A grid point never lies in an open grid cell; hence point outputs cannot
represent the same root as any selected interval output. -/
theorem gridPoint_not_in_open_cell {a b : ℚ} (hab : a ≤ b) (n i j : ℕ) :
    (gridPoint a b n j:ℝ) ∉
      Ioo (gridPoint a b n i:ℝ) (gridPoint a b n (i+1):ℝ) := by
  intro hj
  by_cases hji : j ≤ i
  · have h : (gridPoint a b n j:ℝ) ≤ (gridPoint a b n i:ℝ) := by
      exact_mod_cast gridPoint_mono hab n hji
    exact (not_lt_of_ge h) hj.1
  · have h : (gridPoint a b n (i+1):ℝ) ≤ (gridPoint a b n j:ℝ) := by
      exact_mod_cast gridPoint_mono hab n (by omega : i+1 ≤ j)
    exact (not_lt_of_ge h) hj.2

end C2.CADIsolation
