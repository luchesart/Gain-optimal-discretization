import C2.FirstOrder

namespace C2.FirstOrder

theorem γStar_gt_half {r : ℝ} (hr : 0 ≤ r) : 1 / 2 < γStar r := by
  have hs := (sqrt_param hr).1
  unfold γStar
  have hp : 0 < 1 / (2 * (1 + Real.sqrt (1 + r))) := by positivity
  linarith

theorem γStar_lt_three_quarters {r : ℝ} (hr : 0 < r) : γStar r < 3 / 4 := by
  have h := γStar_strict_decrease (le_refl 0) hr
  simpa only [integrator_γStar] using h

theorem γStar_hasDerivAt {r : ℝ} (hr : 0 ≤ r) :
    HasDerivAt γStar
      (-1 / (4 * Real.sqrt (1 + r) * (1 + Real.sqrt (1 + r)) ^ 2)) r := by
  have hu := (sqrt_param hr).1
  have hbase : HasDerivAt (fun x : ℝ => 1 + x) 1 r :=
    (hasDerivAt_id r).const_add 1
  have hs := hbase.sqrt (show 1 + r ≠ 0 by linarith)
  have hd := (hs.const_add 1).const_mul 2
  have hn : 2 * (1 + Real.sqrt (1 + r)) ≠ 0 := by nlinarith
  have hi := hd.inv hn
  have hf := hi.const_add (1 / 2 : ℝ)
  convert hf using 1
  · ext x
    simp only [γStar, one_div]
  · field_simp
    <;> ring

theorem γStar_derivative {r : ℝ} (hr : 0 ≤ r) :
    deriv γStar r =
      -1 / (4 * Real.sqrt (1 + r) * (1 + Real.sqrt (1 + r)) ^ 2) :=
  (γStar_hasDerivAt hr).deriv

theorem γStar_derivative_negative {r : ℝ} (hr : 0 ≤ r) :
    deriv γStar r < 0 := by
  rw [γStar_derivative hr]
  have hu := (sqrt_param hr).1
  apply div_neg_of_neg_of_pos (by norm_num)
  positivity

theorem γStar_tendsto_half :
    Filter.Tendsto γStar Filter.atTop (nhds (1 / 2 : ℝ)) := by
  have ht : Filter.Tendsto (fun r : ℝ => 2 * (1 + Real.sqrt (1 + r)))
      Filter.atTop Filter.atTop := by
    apply Filter.tendsto_atTop.2
    intro b
    filter_upwards [Filter.eventually_ge_atTop ((max b 0) ^ 2)] with x hx
    have hx0 : 0 ≤ x := le_trans (sq_nonneg _) hx
    have hs : (Real.sqrt (1 + x)) ^ 2 = 1 + x := Real.sq_sqrt (by linarith)
    have hm : max b 0 ≤ Real.sqrt (1 + x) := by
      apply (sq_le_sq₀ (le_max_right b 0) (Real.sqrt_nonneg _)).1
      linarith
    nlinarith [le_max_left b 0, Real.sqrt_nonneg (1 + x)]
  have hi := (tendsto_inv_atTop_zero (𝕜 := ℝ)).comp ht
  have hf := Filter.Tendsto.add (tendsto_const_nhds (x := (1 / 2 : ℝ))) hi
  change Filter.Tendsto (fun r : ℝ => 1 / 2 + 1 / (2 * (1 + Real.sqrt (1 + r)))) _ _
  simpa only [Function.comp_apply, one_div, add_zero] using hf

end C2.FirstOrder
