# C2: exact remaining scope of the gain-projection theorem

Audit date: 9 November 2026. Target: `thm:exact-gain-projection` in
`general_gain_projection.tex`. Environment: Lean 4.19.0, mathlib commit
`c44e0c8ee63ca166450922a373c7409c5d26b00b`. The checked mathlib checkout has
no tracked source changes. This is an audit of the pinned project, not a
statement about later mathlib releases or other formal libraries.

**The theorem remains PARTIAL.** The uniform gain bound, openness,
exceptional-fiber omission, and rational interior-witness arguments are proved.
The prescribed polynomial projection and lifting procedure is not yet defined
and verified in Lean. Existing classical algebra APIs provide several useful
ingredients, but they do not supply the missing CAD correctness theorem or
the executable root-isolation/factorization algorithms.

## Exact theorem that must eventually be checked

The input is a finite family of rational bivariate polynomials
`f_i(gamma,k)`, whose strict positivity is assumed to be an exact Schur
description on `0 <= gamma <= 1`, together with the proved gain bound. The
output is either an emptiness conclusion or the largest right endpoint of
a marked gain cell. The required conclusion is that this endpoint is the
supremum over **all** positive stabilizing gains, including disconnected
components, and is real algebraic.

The stated procedure factors the input and endpoint polynomials, constructs
leading coefficients, discriminants and pairwise resultants, isolates their
gain roots, chooses rational gain samples, isolates the specialized parameter
roots, and tests signs at rational parameter samples. Correctness must cover
zero inequalities, constants, gain-only factors, multiple or coincident
projection roots, parameter endpoints, and omitted exceptional fibers.

The input assumption that the `f_i` give an exact Schur description is already
part of the numbered theorem. Proving a general strict Schur-recursion
implementation from `A,B,T,m` would additionally be required for a verified
end-to-end program starting directly from a plant. It is not legitimate to
count that upstream implementation as proved here, but it need not be added
as a new obligation of a theorem that explicitly takes the exact description
as input.

## Auxiliary-bound clarification found during this audit

The prior wording allowed “let `K` be a strict uniform bound” without spelling
out the arithmetic type. Yet step 2 includes `k-K` among rational projection
polynomials. An arbitrary real `K` is insufficient for that operation.

The corrected manuscript now uses the already supplied integer
`K = ceil(K0)+1` from `prop:explicit-uniform-gain-bound`. This makes `k-K`
rational and retains the proved stronger separation
`stable gain <= K0 < K`.

The prior proof sentence “the strict uniform bound places the supremum below K”
also needed that separation: merely proving every feasible gain `k<K` only
implies `sup <= K`. The corrected sentence uses `k<=K0<K` to obtain
`sup<=K0<K` in the nonempty case. The right-endpoint rule itself would allow
`sup=K`; however, the supplied Python implementation explicitly rejects that
case, so the stronger bound is the appropriate convention for this project.
This clarification specializes the auxiliary bound to the one already
constructed; it does not weaken the optimization conclusion.

No further error in the four mathematical CAD steps was confirmed by this
audit. The remaining issue is their missing formal verification.

## What is already proved

| Stage | Checked declarations | Exact coverage |
|---|---|---|
| Uniform search bound | `C2.GeneralCompletion.uniform_gain_bound`, `exists_paper_node`, `strict_search_bound` | Actual complex-root coefficient bounds, the prescribed nonvanishing negative node, symbolic coefficient one-norm envelopes, `k<=K0`, and `k<ceil(K0)+1`. |
| Open gain projection | `C2.GainProjection.feasibleGains_isOpen`, `polynomial_feasibleGains_isOpen` | Projection of finitely many strict inequalities is open; witnesses at the closed parameter endpoints are allowed. |
| Finite exceptional fibers | `upperBounds_diff_finite`, `isLUB_diff_finite_iff`, `diff_finite_nonempty_iff`, `feasibleGains_isLUB_iff` | Removing a specified finite set preserves all upper bounds, least-upper-bound assertions, and emptiness/nonemptiness of an open gain set. |
| Parameter endpoint handling | `C2.GainProjection.exists_rational_interior_witness`, `feasibleGains_iff_rational_interior` | Strict feasibility at any `gamma` in `[0,1]` implies feasibility at some rational `gamma` in `(0,1)`. |
| Fixed-parameter boundaries | `C2.GeneralBoundaryCandidates.complete_fixed_parameter_decomposition` | For fixed real `H,N`, the explicit finite Chebyshev/endpoints set equals the positive unit-root gains; root multiplicity counts and Schur status are constant on every preconnected subset of its complement. This is a separate, completed theorem. |

None of these statements assumes that a CAD algorithm has returned a correct
partition. None by itself constructs such a partition. In particular, the
finite set of exceptional gains used by `isLUB_diff_finite_iff` is a parameter
of that theorem, not the output of a verified projection operation.

## Existing mathlib APIs: what they can and cannot provide

The positive API inventory below was checked against declarations in the
pinned mathlib source. It is a source-level availability audit, not an
additional compiled C2 theorem or a claim that these ingredients already
compose into CAD correctness. A redundant read-only import/type-check job
was stopped during project integration; its unfinished optional script and
log are not included as validation evidence.

| Needed ingredient | Present in the pinned checkout | Remaining distinction |
|---|---|---|
| Finite irreducible factorization | `Polynomial.uniqueFactorizationMonoid`, the corresponding multivariate instance, `UniqueFactorizationMonoid.normalizedFactors`, `UniqueFactorizationMonoid.prod_normalizedFactors`, `UniqueFactorizationMonoid.prime_of_normalized_factor` | Gives classical existence and algebraic correctness of finite normalized factors. `normalizedFactors` is explicitly noncomputable. This is not an executable factorization routine over `Q[gamma,k]` with termination proof. |
| Passage to `Q(k)[gamma]` | `Polynomial.IsPrimitive.irreducible_iff_irreducible_map_fraction_map` in `RingTheory/Polynomial/GaussLemma.lean` | Can support the required primitive-factor/Gauss argument. The concrete CAD factor list, content handling, and distinctness up to units over the fraction field are not assembled in C2. |
| Square-freeness in characteristic zero | `Irreducible.separable`, `Polynomial.separable_def`, `Polynomial.Separable.eval₂_derivative_ne_zero` | Provides coprimeness with the derivative and simple-root consequences for an irreducible polynomial over a characteristic-zero field. It does not identify the exceptional parameter values at which specialization loses those properties. |
| Finite root sets and bounds | `Polynomial.roots`, `finite_setOf_isRoot`, `Polynomial.IsRoot.norm_lt_cauchyBound` | Gives abstract roots, finiteness, and a root bound. `Polynomial.roots` is explicitly noncomputable. There is no verified sorted rational isolating-interval output here. |
| Algebraic endpoints | `IsAlgebraic` and the existing algebraic-element/minimal-polynomial theory | A returned endpoint would be algebraic once it is proved to be a zero of a nonzero rational projection polynomial. This does not prove that the optimizer is such an endpoint. |
| Rational witnesses | `exists_rat_btwn` and C2's rational-interior theorem | Proves existence; does not verify the Python approximation/refinement loop or supply the missing gain-cell decomposition. |
| Local root continuation | Scalar inverse-function APIs, including `HasStrictDerivAt.localInverse` and `to_localInverse` | Useful at an already established simple root. A global ordered family of all real roots over an entire projection-free interval still needs a new proof. |

Search of the entire pinned `Mathlib` tree found no general polynomial
resultant/Sylvester-resultant API, no arbitrary-degree polynomial
discriminant API, and no CAD/delineability, real-closed-field quantifier
elimination, Sturm root-isolation, or verified real-algebraic isolator library
that closes the present obligation. The search covered names and descriptions
containing `resultant`, `Sylvester`, `discriminant`, `delineab`,
`semialgebraic`, `RealClosed`, `RealClosure`, `Sturm`, and root-isolation terms.

There **are** quadratic discriminants and basis/number-field discriminants.
For example, `RingTheory/Discriminant.lean` defines the trace-pairing
discriminant `Algebra.discr`; this is not the polynomial discriminant in
`Q[k]` used by the CAD projection. Likewise Sylvester's law of inertia is
unrelated to a Sylvester resultant matrix. These similarly named APIs cannot
be substituted for the missing statements.

## Minimal remaining obligations

The following is a concrete one-parameter projection development. It need
not formalize arbitrary-dimensional CAD.

1. **Fix the exact bivariate representation and factor specification.**
   Use, for example, `Polynomial (Polynomial Q)`, with outer variable gamma
   and coefficient variable k. Define both evaluations and their commuting
   identities. Define the finite factor basis including gamma and gamma-1,
   preserve the original polynomial signs through their factorizations, and
   distinguish zero inequalities, units/constants, and gain-only factors.
   Existing UFD/Gauss APIs can discharge much of the *classical algebraic*
   factor specification. They do not establish an executable factorizer.

2. **Define and verify projection polynomials.**
   A determinant of a Sylvester matrix is finite arithmetic, but its required
   properties must be proved: specialization/base-change, the common-root
   criterion when degrees are preserved, and nonvanishing for coprime factors
   over `Q(k)`. Define the polynomial discriminant, or prove an equivalent
   derivative-resultant formulation has the same excluded roots once leading
   coefficients are included. Connect irreducibility, primitivity and
   characteristic-zero separability to nonzero projection polynomials.

3. **Prove regularity over every projection-free gain interval.**
   Establish fixed gamma degrees, simple specialized roots, disjoint roots
   between different factors, and no endpoint incidences with 0 or 1. The
   projection definition, rather than an assumption of regularity, must imply
   these facts.

4. **Prove one-parameter delineability and cell sign invariance.**
   Show that all real gamma roots over such an interval are finitely many
   continuous ordered sections, with no unaccounted roots. Local inverse
   theorems alone do not give completeness or continuation to the whole
   interval. Degree preservation, root bounds on compact subintervals,
   noncollision, and the endpoint factors supply a possible proof route.
   Then prove each original `f_i` has constant sign in every intervening open
   cell and hence feasible-gamma existence is constant across the gain cell.
   This is the central missing mathematical correctness bridge.

5. **Provide verified finite root isolation and samples.**
   For univariate rational polynomials, specify a terminating procedure that
   returns all distinct real roots in a rational interval, in order, with
   disjoint rational isolating intervals or equivalent exact representations.
   Multiplicities must not cause missing cuts. A possible new route is a
   signed remainder/Sturm sequence with a proved variation-count theorem,
   a root bound, and dyadic refinement with a termination proof. Produce a
   rational sample between adjacent roots from the isolators, and prove the
   rational polynomial sign tests used during lifting are exact.

   A full general-purpose algebraic-number arithmetic package is **not** a
   minimal requirement here. Gain samples are rational, so each lifted gamma
   polynomial is rational; the sign tests are at rational gamma values.
   Sorted isolators for roots of rational polynomials, rational samples, and
   an exact representation of the final root endpoint suffice. This narrower
   interface is enough for the manuscript procedure.

6. **Connect the finite operations to the returned supremum.**
   Define the marked-cell output and prove that a sample marks precisely the
   feasible gain cells, using step 4 and the verified lifting operations.
   Combine with the already proved finite-exception and endpoint-witness
   lemmas to handle omitted fibers and emptiness. Prove that the largest right
   endpoint exists exactly in the nonempty case, is the actual least upper
   bound of all positive stabilizing gains, is a root of a nonzero rational
   polynomial, and lies below the chosen integer K. Finally prove termination
   of every loop and connect the implementation output to this mathematical
   specification.

For the **literal factorization-based algorithm**, step 1 also needs a
verified effective factorization operation or a verified generator of exact
factorization data. Accepting a supplied factor list and checking its
identities can be useful for individual runs, but is not a proof that the
algorithm can always produce it. A future square-free coprime-basis algorithm
using gcds over `Q(k)` might reduce this implementation burden; that would be
a separately specified procedure requiring its own equivalence/correctness
proof, not an automatic completion of the present statement.

## Why the available shortcuts do not close the theorem

An open bounded gain set can have any prescribed real supremum: consider
`(0,a)` for an arbitrary positive real a. Openness, a uniform bound, and
omission of any finite exceptional set do not force algebraicity or a finite
rational-polynomial cell description. The projection/delineability bridge
cannot be replaced by the existing topology.

The new fixed-parameter Chebyshev construction also does not solve the
two-variable problem. It constructs a finite set after gamma is fixed;
varying gamma gives a family of such sets, whose union need not be finite.
Its root-count constancy theorem concerns actual characteristic roots on
components of that fixed gain line. It does not supply ordered real roots of
all bivariate inequality factors over gain intervals.

Finally, replacing factorization or root isolation by `Classical.choose`,
assuming sign-invariant cells, or assuming that the returned endpoint is the
supremum would remove exactly the obligations still at issue. Such a result
may be a useful conditional interface but must not receive COMPLETE status
for `thm:exact-gain-projection`.

## Independent check of the completed fixed-parameter boundary modules

The current compiled `GeneralBoundaryCandidatesChebyshev`,
`GeneralBoundaryCandidates`, and `GeneralBoundaryCandidatesDecomposition`
files were read. The construction uses the full imaginary cross product,
handles the endpoints 1 and -1, reduces lower-half-circle roots by real
coefficient conjugation, excludes zero numerator values using the no-common-
unit-root hypothesis, and filters positive gains. Finiteness uses the
nonzero Chebyshev polynomial; no converse direction drops the zero-numerator
condition. The decomposition wrapper uses actual roots counted with
multiplicity and the fixed-degree hypothesis for Schur equivalence.

No weakened root-count or merely formal-frequency substitute was found in
that numbered result. The additional compiled modules
`GeneralBoundaryGroupedCoefficients`, `GeneralBoundaryChebyshevDegree`, and
`GeneralBoundaryCandidateCardinality` now also prove literal equality to the
manuscript's grouped coefficient formula, the degree bound `L-1`, and the
candidate-point and retained-gain cardinality bound `L+1`. The declarations
are `Q_eq_groupedQ`, `differenceCoefficient_eq`, `Q_natDegree_le`, and
`candidate_cardinality_bound`, all in namespace
`C2.GeneralBoundaryCandidates`; see
`validation/general_boundaries_completion_20261109.json`. Thus no part of
the numbered fixed-parameter theorem or its displayed construction remains
open. These semantic finite-set theorems do not supply an executable
real-root isolator, nor the two-variable projection/lifting theorem required
for generic CAD.

## Status of the Python implementation

`extension_checks/general_optimizer/exact_gain_projection.py` uses SymPy
`factor_list`, `discriminant`, `resultant`, `real_roots`, and algebraic sign
queries. Its `rational_between` routine proposes witnesses by increasing
decimal precision and accepts them only after exact comparisons. Exact
acceptance supports individual accepted witnesses; it does not itself prove
termination of the refinement loop or totality of the sign routine.

The script and its example outputs remain useful computational evidence.
Neither SymPy correctness nor equivalence of those routines to Lean
definitions has been established by the present formalization. No Python
rerun or empirical example was treated as filling the missing proof.

The defensible current status is therefore: **all listed topological and
witness stages proved; generic CAD projection/lifting correctness and its
finite effective realization still open.**
