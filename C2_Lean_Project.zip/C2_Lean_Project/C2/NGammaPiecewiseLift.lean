import C2.NGammaArgumentMatch

/-! A continuous argument for a positive amplitude curve translated by a positive
real number.  The branch shift is proved at its unique amplitude crossing. -/

noncomputable section
open Set
set_option maxHeartbeats 800000
open scoped Topology

namespace C2.NGamma.ArgumentMatch

def polarCurve (B ψ : ℝ → ℝ) (t : ℝ) : ℂ :=
  (B t : ℂ)*Complex.exp ((ψ t : ℂ)*Complex.I)

def translatedAngle (B ψ : ℝ → ℝ) (b tb : ℝ) (k : ℤ) (t : ℝ) : ℝ :=
  if t ≤ tb then Complex.arg (polarCurve B ψ t+b)
  else ψ t+Complex.arg (1+(b:ℂ)/polarCurve B ψ t)-2*Real.pi*k

lemma polarCurve_norm {B ψ : ℝ → ℝ} {t : ℝ} (hB : 0 < B t) :
    ‖polarCurve B ψ t‖ = B t := by
  simp [polarCurve, norm_mul, Complex.norm_exp_ofReal_mul_I, abs_of_pos hB]

lemma polarCurve_ne_zero {B ψ : ℝ → ℝ} {t : ℝ} (hB : 0 < B t) :
    polarCurve B ψ t ≠ 0 := by
  apply norm_ne_zero_iff.mp
  rw [polarCurve_norm hB]
  exact ne_of_gt hB

lemma polarCurve_continuous {B ψ : ℝ → ℝ} (hB : Continuous B) (hψ : Continuous ψ) :
    Continuous (polarCurve B ψ) := by
  exact (Complex.continuous_ofReal.comp hB).mul
    (Complex.continuous_exp.comp ((Complex.continuous_ofReal.comp hψ).mul continuous_const))

lemma one_add_exp_re_pos {u : ℝ} (hlo : -Real.pi < u) (hhi : u < Real.pi) :
    0 < (1+Complex.exp ((u : ℂ)*Complex.I)).re := by
  have hc : 0 < Real.cos (u/2) := Real.cos_pos_of_mem_Ioo ⟨by linarith, by linarith⟩
  rw [one_add_exp_half]
  simp only [Complex.exp_mul_I, ← Complex.ofReal_cos, ← Complex.ofReal_sin]
  simp only [Complex.mul_re, Complex.add_re, Complex.ofReal_re, Complex.ofReal_im,
    Complex.I_re, Complex.I_im, mul_zero, zero_mul, add_zero, sub_zero]
  exact mul_pos (mul_pos (by norm_num) hc) hc

lemma add_re_pos_of_norm_lt {z : ℂ} {b : ℝ} (h : ‖z‖ < b) :
    0 < (z+(b:ℂ)).re := by
  have hlo := (abs_le.mp (Complex.abs_re_le_norm z)).1
  simp only [Complex.add_re, Complex.ofReal_re]
  linarith

lemma one_add_re_pos_of_norm_lt {z : ℂ} (h : ‖z‖ < 1) :
    0 < (1+z).re := by
  simpa only [add_comm] using add_re_pos_of_norm_lt h

lemma left_branch_re_pos {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    (hBp : ∀ t ∈ Ici (0:ℝ), 0 < B t) (hBm : StrictMonoOn B (Ici 0))
    (htb : 0 ≤ tb) (hBeq : B tb = b)
    (hlo : -Real.pi < ψ tb-2*Real.pi*k) (hhi : ψ tb-2*Real.pi*k < Real.pi)
    {t : ℝ} (ht : 0 ≤ t) (htt : t ≤ tb) :
    0 < (polarCurve B ψ t+b).re := by
  rcases lt_or_eq_of_le htt with hlt | heq
  · apply add_re_pos_of_norm_lt
    rw [polarCurve_norm (hBp t ht)]
    rw [← hBeq]
    exact hBm ht htb hlt
  · subst t
    have hb : 0 < b := hBeq ▸ hBp tb htb
    have hp := one_add_exp_re_pos hlo hhi
    rw [exp_sub_turns] at hp
    have he : polarCurve B ψ tb+b = (b:ℂ)*(1+Complex.exp ((ψ tb : ℂ)*Complex.I)) := by
      simp only [polarCurve, hBeq]
      ring
    rw [he]
    simpa using mul_pos hb hp

lemma right_branch_re_pos {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    (hBp : ∀ t ∈ Ici (0:ℝ), 0 < B t) (hBm : StrictMonoOn B (Ici 0))
    (htb : 0 ≤ tb) (hBeq : B tb = b)
    (hlo : -Real.pi < ψ tb-2*Real.pi*k) (hhi : ψ tb-2*Real.pi*k < Real.pi)
    {t : ℝ} (htt : tb ≤ t) :
    0 < (1+(b:ℂ)/polarCurve B ψ t).re := by
  have ht : 0 ≤ t := le_trans htb htt
  have hb : 0 < b := hBeq ▸ hBp tb htb
  rcases lt_or_eq_of_le htt with hlt | heq
  · apply one_add_re_pos_of_norm_lt
    rw [norm_div, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hb,
      polarCurve_norm (hBp t ht)]
    apply (div_lt_one (hBp t ht)).2
    rw [← hBeq]
    exact hBm htb ht hlt
  · subst t
    have hbn : (b:ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hb
    have he : (b:ℂ)/polarCurve B ψ tb = Complex.exp (-((ψ tb):ℂ)*Complex.I) := by
      rw [polarCurve, hBeq, neg_mul, Complex.exp_neg]
      field_simp
    rw [he, neg_mul, Complex.exp_neg, ← exp_sub_turns (ψ tb) k, ← Complex.exp_neg, ← neg_mul]
    convert one_add_exp_re_pos (u := -(ψ tb-2*Real.pi*k)) (by linarith) (by linarith) using 1 <;> simp only [Complex.ofReal_neg]

lemma translatedAngle_continuousOn {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    (hB : Continuous B) (hψ : Continuous ψ)
    (hBp : ∀ t ∈ Ici (0:ℝ), 0 < B t) (hBm : StrictMonoOn B (Ici 0))
    (htb : 0 ≤ tb) (hBeq : B tb = b)
    (hlo : -Real.pi < ψ tb-2*Real.pi*k) (hhi : ψ tb-2*Real.pi*k < Real.pi) :
    ContinuousOn (translatedAngle B ψ b tb k) (Ici 0) := by
  have hW := polarCurve_continuous hB hψ
  have hleft : ContinuousOn (fun t => Complex.arg (polarCurve B ψ t+b)) (Ici 0 ∩ Iic tb) := by
    intro t ht
    have hc : ContinuousWithinAt (fun u => polarCurve B ψ u + (b:ℂ)) (Ici 0 ∩ Iic tb) t :=
      (hW.add continuous_const).continuousAt.continuousWithinAt
    exact ContinuousAt.comp_continuousWithinAt (f := fun u => polarCurve B ψ u + (b:ℂ))
      (Complex.continuousAt_arg (Or.inl (left_branch_re_pos hBp hBm htb hBeq hlo hhi ht.1 ht.2))) hc
  have hright : ContinuousOn (fun t => ψ t+Complex.arg (1+(b:ℂ)/polarCurve B ψ t)-2*Real.pi*k)
      (Ici 0 ∩ Ici tb) := by
    intro t ht
    apply ContinuousWithinAt.sub _ continuousWithinAt_const
    apply hψ.continuousAt.continuousWithinAt.add
    have hc : ContinuousWithinAt (fun u => 1+(b:ℂ)/polarCurve B ψ u) (Ici 0 ∩ Ici tb) t :=
      continuousWithinAt_const.add (continuousWithinAt_const.div hW.continuousAt.continuousWithinAt
        (polarCurve_ne_zero (hBp t ht.1)))
    exact ContinuousAt.comp_continuousWithinAt (f := fun u => 1+(b:ℂ)/polarCurve B ψ u)
      (Complex.continuousAt_arg (Or.inl (right_branch_re_pos hBp hBm htb hBeq hlo hhi ht.2))) hc
  have hmatch : ∀ t ∈ Ici (0:ℝ) ∩ frontier (Iic tb),
      Complex.arg (polarCurve B ψ t+b) =
        ψ t+Complex.arg (1+(b:ℂ)/polarCurve B ψ t)-2*Real.pi*k := by
    intro t ht
    have he : t = tb := by simpa using ht.2
    subst t
    simp only [polarCurve, hBeq]
    exact amplitude_crossing_branch_match (hBeq ▸ hBp tb htb) (ψ tb) k hlo hhi
  simpa only [closure_Iic, compl_Iic, closure_Ioi, Set.piecewise, mem_Iic] using
    (ContinuousOn.piecewise (t := Iic tb) hmatch
      (by simpa only [closure_Iic] using hleft)
      (by simpa only [compl_Iic, closure_Ioi] using hright))

lemma translated_curve_ne_zero {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    (hBp : ∀ t ∈ Ici (0:ℝ), 0 < B t) (hBm : StrictMonoOn B (Ici 0))
    (htb : 0 ≤ tb) (hBeq : B tb = b)
    (hlo : -Real.pi < ψ tb-2*Real.pi*k) (hhi : ψ tb-2*Real.pi*k < Real.pi)
    {t : ℝ} (ht : 0 ≤ t) : polarCurve B ψ t+b ≠ 0 := by
  by_cases htt : t ≤ tb
  · intro hz
    have hp := left_branch_re_pos hBp hBm htb hBeq hlo hhi ht htt
    rw [hz] at hp
    exact lt_irrefl 0 hp
  · have hW := polarCurve_ne_zero (ψ := ψ) (hBp t ht)
    have hp := right_branch_re_pos hBp hBm htb hBeq hlo hhi (le_of_not_ge htt)
    intro hz
    have he : 1+(b:ℂ)/polarCurve B ψ t = 0 := by
      field_simp
      linear_combination hz
    rw [he] at hp
    exact lt_irrefl 0 hp

lemma translatedAngle_polar {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    {t : ℝ} (hBp : 0 < B t) :
    polarCurve B ψ t+b = (‖polarCurve B ψ t+b‖ : ℂ)*
      Complex.exp ((translatedAngle B ψ b tb k t : ℂ)*Complex.I) := by
  unfold translatedAngle
  split_ifs with htt
  · exact (Complex.norm_mul_exp_arg_mul_I _).symm
  · set W := polarCurve B ψ t
    set Z : ℂ := 1+(b:ℂ)/W
    have hW : W ≠ 0 := polarCurve_ne_zero hBp
    have hmul : W+b = W*Z := by dsimp [Z]; field_simp
    have hnorm : ‖W+b‖ = B t*‖Z‖ := by
      rw [hmul, norm_mul]
      exact congrArg (fun v : ℝ => v*‖Z‖) (polarCurve_norm hBp)
    rw [exp_sub_turns, Complex.ofReal_add, add_mul, Complex.exp_add, hnorm,
      Complex.ofReal_mul]
    calc
      W+b = W*Z := hmul
      _ = (B t:ℂ)*Complex.exp ((ψ t:ℂ)*Complex.I)*
          ((‖Z‖:ℂ)*Complex.exp ((Complex.arg Z:ℂ)*Complex.I)) := by
        rw [Complex.norm_mul_exp_arg_mul_I]
        rfl
      _ = _ := by ring

lemma translatedAngle_zero {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    (hB0 : 0 < B 0) (hb : 0 < b) (htb : 0 ≤ tb) (hψ0 : ψ 0 = 0) :
    translatedAngle B ψ b tb k 0 = 0 := by
  simp only [translatedAngle, htb, if_pos, polarCurve, hψ0, Complex.ofReal_zero,
    zero_mul, Complex.exp_zero, mul_one]
  have hp : 0 < B 0+b := add_pos hB0 hb
  rw [← Complex.ofReal_add]
  exact Complex.arg_ofReal_of_nonneg hp.le

lemma translatedAngle_tendsto_atTop {B ψ : ℝ → ℝ} {b tb L : ℝ} {k : ℤ}
    (hψ : Filter.Tendsto ψ Filter.atTop (𝓝 L))
    (harg : Filter.Tendsto (fun t => Complex.arg (1+(b:ℂ)/polarCurve B ψ t))
      Filter.atTop (𝓝 0)) :
    Filter.Tendsto (translatedAngle B ψ b tb k) Filter.atTop (𝓝 (L-2*Real.pi*k)) := by
  have h := (hψ.add harg).sub_const (2*Real.pi*k)
  simp only [add_zero] at h
  apply h.congr'
  filter_upwards [Filter.eventually_gt_atTop tb] with t ht
  simp only [translatedAngle, not_le.mpr ht, if_false]

end C2.NGamma.ArgumentMatch
