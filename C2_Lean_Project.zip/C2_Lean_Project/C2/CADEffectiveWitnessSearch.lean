import C2.CADEffectiveWitnessEncoding
import C2.CADEffectiveSearchExecution

/-! A total executable producer of the full finite factorization and projection
witness. Mathematical existence is used only by the erased termination proof;
the returned coefficients are decoded by an explicit finite search and checked
using rational list arithmetic. -/
namespace C2.CADEffective.Bivariate

/-- Every input polynomial is nonzero, decided by finite coefficient checks. -/
def nonzeroInputs (F : List Poly) : Bool :=
  decide (∀ i : Fin F.length, eqb (F.getD i []) [] = false)

theorem nonzeroInputs_iff (F : List Poly) : nonzeroInputs F = true ↔
    ∀ i : Fin F.length, inputFamily F i ≠ 0 := by
  simp only [nonzeroInputs, decide_eq_true_eq, inputFamily]
  apply forall_congr'
  intro i
  simpa only [Bool.not_eq_true, denote_nil] using not_congr (eqb_eq_true_iff (F.getD i []) [])

/-- The full projection-data producer uses no factorization or root oracle. -/
def produceWitness (F : List Poly) (hF : ∀ i : Fin F.length, inputFamily F i ≠ 0) : Witness :=
  C2.CADEffective.search (witnessCheck F) (exists_witnessCheck F hF)

theorem produceWitness_accepted (F : List Poly)
    (hF : ∀ i : Fin F.length, inputFamily F i ≠ 0) :
    witnessCheck F (produceWitness F hF) = true :=
  C2.CADEffective.search_accepted _ _

theorem produceWitness_correct (F : List Poly)
    (hF : ∀ i : Fin F.length, inputFamily F i ≠ 0) :
    C2.CADProjection.ValidFactorData (inputFamily F) (toFactorData F (produceWitness F hF)) ∧
    C2.CADProjection.ValidProjectionData (toFactorData F (produceWitness F hF)).factors
      (toProjectionData (produceWitness F hF)) :=
  (witnessCheck_iff F _).mp (produceWitness_accepted F hF)

/-- A concrete finite execution of the actual producer, with a natural-number
bound on its rational-data search. No external certificate is a runtime input. -/
theorem produceWitness_finite_execution (F : List Poly)
    (hF : ∀ i : Fin F.length, inputFamily F i ≠ 0) :
    ∃ fuel : ℕ, C2.CADEffective.scanFrom (witnessCheck F) 0 fuel =
      some (produceWitness F hF) := by
  exact ⟨C2.CADEffective.searchIndex (witnessCheck F) (exists_witnessCheck F hF) + 1,
    C2.CADEffective.search_finite_execution_eq _ _⟩

end C2.CADEffective.Bivariate
