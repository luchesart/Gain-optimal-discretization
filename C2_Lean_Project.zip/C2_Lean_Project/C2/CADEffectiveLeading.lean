import C2.CADEffectiveBivariate

/-! Executable coefficient selection and gamma specialization for dense
bivariate polynomials. All runtime operations are finite list/rational arithmetic. -/
namespace C2.CADEffective.Bivariate
open Polynomial

/-- Highest semantically nonzero gamma coefficient; inner zero lists may have
arbitrary trailing zeros, so they are tested with the proved dense equality test. -/
def leadingCoeff : Poly → Dense.Poly
  | [] => []
  | a :: p =>
      let b := leadingCoeff p
      if Dense.eqb b [] then a else b

/-- Horner specialization in gamma, leaving an executable gain polynomial. -/
def gammaEval : Poly → ℚ → Dense.Poly
  | [], _ => []
  | a :: p, g => Dense.add a (Dense.scale g (gammaEval p g))

@[simp] theorem denote_gammaEval (p : Poly) (g : ℚ) :
    Dense.denote (gammaEval p g) = (denote p).eval (C g) := by
  induction p with
  | nil => simp [gammaEval]
  | cons a p ih => simp [gammaEval, ih]

@[simp] theorem denote_leadingCoeff (p : Poly) :
    Dense.denote (leadingCoeff p) = (denote p).leadingCoeff := by
  induction p with
  | nil => simp [leadingCoeff]
  | cons a p ih =>
      change Dense.denote (if Dense.eqb (leadingCoeff p) [] then a else leadingCoeff p) =
        (C (Dense.denote a) + X * denote p).leadingCoeff
      split_ifs with ht
      · have he : (denote p).leadingCoeff = 0 := by
          simpa only [ih, Dense.denote_nil] using
            (Dense.eqb_eq_true_iff (leadingCoeff p) []).mp ht
        have hp : denote p = 0 := Polynomial.leadingCoeff_eq_zero.mp he
        simp [hp]
      · have hp : denote p ≠ 0 := by
          intro h
          apply ht
          apply (Dense.eqb_eq_true_iff (leadingCoeff p) []).mpr
          simp only [ih, h, Polynomial.leadingCoeff_zero, Dense.denote_nil]
        have hxp : (X * denote p : Polynomial (Polynomial ℚ)) ≠ 0 :=
          mul_ne_zero Polynomial.X_ne_zero hp
        have hd : (C (Dense.denote a) : Polynomial (Polynomial ℚ)).degree <
            (X * denote p).degree := by
          have hpos : (0 : WithBot ℕ) < (X * denote p).degree := by
            rw [Polynomial.degree_eq_natDegree hxp, Polynomial.natDegree_X_mul hp]
            exact_mod_cast Nat.succ_pos (denote p).natDegree
          exact lt_of_le_of_lt Polynomial.degree_C_le hpos
        rw [ih, Polynomial.leadingCoeff_add_of_degree_lt hd,
          Polynomial.leadingCoeff_mul, Polynomial.leadingCoeff_X, one_mul]

/-- Nonzero tests on the selected gain coefficient agree with nonzero
mathematical bivariate polynomials. -/
theorem leadingCoeff_eqb_zero_iff (p : Poly) :
    Dense.eqb (leadingCoeff p) [] = true ↔ denote p = 0 := by
  rw [Dense.eqb_eq_true_iff, denote_leadingCoeff, Dense.denote_nil,
    Polynomial.leadingCoeff_eq_zero]

/-- Endpoint gain polynomials are computed by the same Horner routine. -/
theorem gammaEval_zero (p : Poly) :
    Dense.denote (gammaEval p 0) = (denote p).eval 0 := by
  simpa using denote_gammaEval p 0

theorem gammaEval_one (p : Poly) :
    Dense.denote (gammaEval p 1) = (denote p).eval 1 := by
  simpa using denote_gammaEval p 1

end C2.CADEffective.Bivariate
