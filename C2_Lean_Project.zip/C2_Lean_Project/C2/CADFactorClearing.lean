import C2.CADFactorBasis
import C2.CADProjectionBezout

/-! Exact polynomial identities after clearing a finite factor basis.
No evaluation homomorphism from a rational-function field at a gain is used. -/
noncomputable section
open Polynomial
open scoped BigOperators
namespace C2.CADFactor

variable {R K : Type*} [CommRing R] [IsDomain R] [Field K]
  [Algebra R K] [IsFractionRing R K]

theorem exists_clear_unit_multiple (P Q : R[X]) {u : K} (hu : u ≠ 0)
    (h : P.map (algebraMap R K) = C u * Q.map (algebraMap R K)) :
    ∃ r s : R, r ≠ 0 ∧ s ≠ 0 ∧ C r * P = C s * Q := by
  obtain ⟨s,r,hr,hsr⟩ := IsFractionRing.div_surjective (A:=R) u
  have hr0 : r ≠ 0 := nonZeroDivisors.ne_zero hr
  have hrK : algebraMap R K r ≠ 0 :=
    IsFractionRing.to_map_ne_zero_of_mem_nonZeroDivisors hr
  have hs0 : s ≠ 0 := by
    intro hs
    apply hu
    rw [← hsr, hs, map_zero, zero_div]
  refine ⟨r,s,hr0,hs0,?_⟩
  apply Polynomial.map_injective (f:=algebraMap R K) (IsFractionRing.injective R K)
  simp only [Polynomial.map_mul, Polynomial.map_C]
  have he : algebraMap R K r * u = algebraMap R K s := by
    rw [← hsr]
    field_simp
  rw [h, ← mul_assoc, ← Polynomial.C_mul, he]

variable {J : Type*} [Fintype J]

/-- Clearing each factor and the scalar unit gives an actual identity over R,
with nonzero coefficient multipliers on both sides. -/
theorem exists_clear_factor_identity (P : R[X]) (q : J → K[X])
    (Q : J → R[X]) (d : J → R) (hd : ∀ j, d j ≠ 0)
    (hQ : ∀ j, (Q j).map (algebraMap R K) = C (algebraMap R K (d j)) * q j)
    (a b : ℕ) (m : J → ℕ) {u : K} (hu : u ≠ 0)
    (hP : P.map (algebraMap R K) =
      C u * X^a * (X-1)^b * ∏ j, (q j)^(m j)) :
    ∃ r s : R, r ≠ 0 ∧ s ≠ 0 ∧
      C r * P = C s * X^a * (X-1)^b * ∏ j, (Q j)^(m j) := by
  classical
  let D : R := ∏ j, d j ^ m j
  let H : K[X] := X^a * (X-1)^b * ∏ j, (q j)^(m j)
  let G : R[X] := X^a * (X-1)^b * ∏ j, (Q j)^(m j)
  have hD : D ≠ 0 := Finset.prod_ne_zero_iff.mpr (fun j _ => pow_ne_zero _ (hd j))
  have hDK : algebraMap R K D ≠ 0 := by
    simpa only [map_zero] using (IsFractionRing.injective R K).ne hD
  have hprod : (∏ j, ((Q j).map (algebraMap R K)) ^ m j) =
      C (algebraMap R K D) * ∏ j, (q j) ^ m j := by
    simp only [hQ, mul_pow, Finset.prod_mul_distrib]
    congr 1
    simp only [D, map_prod, map_pow]
  have hG : G.map (algebraMap R K) = C (algebraMap R K D) * H := by
    simp only [G, Polynomial.map_mul, Polynomial.map_pow, Polynomial.map_X,
      Polynomial.map_sub, Polynomial.map_one, Polynomial.map_prod]
    rw [hprod]
    dsimp only [H]
    ring
  have hP' : P.map (algebraMap R K) = C u * H := by
    rw [hP]
    dsimp only [H]
    ring
  have he : P.map (algebraMap R K) =
      C (u / algebraMap R K D) * G.map (algebraMap R K) := by
    have hC : C (u / algebraMap R K D) * C (algebraMap R K D) = (C u : K[X]) := by
      rw [← Polynomial.C_mul, div_mul_cancel₀ _ hDK]
    calc
      P.map (algebraMap R K) = C u * H := hP'
      _ = (C (u / algebraMap R K D) * C (algebraMap R K D)) * H := by rw [hC]
      _ = C (u / algebraMap R K D) * (C (algebraMap R K D) * H) := mul_assoc _ _ _
      _ = C (u / algebraMap R K D) * G.map (algebraMap R K) :=
        congrArg (fun z => C (u / algebraMap R K D) * z) hG.symm
  obtain ⟨r,s,hr,hs,hrs⟩ := exists_clear_unit_multiple P G (div_ne_zero hu hDK) he
  refine ⟨r,s,hr,hs,?_⟩
  simpa only [G, mul_assoc] using hrs

/-- The cleared identity specializes at every gain for which the denominator
multiplier remains nonzero. This statement uses an ordinary coefficient map. -/
theorem specialize_cleared_identity {S : Type*} [Field S]
    (e : R →+* S) (P : R[X]) (Q : J → R[X]) (a b : ℕ) (m : J → ℕ)
    {r s : R} (h : C r * P = C s * X^a * (X-1)^b * ∏ j, (Q j)^m j)
    (hr : e r ≠ 0) (x : S) :
    (P.map e).eval x = (e s / e r) * x^a * (x-1)^b *
      ∏ j, (Q j |>.map e |>.eval x)^m j := by
  have he := congrArg (fun p : R[X] => (p.map e).eval x) h
  simp only [Polynomial.map_mul, Polynomial.map_C, Polynomial.map_pow,
    Polynomial.map_X, Polynomial.map_sub, Polynomial.map_one, Polynomial.map_prod,
    Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_pow, Polynomial.eval_X,
    Polynomial.eval_sub, Polynomial.eval_one, Polynomial.eval_prod] at he
  apply (mul_left_cancel₀ hr)
  calc
    e r * (P.map e).eval x = e s * x^a * (x-1)^b *
        ∏ j, (Q j |>.map e |>.eval x)^m j := he
    _ = e r * ((e s / e r) * x^a * (x-1)^b *
        ∏ j, (Q j |>.map e |>.eval x)^m j) := by field_simp

end C2.CADFactor
