import C2.GeneralBoundaryCandidatesChebyshev
import Mathlib

/-! Exact equality of the double-sum boundary polynomial to the manuscript's
grouped coefficient construction c_q and sum c_q U_(q-1). -/
noncomputable section
open scoped BigOperators
open Polynomial

namespace C2.GeneralBoundaryCandidates

def differenceCoefficient (H N : ℝ[X]) (q : ℕ) : ℝ :=
  ∑ i ∈ H.support, ∑ j ∈ N.support,
    ((if i = j + q then H.coeff i * N.coeff j else 0) -
      (if j = i + q then H.coeff i * N.coeff j else 0))

def groupedQ (H N : ℝ[X]) (L : ℕ) : ℝ[X] :=
  ∑ q ∈ Finset.Icc 1 L,
    C (differenceCoefficient H N q) * Polynomial.Chebyshev.U ℝ ((q : ℤ) - 1)

theorem differenceCoefficient_eq (H N : ℝ[X]) (q : ℕ) :
    differenceCoefficient H N q =
      (∑ i ∈ H.support, ∑ j ∈ N.support,
        if i = j + q then H.coeff i * N.coeff j else 0) -
      (∑ i ∈ H.support, ∑ j ∈ N.support,
        if j = i + q then H.coeff i * N.coeff j else 0) := by
  simp only [differenceCoefficient, Finset.sum_sub_distrib]

theorem signed_chebyshev_grouping (h : ℝ) {i j L : ℕ} (hi : i ≤ L) (hj : j ≤ L) :
    C h * Polynomial.Chebyshev.U ℝ ((i : ℤ) - (j : ℤ) - 1) =
      ∑ q ∈ Finset.Icc 1 L,
        C ((if i = j + q then h else 0) - (if j = i + q then h else 0)) *
          Polynomial.Chebyshev.U ℝ ((q : ℤ) - 1) := by
  classical
  rcases lt_trichotomy i j with hij | hij | hij
  · have hmem : j - i ∈ Finset.Icc 1 L := by simp only [Finset.mem_Icc]; omega
    rw [Finset.sum_eq_single (j - i)]
    · have hpos : ¬ i = j + (j - i) := by omega
      have hneg : j = i + (j - i) := by omega
      have hind : (i : ℤ) - (j : ℤ) - 1 = -(((j - i : ℕ) : ℤ) - 1) - 2 := by omega
      rw [hind, Polynomial.Chebyshev.U_neg_sub_two]
      simp only [if_neg hpos, if_pos hneg, zero_sub, map_neg, mul_neg, neg_mul]
    · intro q hq hne
      have hq1 := (Finset.mem_Icc.mp hq).1
      have hpos : ¬ i = j + q := by omega
      have hneg : ¬ j = i + q := by omega
      simp [hpos, hneg]
    · exact fun hn => False.elim (hn hmem)
  · subst j
    have hzero : (∑ q ∈ Finset.Icc 1 L,
        C ((if i = i + q then h else 0) - (if i = i + q then h else 0)) *
          Polynomial.Chebyshev.U ℝ ((q : ℤ) - 1)) = 0 := by simp
    simpa using hzero.symm
  · have hmem : i - j ∈ Finset.Icc 1 L := by simp only [Finset.mem_Icc]; omega
    rw [Finset.sum_eq_single (i - j)]
    · have hpos : i = j + (i - j) := by omega
      have hneg : ¬ j = i + (i - j) := by omega
      have hind : (i : ℤ) - (j : ℤ) - 1 = ((i - j : ℕ) : ℤ) - 1 := by omega
      simp only [if_pos hpos, if_neg hneg, sub_zero, hind]
    · intro q hq hne
      have hq1 := (Finset.mem_Icc.mp hq).1
      have hpos : ¬ i = j + q := by omega
      have hneg : ¬ j = i + q := by omega
      simp [hpos, hneg]
    · exact fun hn => False.elim (hn hmem)

/-- The manuscript's c_q formula and the implemented double-sum Q are
literally equal polynomials, for every declared degree bound L. -/
theorem Q_eq_groupedQ (H N : ℝ[X]) (L : ℕ)
    (hH : H.natDegree ≤ L) (hN : N.natDegree ≤ L) : Q H N = groupedQ H N L := by
  classical
  unfold Q groupedQ differenceCoefficient
  simp only [map_sum, Finset.sum_mul]
  calc
    (∑ i ∈ H.support, ∑ j ∈ N.support,
        C (H.coeff i * N.coeff j) * Polynomial.Chebyshev.U ℝ ((i : ℤ) - (j : ℤ) - 1)) =
      ∑ i ∈ H.support, ∑ j ∈ N.support, ∑ q ∈ Finset.Icc 1 L,
        C ((if i = j + q then H.coeff i * N.coeff j else 0) -
          (if j = i + q then H.coeff i * N.coeff j else 0)) *
            Polynomial.Chebyshev.U ℝ ((q : ℤ) - 1) := by
      apply Finset.sum_congr rfl
      intro i hi
      apply Finset.sum_congr rfl
      intro j hj
      exact signed_chebyshev_grouping _ ((le_natDegree_of_mem_supp i hi).trans hH)
        ((le_natDegree_of_mem_supp j hj).trans hN)
    _ = ∑ i ∈ H.support, ∑ q ∈ Finset.Icc 1 L, ∑ j ∈ N.support,
        C ((if i = j + q then H.coeff i * N.coeff j else 0) -
          (if j = i + q then H.coeff i * N.coeff j else 0)) *
            Polynomial.Chebyshev.U ℝ ((q : ℤ) - 1) := by
      apply Finset.sum_congr rfl
      intro i hi
      rw [Finset.sum_comm]
    _ = _ := by rw [Finset.sum_comm]

end C2.GeneralBoundaryCandidates
