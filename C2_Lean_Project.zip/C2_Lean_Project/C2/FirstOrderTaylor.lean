import C2.FirstOrder

namespace C2.FirstOrder

/-- Explicit global remainder bounds imply the stated right-sided Taylor
orders at the integrator limit.  The bounds are stronger than an unspecified
big-O constant and are valid for every r >= 0. -/
theorem param_γ_remainder_bounds {u : ℝ} (hu : 1 ≤ u) :
    0 ≤ γParam u - 3 / 4 + (u ^ 2 - 1) / 16 ∧
      γParam u - 3 / 4 + (u ^ 2 - 1) / 16 ≤ (u ^ 2 - 1) ^ 2 / 32 := by
  have hn : u + 1 ≠ 0 := by linarith
  have hid : γParam u - 3 / 4 + (u ^ 2 - 1) / 16 =
      (u - 1) ^ 2 * (u + 3) / (16 * (u + 1)) := by
    unfold γParam
    field_simp [hn]
    <;> ring
  have hdiff : (u ^ 2 - 1) ^ 2 / 32 -
      (γParam u - 3 / 4 + (u ^ 2 - 1) / 16) =
      (u - 1) ^ 3 * (u ^ 2 + 4 * u + 5) / (32 * (u + 1)) := by
    unfold γParam
    field_simp [hn]
    <;> ring
  have hp : 0 ≤ (u - 1) ^ 3 * (u ^ 2 + 4 * u + 5) / (32 * (u + 1)) := by
    apply div_nonneg
    · apply mul_nonneg (pow_nonneg (by linarith) _)
      nlinarith [sq_nonneg u]
    · linarith
  constructor
  · rw [hid]
    apply div_nonneg
    · exact mul_nonneg (sq_nonneg _) (by linarith)
    · linarith
  · linarith [hdiff]

theorem param_a_remainder_bounds {u : ℝ} (hu : 1 ≤ u) :
    0 ≤ aParam u - (4 + 2 * (u ^ 2 - 1) - (u ^ 2 - 1) ^ 2 / 4) ∧
      aParam u - (4 + 2 * (u ^ 2 - 1) - (u ^ 2 - 1) ^ 2 / 4) ≤
        (u ^ 2 - 1) ^ 3 / 8 := by
  have hid : aParam u - (4 + 2 * (u ^ 2 - 1) - (u ^ 2 - 1) ^ 2 / 4) =
      (u - 1) ^ 3 * (u + 3) / 4 := by
    unfold aParam
    ring
  have hdiff : (u ^ 2 - 1) ^ 3 / 8 -
      (aParam u - (4 + 2 * (u ^ 2 - 1) - (u ^ 2 - 1) ^ 2 / 4)) =
      (u - 1) ^ 4 * (u ^ 2 + 4 * u + 5) / 8 := by
    unfold aParam
    ring
  have hp : 0 ≤ (u - 1) ^ 4 * (u ^ 2 + 4 * u + 5) / 8 := by
    apply div_nonneg
    · apply mul_nonneg (pow_nonneg (by linarith) _)
      nlinarith [sq_nonneg u]
    · norm_num
  constructor
  · rw [hid]
    exact div_nonneg (mul_nonneg (pow_nonneg (by linarith) _) (by linarith)) (by norm_num)
  · linarith [hdiff]

theorem γStar_remainder_bounds {r : ℝ} (hr : 0 ≤ r) :
    0 ≤ γStar r - 3 / 4 + r / 16 ∧
      γStar r - 3 / 4 + r / 16 ≤ r ^ 2 / 32 := by
  obtain ⟨hu, heq⟩ := sqrt_param hr
  have h := param_γ_remainder_bounds hu
  simpa only [← heq, ← γStar_eq_param hr] using h

theorem aStar_remainder_bounds {r : ℝ} (hr : 0 ≤ r) :
    0 ≤ aStar r - (4 + 2 * r - r ^ 2 / 4) ∧
      aStar r - (4 + 2 * r - r ^ 2 / 4) ≤ r ^ 3 / 8 := by
  obtain ⟨hu, heq⟩ := sqrt_param hr
  have h := param_a_remainder_bounds hu
  simpa only [← heq, ← aStar_eq_param] using h

end C2.FirstOrder
