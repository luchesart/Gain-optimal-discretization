import C2.NGammaRootCountBridge

/-! The real-coefficient, upper-semicircle form of the polynomial argument
principle. The conjugate symmetry doubles the argument increment. -/
noncomputable section
open scoped BigOperators ComplexConjugate
open Set Complex Polynomial
namespace C2.NGamma.RootCountBridge

theorem circle_reflect (t : ℝ) : circle (2 * Real.pi - t) = conj (circle t) := by
  unfold circle
  rw [Complex.ofReal_sub, sub_mul, Complex.exp_sub]
  simp only [Complex.ofReal_mul, Complex.ofReal_ofNat, Complex.exp_two_pi_mul_I, one_div]
  rw [← Complex.exp_neg, ← Complex.exp_conj]
  congr 1
  simp

theorem polynomial_reflected_polar {p : Polynomial ℂ}
    (hconj : ∀ z : ℂ, p.eval (conj z) = conj (p.eval z))
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) (t : ℝ) :
    p.eval (circle t) = (‖p.eval (circle t)‖ : ℂ) *
      Complex.exp (((-polynomialAngle p (2 * Real.pi - t) : ℝ) : ℂ) * I) := by
  have hp := polynomial_polar p hroots (2 * Real.pi - t)
  rw [circle_reflect, hconj] at hp
  have hc := congrArg conj hp
  simpa only [Complex.conj_conj, map_mul, Complex.conj_ofReal,
    Complex.norm_conj, ← Complex.exp_conj, map_mul, Complex.conj_I,
    mul_neg, Complex.ofReal_neg, neg_mul] using hc

theorem polynomialAngle_half_increment {p : Polynomial ℂ} (hp : p ≠ 0)
    (hconj : ∀ z : ℂ, p.eval (conj z) = conj (p.eval z))
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) :
    polynomialAngle p Real.pi - polynomialAngle p 0 =
      (countInside p : ℝ) * Real.pi := by
  let β : ℝ → ℝ := fun t => -polynomialAngle p (2 * Real.pi - t)
  have hβ : Continuous β := by
    exact ((continuous_polynomialAngle p hroots).comp (continuous_const.sub continuous_id)).neg
  have he : ∀ t ∈ (Set.univ : Set ℝ),
      Complex.exp ((polynomialAngle p t : ℂ) * I) = Complex.exp ((β t : ℂ) * I) := by
    intro t ht
    have hn : (‖p.eval (circle t)‖ : ℂ) ≠ 0 := by
      exact_mod_cast (norm_ne_zero_iff.mpr (eval_circle_ne_zero hp hroots t))
    apply mul_left_cancel₀ hn
    exact (polynomial_polar p hroots t).symm.trans (polynomial_reflected_polar hconj hroots t)
  have hc := argument_difference_constant isPreconnected_univ
    (continuous_polynomialAngle p hroots).continuousOn hβ.continuousOn he
    (Set.mem_univ (0 : ℝ)) (Set.mem_univ Real.pi)
  dsimp [β] at hc
  have hm : 2 * Real.pi - Real.pi = Real.pi := by ring
  simp only [sub_zero, hm, sub_neg_eq_add] at hc
  linarith [polynomialAngle_increment p]

/-- An upper-half-circle argument lift counts the actual interior roots of a
real-coefficient polynomial, including multiplicities. -/
theorem polynomial_argument_principle_half {p : Polynomial ℂ} (hp : p ≠ 0)
    (hconj : ∀ z : ℂ, p.eval (conj z) = conj (p.eval z))
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) {α : ℝ → ℝ}
    (hα : ContinuousOn α (Set.Icc 0 Real.pi))
    (hpolar : ∀ t ∈ Set.Icc 0 Real.pi, p.eval (circle t) =
      (‖p.eval (circle t)‖ : ℂ) * Complex.exp ((α t : ℂ) * I)) :
    α Real.pi - α 0 = (countInside p : ℝ) * Real.pi := by
  have he : ∀ t ∈ Set.Icc 0 Real.pi, Complex.exp ((α t : ℂ) * I) =
      Complex.exp ((polynomialAngle p t : ℂ) * I) := by
    intro t ht
    have hn : (‖p.eval (circle t)‖ : ℂ) ≠ 0 := by
      exact_mod_cast (norm_ne_zero_iff.mpr (eval_circle_ne_zero hp hroots t))
    apply mul_left_cancel₀ hn
    exact (hpolar t ht).symm.trans (polynomial_polar p hroots t)
  have hc := argument_difference_constant isPreconnected_Icc hα
    (continuous_polynomialAngle p hroots).continuousOn he
    (show Real.pi ∈ Set.Icc 0 Real.pi from ⟨le_of_lt Real.pi_pos, le_rfl⟩)
    (show 0 ∈ Set.Icc 0 Real.pi from ⟨le_rfl, le_of_lt Real.pi_pos⟩)
  linarith [polynomialAngle_half_increment hp hconj hroots]

end C2.NGamma.RootCountBridge
