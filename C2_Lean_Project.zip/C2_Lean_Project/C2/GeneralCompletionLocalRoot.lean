import Mathlib

/-! A genuine local real root branch of H(z)+k N(z), with its derivative
and a uniform quadratic remainder. No root branch or remainder is assumed. -/

noncomputable section
open Polynomial Filter Asymptotics
open scoped Topology
namespace C2.GeneralCompletion

theorem exists_local_real_root_branch (H N : ℝ[X])
    (hH : H.eval 1 = 0) (hD : H.derivative.eval 1 ≠ 0) (hN : N.eval 1 ≠ 0) :
    ∃ z : ℝ → ℝ, z 0 = 1 ∧
      HasDerivAt z (-N.eval 1 / H.derivative.eval 1) 0 ∧
      ∀ᶠ k in 𝓝 (0:ℝ), H.eval (z k) + k*N.eval (z k) = 0 := by
  let F : ℝ → ℝ := fun x => -H.eval x / N.eval x
  let d : ℝ := -H.derivative.eval 1 / N.eval 1
  have hd : d ≠ 0 := div_ne_zero (neg_ne_zero.mpr hD) hN
  have hF0 : F 1 = 0 := by simp [F,hH]
  have hf : HasStrictDerivAt F d 1 := by
    convert (H.hasStrictDerivAt (1:ℝ)).neg.div (N.hasStrictDerivAt 1) hN using 1
    dsimp [d]
    rw [hH]
    field_simp [hN]
    <;> ring
  let z : ℝ → ℝ := hf.localInverse F d 1 hd
  let hFE := hf.hasStrictFDerivAt_equiv hd
  have hz0 : z 0 = 1 := by
    simpa only [z,hF0] using hFE.localInverse_apply_image
  have hzder : HasDerivAt z (-N.eval 1 / H.derivative.eval 1) 0 := by
    have h := (hf.to_localInverse hd).hasDerivAt
    rw [hF0] at h
    convert h using 1
    dsimp [d]
    field_simp [hD,hN]
  have hzt : Tendsto z (𝓝 0) (𝓝 1) := by
    simpa only [ContinuousAt,hz0] using hzder.continuousAt
  have hInv : ∀ᶠ k in 𝓝 (0:ℝ), F (z k) = k := by
    simpa only [z,hF0] using hFE.eventually_right_inverse
  have hNnear : ∀ᶠ k in 𝓝 (0:ℝ), N.eval (z k) ≠ 0 :=
    hzt ((N.continuous.continuousAt).eventually_ne hN)
  refine ⟨z,hz0,hzder,?_⟩
  filter_upwards [hInv,hNnear] with k hk hNk
  dsimp [F] at hk
  have he := (div_eq_iff hNk).mp hk
  linarith

/-- The quadratic error follows from polynomial divisibility and one-point
first-order bounds: H=(X-1)Q and z-1=-k N(z)/Q(z). -/
theorem local_real_root_quadratic_error (H N : ℝ[X])
    (hH : H.eval 1 = 0) (hD : H.derivative.eval 1 ≠ 0)
    {z : ℝ → ℝ} (hz0 : z 0 = 1)
    (hzder : HasDerivAt z (-N.eval 1 / H.derivative.eval 1) 0)
    (hroot : ∀ᶠ k in 𝓝 (0:ℝ), H.eval (z k) + k*N.eval (z k) = 0) :
    (fun k => z k - (1-k*N.eval 1/H.derivative.eval 1)) =O[𝓝 (0:ℝ)]
      (fun k => k^2) := by
  obtain ⟨Q,hQ⟩ := (Polynomial.dvd_iff_isRoot (p:=H) (a:=(1:ℝ))).mpr hH
  have hQone : Q.eval 1 = H.derivative.eval 1 := by
    rw [hQ,Polynomial.derivative_mul]
    simp
  have hQ1 : Q.eval 1 ≠ 0 := by rw [hQone]; exact hD
  let R : ℝ → ℝ := fun x => N.eval x / Q.eval x
  have hRdiff := (N.hasDerivAt (1:ℝ)).div (Q.hasDerivAt 1) hQ1
  have hRO : (fun x => R x - R 1) =O[𝓝 (1:ℝ)] (fun x => x-1) :=
    hRdiff.isBigO_sub
  have hzt : Tendsto z (𝓝 0) (𝓝 1) := by
    simpa only [ContinuousAt,hz0] using hzder.continuousAt
  have hzO : (fun k => z k - 1) =O[𝓝 (0:ℝ)] (fun k => k) := by
    simpa only [hz0,sub_zero] using hzder.isBigO_sub
  have hROz : (fun k => R (z k) - R 1) =O[𝓝 (0:ℝ)] (fun k => z k - 1) := by
    simpa only [Function.comp_def] using hRO.comp_tendsto hzt
  have hprod := (isBigO_refl (fun k : ℝ => k) (𝓝 (0:ℝ))).mul (hROz.trans hzO)
  have hQnear : ∀ᶠ k in 𝓝 (0:ℝ), Q.eval (z k) ≠ 0 :=
    hzt ((Q.continuous.continuousAt).eventually_ne hQ1)
  apply hprod.neg_left.congr'
  · filter_upwards [hroot,hQnear] with k hk hQk
    have he : (z k - 1)*Q.eval (z k) + k*N.eval (z k) = 0 := by
      simpa only [hQ,Polynomial.eval_mul,Polynomial.eval_sub,Polynomial.eval_X,
        Polynomial.eval_C] using hk
    have hratio : z k - 1 = -k * R (z k) := by
      have hmul : (z k - 1)*Q.eval (z k) = -k*N.eval (z k) := by linarith
      have heq := (eq_div_iff hQk).mpr hmul
      calc
        z k - 1 = (-k*N.eval (z k))/Q.eval (z k) := heq
        _ = -k * R (z k) := by dsimp [R]; ring
    have hR1 : R 1 = N.eval 1/H.derivative.eval 1 := by dsimp [R]; rw [hQone]
    rw [hR1]
    linear_combination -hratio
  · filter_upwards with k
    ring

/-- Complete local perturbation theorem with an explicit quantified O(k²)
remainder, obtained from the polynomial hypotheses alone. -/
theorem exists_local_real_root_branch_quadratic (H N : ℝ[X])
    (hH : H.eval 1 = 0) (hD : H.derivative.eval 1 ≠ 0) (hN : N.eval 1 ≠ 0) :
    ∃ (z : ℝ → ℝ) (C δ : ℝ), z 0 = 1 ∧
      HasDerivAt z (-N.eval 1/H.derivative.eval 1) 0 ∧ 0 < C ∧ 0 < δ ∧
      ∀ k : ℝ, |k| < δ → H.eval (z k)+k*N.eval (z k)=0 ∧
        |z k-(1-k*N.eval 1/H.derivative.eval 1)| ≤ C*k^2 := by
  obtain ⟨z,hz0,hzder,hroot⟩ := exists_local_real_root_branch H N hH hD hN
  obtain ⟨C,hC,hbound⟩ := (local_real_root_quadratic_error H N hH hD hz0 hzder hroot).exists_pos
  have hall : ∀ᶠ k in 𝓝 (0:ℝ), H.eval (z k)+k*N.eval (z k)=0 ∧
      |z k-(1-k*N.eval 1/H.derivative.eval 1)| ≤ C*k^2 := by
    filter_upwards [hroot,hbound.bound] with k hk hb
    refine ⟨hk,?_⟩
    simpa only [Real.norm_eq_abs,abs_sq] using hb
  obtain ⟨δ,hδ,hball⟩ := Metric.mem_nhds_iff.mp hall
  refine ⟨z,C,δ,hz0,hzder,hC,hδ,?_⟩
  intro k hk
  apply hball
  simpa only [Metric.mem_ball,Real.dist_eq,sub_zero] using hk

end C2.GeneralCompletion
