import C2.IntegratorDelayGlobal
import C2.IntegratorDelayManuscript
import C2.IntegratorDelayRootBranch

/-! Full manuscript wrappers for the inherited integer-delay integrator block. -/
noncomputable section
namespace C2.IntegratorDelay
open NGamma.Cayley

theorem frequency_boundary_root {n : ℕ} (hn : 2 ≤ n) {γ : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    0 < boundaryGain n (frequency n (2 * γ - 1)) ∧
      characteristic n γ (boundaryGain n (frequency n (2 * γ - 1)))
        (Complex.exp ((frequency n (2 * γ - 1) : ℂ) * Complex.I)) = 0 := by
  refine ⟨criticalGain_pos hn hγ0 hγ1, ?_⟩
  let x := 2 * γ - 1
  have hx0 : -1 ≤ x := by dsimp [x]; linarith
  have hx1 : x ≤ 1 := by dsimp [x]; linarith
  let t := criticalCayleyPoint n x
  have ht : 0 < t := criticalCayleyPoint_pos hn hx0 hx1
  have hpoint : point t = Complex.exp ((frequency n x : ℂ) * Complex.I) := by
    rw [point_exp, criticalCayleyPoint_angle hn hx0 hx1]
  have hB : amplitude x t = criticalGain n γ := criticalCayleyPoint_amplitude hn hx0 hx1
  have hp : totalPhase n x t = Real.pi := criticalCayleyPoint_phase hn hx0 hx1
  change characteristic n γ (criticalGain n γ)
    (Complex.exp ((frequency n x : ℂ) * Complex.I)) = 0
  rw [← hpoint, ← poly_eval_characteristic, poly_eval_point, transfer_polar n x t ht.le,
    hB, hp, Complex.exp_pi_mul_I]
  ring

/-- All clauses of `lem:phase` except parameter monotonicity, which is
`manuscript_frequency_strictMonoOn`: the exact unique printed phase equation,
the prescribed interval, positive gain, and the actual unit-circle root. -/
theorem low_frequency_boundary_theorem {n : ℕ} (hn : 2 ≤ n) {γ : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    ∃! w : ℝ, w ∈ Set.Icc (lowerFrequency n) (upperFrequency n) ∧
      ((n : ℝ) + 1 / 2) * w - chordPhase γ w = Real.pi / 2 ∧
      0 < boundaryGain n w ∧
      characteristic n γ (boundaryGain n w) (Complex.exp ((w : ℂ) * Complex.I)) = 0 := by
  have hx0 : -1 ≤ 2 * γ - 1 := by linarith
  have hx1 : 2 * γ - 1 ≤ 1 := by linarith
  have hf := frequency_spec hn hx0 hx1
  have hb := frequency_bounds hn hf.1
  have hphase : ((n : ℝ) + 1 / 2) * frequency n (2 * γ - 1) -
      chordPhase γ (frequency n (2 * γ - 1)) = Real.pi / 2 := by
    rw [manuscript_phase_eq_lowPhase hγ0 hγ1 hb.1.le
      (by linarith [hb.2.1, Real.pi_pos])]
    exact hf.2
  refine ⟨frequency n (2 * γ - 1), ⟨hf.1, hphase, frequency_boundary_root hn hγ0 hγ1⟩, ?_⟩
  intro v hv
  obtain ⟨w, hw, hu⟩ := existsUnique_manuscript_frequency hn hγ0 hγ1
  exact (hu v ⟨hv.1, hv.2.1⟩).trans (hu _ ⟨hf.1, hphase⟩).symm

end C2.IntegratorDelay
