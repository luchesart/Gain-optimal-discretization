import C2.NGammaPolynomial
import Mathlib.Algebra.Polynomial.FieldDivision

noncomputable section
open scoped BigOperators
open Polynomial

namespace C2.NGamma.PolynomialModel

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

def linearProduct (s : Finset ι) (a : ι → ℂ) : Polynomial ℂ :=
  ∏ i ∈ s, (1 - C (a i) * X)

theorem linearProduct_eval_zero (s : Finset ι) (a : ι → ℂ) :
    (linearProduct s a).eval 0 = 1 := by
  simp [linearProduct, eval_prod]

theorem linearProduct_derivative_zero (s : Finset ι) (a : ι → ℂ) :
    (linearProduct s a).derivative.eval 0 = -∑ i ∈ s, a i := by
  induction s using Finset.induction_on with
  | empty => simp [linearProduct]
  | @insert i s hi ih =>
    have he : linearProduct (insert i s) a = (1 - C (a i) * X) * linearProduct s a := by
      simp [linearProduct, hi]
    rw [he, derivative_mul]
    simp only [eval_add, eval_mul, derivative_sub, derivative_one, derivative_mul,
      derivative_C, zero_mul, derivative_X, mul_one, zero_add, zero_sub, eval_neg,
      eval_C, linearProduct_eval_zero, mul_one, eval_sub, eval_one, eval_X,
      mul_zero, sub_zero, one_mul, ih, Finset.sum_insert hi]
    ring

theorem linearProduct_second_derivative_zero (s : Finset ι) (a : ι → ℂ) :
    (linearProduct s a).derivative.derivative.eval 0 =
      (∑ i ∈ s, a i) ^ 2 - ∑ i ∈ s, (a i) ^ 2 := by
  induction s using Finset.induction_on with
  | empty => simp [linearProduct]
  | @insert i s hi ih =>
    have he : linearProduct (insert i s) a = (1 - C (a i) * X) * linearProduct s a := by
      simp [linearProduct, hi]
    rw [he, derivative_mul, derivative_add, derivative_mul, derivative_mul]
    simp only [eval_add, eval_mul, derivative_sub, derivative_one, derivative_mul,
      derivative_C, zero_mul, derivative_X, mul_one, zero_add, zero_sub, eval_neg,
      eval_C, linearProduct_eval_zero, mul_one, eval_sub, eval_one, eval_X,
      mul_zero, sub_zero, one_mul, derivative_neg, eval_zero,
      linearProduct_derivative_zero, ih, Finset.sum_insert hi]
    ring

def endpointAlpha (r x : ℝ) : ℝ := (1 + r * (1 + x) / 2) / (2 + r * x)
def endpointBeta (x : ℝ) : ℝ := (1 + x) / (2 * x)

theorem endpointAlpha_gt_half {r x : ℝ} (hr : 0 < r) (hx : 0 < x) :
    1 / 2 < endpointAlpha r x := by
  unfold endpointAlpha
  apply (lt_div_iff₀ (by positivity : 0 < 2 + r*x)).2
  linarith

theorem endpointBeta_gt_half {x : ℝ} (hx : 0 < x) :
    1 / 2 < endpointBeta x := by
  unfold endpointBeta
  apply (lt_div_iff₀ (by positivity : 0 < 2*x)).2
  linarith

theorem endpoint_difference {r x : ℝ} (hr : 0 < r) (hx : 0 < x) :
    endpointBeta x - endpointAlpha r x = 1 / (x * (2 + r*x)) := by
  have hx0 := ne_of_gt hx
  have ha0 : 2+r*x ≠ 0 := by positivity
  unfold endpointBeta endpointAlpha
  field_simp
  ring

def normalizedBoundary (a b : ι → ℂ) : Polynomial ℂ :=
  (X - 1) * linearProduct Finset.univ a + linearProduct Finset.univ b

theorem normalizedBoundary_eval_zero (a b : ι → ℂ) :
    (normalizedBoundary a b).eval 0 = 0 := by
  simp [normalizedBoundary, linearProduct_eval_zero]

theorem normalizedBoundary_derivative_zero (a b : ι → ℂ) :
    (normalizedBoundary a b).derivative.eval 0 = 1 + ∑ i, a i - ∑ i, b i := by
  simp [normalizedBoundary, derivative_mul, linearProduct_eval_zero,
    linearProduct_derivative_zero]
  ring

theorem normalizedBoundary_second_derivative_zero (a b : ι → ℂ)
    (hs : ∑ i, (b i - a i) = 1) :
    (normalizedBoundary a b).derivative.derivative.eval 0 =
      -∑ i, (b i - a i) * (b i + a i - 1) := by
  have hs' : (∑ i, b i) - ∑ i, a i = 1 := by
    simpa only [Finset.sum_sub_distrib] using hs
  have hid : ∑ i, (b i - a i) * (b i + a i - 1) =
      (∑ i, (b i)^2) - (∑ i, (a i)^2) - (∑ i, b i) + ∑ i, a i := by
    simp_rw [show ∀ i, (b i-a i)*(b i+a i-1) = (b i)^2-(a i)^2-b i+a i by intro i; ring]
    simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib]
  rw [hid]
  simp only [normalizedBoundary, derivative_add, derivative_mul, derivative_sub,
    derivative_X, derivative_one, sub_zero, derivative_zero, derivative_add,
    derivative_one, zero_mul, mul_one, one_mul, zero_add, eval_add, eval_mul,
    eval_sub, eval_X, eval_one, zero_sub, linearProduct_derivative_zero,
    linearProduct_second_derivative_zero]
  have hb : (∑ i, b i) = (∑ i, a i) + 1 := by linear_combination hs'
  rw [hb]
  ring

theorem q_comp_shift {x : ℝ} (hx : 0 < x) :
    (q x).comp (X - 1) = C (-(x : ℂ)) * (1 - C (endpointBeta x : ℂ) * X) := by
  apply Polynomial.funext
  intro z
  simp only [eval_comp, eval_sub, eval_X, eval_one, eval_mul, eval_C]
  rw [q_eval]
  unfold endpointBeta
  push_cast
  have hn : (x : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hx
  field_simp
  ring

theorem factor_comp_shift {r x : ℝ} (hr : 0 < r) (hx : 0 < x) :
    (factor r x).comp (X - 1) =
      C (-(2 + (r : ℂ)*x)) * (1 - C (endpointAlpha r x : ℂ) * X) := by
  apply Polynomial.funext
  intro z
  simp only [eval_comp, eval_sub, eval_X, eval_one, eval_mul, eval_C]
  rw [factor_eval, q_eval]
  unfold endpointAlpha
  push_cast
  have hn : (2 + (r : ℂ)*x) ≠ 0 := by
    exact_mod_cast (ne_of_gt (by positivity : 0 < 2 + r*x))
  field_simp
  ring

theorem endpoint_product_identity {r x : ι → ℝ} (hx : ∀ i, 0 < x i) :
    ((∏ i, (r i + 2 / x i) : ℝ) : ℂ) * ∏ i, (x i : ℂ) =
      ∏ i, (2 + (r i : ℂ) * x i) := by
  push_cast
  rw [← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i _
  have hn : (x i : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt (hx i)
  field_simp
  ring

theorem characteristic_comp_shift {r x : ι → ℝ} (hr : ∀ i, 0 < r i)
    (hx : ∀ i, 0 < x i) :
    (characteristic r x 1 (∏ i, (r i + 2 / x i))).comp (X - 1) =
      C ((-1 : ℂ) ^ Fintype.card ι * ∏ i, (2 + (r i : ℂ) * x i)) *
      normalizedBoundary (fun i => (endpointAlpha (r i) (x i) : ℂ))
        (fun i => (endpointBeta (x i) : ℂ)) := by
  apply Polynomial.funext
  intro z
  have hD (i : ι) := congrArg (Polynomial.eval z) (factor_comp_shift (hr i) (hx i))
  have hQ (i : ι) := congrArg (Polynomial.eval z) (q_comp_shift (hx i))
  simp only [eval_comp, eval_sub, eval_X, eval_one, eval_mul, eval_C] at hD hQ
  simp only [eval_comp, eval_sub, eval_X, eval_one, characteristic,
    eval_add, eval_mul, eval_pow, pow_one, eval_prod, eval_C]
  simp_rw [hD, hQ]
  simp only [Finset.prod_mul_distrib, Finset.prod_neg, Finset.card_univ]
  simp only [normalizedBoundary, eval_mul, eval_add, eval_sub, eval_X,
    eval_one, eval_C, linearProduct, eval_prod]
  have hp := endpoint_product_identity hx (r := r)
  linear_combination
    (-1 : ℂ)^Fintype.card ι *
      (∏ i, (1 - (endpointBeta (x i) : ℂ) * z)) * hp

theorem normalizedBoundary_second_derivative_ne_zero
    [Nonempty ι] {r x : ι → ℝ} (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i)
    (hS : ∑ i, 1 / (x i * (2 + r i * x i)) = 1) :
    (normalizedBoundary (fun i => (endpointAlpha (r i) (x i) : ℂ))
      (fun i => (endpointBeta (x i) : ℂ))).derivative.derivative.eval 0 ≠ 0 := by
  have hsR : ∑ i, (endpointBeta (x i) - endpointAlpha (r i) (x i)) = 1 := by
    simpa only [endpoint_difference (hr _) (hx _)] using hS
  have hsC : ∑ i, ((endpointBeta (x i) : ℂ) - endpointAlpha (r i) (x i)) = 1 := by
    exact_mod_cast hsR
  rw [normalizedBoundary_second_derivative_zero _ _ hsC]
  have hp : 0 < ∑ i, (endpointBeta (x i) - endpointAlpha (r i) (x i)) *
      (endpointBeta (x i) + endpointAlpha (r i) (x i) - 1) := by
    apply Finset.sum_pos
    · intro i _
      apply mul_pos
      · rw [endpoint_difference (hr i) (hx i)]
        have hri := hr i
        have hxi := hx i
        positivity
      · have ha := endpointAlpha_gt_half (hr i) (hx i)
        have hb := endpointBeta_gt_half (hx i)
        linarith
    · exact Finset.univ_nonempty
  have hne := ne_of_gt hp
  simpa only [neg_ne_zero] using (show
    (∑ i, ((endpointBeta (x i) : ℂ) - endpointAlpha (r i) (x i)) *
      ((endpointBeta (x i) : ℂ) + endpointAlpha (r i) (x i) - 1)) ≠ 0 by exact_mod_cast hne)

/-- At a positive one-delay endpoint with saturated resource, the characteristic
polynomial has a root of multiplicity exactly two at -1. -/
theorem endpoint_root_multiplicity_two
    [Nonempty ι] {r x : ι → ℝ} (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i)
    (hS : ∑ i, 1 / (x i * (2 + r i * x i)) = 1) :
    (characteristic r x 1 (∏ i, (r i + 2 / x i))).rootMultiplicity (-1) = 2 := by
  classical
  let p := characteristic r x 1 (∏ i, (r i + 2 / x i))
  let a : ι → ℂ := fun i => (endpointAlpha (r i) (x i) : ℂ)
  let b : ι → ℂ := fun i => (endpointBeta (x i) : ℂ)
  let c : ℂ := (-1 : ℂ) ^ Fintype.card ι * ∏ i, (2 + (r i : ℂ) * x i)
  have hcomp : p.comp (X - 1) = C c * normalizedBoundary a b :=
    characteristic_comp_shift hr hx
  have hsR : ∑ i, (endpointBeta (x i) - endpointAlpha (r i) (x i)) = 1 := by
    simpa only [endpoint_difference (hr _) (hx _)] using hS
  have hsC : ∑ i, (b i - a i) = 1 := by
    dsimp [a, b]
    exact_mod_cast hsR
  have hsum : (∑ i, b i) - ∑ i, a i = 1 := by
    simpa only [Finset.sum_sub_distrib] using hsC
  have hN1 : (normalizedBoundary a b).derivative.eval 0 = 0 := by
    rw [normalizedBoundary_derivative_zero]
    linear_combination -hsum
  have hN2 : (normalizedBoundary a b).derivative.derivative.eval 0 ≠ 0 :=
    normalizedBoundary_second_derivative_ne_zero hr hx hS
  have hc : c ≠ 0 := by
    apply mul_ne_zero (pow_ne_zero _ (by norm_num))
    apply Finset.prod_ne_zero_iff.mpr
    intro i _
    have hri := hr i
    have hxi := hx i
    exact_mod_cast (ne_of_gt (by positivity : 0 < 2 + r i * x i))
  have hp1 : p.derivative.eval (-1) = 0 := by
    have hh := congrArg (fun q : Polynomial ℂ => q.derivative.eval 0) hcomp
    simpa [derivative_comp, derivative_mul, hN1] using hh
  have hp2 : p.derivative.derivative.eval (-1) ≠ 0 := by
    have hh := congrArg (fun q : Polynomial ℂ => q.derivative.derivative.eval 0) hcomp
    have hh' : p.derivative.derivative.eval (-1) =
        c * (normalizedBoundary a b).derivative.derivative.eval 0 := by
      simpa [derivative_comp, derivative_mul] using hh
    rw [hh']
    exact mul_ne_zero hc hN2
  have hp0 : p.eval (-1) = 0 := endpoint_is_root (fun i => ne_of_gt (hx i))
  have hpne : p ≠ 0 := by
    intro h
    apply hp2
    simp [h]
  have hlo : 1 < p.rootMultiplicity (-1) :=
    (Polynomial.one_lt_rootMultiplicity_iff_isRoot hpne).2 ⟨hp0, hp1⟩
  have hhi : p.rootMultiplicity (-1) ≤ 2 := by
    by_contra h
    have hh := Polynomial.isRoot_iterate_derivative_of_lt_rootMultiplicity
      (p := p) (t := (-1 : ℂ)) (n := 2) (by omega : 2 < p.rootMultiplicity (-1))
    apply hp2
    simpa [Polynomial.IsRoot, Function.iterate_succ_apply] using hh
  change p.rootMultiplicity (-1) = 2
  omega

end C2.NGamma.PolynomialModel
