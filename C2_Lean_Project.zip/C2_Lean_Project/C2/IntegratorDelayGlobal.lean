import C2.IntegratorDelayRegion
import C2.FirstOrderSchur

noncomputable section
namespace C2.IntegratorDelay

theorem one_characteristic (γ a : ℝ) (z : ℂ) :
    characteristic 1 γ a z =
      (1 : ℂ) * z ^ 2 + (-1 + a * γ : ℝ) * z + (a * (1 - γ) : ℝ) := by
  simp only [characteristic, pow_one]
  push_cast
  ring

theorem one_stable_iff_firstOrder {γ a : ℝ} (hγ : γ ≤ 1) :
    Stable 1 γ a ↔ FirstOrder.Stable 0 γ a := by
  have hq : Stable 1 γ a ↔ C2.QuadraticSchur 1 (-1 + a * γ) (a * (1 - γ)) := by
    simp only [Stable, C2.QuadraticSchur, one_characteristic, Complex.ofReal_one]
  unfold FirstOrder.Stable
  simp only [zero_mul, add_zero, zero_add]
  constructor
  · intro hs
    exact ⟨stable_gain_pos (by norm_num) hγ hs, hq.mp hs⟩
  · rintro ⟨_, hs⟩
    exact hq.mpr hs

theorem one_optimal_stable_iff {a : ℝ} :
    Stable 1 (3 / 4) a ↔ 0 < a ∧ a < 4 := by
  rw [one_stable_iff_firstOrder (by norm_num)]
  exact FirstOrder.integrator_stable_optimum_iff

theorem one_stable_gain_bound {γ a : ℝ} (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1)
    (hs : Stable 1 γ a) : a < 4 := by
  have h := FirstOrder.stable_global_gain_bound (by norm_num : (0 : ℝ) ≤ 0)
    hγ0 ((one_stable_iff_firstOrder hγ1).mp hs)
  simpa only [FirstOrder.integrator_aStar] using h

theorem one_maximizing_parameter_iff {γ : ℝ} (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    IsLUB {a : ℝ | Stable 1 γ a} 4 ↔ γ = 3 / 4 := by
  have he : {a : ℝ | Stable 1 γ a} = {a : ℝ | FirstOrder.Stable 0 γ a} := by
    ext a
    exact one_stable_iff_firstOrder hγ1
  rw [he]
  simpa only [FirstOrder.integrator_aStar, FirstOrder.integrator_γStar] using
    FirstOrder.stable_maximizing_parameter_iff (by norm_num : (0 : ℝ) ≤ 0) hγ0

def PhysicalStable (n : ℕ) (γ α : ℝ) : Prop :=
  ∃ a : ℝ, Stable n γ a ∧ α = (n : ℝ) * a

theorem fine_physical_region {n : ℕ} (hn : 2 ≤ n) {γ α : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    PhysicalStable n γ α ↔ 0 < α ∧ α < (n : ℝ) * criticalGain n γ := by
  have hn0 : (0 : ℝ) < n := by exact_mod_cast (show 0 < n by omega)
  constructor
  · rintro ⟨a, hs, rfl⟩
    have ha := (complete_region hn hγ0 hγ1).mp hs
    exact ⟨mul_pos hn0 ha.1, mul_lt_mul_of_pos_left ha.2 hn0⟩
  · rintro ⟨hα0, hα1⟩
    refine ⟨α / n, (complete_region hn hγ0 hγ1).mpr ⟨div_pos hα0 hn0, ?_⟩, ?_⟩
    · exact (div_lt_iff₀ hn0).mpr (by simpa [mul_comm] using hα1)
    · field_simp

theorem fine_physicalThreshold_isLUB {n : ℕ} (hn : 2 ≤ n) :
    IsLUB {α : ℝ | PhysicalStable n 1 α} (physicalThreshold n) := by
  have he : {α : ℝ | PhysicalStable n 1 α} = Set.Ioo 0 (physicalThreshold n) := by
    ext α
    change PhysicalStable n 1 α ↔ 0 < α ∧ α < physicalThreshold n
    rw [fine_physical_region hn (by norm_num) (by norm_num), physicalThreshold_eq_criticalGain hn]
  rw [he]
  apply isLUB_Ioo
  rw [physicalThreshold_eq_criticalGain hn]
  exact mul_pos (by exact_mod_cast (show 0 < n by omega))
    (criticalGain_pos hn (by norm_num) (by norm_num))

theorem fine_physical_gain_lt_two {n : ℕ} (hn : 2 ≤ n) {γ α : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (hs : PhysicalStable n γ α) : α < 2 := by
  have h := (fine_physical_region hn hγ0 hγ1).mp hs
  have hmax := (criticalGain_unique_max hn ⟨hγ0, hγ1⟩).1
  have hmul := mul_le_mul_of_nonneg_left hmax (Nat.cast_nonneg n : (0 : ℝ) ≤ n)
  rw [← physicalThreshold_eq_criticalGain hn] at hmul
  exact lt_of_lt_of_le h.2 (hmul.trans (physicalThreshold_le_two hn))

theorem one_physical_iff (γ α : ℝ) : PhysicalStable 1 γ α ↔ Stable 1 γ α := by
  constructor
  · rintro ⟨a, ha, he⟩
    have h : α = a := by simpa using he
    simpa only [h] using ha
  · intro h
    exact ⟨α, h, by simp⟩

/-- The union over every positive integer delay resolution is the exact
physical-gain interval `(0,4)`. -/
theorem physical_gain_projection {α : ℝ} :
    (∃ n : ℕ, 1 ≤ n ∧ ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ PhysicalStable n γ α) ↔
      0 < α ∧ α < 4 := by
  constructor
  · rintro ⟨n, hn, γ, hγ0, hγ1, hs⟩
    have hα : 0 < α := by
      obtain ⟨a, ha, rfl⟩ := hs
      exact mul_pos (by exact_mod_cast (show 0 < n by omega)) (stable_gain_pos hn hγ1 ha)
    refine ⟨hα, ?_⟩
    by_cases hn1 : n = 1
    · subst n
      exact one_stable_gain_bound hγ0 hγ1 ((one_physical_iff γ α).mp hs)
    · have h := fine_physical_gain_lt_two (by omega : 2 ≤ n) hγ0 hγ1 hs
      linarith
  · intro h
    exact ⟨1, by norm_num, 3 / 4, by norm_num, by norm_num,
      (one_physical_iff _ _).mpr (one_optimal_stable_iff.mpr h)⟩

theorem global_physical_gain_isLUB :
    IsLUB {α : ℝ | ∃ n : ℕ, 1 ≤ n ∧ ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ PhysicalStable n γ α} 4 := by
  have he : {α : ℝ | ∃ n : ℕ, 1 ≤ n ∧ ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ PhysicalStable n γ α} =
      Set.Ioo 0 4 := by ext α; exact physical_gain_projection
  rw [he]
  exact isLUB_Ioo (by norm_num)

/-- `cor:global`: uniqueness over both the delay resolution and integration weight. -/
theorem global_physical_maximizer_iff {n : ℕ} (hn : 1 ≤ n) {γ : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    IsLUB {α : ℝ | PhysicalStable n γ α} 4 ↔ n = 1 ∧ γ = 3 / 4 := by
  by_cases hn1 : n = 1
  · subst n
    have he : {α : ℝ | PhysicalStable 1 γ α} = {a : ℝ | Stable 1 γ a} := by
      ext α; exact one_physical_iff γ α
    rw [he, one_maximizing_parameter_iff hγ0 hγ1]
    simp
  · have hbad : ¬ IsLUB {α : ℝ | PhysicalStable n γ α} 4 := by
      intro h
      have hu : (2 : ℝ) ∈ upperBounds {α : ℝ | PhysicalStable n γ α} := by
        intro α hα
        exact (fine_physical_gain_lt_two (by omega : 2 ≤ n) hγ0 hγ1 hα).le
      have hh := h.2 hu
      norm_num at hh
    simp only [hbad, hn1, false_and]

theorem physical_controller_gain_projection {K τ k : ℝ} (hK : 0 < K) (hτ : 0 < τ) :
    (∃ n : ℕ, 1 ≤ n ∧ ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ PhysicalStable n γ (K * τ * k)) ↔
      0 < k ∧ k < 4 / (K * τ) := by
  rw [physical_gain_projection]
  have hc : 0 < K * τ := mul_pos hK hτ
  rw [mul_pos_iff_of_pos_left hc]
  constructor
  · rintro ⟨hk, h⟩
    exact ⟨hk, (lt_div_iff₀ hc).mpr (by simpa [mul_comm] using h)⟩
  · rintro ⟨hk, h⟩
    exact ⟨hk, by simpa [mul_comm] using (lt_div_iff₀ hc).mp h⟩

end C2.IntegratorDelay
