import C2.TwoGammaFullSquare
import C2.SecondOrderPolynomial

/-! Strict benefit of independent parameters over the globally optimized
shared parameter. The comparison is between actual optimal gains. -/
noncomputable section
open scoped BigOperators
open Set Polynomial
namespace C2.TwoGamma
open NGamma NGamma.PolynomialModel

theorem diagonal_eval (r₁ r₂ t b : ℝ) (z : ℂ) :
    (PolynomialModel.characteristic (poles r₁ r₂) ![t,t] 1 b).eval z =
      SecondOrder.delayCharacteristic (r₁+r₂) (r₁*r₂) t b z := by
  simp [PolynomialModel.characteristic,poles,Fin.prod_univ_two,factor_eval,q_eval,
    SecondOrder.delayCharacteristic,SecondOrder.gamma]
  push_cast
  ring

theorem diagonal_schur_iff {r₁ r₂ t b : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂) (ht : -1 ≤ t) :
    SchurStable (PolynomialModel.characteristic (poles r₁ r₂) ![t,t] 1 b) ↔
      SecondOrder.Schur (r₁+r₂) (r₁*r₂) t b := by
  have hl : 0 < SecondOrder.L (r₁+r₂) (r₁*r₂) t := by
    have hh : 0 ≤ 1+t := by linarith
    unfold SecondOrder.L
    positivity
  rw [SecondOrder.schur_iff_delay_characteristic hl]
  simp only [SchurStable,diagonal_eval]

theorem shared_root_margin {r₁ r₂ t : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂) (ht : 0 < t) (ht1 : t < 1)
    (hf : SecondOrder.f (r₁+r₂) (r₁*r₂) t = 0) :
    initialGainMargin (poles r₁ r₂) ![t,t] 1 = SecondOrder.optimum (r₁+r₂) t := by
  have hu : 0 < r₁+r₂ := by linarith
  have hv : 0 < r₁*r₂ := mul_pos h₁ h₂
  have hopt := SecondOrder.optimum_positive hu ht
  apply initialGainMargin_eq_of_exact_interval hopt
  intro b hb
  by_cases hb0 : b = 0
  · subst b
    exact iff_of_true (zero_gain_schur (poles_pos h₁ h₂) (by intro i; fin_cases i <;> simpa using ht.le) 1) hopt
  · rw [diagonal_schur_iff h₁ h₂ (by linarith)]
    exact SecondOrder.schur_at_optimal_parameter_iff hu hv ht ht1 hf (lt_of_le_of_ne hb (Ne.symm hb0))

/-- The independent gain is strictly larger than the global shared optimum
exactly when the continuous poles differ. -/
theorem strict_improvement_iff {r₁ r₂ t : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂) (ht : 0 < t) (ht1 : t < 1)
    (hf : SecondOrder.f (r₁+r₂) (r₁*r₂) t = 0) :
    SecondOrder.optimum (r₁+r₂) t < gain r₁ r₂ ↔ r₁ ≠ r₂ := by
  have hm := shared_root_margin h₁ h₂ ht ht1 hf
  have hcube : ∀ i : Fin 2, (![t,t] : Fin 2 → ℝ) i ∈ Icc (-1:ℝ) 1 := by
    intro i
    fin_cases i <;> constructor <;> simp <;> linarith
  have hbound := (explicit_initial_margin_optimum h₁ h₂).2.2.2 ![t,t] hcube
  rw [hm] at hbound
  constructor
  · intro hlt heq
    subst r₂
    have hu : 0 < r₁+r₁ := by linarith
    have hv : 0 < r₁*r₁ := mul_pos h₁ h₁
    have ho := SecondOrder.optimum_positive hu ht
    let b := (gain r₁ r₁+SecondOrder.optimum (r₁+r₁) t)/2
    have hb : 0 < b := by dsimp [b]; linarith
    have hbB : b < gain r₁ r₁ := by dsimp [b]; linarith
    have hs := ((explicit_initial_margin_optimum h₁ h₁).2.1 b hb.le).mpr hbB
    change SchurStable (PolynomialModel.characteristic (poles r₁ r₁) ![optimalX r₁ r₁,optimalX r₁ r₁] 1 b) at hs
    have hx := optimalX_interior h₁ h₁
    have hs' := (diagonal_schur_iff h₁ h₁ (by linarith : -1 ≤ optimalX r₁ r₁)).mp hs
    have hh := SecondOrder.schur_global_gain_bound hu hv ht ht1 hf (by linarith : -1 ≤ optimalX r₁ r₁) hb hs'
    dsimp [b] at hh
    linarith
  · intro hne
    apply lt_of_le_of_ne hbound.1
    intro heq
    have he := hbound.2.mp heq
    have ha := congrFun he (0:Fin 2)
    have hb := congrFun he (1:Fin 2)
    have hx : optimalX r₁ r₂ = optimalX r₂ r₁ := by
      simpa [optimalVector] using ha.symm.trans hb
    exact hne ((optimalX_equal_iff h₁ h₂).mp hx)

/-- Unconditional comparison with an attained shared-parameter global
supremum. Since its parameter lies in (0,1), it is admissible both for
shared gamma in [1/2,1] and for shared gamma in [0,1]. -/
theorem shared_global_supremum_comparison {r₁ r₂ : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    ∃ t : ℝ, 0 < t ∧ t < 1 ∧
      IsLUB (SecondOrder.stableGains (r₁+r₂) (r₁*r₂) t) (SecondOrder.optimum (r₁+r₂) t) ∧
      (∀ s b : ℝ, -1 ≤ s → 0 < b → SecondOrder.Schur (r₁+r₂) (r₁*r₂) s b →
        b < SecondOrder.optimum (r₁+r₂) t) ∧
      (SecondOrder.optimum (r₁+r₂) t < gain r₁ r₂ ↔ r₁ ≠ r₂) := by
  have hu : 0 < r₁+r₂ := by linarith
  have hv : 0 < r₁*r₂ := mul_pos h₁ h₂
  obtain ⟨t,⟨ht,ht1,hf⟩,_⟩ := SecondOrder.exists_unique_optimal_root hu hv
  exact ⟨t,ht,ht1,SecondOrder.optimal_gain_isLUB hu hv ht ht1 hf,
    fun s b hs hb hstable => SecondOrder.schur_global_gain_bound hu hv ht ht1 hf hs hb hstable,
    strict_improvement_iff h₁ h₂ ht ht1 hf⟩

end C2.TwoGamma
