import C2.NGammaEqualAnalytic
import C2.NGammaEqualBoundary
import C2.NGammaOuter

/-! Identification of the explicit equal-factor angle and gain with the
actual all-backward-Euler frequency optimizer. -/
noncomputable section
open scoped BigOperators
open Set C2.NGamma C2.NGamma.Global
namespace C2.NGammaEqual

lemma cos_two_arctan (w : ℝ) :
    Real.cos (2*Real.arctan w) = (1-w^2)/(1+w^2) := by
  rw [Real.cos_two_mul,Real.cos_arctan]
  have hs := Real.sq_sqrt (show 0 ≤ 1+w^2 by positivity)
  have hn : Real.sqrt (1+w^2) ≠ 0 := ne_of_gt (Real.sqrt_pos.mpr (by positivity))
  field_simp
  nlinarith

lemma all_one_phase_tangent {r w : ℝ} (hr : 0 < r) (hw : 0 < w) :
    Real.sin (allocationPhase r 1 w) * (r*(1+w^2)+2) =
      Real.cos (allocationPhase r 1 w) * (2*w) := by
  have hp : allocationPhase r 1 w = Real.arctan (2*w/(r*(1+w^2)+2)) := by
    simpa [phaseDenom] using phase_eq_arctan (x := 1) hr (by norm_num) hw
  rw [hp,Real.sin_arctan,Real.cos_arctan]
  have hd : r*(1+w^2)+2 ≠ 0 := by positivity
  field_simp
  <;> ring

lemma angle_from_all_one_phase {n : ℕ} (hn : 0 < n) {r w : ℝ}
    (hr : 0 < r) (hw : 0 < w)
    (hp : (∑ _ : Fin n, allocationPhase r 1 w) = 2*Real.arctan w) :
    allocationPhase r 1 w ∈ Ioo 0 (Real.pi/(n:ℝ)) ∧
      r+1 = Real.sin (((n:ℝ)-1)*allocationPhase r 1 w) /
        Real.sin (allocationPhase r 1 w) := by
  let φ := allocationPhase r 1 w
  have hnR : 0 < (n:ℝ) := by exact_mod_cast hn
  have hnp : (n:ℝ)*φ=2*Real.arctan w := by simpa [φ] using hp
  have hφ : 0 < φ := phase_pos hr hw
  have hφhalf : φ < Real.pi/2 := phase_lt_pi_div_two (by norm_num : (0:ℝ)≤1) hw
  have hφpi : φ < Real.pi := lt_trans hφhalf (by linarith [Real.pi_pos])
  have hs : Real.sin φ ≠ 0 := ne_of_gt (Real.sin_pos_of_pos_of_lt_pi hφ hφpi)
  have htan := all_one_phase_tangent hr hw
  change Real.sin φ*(r*(1+w^2)+2)=Real.cos φ*(2*w) at htan
  refine ⟨⟨hφ,(lt_div_iff₀ hnR).2 ?_⟩,?_⟩
  · have ha := Real.arctan_lt_pi_div_two w
    nlinarith
  · apply (eq_div_iff hs).2
    rw [show ((n:ℝ)-1)*φ=(n:ℝ)*φ-φ by ring,Real.sin_sub,hnp,
      sin_two_arctan,cos_two_arctan]
    have hd : 1+w^2 ≠ 0 := by positivity
    field_simp
    nlinarith [htan]

lemma all_one_gain_angle {n : ℕ} (hn : 0 < n) {r w : ℝ}
    (hr : 0 < r) (hw : 0 < w)
    (hp : (∑ _ : Fin n, allocationPhase r 1 w) = 2*Real.arctan w) :
    allocationGain r 1 w = Real.sin ((n:ℝ)*allocationPhase r 1 w) /
      Real.sin (allocationPhase r 1 w) := by
  let φ := allocationPhase r 1 w
  have hnp : (n:ℝ)*φ=2*Real.arctan w := by simpa [φ] using hp
  have hf := angle_from_all_one_phase hn hr hw hp
  have hnR : 0 < (n:ℝ) := by exact_mod_cast hn
  have hφpi : φ < Real.pi := by
    have hhalf : φ < Real.pi/2 := phase_lt_pi_div_two (by norm_num : (0:ℝ)≤1) hw
    linarith [Real.pi_pos]
  have hspos := Real.sin_pos_of_pos_of_lt_pi hf.1.1 hφpi
  have hnumpos : 0 < Real.sin ((n:ℝ)*φ) :=
    Real.sin_pos_of_pos_of_lt_pi (mul_pos hnR hf.1.1)
      (by have h := (lt_div_iff₀ hnR).mp hf.1.2; nlinarith)
  have hgain := allocationGain_pos hr hw 1
  have hd : 1+w^2 ≠ 0 := by positivity
  have hD : r*(1+w^2)+2 ≠ 0 := by positivity
  have hφeq : φ = Real.arctan (2*w/(r*(1+w^2)+2)) := by
    simpa [phaseDenom] using phase_eq_arctan (x := 1) hr (by norm_num) hw
  have hsq : (Real.sin ((n:ℝ)*φ)/Real.sin φ)^2 = (allocationGain r 1 w)^2 := by
    rw [hnp,sin_two_arctan,hφeq,Real.sin_arctan]
    unfold allocationGain
    rw [Real.sq_sqrt (by positivity)]
    have hroot := Real.sq_sqrt (show 0 ≤ 1+(2*w/(r*(1+w^2)+2))^2 by positivity)
    have hrootne : Real.sqrt (1+(2*w/(r*(1+w^2)+2))^2) ≠ 0 := by positivity
    field_simp
    rw [mul_pow, Real.sq_sqrt (by positivity)]
    ring
  have hquot : 0 < Real.sin ((n:ℝ)*φ)/Real.sin φ := div_pos hnumpos hspos
  change allocationGain r 1 w = Real.sin ((n:ℝ)*φ)/Real.sin φ
  nlinarith

end C2.NGammaEqual
