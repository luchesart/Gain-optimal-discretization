import C2.CADGlobalLifting
import C2.CADDelineability

/-! Mathematical assembly from a proved nonzero projection polynomial. Every
cut, rational sample, lifting test and endpoint conclusion is constructed from
the actual input polynomials. The final original-input theorem discharges the
projection premise using the algebraic factor/projection development. -/

noncomputable section
open Polynomial Set
namespace C2.CADGlobal

/-- The actual positive-gain projection of the strict polynomial system. -/
def positiveGains {n : ℕ} (f : Fin n → CADProjection.Bivariate) : Set ℝ :=
  {k | 0 < k ∧ ∃ γ ∈ Icc (0 : ℝ) 1, ∀ i, 0 < CADProjection.value (f i) k γ}

theorem positiveGains_isOpen {n : ℕ} (f : Fin n → CADProjection.Bivariate) :
    IsOpen (positiveGains f) := by
  exact isOpen_Ioi.inter
    (CADDelineability.patternGains_isOpen
      (fun i p => CADProjection.value (f i) p.1 p.2)
      (fun i => CADProjection.continuous_value (f i)))

def calculationOutput {n : ℕ} (f : Fin n → CADProjection.Bivariate)
    (d : ℚ[X]) (hd : d ≠ 0) (K : ℚ)
    (gainSamples : (ℝ × ℝ) → ℚ) (parameterSamples : (ℝ × ℝ) → List ℚ) : Option ℝ :=
  CADAlgorithm.testAndSelect (List.ofFn (fun i => rationalTest (f i)))
    (CADAlgorithm.adjacentSampledCells (CADGainCuts.cuts d hd K) gainSamples parameterSamples)

/-- Complete correctness of a finite mathematical calculation, with all
relations referring to the original real polynomial evaluations. -/
def CalculationCorrect {n : ℕ} (f : Fin n → CADProjection.Bivariate)
    (d : ℚ[X]) (hd : d ≠ 0) (K : ℚ)
    (gainSamples : (ℝ × ℝ) → ℚ) (parameterSamples : (ℝ × ℝ) → List ℚ) : Prop :=
  (∀ c ∈ CADCells.cells (CADGainCuts.cuts d hd K),
    (gainSamples c : ℝ) ∈ Ioo c.1 c.2) ∧
  (∀ c ∈ CADCells.cells (CADGainCuts.cuts d hd K),
    CADAlgorithm.markAtGain (List.ofFn (fun i => rationalTest (f i)))
      (parameterSamples c) (gainSamples c) = true ↔
        (gainSamples c : ℝ) ∈ positiveGains f) ∧
  (calculationOutput f d hd K gainSamples parameterSamples = none ↔ positiveGains f = ∅) ∧
  (∀ b, calculationOutput f d hd K gainSamples parameterSamples = some b →
    IsLUB (positiveGains f) b ∧ IsAlgebraic ℚ b ∧ 0 < b ∧ b < (K : ℝ))

/-- The finite calculation is constructed from the exact input evaluations,
provided a nonzero polynomial has already been proved to cut the gain axis
into feasibility-constant connected cells. No cells or test answers are inputs. -/
theorem exists_calculation_of_projection {n : ℕ}
    (f : Fin n → CADProjection.Bivariate) (d : ℚ[X]) (hd : d ≠ 0)
    (hprojection : ∀ I : Set ℝ, IsPreconnected I →
      (∀ k ∈ I, d.eval₂ (algebraMap ℚ ℝ) k ≠ 0) →
      ∀ {a b : ℝ}, a ∈ I → b ∈ I →
      ((∃ x ∈ Icc (0 : ℝ) 1, ∀ i, 0 < CADProjection.value (f i) a x) ↔
        ∃ x ∈ Icc (0 : ℝ) 1, ∀ i, 0 < CADProjection.value (f i) b x))
    (K : ℚ) (hK : 0 < K) (K₀ : ℝ)
    (hbound : ∀ k ∈ positiveGains f, k ≤ K₀) (hstrict : K₀ < (K : ℝ)) :
    ∃ gainSamples : (ℝ × ℝ) → ℚ, ∃ parameterSamples : (ℝ × ℝ) → List ℚ,
      CalculationCorrect f d hd K gainSamples parameterSamples := by
  classical
  let cuts := CADGainCuts.cuts d hd K
  have hzero : 0 ∈ cuts := CADGainCuts.zero_mem d hd K
  have hupper : (K : ℝ) ∈ cuts := CADGainCuts.upper_mem d hd K
  have hcuts : ∀ c ∈ cuts, c ∈ Icc (0 : ℝ) (K : ℝ) :=
    CADGainCuts.cuts_bounded d hd hK.le
  have hsupport : positiveGains f ⊆ Ioo 0 (K : ℝ) := by
    intro k hk
    exact ⟨hk.1, (hbound k hk).trans_lt hstrict⟩
  obtain ⟨gainSamples, hgain⟩ := exists_cell_samples cuts
  choose parameterSamples hparameter using
    (fun c : ℝ × ℝ => exists_bivariate_lifting_samples f (gainSamples c))
  have hgainpos : ∀ c ∈ CADCells.cells cuts, 0 < (gainSamples c : ℝ) := by
    intro c hc
    have hcell := (CADCells.mem_cells_iff cuts c.1 c.2).mp hc
    exact (hcuts c.1 hcell.1).1.trans_lt (hgain c hc).1
  have htest : ∀ c ∈ CADCells.cells cuts,
      CADAlgorithm.markAtGain (List.ofFn (fun i => rationalTest (f i)))
        (parameterSamples c) (gainSamples c) = true ↔
        (gainSamples c : ℝ) ∈ positiveGains f := by
    intro c hc
    simpa only [positiveGains, mem_setOf_eq, hgainpos c hc, true_and] using hparameter c
  have hconstant : ∀ c ∈ CADCells.cells cuts, ∀ k ∈ Ioo c.1 c.2,
      k ∈ positiveGains f ↔ (gainSamples c : ℝ) ∈ positiveGains f := by
    intro c hc k hk
    have hcell := (CADCells.mem_cells_iff cuts c.1 c.2).mp hc
    have hkp : 0 < k := (hcuts c.1 hcell.1).1.trans_lt hk.1
    have hnonzero : ∀ t ∈ Ioo c.1 c.2,
        d.eval₂ (algebraMap ℚ ℝ) t ≠ 0 := by
      intro t ht
      exact CADGainCuts.nonzero_on_cell d hd hK.le hcell ht
    have he := hprojection (Ioo c.1 c.2) isPreconnected_Ioo hnonzero hk (hgain c hc)
    simpa only [positiveGains, mem_setOf_eq, hkp, hgainpos c hc, true_and] using he
  have hempty := CADAlgorithm.tested_adjacent_empty_iff (positiveGains_isOpen f)
    hzero hupper hcuts hsupport gainSamples parameterSamples
    (List.ofFn (fun i => rationalTest (f i))) hconstant htest
  refine ⟨gainSamples, parameterSamples, hgain, htest, hempty, ?_⟩
  intro b hout
  have hlub : IsLUB (positiveGains f) b :=
    CADAlgorithm.tested_adjacent_supremum (positiveGains_isOpen f)
      hzero hupper hcuts hsupport gainSamples parameterSamples
      (List.ofFn (fun i => rationalTest (f i))) hconstant htest hout
  have halg : IsAlgebraic ℚ b :=
    CADAlgorithm.tested_adjacent_output_algebraic gainSamples parameterSamples
      (List.ofFn (fun i => rationalTest (f i))) (CADGainCuts.cuts_algebraic d hd K) hout
  have hne : (positiveGains f).Nonempty := by
    apply Set.nonempty_iff_ne_empty.mpr
    intro hz
    have hn := hempty.mpr hz
    change calculationOutput f d hd K gainSamples parameterSamples = none at hn
    rw [hout] at hn
    cases hn
  obtain ⟨k, hk⟩ := hne
  exact ⟨hlub, halg, hk.1.trans_le (hlub.1 hk),
    CADAlgorithm.supremum_strict_search_bound hlub hbound hstrict⟩

/-- No identically zero strict inequality can be feasible, at any gain. -/
theorem zero_input_positiveGains_empty {n : ℕ} (f : Fin n → CADProjection.Bivariate)
    {i : Fin n} (hi : f i = 0) : positiveGains f = ∅ := by
  apply Set.eq_empty_iff_forall_not_mem.mpr
  rintro k ⟨_, x, _, hpos⟩
  have h := hpos i
  simpa [hi, CADProjection.value, CADProjection.specialize] using h

end C2.CADGlobal
