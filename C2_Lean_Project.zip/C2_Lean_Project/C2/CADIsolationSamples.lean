import C2.CADIsolationOutput

/-! Explicit rational separating samples for the finite root output and exact
rational sign semantics. -/
namespace C2.CADIsolation
open Polynomial Set

theorem realEval_zero_isAlgebraic {p : ℚ[X]} (hp : p ≠ 0) {x : ℝ}
    (hx : realEval p x = 0) : IsAlgebraic ℚ x := by
  exact ⟨p,hp,hx⟩

@[simp] theorem realEval_rat_pos (p : ℚ[X]) (q : ℚ) :
    0 < realEval p (q:ℝ) ↔ 0 < p.eval q := by
  rw [realEval_rat]
  exact_mod_cast (Iff.rfl : (0:ℚ) < p.eval q ↔ 0 < p.eval q)

@[simp] theorem realEval_rat_neg (p : ℚ[X]) (q : ℚ) :
    realEval p (q:ℝ) < 0 ↔ p.eval q < 0 := by
  rw [realEval_rat]
  exact_mod_cast (Iff.rfl : p.eval q < (0:ℚ) ↔ p.eval q < 0)

@[simp] theorem realEval_rat_zero (p : ℚ[X]) (q : ℚ) :
    realEval p (q:ℝ) = 0 ↔ p.eval q = 0 := by
  rw [realEval_rat]
  exact_mod_cast (Iff.rfl : p.eval q = (0:ℚ) ↔ p.eval q = 0)

/-- Two open root enclosures are separated by the right rational endpoint
of the earlier cell, even when the cells share that endpoint. -/
theorem rational_sample_between_cells {a b : ℚ} (hab : a ≤ b) (n : ℕ)
    {i j : ℕ} (hij : i < j) {x y : ℝ}
    (hx : x ∈ Ioo (gridPoint a b n i:ℝ) (gridPoint a b n (i+1):ℝ))
    (hy : y ∈ Ioo (gridPoint a b n j:ℝ) (gridPoint a b n (j+1):ℝ)) :
    x < (gridPoint a b n (i+1):ℝ) ∧ (gridPoint a b n (i+1):ℝ) < y := by
  refine ⟨hx.2,?_⟩
  have h : (gridPoint a b n (i+1):ℝ) ≤ (gridPoint a b n j:ℝ) := by
    exact_mod_cast gridPoint_mono hab n (Nat.succ_le_iff.mpr hij)
  exact h.trans_lt hy.1

/-- A rational root point before a selected root cell has a strict rational
separator: selection rules out the point being the cell's left endpoint. -/
theorem rational_sample_point_before_cell (p : ℚ[X]) {a b : ℚ} (hab : a < b)
    (n : ℕ) {j i : ℕ} (hji : j ≤ i)
    (hp : selectedPoint p a b n j) (hc : selectedInterval p a b n i)
    {x : ℝ} (hx : x ∈ Ioo (gridPoint a b n i:ℝ) (gridPoint a b n (i+1):ℝ)) :
    (gridPoint a b n j:ℝ) < (gridPoint a b n i:ℝ) ∧
      (gridPoint a b n i:ℝ) < x := by
  have hne : j ≠ i := by
    intro h
    have hneg := hc.2
    rw [← h,hp.2,zero_mul] at hneg
    exact (lt_irrefl 0) hneg
  refine ⟨?_,hx.1⟩
  exact_mod_cast gridPoint_strictMono hab n (lt_of_le_of_ne hji hne)

/-- The right endpoint similarly separates a selected root cell from a
later rational root point. -/
theorem rational_sample_cell_before_point (p : ℚ[X]) {a b : ℚ} (hab : a < b)
    (n : ℕ) {i j : ℕ} (hij : i < j)
    (hc : selectedInterval p a b n i) (hp : selectedPoint p a b n j)
    {x : ℝ} (hx : x ∈ Ioo (gridPoint a b n i:ℝ) (gridPoint a b n (i+1):ℝ)) :
    x < (gridPoint a b n (i+1):ℝ) ∧
      (gridPoint a b n (i+1):ℝ) < (gridPoint a b n j:ℝ) := by
  have hne : i+1 ≠ j := by
    intro h
    have hneg := hc.2
    rw [h,hp.2,mul_zero] at hneg
    exact (lt_irrefl 0) hneg
  refine ⟨hx.2,?_⟩
  exact_mod_cast gridPoint_strictMono hab n (lt_of_le_of_ne (Nat.succ_le_iff.mpr hij) hne)

/-- Two exact rational root points admit their explicit rational midpoint. -/
theorem rational_sample_between_points {a b : ℚ} (hab : a < b) (n : ℕ)
    {i j : ℕ} (hij : i < j) :
    (gridPoint a b n i:ℝ) <
      (midpoint (gridPoint a b n i) (gridPoint a b n j):ℝ) ∧
    (midpoint (gridPoint a b n i) (gridPoint a b n j):ℝ) < (gridPoint a b n j:ℝ) := by
  have h : (gridPoint a b n i:ℝ) < (gridPoint a b n j:ℝ) := by
    exact_mod_cast gridPoint_strictMono hab n hij
  dsimp [midpoint]
  push_cast
  constructor <;> linarith

/-- Constant sign on an interval with no polynomial root. The exact rational
sample tests therefore determine the sign throughout any such cell. -/
theorem realEval_pos_iff_of_no_roots (p : ℚ[X]) {l u x y : ℝ}
    (hx : x ∈ Ioo l u) (hy : y ∈ Ioo l u)
    (hzero : ∀ z ∈ Ioo l u, realEval p z ≠ 0) :
    0 < realEval p x ↔ 0 < realEval p y := by
  have aux : ∀ x ∈ Ioo l u, ∀ y ∈ Ioo l u,
      x ≤ y → 0 < realEval p x → 0 < realEval p y := by
    intro x hx y hy hxy hpos
    by_contra hn
    have hneg : realEval p y < 0 := lt_of_le_of_ne (not_lt.mp hn) (hzero y hy)
    obtain ⟨z,hz,hpz⟩ := intermediate_value_Icc' hxy
      (realEval_continuous p).continuousOn ⟨hneg.le,hpos.le⟩
    exact hzero z ⟨hx.1.trans_le hz.1,hz.2.trans_lt hy.2⟩ hpz
  have aux' : ∀ x ∈ Ioo l u, ∀ y ∈ Ioo l u,
      x ≤ y → 0 < realEval p y → 0 < realEval p x := by
    intro x hx y hy hxy hpos
    by_contra hn
    have hneg : realEval p x < 0 := lt_of_le_of_ne (not_lt.mp hn) (hzero x hx)
    obtain ⟨z,hz,hpz⟩ := intermediate_value_Icc hxy
      (realEval_continuous p).continuousOn ⟨hneg.le,hpos.le⟩
    exact hzero z ⟨hx.1.trans_le hz.1,hz.2.trans_lt hy.2⟩ hpz
  rcases le_total x y with h | h
  · exact ⟨aux x hx y hy h,aux' x hx y hy h⟩
  · exact ⟨aux' y hy x hx h,aux y hy x hx h⟩

end C2.CADIsolation
