import C2.NGammaParameterization

/-! Exact specialization of the arbitrary-order cascade theorem to the
manuscript's two independently discretized first-order factors. -/
noncomputable section
open scoped BigOperators
open Polynomial Set
namespace C2.TwoGamma
open NGamma NGamma.PolynomialModel NGamma.Parameterization

def poles (r₁ r₂ : ℝ) : Fin 2 → ℝ := ![r₁, r₂]
def coordinates (γ₁ γ₂ : ℝ) : Fin 2 → ℝ := ![xOfGamma γ₁, xOfGamma γ₂]

def characteristic (r₁ r₂ γ₁ γ₂ b : ℝ) : Polynomial ℂ :=
  X * ((X-1) + C (r₁:ℂ) * (C (γ₁:ℂ)*X+C (1-(γ₁:ℂ)))) *
      ((X-1) + C (r₂:ℂ) * (C (γ₂:ℂ)*X+C (1-(γ₂:ℂ)))) +
    C (b:ℂ) * (C (γ₁:ℂ)*X+C (1-(γ₁:ℂ))) * (C (γ₂:ℂ)*X+C (1-(γ₂:ℂ)))

theorem characteristic_eq_generic (r₁ r₂ γ₁ γ₂ b : ℝ) :
    characteristic r₁ r₂ γ₁ γ₂ b =
      PolynomialModel.characteristic (poles r₁ r₂) (coordinates γ₁ γ₂) 1 b := by
  simp [characteristic, PolynomialModel.characteristic, poles, coordinates,
    Fin.prod_univ_two, PolynomialModel.factor, numerator_factor]
  ring

theorem poles_pos {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    ∀ i, 0 < poles r₁ r₂ i := by
  intro i
  fin_cases i
  · simpa [poles] using h₁
  · simpa [poles] using h₂

theorem coordinates_in_half_cube {γ₁ γ₂ : ℝ}
    (h₁ : γ₁ ∈ Icc (1/2:ℝ) 1) (h₂ : γ₂ ∈ Icc (1/2:ℝ) 1) :
    ∀ i, coordinates γ₁ γ₂ i ∈ Icc (0:ℝ) 1 := by
  intro i
  fin_cases i
  · simpa [coordinates] using (half_cube_coordinate γ₁).mp h₁
  · simpa [coordinates] using (half_cube_coordinate γ₂).mp h₂

end C2.TwoGamma
