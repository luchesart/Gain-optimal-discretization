import C2.NGammaGainInterval

noncomputable section
open scoped ComplexConjugate
namespace C2.NGamma.Cayley
open PolynomialModel RootCountBridge

lemma point_im_pos {t : ℝ} (ht : 0 < t) : 0 < (point t).im := by
  rw [point_exp, Complex.exp_ofReal_mul_I_im]
  exact Real.sin_pos_of_pos_of_lt_pi (by linarith [Phase.arctan_pos ht])
    (by linarith [Real.arctan_lt_pi_div_two t])

lemma first_crossing_conjugate_pair {n : ℕ} {r : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (x : Fin n → ℝ) (d : ℕ) {t : ℝ} (ht : 0 < t)
    (hphase : Phase.totalPhase (fun i => x i+2/r i) x d t = Real.pi) :
    (characteristic r x d (amplitude r x t)).eval (point t) = 0 ∧
    (characteristic r x d (amplitude r x t)).eval (conj (point t)) = 0 ∧
    ‖point t‖ = 1 ∧ ‖conj (point t)‖ = 1 ∧ point t ≠ conj (point t) := by
  have hroot := first_crossing_gives_unit_root hr x d t hphase
  refine ⟨hroot.1, ?_, hroot.2, ?_, ?_⟩
  · rw [characteristic_eval_conj, hroot.1, map_zero]
  · simpa using hroot.2
  · intro he
    have hh := congrArg Complex.im he
    have hp := point_im_pos ht
    simp only [Complex.conj_im] at hh
    linarith

end C2.NGamma.Cayley
