# C2 axiom and coverage checklist — 2026-11-08

- [x] Lean 4.19.0 and mathlib commit c44e0c8ee63ca166450922a373c7409c5d26b00b are pinned.
- [x] All 95 proof modules and the umbrella import compile.
- [x] The generated single-file version compiles from the same proof sources.
- [x] All 1080 explicit public declarations resolve in the full axiom audit.
- [x] Transitive dependencies use only propext, Classical.choice and Quot.sound.
- [x] No sorryAx, admitted proof, custom axiom or unsafe proof is accepted.
- [x] Declarations with same-line Lean attributes are included in the inventory.
- [x] The 20 original proof modules are byte-identical to the input release.
- [x] Every one of the 13 new numbered results is mapped to proved declarations.
- [x] Root counts use actual complex polynomial roots, with multiplicity.
- [x] Schur stability quantifies over actual roots; the initial margin is the supremum of actual stable intervals.
- [x] State stability means convergence of every homogeneous state trajectory.
- [x] Endpoint, zero-coordinate, equality and active-bound cases are included.
- [x] Global optimization statements include uniqueness and the explicit design regimes.
- [x] No unproved root count, stability, optimizer regularity or global optimality is hidden in a final theorem hypothesis.
- [x] The full-cube conclusion concerns the initial interval adjacent to zero.
- [x] The older IJC checkpoint remains historical; no journal submission is implied.

There are 903 explicit public theorem/lemma declarations. Generated helper constants and private declarations are not presented as separately counted public claims; their axioms are checked transitively through the exported results. The independent coverage review is in validation/ngamma_coverage_review.json. This is a local Lean check, not a live.lean website session.

Reproduce:

```sh
lake exe cache get
python tools/make_single_file.py
python tools/theorem_inventory.py
lake build
lake env lean live/C2_Live_Lean419.lean
python tools/run_axiom_audit.py
```

The 45-entry manuscript map contains 20 COMPLETE, 3 CORE_COMPLETE, 4 PARTIAL and 18 NOT_FORMALIZED results. All 13 arbitrary-order results are in the COMPLETE group; whole-article formalization is not claimed.
