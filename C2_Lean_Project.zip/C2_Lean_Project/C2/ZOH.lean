import Mathlib

/-!
# Exact ZOH lag: algebraic Schur inequalities and global parameter optimum

This file proves the cubic Jury inequalities, their exact positive-gain interval,
and the unique optimal integration parameter. The predicate `zohJury` is explicitly
an algebraic predicate, not a redefinition of root-based Schur stability. The
module `C2.ZOHRoots` composes these results with a proved complex-root cubic
Schur criterion.
-/

noncomputable section
namespace C2

/-- Last cubic Jury expression, using `beta = 1 - gamma`. -/
def zohF (ρ a β : ℝ) : ℝ :=
  1 - ρ - a * (1 + ρ * β) - a ^ 2 * β ^ 2

/-- The four classical cubic Jury inequalities for
`z³ -(1+ρ)z² +(ρ+a(1-β))z +aβ`. -/
def zohJury (ρ a β : ℝ) : Prop :=
  |a * β| < 1 ∧
  0 < 1 + (-(1 + ρ)) + (ρ + a * (1 - β)) + a * β ∧
  0 < 1 - (-(1 + ρ)) + (ρ + a * (1 - β)) - a * β ∧
  0 < 1 - (a * β)^2 - (ρ + a * (1 - β)) + (-(1 + ρ)) * (a * β)

theorem zoh_last_jury_identity (ρ a β : ℝ) :
    1 - (a * β)^2 - (ρ + a * (1 - β)) + (-(1 + ρ)) * (a * β)
      = zohF ρ a β := by
  unfold zohF
  ring

/-- Every point satisfying the decisive inequality lies below the universal cap. -/
theorem zoh_gain_lt_cap {ρ a β : ℝ} (hρ : 0 < ρ) (ha : 0 < a)
    (hβ : 0 ≤ β) (hF : 0 < zohF ρ a β) : a < 1 - ρ := by
  unfold zohF at hF
  have h1 : 0 ≤ a * ρ * β := mul_nonneg (mul_nonneg ha.le hρ.le) hβ
  have h2 : 0 ≤ a ^ 2 * β ^ 2 := mul_nonneg (sq_nonneg a) (sq_nonneg β)
  nlinarith

/-- The four cubic inequalities reduce exactly to one inequality. -/
theorem zoh_jury_iff {ρ a β : ℝ} (hρ : 0 < ρ) (hρ1 : ρ < 1)
    (ha : 0 < a) (hβ : 0 ≤ β) (hβ1 : β ≤ 1) :
    zohJury ρ a β ↔ 0 < zohF ρ a β := by
  constructor
  · intro h
    rw [← zoh_last_jury_identity]
    exact h.2.2.2
  · intro hF
    have hcap := zoh_gain_lt_cap hρ ha hβ hF
    have hab : 0 ≤ a * β := mul_nonneg ha.le hβ
    have hab1 : a * β ≤ a := by nlinarith
    refine ⟨?_, ?_, ?_, ?_⟩
    · rw [abs_of_nonneg hab]
      linarith
    · nlinarith
    · nlinarith
    · rw [zoh_last_jury_identity]
      exact hF

/-- Increasing beta strictly decreases the decisive expression at positive gain. -/
theorem zohF_strictAnti_beta {ρ a β₁ β₂ : ℝ} (hρ : 0 < ρ) (ha : 0 < a)
    (hβ₁ : 0 ≤ β₁) (hβ : β₁ < β₂) :
    zohF ρ a β₂ < zohF ρ a β₁ := by
  have hβ₂ : 0 ≤ β₂ := le_trans hβ₁ hβ.le
  have hp : 0 < a * ρ * (β₂ - β₁) :=
    mul_pos (mul_pos ha hρ) (sub_pos.mpr hβ)
  have hs : 0 ≤ β₂ ^ 2 - β₁ ^ 2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hβ.le) (add_nonneg hβ₁ hβ₂)]
  have hq : 0 ≤ a ^ 2 * (β₂ ^ 2 - β₁ ^ 2) := mul_nonneg (sq_nonneg a) hs
  unfold zohF
  nlinarith

/-- Increasing gain strictly decreases the decisive expression. -/
theorem zohF_strictAnti_gain {ρ a₁ a₂ β : ℝ} (hρ : 0 ≤ ρ)
    (hβ : 0 ≤ β) (ha₁ : 0 ≤ a₁) (ha : a₁ < a₂) :
    zohF ρ a₂ β < zohF ρ a₁ β := by
  have ha₂ : 0 ≤ a₂ := le_trans ha₁ ha.le
  have hp : 0 ≤ ρ * β := mul_nonneg hρ hβ
  have hlin : 0 < (a₂ - a₁) * (1 + ρ * β) :=
    mul_pos (sub_pos.mpr ha) (by linarith)
  have hs : 0 ≤ a₂ ^ 2 - a₁ ^ 2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr ha.le) (add_nonneg ha₁ ha₂)]
  have hq : 0 ≤ (a₂ ^ 2 - a₁ ^ 2) * β ^ 2 := mul_nonneg hs (sq_nonneg β)
  unfold zohF
  nlinarith

/-- Positive root, written in a form valid also at beta=0. -/
def zohThreshold (ρ β : ℝ) : ℝ :=
  2 * (1 - ρ) /
    (1 + ρ * β + Real.sqrt ((1 + ρ * β)^2 + 4 * (1 - ρ) * β^2))

private theorem zoh_denom_pos {ρ β : ℝ} (hρ : 0 ≤ ρ) (hβ : 0 ≤ β) :
    0 < 1 + ρ * β + Real.sqrt ((1 + ρ * β)^2 + 4 * (1 - ρ) * β^2) := by
  have hp : 0 ≤ ρ * β := mul_nonneg hρ hβ
  have hs := Real.sqrt_nonneg ((1 + ρ * β)^2 + 4 * (1 - ρ) * β^2)
  linarith

theorem zoh_threshold_pos {ρ β : ℝ} (hρ : 0 ≤ ρ) (hρ1 : ρ < 1)
    (hβ : 0 ≤ β) : 0 < zohThreshold ρ β := by
  unfold zohThreshold
  exact div_pos (by linarith) (zoh_denom_pos hρ hβ)

/-- The closed-form threshold lies exactly on the decisive Jury boundary. -/
theorem zoh_threshold_boundary {ρ β : ℝ} (hρ : 0 ≤ ρ) (hρ1 : ρ < 1)
    (hβ : 0 ≤ β) : zohF ρ (zohThreshold ρ β) β = 0 := by
  let b : ℝ := 1 + ρ * β
  let c : ℝ := 1 - ρ
  let s : ℝ := Real.sqrt (b^2 + 4*c*β^2)
  have hc : 0 < c := by dsimp [c]; linarith
  have hb : 0 < b := by dsimp [b]; nlinarith [mul_nonneg hρ hβ]
  have hd : 0 ≤ b^2 + 4*c*β^2 := by positivity
  have hs : s^2 = b^2 + 4*c*β^2 := Real.sq_sqrt hd
  have hbs : b+s ≠ 0 := ne_of_gt (by
    have hsn : 0 ≤ s := Real.sqrt_nonneg _
    linarith)
  change c - (2*c/(b+s))*b - (2*c/(b+s))^2*β^2 = 0
  field_simp [hbs]
  nlinarith [congrArg (fun x : ℝ => c*x) hs]

/-- The positive-gain stable region defined by the cubic inequalities is one interval. -/
theorem zohF_pos_iff_lt_threshold {ρ a β : ℝ} (hρ : 0 ≤ ρ) (hρ1 : ρ < 1)
    (ha : 0 ≤ a) (hβ : 0 ≤ β) :
    0 < zohF ρ a β ↔ a < zohThreshold ρ β := by
  have ht := zoh_threshold_pos hρ hρ1 hβ
  have hb := zoh_threshold_boundary hρ hρ1 hβ
  constructor
  · intro hF
    by_contra h
    have hle : zohThreshold ρ β ≤ a := le_of_not_gt h
    rcases hle.eq_or_lt with he | hlt
    · rw [← he, hb] at hF
      exact (lt_irrefl 0) hF
    · have hm := zohF_strictAnti_gain hρ hβ ht.le hlt
      rw [hb] at hm
      linarith
  · intro hlt
    have hm := zohF_strictAnti_gain hρ hβ ha hlt
    rw [hb] at hm
    exact hm

/-- Full exact algebraic region with all input hypotheses visible. -/
theorem zoh_jury_iff_gain_interval {ρ a β : ℝ} (hρ : 0 < ρ) (hρ1 : ρ < 1)
    (ha : 0 < a) (hβ : 0 ≤ β) (hβ1 : β ≤ 1) :
    zohJury ρ a β ↔ a < zohThreshold ρ β := by
  rw [zoh_jury_iff hρ hρ1 ha hβ hβ1,
    zohF_pos_iff_lt_threshold hρ.le hρ1 ha.le hβ]

theorem zoh_threshold_beta_zero (ρ : ℝ) : zohThreshold ρ 0 = 1 - ρ := by
  simp [zohThreshold]
  ring

/-- Threshold decreases strictly with beta, hence increases strictly with gamma. -/
theorem zoh_threshold_strictAnti {ρ β₁ β₂ : ℝ} (hρ : 0 < ρ) (hρ1 : ρ < 1)
    (hβ₁ : 0 ≤ β₁) (hβ : β₁ < β₂) :
    zohThreshold ρ β₂ < zohThreshold ρ β₁ := by
  have hβ₂ : 0 ≤ β₂ := le_trans hβ₁ hβ.le
  have ht₂ := zoh_threshold_pos hρ.le hρ1 hβ₂
  have hb₂ := zoh_threshold_boundary hρ.le hρ1 hβ₂
  have hm := zohF_strictAnti_beta hρ ht₂ hβ₁ hβ
  rw [hb₂] at hm
  exact (zohF_pos_iff_lt_threshold hρ.le hρ1 ht₂.le hβ₁).mp hm

/-- Backward Euler is the unique maximizer over gamma in [0,1]. -/
theorem zoh_threshold_unique_max {ρ γ : ℝ} (hρ : 0 < ρ) (hρ1 : ρ < 1)
    (hγ : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    zohThreshold ρ (1-γ) ≤ 1-ρ ∧
      (zohThreshold ρ (1-γ) = 1-ρ ↔ γ = 1) := by
  by_cases he : γ = 1
  · subst γ
    simp [zoh_threshold_beta_zero]
  · have hb : 0 < 1-γ := sub_pos.mpr (lt_of_le_of_ne hγ1 he)
    have hm := zoh_threshold_strictAnti hρ hρ1 (le_refl 0) hb
    rw [zoh_threshold_beta_zero] at hm
    exact ⟨hm.le, ⟨fun h => False.elim (ne_of_lt hm h), fun h => False.elim (he h)⟩⟩

/-- The dimensional optimum is independent of the sampled lag pole. -/
theorem zoh_physical_gain_iff {ρ k : ℝ} (hρ1 : ρ < 1) :
    k * (1-ρ) < zohThreshold ρ 0 ↔ k < 1 := by
  rw [zoh_threshold_beta_zero]
  have hpos : 0 < 1-ρ := by linarith
  constructor <;> intro h <;> nlinarith

/-- Direct polynomial identity for the characteristic expression. -/
theorem zoh_characteristic_identity (z ρ a β : ℝ) :
    z * (z - ρ) * (z - 1) + a * ((1-β)*z+β) =
      z^3 - (1+ρ)*z^2 + (ρ+a*(1-β))*z + a*β := by ring


/-- The physical first-order lag supplies a pole strictly between zero and one. -/
theorem zoh_sampled_pole_range {T τ : ℝ} (hT : 0 < T) (hτ : 0 < τ) :
    0 < Real.exp (-T/τ) ∧ Real.exp (-T/τ) < 1 := by
  refine ⟨Real.exp_pos _, Real.exp_lt_one_iff.mpr ?_⟩
  exact div_neg_of_neg_of_pos (neg_neg_of_pos hT) hτ


/-- Boundary factorization; the remaining linear root is `-a*beta`. -/
theorem zoh_boundary_factorization (z ρ a β : ℝ)
    (hF : zohF ρ a β = 0) :
    z^3 - (1+ρ)*z^2 + (ρ+a*(1-β))*z + a*β =
      (z+a*β) * (z^2 - (1+ρ+a*β)*z + 1) := by
  unfold zohF at hF
  linear_combination -z * hF

end C2
