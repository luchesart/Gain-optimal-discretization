import C2.NGammaRealizationCausal
import C2.NGammaRealizationDelay
import C2.NGammaDiagonal

/-! Exact characteristic polynomial of the concrete delayed feedback matrix.
Polynomial continuation closes the singular-point cases left out of a
resolvent computation, so cancelled transfer modes are retained. -/
noncomputable section
namespace C2.NGamma.Realization
open Matrix Polynomial
variable {𝕜 : Type} [Field 𝕜] [Infinite 𝕜]

/-- The actual delayed feedback matrix has the uncancelled causal polynomial. -/
theorem delayed_charpoly (S : Delay.StateSpace 𝕜) {d : ℕ} (hd : 0 < d) (k : 𝕜) :
    (Delay.closedLoop (Delay.delay S d) k).charpoly =
      X^d * S.A.charpoly + Polynomial.C k * causalNumerator S.A S.B S.C S.D := by
  let R := (Delay.closedLoop (Delay.delay S d) k).charpoly -
    (X^d * S.A.charpoly + Polynomial.C k * causalNumerator S.A S.B S.C S.D)
  have hp : (X * S.A.charpoly) * R = 0 := by
    apply Polynomial.funext
    intro z
    simp only [Polynomial.eval_mul, Polynomial.eval_X, Polynomial.eval_zero]
    by_cases hz : z = 0
    · rw [hz, zero_mul, zero_mul]
    by_cases hM : (Delay.pencil S z).det = 0
    · rw [charpoly_eval]
      change (z * (Delay.pencil S z).det) * _ = 0
      rw [hM, mul_zero, zero_mul]
    · have ht := Delay.delayed_closedLoop_determinant S hd z k hz hM
      have hq := causalNumerator_quotient S.A S.B S.C S.D z hM
      change Delay.transfer S z = _ at hq
      rw [charpoly_eval] at hq
      have hn : (Delay.pencil S z).det * Delay.transfer S z =
          (causalNumerator S.A S.B S.C S.D).eval z := by
        rw [hq]
        exact mul_div_cancel₀ _ hM
      have hr : R.eval z = 0 := by
        dsimp [R]
        simp only [Polynomial.eval_sub, Polynomial.eval_add, Polynomial.eval_mul,
          Polynomial.eval_pow, Polynomial.eval_X, Polynomial.eval_C, charpoly_eval]
        change _ - (z^d*(Delay.pencil S z).det + _) = 0
        rw [ht, hn, sub_self]
      rw [hr, mul_zero]
  have hn := (mul_eq_zero.mp hp).resolve_left
    (mul_ne_zero Polynomial.X_ne_zero (Matrix.charpoly_monic S.A).ne_zero)
  exact sub_eq_zero.mp hn

variable {ι : Type} [Fintype ι] [DecidableEq ι]

/-- The concrete shifted causal realization of the independently weighted
 state scheme. -/
def causalStateSpace (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D : 𝕜) :
    Delay.StateSpace 𝕜 where
  State := ι
  fintype := inferInstance
  decEq := inferInstance
  A := Ad T Γ A
  B := Bd T Γ A B
  C := C
  D := D + dotProduct C (B0 T Γ A B)

/-- Exact aligned-delay polynomial identity for the actual n+d state matrix. -/
theorem aligned_characteristic (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D k : 𝕜)
    {d : ℕ} (hd : 0 < d) (hE : (E T Γ A).det ≠ 0) :
    Polynomial.C (E T Γ A).det *
        (Delay.closedLoop (Delay.delay (causalStateSpace T Γ A B C D) d) k).charpoly =
      X^d * denominator T Γ A + Polynomial.C k * numerator T Γ A B C D := by
  rw [delayed_charpoly _ hd, denominator_eq_charpoly T Γ A hE,
    numerator_eq_causal T Γ A B C D hE]
  dsimp only [causalStateSpace]
  ring

/-- The displayed determinant quotient holds at all z, even plant eigenvalues
 or z=0, because it is derived from a polynomial identity. -/
theorem aligned_characteristic_eval (T z : 𝕜) (Γ A : Matrix ι ι 𝕜)
    (B C : ι → 𝕜) (D k : 𝕜) {d : ℕ} (hd : 0 < d) (hE : (E T Γ A).det ≠ 0) :
    (z • (1 : Matrix (Delay.delay (causalStateSpace T Γ A B C D) d).State
        (Delay.delay (causalStateSpace T Γ A B C D) d).State 𝕜) -
      Delay.closedLoop (Delay.delay (causalStateSpace T Γ A B C D) d) k).det =
      (z^d*(denominator T Γ A).eval z+k*(numerator T Γ A B C D).eval z) / (E T Γ A).det := by
  have h := congrArg (Polynomial.eval z) (aligned_characteristic T Γ A B C D k hd hE)
  simp only [Polynomial.eval_mul, Polynomial.eval_add, Polynomial.eval_pow,
    Polynomial.eval_X, Polynomial.eval_C, charpoly_eval] at h
  exact (eq_div_iff hE).mpr (by simpa only [mul_comm] using h)

/-- The actual augmented state dimension is n+d. -/
theorem aligned_state_count (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D : 𝕜) (d : ℕ) :
    Fintype.card (Delay.delay (causalStateSpace T Γ A B C D) d).State = Fintype.card ι + d :=
  Delay.delay_card _ _

/-- Retaining the determinant polynomial preserves every complex closed-loop
 mode; Schur stability is exactly equivalent on the two sides. -/
theorem aligned_schur_iff (T : ℝ) (Γ A : Matrix ι ι ℝ) (B C : ι → ℝ) (D k : ℝ)
    {d : ℕ} (hd : 0 < d) (hE : (E T Γ A).det ≠ 0) :
    C2.NGamma.MatrixSchurStable
        (Delay.closedLoop (Delay.delay (causalStateSpace T Γ A B C D) d) k) ↔
      ∀ z : ℂ, ((X^d * denominator T Γ A + Polynomial.C k * numerator T Γ A B C D).map
        Complex.ofRealHom).eval z = 0 → ‖z‖ < 1 := by
  have hc : ((E T Γ A).det : ℂ) ≠ 0 := by exact_mod_cast hE
  have hp := congrArg (Polynomial.map Complex.ofRealHom)
    (aligned_characteristic T Γ A B C D k hd hE)
  simp only [Polynomial.map_mul, Polynomial.map_C] at hp
  have he (z : ℂ) :
      ((X^d * denominator T Γ A + Polynomial.C k * numerator T Γ A B C D).map
        Complex.ofRealHom).eval z = 0 ↔
      (C2.NGamma.complexify
        (Delay.closedLoop (Delay.delay (causalStateSpace T Γ A B C D) d) k)).charpoly.eval z = 0 := by
    rw [← hp, Polynomial.eval_mul, Polynomial.eval_C, mul_eq_zero]
    simp only [Complex.ofRealHom_eq_coe, hc, false_or]
    rw [← Matrix.charpoly_map _ Complex.ofRealHom]
    rfl
  constructor
  · intro h z hz
    exact h z ((he z).mp hz)
  · intro h z hz
    exact h z ((he z).mpr hz)

end C2.NGamma.Realization
