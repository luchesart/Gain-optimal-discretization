import C2.NGammaPolynomial

/-! A direct exterior-disk proof of the initial stable gain interval.
The estimate is strict away from z=1 and therefore includes b=product r.
It requires no root-continuation or winding-number assumption. -/
noncomputable section
open scoped BigOperators
open Polynomial
namespace C2.NGamma.PolynomialModel

/-- Exact exterior-disk energy identity for a single cascade factor. -/
theorem factor_norm_gap (r x : ℝ) (z : ℂ) :
    ‖(factor r x).eval z‖^2 - r^2 * ‖(q x).eval z‖^2 =
      (1+r*x)*‖z-1‖^2 + r*(‖z‖^2-1) := by
  simp only [Complex.sq_norm, Complex.normSq_apply, factor_eval, q_eval]
  simp [Complex.add_re, Complex.add_im, Complex.sub_re, Complex.sub_im,
    Complex.mul_re, Complex.mul_im, Complex.div_re, Complex.div_im,
    Complex.normSq_apply]
  ring

/-- Outside the open unit disk, every nontrivial factor dominates r*q strictly. -/
theorem factor_norm_gt_mul_q {r x : ℝ} (hr : 0 < r) (hx : 0 ≤ x)
    {z : ℂ} (hz : 1 ≤ ‖z‖) (hz1 : z ≠ 1) :
    r * ‖(q x).eval z‖ < ‖(factor r x).eval z‖ := by
  have hgap := factor_norm_gap r x z
  have hcoeff : 0 < 1+r*x := by nlinarith [mul_nonneg hr.le hx]
  have hnorm : 0 < ‖z-1‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hz1)
  have hpos : 0 < (1+r*x)*‖z-1‖^2 := mul_pos hcoeff (sq_pos_of_pos hnorm)
  have hnonneg : 0 ≤ r*(‖z‖^2-1) := mul_nonneg hr.le (by nlinarith)
  have hsq : (r * ‖(q x).eval z‖)^2 < ‖(factor r x).eval z‖^2 := by
    nlinarith
  nlinarith [norm_nonneg ((factor r x).eval z),
    mul_nonneg hr.le (norm_nonneg ((q x).eval z))]

variable {ι : Type*} [Fintype ι] [DecidableEq ι] [Nonempty ι]

/-- The entire closed low-gain interval is strictly Schur stable. This holds
 for all delays d>=0 and all nonnegative weights, hence in particular for
 the manuscript's d>=1 and x in [0,1]. -/
theorem low_gain_schur {r x : ι → ℝ} (hr : ∀ i, 0 < r i)
    (hx : ∀ i, 0 ≤ x i) (d : ℕ) {b : ℝ} (hb : 0 ≤ b) (hB : b ≤ ∏ i, r i) :
    SchurStable (characteristic r x d b) := by
  intro z hroot
  by_contra! hz
  have hz1 : z ≠ 1 := by
    intro he
    subst z
    exact one_not_root hr d hb hroot
  have hf (i : ι) : 0 < ‖(factor (r i) (x i)).eval z‖ := by
    have hs := factor_norm_gt_mul_q (hr i) (hx i) hz hz1
    exact lt_of_le_of_lt (mul_nonneg (hr i).le (norm_nonneg _)) hs
  have hF : 0 < ∏ i, ‖(factor (r i) (x i)).eval z‖ :=
    Finset.prod_pos (fun i _ => hf i)
  have hp : 1 ≤ ‖z‖^d := one_le_pow₀ hz
  have hnorm : ‖z‖^d * ∏ i, ‖(factor (r i) (x i)).eval z‖ =
      b * ∏ i, ‖(q (x i)).eval z‖ := by
    have he : z^d * ∏ i, (factor (r i) (x i)).eval z =
        -((b : ℂ) * ∏ i, (q (x i)).eval z) := by
      apply eq_neg_of_add_eq_zero_left
      simpa only [characteristic, eval_add, eval_mul, eval_pow, eval_X, eval_C, eval_prod] using hroot
    have hn := congrArg norm he
    simpa only [norm_mul, norm_pow, norm_prod, norm_neg, Complex.norm_real,
      Real.norm_eq_abs, abs_of_nonneg hb] using hn
  by_cases hQ : ∏ i, ‖(q (x i)).eval z‖ = 0
  · rw [hQ, mul_zero] at hnorm
    have hpos := mul_pos (lt_of_lt_of_le zero_lt_one hp) hF
    linarith
  · have hq (i : ι) : 0 < r i * ‖(q (x i)).eval z‖ := by
      have hn := Finset.prod_ne_zero_iff.mp hQ i (Finset.mem_univ i)
      exact mul_pos (hr i) (lt_of_le_of_ne (norm_nonneg _) (Ne.symm hn))
    have hprod : (∏ i, r i) * ∏ i, ‖(q (x i)).eval z‖ <
        ∏ i, ‖(factor (r i) (x i)).eval z‖ := by
      rw [← Finset.prod_mul_distrib]
      exact Finset.prod_lt_prod_of_nonempty (fun i _ => hq i)
        (fun i _ => factor_norm_gt_mul_q (hr i) (hx i) hz hz1) Finset.univ_nonempty
    have hQnonneg : 0 ≤ ∏ i, ‖(q (x i)).eval z‖ :=
      Finset.prod_nonneg (fun i _ => norm_nonneg ((q (x i)).eval z))
    have hlow := mul_le_mul_of_nonneg_right hB hQnonneg
    have hhigh : (∏ i, ‖(factor (r i) (x i)).eval z‖) ≤
        ‖z‖^d * ∏ i, ‖(factor (r i) (x i)).eval z‖ := by
      nlinarith
    linarith

/-- The finite-index version used by the gain-interval theorem. -/
theorem low_gain_schur_fin {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) (d : ℕ)
    {b : ℝ} (hb : 0 ≤ b) (hB : b ≤ ∏ i, r i) :
    SchurStable (characteristic r x d b) := by
  letI : Nonempty (Fin n) := ⟨⟨0,hn⟩⟩
  exact low_gain_schur hr hx d hb hB

end C2.NGamma.PolynomialModel
