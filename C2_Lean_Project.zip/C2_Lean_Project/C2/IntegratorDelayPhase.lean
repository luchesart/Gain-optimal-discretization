import C2.IntegratorDelayGain
import Mathlib.Topology.Order.IntermediateValue

noncomputable section
namespace C2.IntegratorDelay

/-- Centered-chord phase; `x = 2γ − 1`. On `0 < w < π` this is
`(n+1/2)w − arg(1−γ+γ exp(iw))`. -/
def lowPhase (n : ℕ) (x w : ℝ) : ℝ :=
  (n : ℝ) * w - Real.arctan (x * Real.tan (w / 2))

def totalPhase (n : ℕ) (x t : ℝ) : ℝ :=
  2 * (n : ℝ) * Real.arctan t + Real.pi / 2 - Real.arctan (x * t)

theorem totalPhase_eq_lowPhase (n : ℕ) (x t : ℝ) :
    totalPhase n x t = lowPhase n x (2 * Real.arctan t) + Real.pi / 2 := by
  simp only [totalPhase, lowPhase]
  have h : 2 * Real.arctan t / 2 = Real.arctan t := by ring
  rw [h, Real.tan_arctan]
  ring

theorem lowPhase_hasDerivAt (n : ℕ) (x : ℝ) {w : ℝ}
    (hc : Real.cos (w / 2) ≠ 0) :
    HasDerivAt (lowPhase n x)
      ((n : ℝ) - x / (2 * Real.cos (w / 2) ^ 2 *
        (1 + (x * Real.tan (w / 2)) ^ 2))) w := by
  have ht := (Real.hasDerivAt_tan hc).comp w ((hasDerivAt_id w).div_const 2)
  have ha := (Real.hasDerivAt_arctan (x * Real.tan (w / 2))).comp w (ht.const_mul x)
  convert ((hasDerivAt_id w).const_mul (n : ℝ)).sub ha using 1
  simp only [mul_one]
  field_simp
  ring

theorem lowPhase_deriv_pos {n : ℕ} (hn : 2 ≤ n) {x w : ℝ} (hx : x ≤ 1)
    (hw : w ∈ Set.Icc 0 (Real.pi / 2)) : 0 < deriv (lowPhase n x) w := by
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  have hw0 := hw.1
  have hw1 := hw.2
  have hc : 0 < Real.cos (w / 2) := Real.cos_pos_of_mem_Ioo
    ⟨by linarith [Real.pi_pos], by linarith [Real.pi_pos]⟩
  have hcos : 0 ≤ Real.cos w := Real.cos_nonneg_of_mem_Icc
    ⟨by linarith [Real.pi_pos], hw.2⟩
  have hdouble : Real.cos w = 2 * Real.cos (w / 2) ^ 2 - 1 := by
    convert Real.cos_two_mul (w / 2) using 1 <;> ring
  have hc2 : 1 / 2 ≤ Real.cos (w / 2) ^ 2 := by linarith
  have hd : 0 < 2 * Real.cos (w / 2) ^ 2 *
      (1 + (x * Real.tan (w / 2)) ^ 2) := by positivity
  have hd1 : 1 ≤ 2 * Real.cos (w / 2) ^ 2 *
      (1 + (x * Real.tan (w / 2)) ^ 2) := by
    nlinarith [mul_nonneg (sq_nonneg (Real.cos (w / 2)))
      (sq_nonneg (x * Real.tan (w / 2)))]
  have hdiv : x / (2 * Real.cos (w / 2) ^ 2 *
      (1 + (x * Real.tan (w / 2)) ^ 2)) ≤ 1 :=
    (div_le_one hd).2 (le_trans hx hd1)
  rw [(lowPhase_hasDerivAt n x hc.ne').deriv]
  linarith

theorem lowPhase_strictMonoOn {n : ℕ} (hn : 2 ≤ n) {x : ℝ} (hx : x ≤ 1) :
    StrictMonoOn (lowPhase n x) (Set.Icc 0 (Real.pi / 2)) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc _ _) ?_ ?_
  · intro w hw
    have hw0 := hw.1
    have hw1 := hw.2
    have hc : 0 < Real.cos (w / 2) := Real.cos_pos_of_mem_Ioo
      ⟨by linarith [Real.pi_pos], by linarith [Real.pi_pos]⟩
    exact (lowPhase_hasDerivAt n x hc.ne').continuousAt.continuousWithinAt
  · intro w hw
    exact lowPhase_deriv_pos hn hx (interior_subset hw)

theorem lowPhase_chord_bounds {n : ℕ} {x w : ℝ}
    (hx0 : -1 ≤ x) (hx1 : x ≤ 1) (hw0 : 0 ≤ w) (hwpi : w < Real.pi) :
    ((n : ℝ) - 1 / 2) * w ≤ lowPhase n x w ∧
      lowPhase n x w ≤ ((n : ℝ) + 1 / 2) * w := by
  have ht : 0 ≤ Real.tan (w / 2) :=
    Real.tan_nonneg_of_nonneg_of_le_pi_div_two (by linarith) (by linarith)
  have hlo : -Real.tan (w / 2) ≤ x * Real.tan (w / 2) := by nlinarith
  have hhi : x * Real.tan (w / 2) ≤ Real.tan (w / 2) := by nlinarith
  have ha1 := Real.arctan_le_arctan hlo
  have ha2 := Real.arctan_le_arctan hhi
  have hid : Real.arctan (Real.tan (w / 2)) = w / 2 :=
    Real.arctan_tan (by linarith [Real.pi_pos]) (by linarith)
  rw [Real.arctan_neg, hid] at ha1
  rw [hid] at ha2
  unfold lowPhase
  constructor <;> nlinarith

theorem frequency_interval_order {n : ℕ} (hn : 2 ≤ n) :
    lowerFrequency n ≤ upperFrequency n := by
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  unfold lowerFrequency upperFrequency
  apply (div_le_div_iff₀ (by positivity) (by linarith)).2
  nlinarith [Real.pi_pos]

/-- Existence and uniqueness of the manuscript's first frequency branch. -/
theorem existsUnique_low_frequency {n : ℕ} (hn : 2 ≤ n) {x : ℝ}
    (hx0 : -1 ≤ x) (hx1 : x ≤ 1) :
    ∃! w : ℝ, w ∈ Set.Icc (lowerFrequency n) (upperFrequency n) ∧
      lowPhase n x w = Real.pi / 2 := by
  have horder := frequency_interval_order hn
  have hl := frequency_bounds hn (show lowerFrequency n ∈
    Set.Icc (lowerFrequency n) (upperFrequency n) from ⟨le_rfl, horder⟩)
  have hu := frequency_bounds hn (show upperFrequency n ∈
    Set.Icc (lowerFrequency n) (upperFrequency n) from ⟨horder, le_rfl⟩)
  have hlo := (lowPhase_chord_bounds (n := n) hx0 hx1 hl.1.le
    (show lowerFrequency n < Real.pi by linarith [hl.2.1, Real.pi_pos])).2
  have hhi := (lowPhase_chord_bounds (n := n) hx0 hx1 hu.1.le
    (show upperFrequency n < Real.pi by linarith [hu.2.1, Real.pi_pos])).1
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  have helo : ((n : ℝ) + 1 / 2) * lowerFrequency n = Real.pi / 2 := by
    unfold lowerFrequency
    field_simp
    ring
  have hehi : ((n : ℝ) - 1 / 2) * upperFrequency n = Real.pi / 2 := by
    unfold upperFrequency
    have hd : 2 * (n : ℝ) - 1 ≠ 0 := by linarith
    field_simp
    ring
  rw [helo] at hlo
  rw [hehi] at hhi
  have hcont : ContinuousOn (lowPhase n x)
      (Set.Icc (lowerFrequency n) (upperFrequency n)) := by
    intro w hw
    have hw' := frequency_bounds hn hw
    have hc : 0 < Real.cos (w / 2) := Real.cos_pos_of_mem_Ioo
      ⟨by linarith [hw'.1, Real.pi_pos], by linarith [hw'.2.1, Real.pi_pos]⟩
    exact (lowPhase_hasDerivAt n x hc.ne').continuousAt.continuousWithinAt
  obtain ⟨w, hw, he⟩ := intermediate_value_Icc horder hcont ⟨hlo, hhi⟩
  refine ⟨w, ⟨hw, he⟩, ?_⟩
  intro v hv
  have hw' := frequency_bounds hn hw
  have hv' := frequency_bounds hn hv.1
  apply (lowPhase_strictMonoOn hn hx1).injOn
    ⟨hv'.1.le, by linarith [hv'.2.1, Real.pi_pos]⟩
    ⟨hw'.1.le, by linarith [hw'.2.1, Real.pi_pos]⟩
  exact hv.2.trans he.symm

def frequency (n : ℕ) (x : ℝ) : ℝ :=
  if h : 2 ≤ n ∧ -1 ≤ x ∧ x ≤ 1 then
    Classical.choose (existsUnique_low_frequency h.1 h.2.1 h.2.2)
  else 0

theorem frequency_spec {n : ℕ} (hn : 2 ≤ n) {x : ℝ}
    (hx0 : -1 ≤ x) (hx1 : x ≤ 1) :
    frequency n x ∈ Set.Icc (lowerFrequency n) (upperFrequency n) ∧
      lowPhase n x (frequency n x) = Real.pi / 2 := by
  simp only [frequency, dif_pos (show 2 ≤ n ∧ -1 ≤ x ∧ x ≤ 1 from ⟨hn, hx0, hx1⟩)]
  exact (Classical.choose_spec (existsUnique_low_frequency hn hx0 hx1)).1

theorem lowPhase_strictAnti_parameter {n : ℕ} {x y w : ℝ}
    (hxy : x < y) (hw0 : 0 < w) (hwpi : w < Real.pi) :
    lowPhase n y w < lowPhase n x w := by
  have ht : 0 < Real.tan (w / 2) :=
    Real.tan_pos_of_pos_of_lt_pi_div_two (by linarith) (by linarith)
  have h := Real.arctan_lt_arctan (mul_lt_mul_of_pos_right hxy ht)
  unfold lowPhase
  linarith

theorem frequency_strictMonoOn {n : ℕ} (hn : 2 ≤ n) :
    StrictMonoOn (frequency n) (Set.Icc (-1) 1) := by
  intro x hx y hy hxy
  have hfx := frequency_spec hn hx.1 hx.2
  have hfy := frequency_spec hn hy.1 hy.2
  have hbx := frequency_bounds hn hfx.1
  have hby := frequency_bounds hn hfy.1
  have hp := lowPhase_strictAnti_parameter (n := n) hxy hbx.1
    (show frequency n x < Real.pi by linarith [hbx.2.1, Real.pi_pos])
  rw [hfx.2, ← hfy.2] at hp
  exact (lowPhase_strictMonoOn hn hy.2).lt_iff_lt
    ⟨hbx.1.le, by linarith [hbx.2.1, Real.pi_pos]⟩
    ⟨hby.1.le, by linarith [hby.2.1, Real.pi_pos]⟩ |>.mp hp

theorem lowPhase_lt_halfpi_iff {n : ℕ} (hn : 2 ≤ n) {x w : ℝ}
    (hx0 : -1 ≤ x) (hx1 : x ≤ 1) (hw0 : 0 < w) (hwpi : w < Real.pi) :
    lowPhase n x w < Real.pi / 2 ↔ w < frequency n x := by
  have hf := frequency_spec hn hx0 hx1
  have hbf := frequency_bounds hn hf.1
  by_cases hw : w ≤ upperFrequency n
  · have hu := frequency_bounds hn ⟨frequency_interval_order hn, le_rfl⟩
    rw [← hf.2]
    exact (lowPhase_strictMonoOn hn hx1).lt_iff_lt
      ⟨hw0.le, by linarith [hu.2.1, Real.pi_pos]⟩
      ⟨hbf.1.le, by linarith [hbf.2.1, Real.pi_pos]⟩
  · have hwu : upperFrequency n < w := lt_of_not_ge hw
    have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
    have hd : 0 < 2 * (n : ℝ) - 1 := by linarith
    have hgt : Real.pi < w * (2 * (n : ℝ) - 1) := (div_lt_iff₀ hd).mp hwu
    have hp := (lowPhase_chord_bounds (n := n) hx0 hx1 hw0.le hwpi).1
    exact iff_of_false (by linarith) (by linarith [hf.1.2])

theorem totalPhase_pos {n : ℕ} (hn : 2 ≤ n) {x t : ℝ}
    (hx : x ≤ 1) (ht : 0 ≤ t) : 0 < totalPhase n x t := by
  have hmul : x * t ≤ t := by nlinarith
  have ha := Real.arctan_le_arctan hmul
  have ht0 : 0 ≤ Real.arctan t := by simpa using Real.arctan_le_arctan ht
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  unfold totalPhase
  nlinarith [Real.pi_pos]

theorem totalPhase_lt_pi_iff {n : ℕ} (hn : 2 ≤ n) {x t : ℝ}
    (hx0 : -1 ≤ x) (hx1 : x ≤ 1) (ht : 0 < t) :
    totalPhase n x t < Real.pi ↔ 2 * Real.arctan t < frequency n x := by
  have hat : 0 < Real.arctan t := by simpa using Real.arctan_lt_arctan ht
  have hapi := Real.arctan_lt_pi_div_two t
  rw [totalPhase_eq_lowPhase]
  have h := lowPhase_lt_halfpi_iff hn hx0 hx1
    (show 0 < 2 * Real.arctan t by positivity) (show 2 * Real.arctan t < Real.pi by linarith)
  convert h using 1 <;> constructor <;> intro hh <;> linarith

end C2.IntegratorDelay
