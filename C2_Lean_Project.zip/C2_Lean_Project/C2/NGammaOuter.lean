import C2.NGammaDualDerivative
import C2.NGammaValueContinuity
import C2.NGammaFrequency

/-! Strict decrease of the actual constrained optimal log gain. The proof
uses a continuous compact dual minimum and differentiable upper supports.
It includes clipping changes and both positive feasible endpoints. -/

noncomputable section
open scoped BigOperators Topology
open Set Filter
namespace C2.NGamma.Global

def frequencyValue {n : ℕ} (r : Fin n → ℝ) (w : ℝ) : ℝ :=
  if h : 0 < w then compactDualValue r ⟨w,h⟩ else 0

theorem frequencyValue_eq_gain {n : ℕ} (r : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {w lam : ℝ} (hw : 0 < w)
    (hphase : frequencyAllocatedPhase r w lam = 2*Real.arctan w) :
    frequencyValue r w = ∑ j, allocationLogGain (r j) (frequencyAllocation (r j) w lam) w := by
  simp only [frequencyValue,dif_pos hw]
  exact compactDualValue_eq_gain r hr ⟨w,hw⟩ hphase

theorem exp_frequencyValue_eq_product {n : ℕ} (r : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {w lam : ℝ} (hw : 0 < w)
    (hphase : frequencyAllocatedPhase r w lam = 2*Real.arctan w) :
    Real.exp (frequencyValue r w) =
      ∏ j, allocationGain (r j) (frequencyAllocation (r j) w lam) w := by
  have hlog : Real.log (∏ j, allocationGain (r j) (frequencyAllocation (r j) w lam) w) =
      frequencyValue r w := by
    rw [Real.log_prod _ _ (fun j _ => ne_of_gt (allocationGain_pos (hr j) hw _))]
    simp_rw [log_allocationGain (hr _) hw]
    exact (frequencyValue_eq_gain r hr hw hphase).symm
  rw [← hlog,Real.exp_log (Finset.prod_pos (fun j _ => allocationGain_pos (hr j) hw _))]

theorem exists_balancing_multiplier {n : ℕ} (r : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {w : ℝ} (hw : 0 < w) (hf : feasible r w) :
    ∃ lam, frequencyAllocatedPhase r w lam = 2*Real.arctan w := by
  obtain ⟨x,hx,hphase⟩ := hf
  have hb := allocation_phase_bounds r hr hw x hx
  exact exists_frequency_multiplier r hr hw (hphase ▸ hb.1) (hphase ▸ hb.2)

theorem frequencyValue_is_unique_maximum {n : ℕ} (r : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) {w : ℝ} (hw : 0 < w) (hf : feasible r w) :
    ∃ xstar : Fin n → ℝ, (∀ j, xstar j ∈ Icc (0:ℝ) 1) ∧
      (∑ j, allocationPhase (r j) (xstar j) w) = 2*Real.arctan w ∧
      frequencyValue r w = (∑ j, allocationLogGain (r j) (xstar j) w) ∧
      ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) →
        (∑ j, allocationPhase (r j) (x j) w) = 2*Real.arctan w →
        (∑ j, allocationLogGain (r j) (x j) w) ≤ frequencyValue r w ∧
        ((∑ j, allocationLogGain (r j) (x j) w) = frequencyValue r w ↔ x = xstar) := by
  obtain ⟨lam,hlam⟩ := exists_balancing_multiplier r hr hw hf
  refine ⟨fun j => frequencyAllocation (r j) w lam,
    fun j => frequencyAllocation_mem _ _ _,hlam,frequencyValue_eq_gain r hr hw hlam,?_⟩
  intro x hx hphase
  have heq : (∑ j, allocationPhase (r j) (x j) w) = frequencyAllocatedPhase r w lam :=
    hphase.trans hlam.symm
  rw [frequencyValue_eq_gain r hr hw hlam]
  refine ⟨frequencyAllocation_log_optimal r hr hw x hx heq,?_⟩
  constructor
  · intro hg
    by_contra hne
    exact (ne_of_lt (frequencyAllocation_log_optimal_strict r hr hw x hx heq hne)) hg
  · intro h
    rw [h]

/-- At an all-one endpoint a maximal marginal gives a multiplier strictly
below 1/w; hence the upper-support slope is still strictly negative. -/
theorem exists_negative_envelope_multiplier {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) {w : ℝ}
    (hw : 0 < w) (hf : feasible r w) :
    ∃ lam, frequencyAllocatedPhase r w lam = 2*Real.arctan w ∧
      envelope r (fun j => frequencyAllocation (r j) w lam) w lam < 0 := by
  obtain ⟨lam,hlam⟩ := exists_balancing_multiplier r hr hw hf
  have hb := allocation_phase_bounds r hr hw (fun j => frequencyAllocation (r j) w lam)
    (fun j => frequencyAllocation_mem _ _ _)
  have hlo : (∑ j, allocationPhase (r j) 1 w) ≤ 2*Real.arctan w := hlam ▸ hb.1
  rcases hlo.lt_or_eq with hstrict | hone
  · exact ⟨lam,hlam,clipped_envelope_neg hn r hr hw hlam hstrict⟩
  obtain ⟨i,hi,hmax⟩ := Finset.exists_max_image Finset.univ
    (fun j : Fin n => allocationMarginal (r j) 1 w) ⟨⟨0,hn⟩,Finset.mem_univ _⟩
  let mu := allocationMarginal (r i) 1 w
  have hone' : ∀ j, frequencyAllocation (r j) w mu = 1 := fun j =>
    frequencyAllocation_one_of (hr j) hw (hmax j (Finset.mem_univ j))
  have hfun : (fun j => frequencyAllocation (r j) w mu) = fun _ => 1 := funext hone'
  have hbalance : frequencyAllocatedPhase r w mu = 2*Real.arctan w := by
    unfold frequencyAllocatedPhase
    simp_rw [hone']
    exact hone
  refine ⟨mu,hbalance,?_⟩
  by_cases hmu : 0 < mu
  · have hm : mu*w < 1 := (lt_div_iff₀ hw).mp (marginal_below_x_div_w (hr i) (by norm_num) hw)
    rw [hfun]
    exact envelope_neg_positive hn r (fun _ => 1) hr (fun _ => by norm_num)
      hw hmu (fun _ => hm) hone
  · exact envelope_neg_nonpositive hn r _ hr
      (fun j => (frequencyAllocation_mem (r j) w mu).1) hw (le_of_not_gt hmu)
      (kkt_nonpositive_products r _ hr (fun j => frequencyAllocation_mem _ _ _) hw
        (le_of_not_gt hmu) (clipped_KKT r hr hw))

theorem frequencyValue_strictAntiOn_interval {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) {a b : ℝ}
    (hpos : ∀ w ∈ Icc a b, 0 < w)
    (hfeasible : ∀ w ∈ Icc a b, feasible r w) :
    StrictAntiOn (frequencyValue r) (Icc a b) := by
  have hF : ∀ w ∈ Icc a b, ∃ lam,
      frequencyAllocatedPhase r w lam = 2*Real.arctan w ∧
      frequencyValue r w = ∑ j, allocationLogGain (r j) (frequencyAllocation (r j) w lam) w := by
    intro w hw
    obtain ⟨lam,hlam⟩ := exists_balancing_multiplier r hr (hpos w hw) (hfeasible w hw)
    exact ⟨lam,hlam,frequencyValue_eq_gain r hr (hpos w hw) hlam⟩
  have hcont := frequencyValue_continuousOn r hr (frequencyValue r) (Icc a b) hpos hF
  apply strictAntiOn_of_upper_support hcont
  intro w hw
  obtain ⟨lam,hlam,hneg⟩ := exists_negative_envelope_multiplier hn r hr (hpos w hw) (hfeasible w hw)
  refine ⟨fun v => dualValue r v lam,
    envelope r (fun j => frequencyAllocation (r j) w lam) w lam,
    dualValue_hasDerivAt r hr (hpos w hw),hneg,?_,?_⟩
  · exact (dualValue_eq_gain r hlam).trans (frequencyValue_eq_gain r hr (hpos w hw) hlam).symm
  · intro v hv
    obtain ⟨mu,hmu,hgain⟩ := hF v hv
    rw [hgain]
    exact gain_le_dualValue r _ hr (fun j => frequencyAllocation_mem _ _ _) (hpos v hv) hmu

theorem feasible_between {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {a b w : ℝ} (ha : 0 < a) (hb : 0 < b) (hfa : feasible r a) (hfb : feasible r b)
    (haw : a ≤ w) (hwb : w ≤ b) : feasible r w := by
  have hw : 0 < w := lt_of_lt_of_le ha haw
  obtain ⟨wp,hwp,hcross,hsmall,hlarge⟩ := feasible_frequency_interval hn r hr
  by_cases hS : endpointSum r ≤ 1
  · exact (hsmall hS w hw).2 (le_trans hwb ((hsmall hS b hb).1 hfb))
  · obtain ⟨wm,hwm,hmwp,hmc,hinterval⟩ := hlarge (lt_of_not_ge hS)
    exact (hinterval w hw).2
      ⟨le_trans ((hinterval a ha).1 hfa).1 haw,le_trans hwb ((hinterval b hb).1 hfb).2⟩

/-- Full outer-monotonicity conclusion for the exact allocation optimum on
the entire positive feasible-frequency interval. -/
theorem frequencyValue_strictAntiOn_feasible {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    StrictAntiOn (frequencyValue r) {w : ℝ | 0 < w ∧ feasible r w} := by
  intro a ha b hb hab
  have hm := frequencyValue_strictAntiOn_interval hn r hr
    (a := a) (b := b) (fun w hw => lt_of_lt_of_le ha.1 hw.1)
    (fun w hw => feasible_between hn r hr ha.1 hb.1 ha.2 hb.2 hw.1 hw.2)
  exact hm ⟨le_refl _,hab.le⟩ ⟨hab.le,le_refl _⟩ hab

theorem frequencyValue_continuousOn_feasible {n : ℕ}
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    ContinuousOn (frequencyValue r) {w : ℝ | 0 < w ∧ feasible r w} := by
  apply frequencyValue_continuousOn r hr _ _ (fun w hw => hw.1)
  intro w hw
  obtain ⟨lam,hlam⟩ := exists_balancing_multiplier r hr hw.1 hw.2
  exact ⟨lam,hlam,frequencyValue_eq_gain r hr hw.1 hlam⟩

/-- Full frequency-domain optimization in the branch with a positive lower
endpoint: the only maximizing pair is that endpoint and the all-one vector.
The separate Schur gain-interval theorem translates this into a stability margin. -/
theorem positive_endpoint_unique_global_maximum {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hS : 1 < endpointSum r) :
    ∃ wm : ℝ, 0 < wm ∧
      (∑ j, allocationPhase (r j) 1 wm) = 2*Real.arctan wm ∧
      ∀ w : ℝ, 0 < w → ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) →
        (∑ j, allocationPhase (r j) (x j) w) = 2*Real.arctan w →
        (∑ j, allocationLogGain (r j) (x j) w) ≤ (∑ j, allocationLogGain (r j) 1 wm) ∧
        ((∑ j, allocationLogGain (r j) (x j) w) = (∑ j, allocationLogGain (r j) 1 wm) ↔
          w = wm ∧ x = fun _ => 1) := by
  obtain ⟨wp,hwp,hpc,hsmall,hlarge⟩ := feasible_frequency_interval hn r hr
  obtain ⟨wm,hwm,hmwp,hmc,hinterval⟩ := hlarge hS
  have hone : (∑ j, allocationPhase (r j) 1 wm) = 2*Real.arctan wm :=
    (ratio_eq_two_iff_phase_eq r (fun _ => 1) hwm).mp hmc
  have hfm : feasible r wm := ⟨fun _ => 1,fun _ => by norm_num,hone⟩
  obtain ⟨xm,hxm,hpm,hvm,hmaxm⟩ := frequencyValue_is_unique_maximum r hr hwm hfm
  have hxmone : xm = fun _ => 1 := funext (lower_frequency_vector_unique r xm hr hwm hone hxm hpm)
  have hvmone : frequencyValue r wm = ∑ j, allocationLogGain (r j) 1 wm := by
    simpa only [hxmone] using hvm
  refine ⟨wm,hwm,hone,?_⟩
  intro w hw x hx hp
  have hfw : feasible r w := ⟨x,hx,hp⟩
  have hmlew := ((hinterval w hw).mp hfw).1
  obtain ⟨xs,hxs,hps,hvs,hmax⟩ := frequencyValue_is_unique_maximum r hr hw hfw
  have hgainle := (hmax x hx hp).1
  have hvalle : frequencyValue r w ≤ frequencyValue r wm :=
    (frequencyValue_strictAntiOn_feasible hn r hr).antitoneOn ⟨hwm,hfm⟩ ⟨hw,hfw⟩ hmlew
  refine ⟨hvmone ▸ le_trans hgainle hvalle,?_⟩
  constructor
  · intro heq
    have hwmeq : w = wm := by
      by_contra hne
      have hlt := frequencyValue_strictAntiOn_feasible hn r hr ⟨hwm,hfm⟩ ⟨hw,hfw⟩
        (lt_of_le_of_ne hmlew (Ne.symm hne))
      rw [hvmone] at hlt
      linarith
    refine ⟨hwmeq,?_⟩
    subst w
    exact funext (lower_frequency_vector_unique r x hr hw hone hx hp)
  · rintro ⟨rfl,rfl⟩
    rfl

end C2.NGamma.Global
