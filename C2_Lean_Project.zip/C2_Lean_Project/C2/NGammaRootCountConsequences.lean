import C2.NGammaRootCountReal
import C2.NGammaPolynomial

/-! Actual root counts, Schur stability, and the conjugate symmetry of the
positive-cascade characteristic polynomial. -/
noncomputable section
open scoped BigOperators ComplexConjugate
open Set Complex Polynomial
namespace C2.NGamma.RootCountBridge

def outsideCount (roots : List ℂ) : ℕ :=
  (roots.filter (fun a => 1 < ‖a‖)).length

def countOutside (p : Polynomial ℂ) : ℕ := outsideCount p.roots.toList

theorem count_partition_list (roots : List ℂ)
    (hroots : ∀ a ∈ roots, ‖a‖ ≠ 1) :
    insideCount roots + outsideCount roots = roots.length := by
  induction roots with
  | nil => simp [insideCount, outsideCount]
  | cons a roots ih =>
    have hh : insideCount roots + outsideCount roots = roots.length :=
      ih (fun a ha => hroots a (by simp [ha]))
    have ha := hroots a (by simp)
    by_cases hi : ‖a‖ < 1
    · have ho : ¬ 1 < ‖a‖ := by linarith
      simpa [insideCount, outsideCount, List.filter_cons, hi, ho, Nat.add_assoc,
        Nat.add_comm, Nat.add_left_comm] using congrArg Nat.succ hh
    · have ho : 1 < ‖a‖ := lt_of_le_of_ne (le_of_not_gt hi) ha.symm
      simpa [insideCount, outsideCount, List.filter_cons, hi, ho, Nat.add_assoc,
        Nat.add_comm, Nat.add_left_comm] using congrArg Nat.succ hh

theorem count_partition (p : Polynomial ℂ)
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) :
    countInside p + countOutside p = p.natDegree := by
  have hh := count_partition_list p.roots.toList (fun a ha => hroots a (by simpa using ha))
  have hd : p.natDegree = p.roots.card := by
    simpa using Polynomial.natDegree_eq_card_roots (IsAlgClosed.splits p)
  simpa [countInside, countOutside, hd] using hh

theorem outsideCount_eq_zero_iff (roots : List ℂ) :
    outsideCount roots = 0 ↔ ∀ a ∈ roots, ‖a‖ ≤ 1 := by
  simp [outsideCount, List.filter_eq_nil_iff, not_lt]

theorem schur_iff_countOutside_zero {p : Polynomial ℂ} (hp : p ≠ 0)
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) :
    PolynomialModel.SchurStable p ↔ countOutside p = 0 := by
  rw [countOutside, outsideCount_eq_zero_iff]
  constructor
  · intro hs a ha
    exact le_of_lt (hs a ((Polynomial.mem_roots hp).1 (by simpa using ha)))
  · intro hs z hz
    have hm : z ∈ p.roots := (Polynomial.mem_roots hp).2 hz
    exact lt_of_le_of_ne (hs z (by simpa using hm)) (hroots z hm)

/-- Once a concrete upper-half-circle lift has the manuscript's endpoint
increment, this theorem gives the exterior-root formula with multiplicity. -/
theorem exterior_count_of_upper_argument {p : Polynomial ℂ} (hp : p ≠ 0)
    (hconj : ∀ z : ℂ, p.eval (conj z) = conj (p.eval z))
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) {α : ℝ → ℝ}
    (hα : ContinuousOn α (Set.Icc 0 Real.pi))
    (hpolar : ∀ t ∈ Set.Icc 0 Real.pi, p.eval (circle t) =
      (‖p.eval (circle t)‖ : ℂ) * Complex.exp ((α t : ℂ) * I))
    (m : ℤ) (hend : α Real.pi - α 0 = ((p.natDegree : ℝ) - 2 * m) * Real.pi) :
    (countOutside p : ℤ) = 2 * m := by
  have hi := polynomial_argument_principle_half hp hconj hroots hα hpolar
  have hn := count_partition p hroots
  have hnr : (countInside p : ℝ) + (countOutside p : ℝ) = p.natDegree := by exact_mod_cast hn
  have hi' : (countInside p : ℝ) = (p.natDegree : ℝ) - 2 * m := by
    apply mul_right_cancel₀ Real.pi_ne_zero
    exact hi.symm.trans hend
  have ho : (countOutside p : ℝ) = 2 * m := by linarith
  exact_mod_cast ho

end C2.NGamma.RootCountBridge

namespace C2.NGamma.PolynomialModel
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem q_eval_conj (x : ℝ) (z : ℂ) : (q x).eval (conj z) = conj ((q x).eval z) := by
  simp only [q_eval, map_div₀, map_sub, map_add, map_mul, map_one, map_ofNat,
    Complex.conj_ofReal]

theorem factor_eval_conj (r x : ℝ) (z : ℂ) :
    (factor r x).eval (conj z) = conj ((factor r x).eval z) := by
  simp only [factor_eval, q_eval_conj, map_add, map_sub, map_mul, map_one,
    Complex.conj_ofReal]

theorem characteristic_eval_conj (r x : ι → ℝ) (d : ℕ) (b : ℝ) (z : ℂ) :
    (characteristic r x d b).eval (conj z) = conj ((characteristic r x d b).eval z) := by
  simp only [characteristic, eval_add, eval_mul, eval_pow, eval_X, eval_C, eval_prod,
    map_add, map_mul, map_pow, map_prod, Complex.conj_ofReal, factor_eval_conj, q_eval_conj]

end C2.NGamma.PolynomialModel
