import C2.CADEffectiveWitness
import C2.CADProjectionComplete

/-! Executable construction of the complete rational projection polynomial.
All multiplication and coefficient selection operate on rational lists;
the mathematical polynomial appears only in the reflection theorems. -/

namespace C2.CADEffective.Bivariate
open Polynomial

def gainProd : List Dense.Poly → Dense.Poly
  | [] => [1]
  | p :: ps => Dense.mul p (gainProd ps)

@[simp] theorem denote_gainProd (ps : List Dense.Poly) :
    Dense.denote (gainProd ps) = (ps.map Dense.denote).prod := by
  induction ps with
  | nil => simp [gainProd]
  | cons p ps ih => simp [gainProd,ih]

def simpleProjection (w : Witness) : Dense.Poly :=
  gainProd (List.ofFn (fun i : Fin w.n =>
    Dense.mul (Dense.mul (Dense.mul (leadingCoeff (w.factors.getD i []))
      (gammaEval (w.factors.getD i []) 0))
      (gammaEval (w.factors.getD i []) 1)) (w.simple.getD i [])))

def pairProjection (w : Witness) : Dense.Poly :=
  gainProd (List.ofFn (fun i : Fin w.n =>
    gainProd (List.ofFn (fun j : Fin w.n => (w.pair.getD i []).getD j []))))

def unitProjection (F : List Poly) (w : Witness) : Dense.Poly :=
  gainProd (List.ofFn (fun i : Fin F.length =>
    Dense.mul (w.left.getD i []) (w.right.getD i [])))

def basisProjection (w : Witness) : Dense.Poly :=
  Dense.mul (simpleProjection w) (pairProjection w)

/-- The exact finite product of all scalar, endpoint, leading and Bezout cuts. -/
def totalProjection (F : List Poly) (w : Witness) : Dense.Poly :=
  Dense.mul (basisProjection w) (unitProjection F w)

@[simp] theorem denote_simpleProjection (F : List Poly) (w : Witness) :
    Dense.denote (simpleProjection w) =
      ∏ i : Fin w.n, ((toFactorData F w).factors i).leadingCoeff *
        ((toFactorData F w).factors i).eval 0 *
        ((toFactorData F w).factors i).eval 1 * (toProjectionData w).simple i := by
  simp [simpleProjection,List.map_ofFn,List.prod_ofFn,toFactorData,toProjectionData]

@[simp] theorem denote_pairProjection (w : Witness) :
    Dense.denote (pairProjection w) =
      ∏ i : Fin w.n, ∏ j : Fin w.n, (toProjectionData w).pair i j := by
  simp [pairProjection,List.map_ofFn,List.prod_ofFn,toProjectionData]

@[simp] theorem denote_unitProjection (F : List Poly) (w : Witness) :
    Dense.denote (unitProjection F w) =
      ∏ i : Fin F.length, (toFactorData F w).left i * (toFactorData F w).right i := by
  simp [unitProjection,List.map_ofFn,List.prod_ofFn,toFactorData]

theorem denote_basisProjection (F : List Poly) (w : Witness) :
    Dense.denote (basisProjection w) =
      C2.CADProjection.projectionCut (toFactorData F w).factors (toProjectionData w) := by
  rw [basisProjection,Dense.denote_mul,denote_simpleProjection F w,denote_pairProjection]
  rfl

theorem denote_totalProjection (F : List Poly) (w : Witness) :
    Dense.denote (totalProjection F w) =
      C2.CADProjection.totalProjectionCut (toFactorData F w) (toProjectionData w) := by
  rw [totalProjection,Dense.denote_mul,denote_basisProjection F w,denote_unitProjection]
  rfl

theorem totalProjection_nonzero_of_valid (F : List Poly) (w : Witness)
    (hf : C2.CADProjection.ValidFactorData (inputFamily F) (toFactorData F w))
    (hp : C2.CADProjection.ValidProjectionData (toFactorData F w).factors (toProjectionData w)) :
    Dense.denote (totalProjection F w) ≠ 0 := by
  rw [denote_totalProjection]
  exact C2.CADProjection.totalProjectionCut_ne_zero hf hp

end C2.CADEffective.Bivariate
