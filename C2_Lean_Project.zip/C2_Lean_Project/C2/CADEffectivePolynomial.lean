import Mathlib

/-! Dense coefficient lists give executable rational polynomial arithmetic.
The mathematical polynomial is used only as the semantic target; no runtime
operation calls mathlib's noncomputable polynomial ring or Euclidean domain. -/
namespace C2.CADEffective.Dense
open Polynomial

abbrev Poly := List ℚ

def denote (p : Poly) : ℚ[X] := ⟨p.toFinsupp⟩

@[simp] theorem coeff_denote (p : Poly) (n : ℕ) :
    (denote p).coeff n = p.getD n 0 := rfl

@[simp] theorem denote_nil : denote [] = 0 := by
  ext n; simp

@[simp] theorem denote_cons (a : ℚ) (p : Poly) :
    denote (a :: p) = C a + X * denote p := by
  ext n
  cases n with
  | zero => simp
  | succ n => simp [coeff_X_mul]

def add : Poly → Poly → Poly
  | [], q => q
  | p, [] => p
  | a :: p, b :: q => (a + b) :: add p q

def neg (p : Poly) : Poly := p.map (- ·)

def scale (a : ℚ) (p : Poly) : Poly := p.map (a * ·)

def mul : Poly → Poly → Poly
  | [], _ => []
  | a :: p, q => add (scale a q) (0 :: mul p q)

def derivative : Poly → Poly
  | [] => []
  | _ :: p => add p (0 :: derivative p)

def eval (p : Poly) (x : ℚ) : ℚ := p.foldr (fun a b => a + x*b) 0

def coeffBound (p : Poly) (R : ℚ) : ℚ :=
  ∑ i ∈ Finset.range p.length, |p.getD i 0| * R^i

def eqb (p q : Poly) : Bool :=
  (List.range (max p.length q.length)).all
    (fun n => decide (p.getD n 0 = q.getD n 0))

@[simp] theorem denote_add (p q : Poly) : denote (add p q) = denote p + denote q := by
  induction p generalizing q with
  | nil => simp [add]
  | cons a p ih =>
      cases q with
      | nil => simp [add]
      | cons b q => simp [add, ih, C_add]; ring

@[simp] theorem denote_neg (p : Poly) : denote (neg p) = -denote p := by
  induction p with
  | nil => simp [neg]
  | cons a p ih =>
      simp only [neg, List.map_cons, denote_cons, C_neg]
      rw [show denote (List.map Neg.neg p) = -denote p from ih]
      ring

@[simp] theorem denote_scale (a : ℚ) (p : Poly) :
    denote (scale a p) = C a * denote p := by
  induction p with
  | nil => simp [scale]
  | cons b p ih =>
      simp only [scale, List.map_cons, denote_cons, C_mul]
      rw [show denote (List.map (a * ·) p) = C a * denote p from ih]
      ring

@[simp] theorem denote_mul (p q : Poly) : denote (mul p q) = denote p * denote q := by
  induction p with
  | nil => simp [mul]
  | cons a p ih => simp [mul, ih]; ring

@[simp] theorem denote_derivative (p : Poly) : denote (derivative p) = (denote p).derivative := by
  induction p with
  | nil => simp [derivative]
  | cons a p ih =>
      simp [derivative, ih, Polynomial.derivative_mul, add_comm]

@[simp] theorem eval_denote (p : Poly) (x : ℚ) : eval p x = (denote p).eval x := by
  induction p with
  | nil => simp [eval]
  | cons a p ih => simpa [eval] using congrArg (fun v : ℚ => a + x*v) ih

@[simp] theorem eqb_eq_true_iff (p q : Poly) : eqb p q = true ↔ denote p = denote q := by
  simp only [eqb, List.all_eq_true, List.mem_range, decide_eq_true_eq]
  constructor
  · intro h
    ext n
    by_cases hn : n < max p.length q.length
    · exact h n hn
    · simp only [coeff_denote]
      rw [List.getD_eq_default _ _ (by omega), List.getD_eq_default _ _ (by omega)]
  · intro h n hn
    exact congrArg (fun P : ℚ[X] => P.coeff n) h

theorem coeffBound_eq_support_sum (p : Poly) (R : ℚ) :
    coeffBound p R = ∑ i ∈ (denote p).support, |(denote p).coeff i| * R^i := by
  change (∑ i ∈ Finset.range p.length, |p.getD i 0| * R^i) =
    ∑ i ∈ (Finset.range p.length).filter (fun i => p.getD i 0 ≠ 0), |p.getD i 0| * R^i
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro i hi
  by_cases h : p.getD i 0 = 0
  · rw [h]; simp only [abs_zero, zero_mul, ne_eq, not_true_eq_false, if_false]
  · simp only [h, ne_eq, not_false_eq_true, if_true]

/-- Every mathematical rational polynomial has a finite dense encoding. This
existence theorem is used only to prove termination of enumeration. -/
theorem exists_encoding (p : ℚ[X]) : ∃ v : Poly, denote v = p := by
  refine ⟨List.ofFn (fun i : Fin (p.natDegree + 1) => p.coeff i), ?_⟩
  ext n
  by_cases hn : n < p.natDegree + 1
  · simp only [coeff_denote]
    rw [List.getD_eq_getElem _ _ (by simpa using hn)]
    exact List.getElem_ofFn _
  · simp only [coeff_denote]
    rw [List.getD_eq_default _ _ (by simp; omega)]
    exact (coeff_eq_zero_of_natDegree_lt (by omega)).symm

/-- Rational identity tests are finite Boolean computations with an exact
reflection theorem; they do not invoke classical polynomial equality. -/
theorem checked_identity (p q : Poly) (h : eqb p q = true) : denote p = denote q :=
  (eqb_eq_true_iff p q).mp h

end C2.CADEffective.Dense
