#!/usr/bin/env python3
"""Validate complete inventory coverage and the official collector's axiom union."""
from pathlib import Path
import hashlib
import json
import re
import sys

root = Path(__file__).resolve().parents[1]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inventory_path = root / 'work/lean_inventory_draft.json'
inventory = json.loads(inventory_path.read_text())
expected = [d['name'] for d in inventory['declarations'] if not d['private']]
raw = json.loads((root / 'work/SharedAxiomAudit.raw.json').read_text())
execution = json.loads((root / 'work/SharedAxiomAudit.execution.json').read_text())
log = (root / 'work/SharedAxiomAudit.log').read_text()
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
roots = raw.get('roots', [])
union = raw.get('axiom_union', [])
checks = {
    'lean_exit_zero': execution['lean_exit_code'] == 0,
    'complete_marker': log.count('C2_SHARED_AXIOM_AUDIT_COMPLETE') == 1,
    'no_lean_errors': not re.search(r'\berror:', log),
    'raw_passed': raw.get('passed') is True,
    'schema': raw.get('schema') == 'c2.shared-axiom-union.v1',
    'root_order_and_names_match_inventory': roots == expected,
    'root_names_unique': len(roots) == len(set(roots)),
    'root_count': raw.get('checked_root_count') == raw.get('expected_count') == len(expected),
    'kernel_environment_presence': raw.get('all_roots_exist_in_checked_kernel_environment') is True,
    'allowed_set_unchanged': set(raw.get('allowed_axioms', [])) == allowed,
    'union_allowed_only': set(union) <= allowed and raw.get('unexpected_axioms') == [],
    'inventory_hash': raw.get('inventory_sha256') == execution['inventory_sha256'] == sha(inventory_path),
    'root_file_hash': raw.get('root_list_sha256') == execution['root_list_sha256'] == sha(root / 'work/SharedAxiomAudit.roots.txt'),
    'audit_source_hash': execution['source_sha256'] == sha(root / 'work/SharedAxiomAudit.lean'),
}
result = {
    'schema': 'c2.shared-axiom-union.validation.v1', 'audit_method': 'shared_official_collector_union',
    'passed': all(checks.values()), 'expected_count': len(expected),
    'reported_count': raw.get('checked_root_count'), 'checked_root_count': raw.get('checked_root_count'),
    'allowed_axioms': sorted(allowed), 'axiom_union': union,
    'unexpected_axioms': sorted(set(union) - allowed), 'missing_declarations': sorted(set(expected) - set(roots)),
    'roots': roots, 'checks': checks, 'execution': execution,
    'coverage': 'Every explicit public inventory root exists in the checked kernel environment and is passed to the unchanged official Lean collector. Types, definition/theorem/opaque bodies, constructor/recursor types and inductive constructors follow the official traversal. One shared visited set computes the union of every root reachable axiom set.',
    'equivalence': 'For allowed set A and roots R, union_{r in R} axioms(r) subset A iff every axioms(r) subset A. Sharing a reachability visited set is sound even for cyclic dependency graphs.',
    'per_root_exact_dependency_lists_produced': False,
}
(root / 'work/axiom_audit.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({k:result[k] for k in ['passed','audit_method','expected_count','checked_root_count','axiom_union','unexpected_axioms','missing_declarations']}))
if not result['passed']:
    print('Failed checks:', [k for k,v in checks.items() if not v], file=sys.stderr)
sys.exit(0 if result['passed'] else 1)
