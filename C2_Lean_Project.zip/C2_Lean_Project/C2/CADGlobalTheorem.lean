import C2.CADGlobalAssembly
import C2.CADProjectionComplete

/-!
# The general exact-gain theorem: mathematical completion

For the original rational polynomial inequalities, this module constructs a
finite exact cell calculation and proves the empty-set and algebraic-supremum
conclusions. No factorization, projection, regularity, partition, sample, or
sign-test-correctness hypothesis is supplied by the caller.

The construction in this mathematical existence theorem uses finite root sets
and classical choice of rational witnesses. Native execution and the total
finite-data search/isolation pipeline are separately verified; this module does
not conflate a mathematical choice with an executable implementation.
-/

noncomputable section
open Polynomial Set
namespace C2.CADGlobal

/-- An identically zero input inequality is handled without any nonzero-input
assumption. Otherwise the fully proved generic algebraic projection applies. -/
theorem exists_total_feasibility_projection {n : ℕ}
    (f : Fin n → CADProjection.Bivariate) :
    ∃ d : ℚ[X], d ≠ 0 ∧
      ∀ I : Set ℝ, IsPreconnected I →
      (∀ k ∈ I, d.eval₂ (algebraMap ℚ ℝ) k ≠ 0) →
      ∀ {a b : ℝ}, a ∈ I → b ∈ I →
      ((∃ x ∈ Icc (0 : ℝ) 1, ∀ i, 0 < CADProjection.value (f i) a x) ↔
        ∃ x ∈ Icc (0 : ℝ) 1, ∀ i, 0 < CADProjection.value (f i) b x) := by
  classical
  by_cases hz : ∃ i, f i = 0
  · obtain ⟨i, hi⟩ := hz
    have hfalse : ∀ k : ℝ,
        ¬∃ x ∈ Icc (0 : ℝ) 1, ∀ j, 0 < CADProjection.value (f j) k x := by
      rintro k ⟨x, _, hpos⟩
      have h := hpos i
      simpa [hi, CADProjection.value, CADProjection.specialize] using h
    exact ⟨1, one_ne_zero, fun _ _ _ {a b} _ _ => iff_of_false (hfalse a) (hfalse b)⟩
  · exact CADProjection.exists_feasibility_projection f (by simpa using hz)

/-- **Finite exact global gain calculation.** From the rational input family
and its proved uniform bound alone, there is a finite actual-cell calculation:
no marked cell iff the positive-gain set is empty; otherwise the selected right
endpoint is its actual least upper bound, is real algebraic, is positive, and
lies at most K₀, strictly below the chosen rational search bound K. Every stable
component is included, whether or not it is connected to zero gain. -/
theorem finite_global_gain_calculation {n : ℕ}
    (f : Fin n → CADProjection.Bivariate)
    (K : ℚ) (hK : 0 < K) (K₀ : ℝ)
    (hbound : ∀ k ∈ positiveGains f, k ≤ K₀) (hstrict : K₀ < (K : ℝ)) :
    ∃ d : ℚ[X], ∃ hd : d ≠ 0,
      ∃ gainSamples : (ℝ × ℝ) → ℚ,
      ∃ parameterSamples : (ℝ × ℝ) → List ℚ,
      CalculationCorrect f d hd K gainSamples parameterSamples ∧
      ∀ b, calculationOutput f d hd K gainSamples parameterSamples = some b → b ≤ K₀ := by
  obtain ⟨d, hd, hprojection⟩ := exists_total_feasibility_projection f
  obtain ⟨gainSamples, parameterSamples, hc⟩ :=
    exists_calculation_of_projection f d hd hprojection K hK K₀ hbound hstrict
  exact ⟨d, hd, gainSamples, parameterSamples, hc,
    fun b hb => (hc.2.2.2 b hb).1.2 hbound⟩

/-- The nonempty original feasible gain set has an actual algebraic supremum
with the stronger coefficient-bound separation required in the manuscript. -/
theorem nonempty_gain_supremum_algebraic {n : ℕ}
    (f : Fin n → CADProjection.Bivariate)
    (K : ℚ) (hK : 0 < K) (K₀ : ℝ)
    (hbound : ∀ k ∈ positiveGains f, k ≤ K₀) (hstrict : K₀ < (K : ℝ))
    (hne : (positiveGains f).Nonempty) :
    ∃ b : ℝ, IsLUB (positiveGains f) b ∧ IsAlgebraic ℚ b ∧
      0 < b ∧ b ≤ K₀ ∧ b < (K : ℝ) ∧ sSup (positiveGains f) = b := by
  obtain ⟨d, hd, gainSamples, parameterSamples, hc, hboundout⟩ :=
    finite_global_gain_calculation f K hK K₀ hbound hstrict
  cases hout : calculationOutput f d hd K gainSamples parameterSamples with
  | none =>
      have he := hc.2.2.1.mp hout
      exact (hne.ne_empty he).elim
  | some b =>
      have hb := hc.2.2.2 b hout
      exact ⟨b, hb.1, hb.2.1, hb.2.2.1, hboundout b hout,
        hb.2.2.2, hb.1.csSup_eq hne⟩

/-- A zero strict input inequality is recognized as the empty case by every
correct calculation of the original system. -/
theorem zero_input_output_none {n : ℕ} (f : Fin n → CADProjection.Bivariate)
    {i : Fin n} (hi : f i = 0)
    (d : ℚ[X]) (hd : d ≠ 0) (K : ℚ)
    (gainSamples : (ℝ × ℝ) → ℚ) (parameterSamples : (ℝ × ℝ) → List ℚ)
    (hc : CalculationCorrect f d hd K gainSamples parameterSamples) :
    calculationOutput f d hd K gainSamples parameterSamples = none :=
  hc.2.2.1.mpr (zero_input_positiveGains_empty f hi)

end C2.CADGlobal
