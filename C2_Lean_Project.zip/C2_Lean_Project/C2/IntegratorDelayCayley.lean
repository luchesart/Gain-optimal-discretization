import C2.IntegratorDelayAmplitude
import C2.IntegratorDelayPhase
import C2.NGammaPhaseEndpoint
import C2.NGammaRootClosedness

noncomputable section
open Polynomial Filter
open scoped Topology ComplexConjugate
namespace C2.IntegratorDelay
open C2.NGamma.PolynomialModel
open C2.NGamma.Cayley

def poly (n : ℕ) (x a : ℝ) : Polynomial ℂ :=
  X ^ n * (X - 1) + C (a : ℂ) * q x

def transfer (n : ℕ) (x : ℝ) (z : ℂ) : ℂ :=
  z ^ n * (z - 1) / (q x).eval z

theorem poly_eval (n : ℕ) (x a : ℝ) (z : ℂ) :
    (poly n x a).eval z = z ^ n * (z - 1) + (a : ℂ) * (q x).eval z := by
  simp [poly]

theorem poly_natDegree {n : ℕ} (hn : 1 ≤ n) (x a : ℝ) :
    (poly n x a).natDegree = n + 1 := by
  have hd : (X ^ n * (X - 1) : Polynomial ℂ).natDegree = n + 1 := by
    rw [natDegree_X_pow_mul n (by simpa using X_sub_C_ne_zero (1 : ℂ))]
    have hsub : (X - 1 : Polynomial ℂ).natDegree = 1 := by
      simpa only [Polynomial.C_1] using natDegree_X_sub_C (1 : ℂ)
    rw [hsub]
    omega
  have hl : (C (a : ℂ) * q x).natDegree < (X ^ n * (X - 1) : Polynomial ℂ).natDegree := by
    have h := (natDegree_C_mul_le (a : ℂ) (q x)).trans (q_natDegree_le_one x)
    rw [hd]
    omega
  unfold poly
  rw [natDegree_add_eq_left_of_natDegree_lt hl, hd]

theorem poly_ne_zero {n : ℕ} (hn : 1 ≤ n) (x a : ℝ) : poly n x a ≠ 0 := by
  intro h
  have hd := poly_natDegree hn x a
  rw [h, natDegree_zero] at hd
  omega

theorem poly_eval_one (n : ℕ) (x a : ℝ) : (poly n x a).eval 1 = (a : ℂ) := by
  simp [poly_eval, q_eval_one]

theorem poly_eval_neg_one (n : ℕ) (x a : ℝ) :
    (poly n x a).eval (-1) = -2 * (-1 : ℂ) ^ n - (a : ℂ) * x := by
  rw [poly_eval, q_eval_neg_one]
  ring

theorem poly_eval_conj (n : ℕ) (x a : ℝ) (z : ℂ) :
    (poly n x a).eval (conj z) = conj ((poly n x a).eval z) := by
  simp [poly_eval, q_eval, map_add, map_sub, map_mul, map_pow, _root_.map_div, map_ofNat]

theorem poly_eval_point (n : ℕ) (x a t : ℝ) :
    (poly n x a).eval (point t) =
      (q x).eval (point t) * (transfer n x (point t) + a) := by
  rw [poly_eval]
  unfold transfer
  field_simp [q_eval_point_ne_zero x t]

theorem transfer_point (n : ℕ) (x t : ℝ) :
    transfer n x (point t) = (point t) ^ n * (2 * Complex.I * t) /
      (1 + Complex.I * (x * t : ℝ)) := by
  unfold transfer
  rw [q_eval_point]
  have hp : point t - 1 = (2 * Complex.I * t) / (1 - Complex.I * t) := by
    unfold point
    field_simp [one_sub_I_mul_ne_zero t]
    ring
  rw [hp]
  field_simp [one_sub_I_mul_ne_zero t, one_add_I_mul_ne_zero (x * t)]

theorem transfer_polar (n : ℕ) (x t : ℝ) (_ht : 0 ≤ t) :
    transfer n x (point t) = (amplitude x t : ℂ) *
      Complex.exp ((totalPhase n x t : ℂ) * Complex.I) := by
  rw [transfer_point, point_exp, linear_polar, ← Complex.exp_nat_mul]
  have hpi : Complex.exp (((Real.pi / 2 : ℝ) : ℂ) * Complex.I) = Complex.I := by
    simpa using Complex.exp_pi_div_two_mul_I
  simp only [amplitude, totalPhase, Complex.ofReal_div, Complex.ofReal_mul,
    Complex.ofReal_sub, Complex.ofReal_add, Complex.ofReal_natCast, Complex.ofReal_ofNat,
    sub_mul, add_mul, Complex.exp_sub, Complex.exp_add]
  rw [show (Real.pi : ℂ) / 2 * Complex.I = ((Real.pi / 2 : ℝ) : ℂ) * Complex.I by push_cast; ring, hpi]
  congr 1 <;> ring

theorem transfer_norm (n : ℕ) (x t : ℝ) (ht : 0 ≤ t) :
    ‖transfer n x (point t)‖ = amplitude x t := by
  rw [transfer_polar n x t ht, norm_mul, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (amplitude_nonneg x ht), Complex.norm_exp_ofReal_mul_I, mul_one]

theorem point_tendsto_atTop : Tendsto point atTop (𝓝 (-1 : ℂ)) := by
  have ha := (Real.tendsto_arctan_atTop.mono_right nhdsWithin_le_nhds).const_mul 2
  have hc := (Complex.continuous_ofReal.tendsto _).comp ha
  have he := Complex.continuous_exp.continuousAt.tendsto.comp (hc.mul_const Complex.I)
  convert he using 1
  · funext t
    exact point_exp t
  · have hp : (2 * (Real.pi / 2) : ℝ) = Real.pi := by ring
    rw [hp, Complex.exp_pi_mul_I]

theorem reciprocal_transfer_identity (n : ℕ) (x a : ℝ) {t : ℝ} (ht : t ≠ 0) :
    (a : ℂ) / transfer n x (point t) =
      (a : ℂ) * ((x : ℂ) / 2 + (1 / t : ℝ) / (2 * Complex.I)) / (point t) ^ n := by
  rw [transfer_point]
  have hp : point t ≠ 0 := by intro h; have hn := point_norm t; simp [h] at hn
  have htc : (t : ℂ) ≠ 0 := by exact_mod_cast ht
  have hlin : (x : ℂ) / 2 + ((1 / t : ℝ) : ℂ) / (2 * Complex.I) =
      (1 + Complex.I * ((x * t : ℝ) : ℂ)) / (2 * Complex.I * t) := by
    push_cast
    field_simp [htc, Complex.I_ne_zero]
    <;> ring
  rw [hlin]
  simp only [div_eq_mul_inv, mul_inv_rev, inv_inv]
  ring

theorem reciprocal_transfer_tendsto_atTop (n : ℕ) (x a : ℝ) :
    Tendsto (fun t => (a : ℂ) / transfer n x (point t)) atTop
      (𝓝 (((a * x / (2 * (-1) ^ n) : ℝ) : ℂ))) := by
  have hi : Tendsto (fun t : ℝ => ((1 / t : ℝ) : ℂ)) atTop (𝓝 0) := by
    simpa only [Function.comp_def, one_div, Complex.ofReal_zero] using
      (Complex.continuous_ofReal.tendsto 0).comp tendsto_inv_atTop_zero
  have hnum : Tendsto (fun t : ℝ => (a : ℂ) * ((x : ℂ) / 2 + ((1 / t : ℝ) : ℂ) / (2 * Complex.I)))
      atTop (𝓝 ((a : ℂ) * ((x : ℂ) / 2 + 0 / (2 * Complex.I)))) :=
    (tendsto_const_nhds.add (hi.div_const (2 * Complex.I))).const_mul (a : ℂ)
  have hden := point_tendsto_atTop.pow n
  have hlim := hnum.div hden (pow_ne_zero n (by norm_num : (-1 : ℂ) ≠ 0))
  have he := hlim.congr' (show ∀ᶠ t : ℝ in atTop,
      (a : ℂ) * ((x : ℂ) / 2 + (1 / t : ℝ) / (2 * Complex.I)) / (point t) ^ n =
        (a : ℂ) / transfer n x (point t) from by
    filter_upwards [eventually_gt_atTop (0 : ℝ)] with t ht
    exact (reciprocal_transfer_identity n x a ht.ne').symm)
  convert he using 1 <;> push_cast <;> ring

theorem transfer_tendsto_atTop (n : ℕ) {x : ℝ} (hx : x ≠ 0) :
    Tendsto (fun t => transfer n x (point t)) atTop
      (𝓝 (((2 * (-1) ^ n / x : ℝ) : ℂ))) := by
  have hxC : (x : ℂ) ≠ 0 := by exact_mod_cast hx
  have hn : (2 * (-1 : ℂ) ^ n) ≠ 0 := mul_ne_zero (by norm_num) (pow_ne_zero n (by norm_num))
  have hnon : (((1 * x / (2 * (-1) ^ n) : ℝ) : ℂ)) ≠ 0 := by
    push_cast
    simpa only [one_mul] using div_ne_zero hxC hn
  have he := (reciprocal_transfer_tendsto_atTop n x 1).inv₀ hnon
  convert he using 1
  · funext t
    simp
  · push_cast
    field_simp

end C2.IntegratorDelay
