import C2.IntegratorDelayCayley
import C2.NGammaRootCount
import C2.NGammaCharacteristicLift

noncomputable section
open Polynomial Filter
open scoped Topology ComplexConjugate
namespace C2.IntegratorDelay
open NGamma.PolynomialModel NGamma.RootCountBridge NGamma.ArgumentMatch
open NGamma.Cayley

def highGainAngle (n : ℕ) (x a t : ℝ) : ℝ :=
  qPhase x t + Complex.arg (transfer n x (point t) + a)

theorem transfer_point_continuous (n : ℕ) (x : ℝ) :
    Continuous (fun t => transfer n x (point t)) := by
  have hp : Continuous point := by
    change Continuous (fun t : ℝ => point t)
    simp_rw [point_exp]
    exact Complex.continuous_exp.comp
      ((Complex.continuous_ofReal.comp (continuous_const.mul Real.continuous_arctan)).mul
        continuous_const)
  have h : Continuous (fun t : ℝ => (point t) ^ n * (2 * Complex.I * t) /
      (1 + Complex.I * (x * t : ℝ))) := by
    apply Continuous.div (by fun_prop) (by fun_prop)
    intro t
    exact one_add_I_mul_ne_zero (x * t)
  simpa only [transfer_point] using h

theorem high_gain_curve_re_pos (n : ℕ) {x a : ℝ} (ha : 0 < a)
    (hhigh : 2 ≤ a * |x|) {t : ℝ} (ht : 0 ≤ t) :
    0 < (transfer n x (point t) + a).re := by
  have hx : x ≠ 0 := by
    intro h
    rw [h, abs_zero, mul_zero] at hhigh
    linarith
  have hax := abs_pos.mpr hx
  apply add_re_pos_of_norm_lt
  rw [transfer_norm n x t ht]
  exact (mul_lt_mul_right hax).mp
    ((amplitude_endpoint_bound x ht).trans_le hhigh)

theorem high_gain_finite_ne_zero (n : ℕ) {x a : ℝ} (ha : 0 < a)
    (hhigh : 2 ≤ a * |x|) {t : ℝ} (ht : 0 ≤ t) :
    (poly n x a).eval (point t) ≠ 0 := by
  rw [poly_eval_point]
  apply mul_ne_zero (q_eval_point_ne_zero x t)
  intro he
  have h := high_gain_curve_re_pos n ha hhigh ht
  rw [he] at h
  exact lt_irrefl 0 h

theorem highGainAngle_continuousOn (n : ℕ) {x a : ℝ} (ha : 0 < a)
    (hhigh : 2 ≤ a * |x|) : ContinuousOn (highGainAngle n x a) (Set.Ici 0) := by
  apply ContinuousOn.add (qPhase_continuous x).continuousOn
  intro t ht
  exact ContinuousAt.comp_continuousWithinAt
    (f := fun u => transfer n x (point u) + (a : ℂ))
    (Complex.continuousAt_arg (Or.inl (high_gain_curve_re_pos n ha hhigh ht)))
    ((transfer_point_continuous n x).add continuous_const).continuousAt.continuousWithinAt

theorem highGainAngle_polar (n : ℕ) (x a t : ℝ) :
    (poly n x a).eval (point t) = (‖(poly n x a).eval (point t)‖ : ℂ) *
      Complex.exp ((highGainAngle n x a t : ℂ) * Complex.I) := by
  have hqnorm : ‖(q x).eval (point t)‖ = qAmplitude x t := by
    rw [q_polar, norm_mul, Complex.norm_real, Real.norm_eq_abs,
      abs_of_pos (qAmplitude_pos x t), Complex.norm_exp_ofReal_mul_I, mul_one]
  have hq : (q x).eval (point t) = (‖(q x).eval (point t)‖ : ℂ) *
      Complex.exp ((qPhase x t : ℂ) * Complex.I) := by rw [hqnorm]; exact q_polar x t
  rw [poly_eval_point]
  exact NGamma.Cayley.polar_mul hq (Complex.norm_mul_exp_arg_mul_I _).symm

theorem highGainAngle_zero (n : ℕ) (x : ℝ) {a : ℝ} (ha : 0 < a) :
    highGainAngle n x a 0 = 0 := by
  simp only [highGainAngle, qPhase, mul_zero, Real.arctan_zero, add_zero,
    transfer_point, Complex.ofReal_zero, mul_zero, zero_div, zero_add]
  exact Complex.arg_ofReal_of_nonneg ha.le

theorem qPhase_negative_limit {x : ℝ} (hx : x < 0) :
    Tendsto (qPhase x) atTop (𝓝 0) := by
  have ha := Real.tendsto_arctan_atTop.mono_right nhdsWithin_le_nhds
  have hb := arctan_mul_tendsto_atTop (show 0 ≤ -x by linarith)
  have hxne : -x ≠ 0 := by linarith
  simp only [hxne, if_false] at hb
  have h := ha.sub hb
  simp only [sub_self] at h
  convert h using 1
  funext t
  simp only [qPhase, neg_mul, Real.arctan_neg]
  ring

theorem highGainAngle_tendsto (n : ℕ) {x a : ℝ} (ha : 0 < a)
    (hhigh : 2 ≤ a * |x|) (hend : (poly n x a).eval (-1) ≠ 0) :
    Tendsto (highGainAngle n x a) atTop (𝓝 (if 0 < x then Real.pi else 0)) := by
  have hx : x ≠ 0 := by
    intro h
    rw [h, abs_zero, mul_zero] at hhigh
    linarith
  let c : ℝ := 2 * (-1) ^ n / x + a
  have hlim : Tendsto (fun t => transfer n x (point t) + a) atTop (𝓝 (c : ℂ)) := by
    simpa [c] using (transfer_tendsto_atTop n hx).add_const (a : ℂ)
  have hreal : Tendsto (fun t => (transfer n x (point t) + a).re) atTop (𝓝 c) := by
    simpa using Complex.continuous_re.continuousAt.tendsto.comp hlim
  have hc0 : 0 ≤ c := ge_of_tendsto hreal (by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
    exact (high_gain_curve_re_pos n ha hhigh ht).le)
  have hcne : c ≠ 0 := by
    intro he
    apply hend
    rw [poly_eval_neg_one]
    have hrc : (-2 * (-1 : ℝ) ^ n - a * x) = 0 := by
      have hh : x * c = 2 * (-1 : ℝ) ^ n + a * x := by dsimp [c]; field_simp [hx] <;> ring
      rw [he, mul_zero] at hh
      linarith
    exact_mod_cast hrc
  have hc : 0 < c := lt_of_le_of_ne hc0 (Ne.symm hcne)
  have harg := (Complex.continuousAt_arg (Or.inl (show 0 < (c : ℂ).re by simpa using hc))).tendsto.comp hlim
  have harg0 : Tendsto (fun t => Complex.arg (transfer n x (point t) + a)) atTop (𝓝 0) := by
    simpa only [Complex.arg_ofReal_of_nonneg hc.le] using harg
  by_cases hxpos : 0 < x
  · rw [if_pos hxpos]
    have hq : Tendsto (qPhase x) atTop (𝓝 Real.pi) := by
      simpa only [ne_of_gt hxpos, if_false, sub_zero] using qPhase_tendsto_atTop hxpos.le
    simpa only [highGainAngle, add_zero] using hq.add harg0
  · rw [if_neg hxpos]
    have hxneg : x < 0 := lt_of_le_of_ne (le_of_not_gt hxpos) hx
    simpa only [highGainAngle, add_zero] using (qPhase_negative_limit hxneg).add harg0

/-- All gains beyond the magnitude endpoint are excluded, including equality. -/
theorem not_schur_of_high_gain {n : ℕ} (hn : 1 ≤ n) {x a : ℝ}
    (ha : 0 < a) (hhigh : 2 ≤ a * |x|) : ¬ SchurStable (poly n x a) := by
  by_cases hend : (poly n x a).eval (-1) = 0
  · intro hs
    have h := hs (-1) hend
    norm_num at h
  · have hroots := no_unit_roots_of_cayley_nonzero (poly_eval_conj n x a)
      (fun t ht => high_gain_finite_ne_zero n ha hhigh ht) hend
    have hi := polynomial_argument_principle_cayley (poly_ne_zero hn x a)
      (poly_eval_conj n x a) hroots (highGainAngle_continuousOn n ha hhigh)
      (fun t _ => highGainAngle_polar n x a t) (highGainAngle_tendsto n ha hhigh hend)
    rw [highGainAngle_zero n x ha, sub_zero] at hi
    have hinside : countInside (poly n x a) ≤ 1 := by
      by_contra! hc
      have hc' : (2 : ℝ) ≤ countInside (poly n x a) := by exact_mod_cast hc
      split_ifs at hi <;> nlinarith [Real.pi_pos]
    intro hs
    have hout := (schur_iff_countOutside_zero (poly_ne_zero hn x a) hroots).1 hs
    have hpart := count_partition (poly n x a) hroots
    rw [hout, add_zero, poly_natDegree hn] at hpart
    omega

end C2.IntegratorDelay
