import C2.MIACEResponse
import C2.RegionCompletionFirstOrder

/-! The reserve optimizer for the actual zero-state unit-step recurrence. -/

noncomputable section
open scoped Topology
open Filter

namespace C2.MIACE

def errorPair (A B : ℝ) : ℕ → ℝ × ℝ
  | 0 => (1, A)
  | n + 1 => let p := errorPair A B n; (p.2, A * p.2 - B * p.1)

def unitStepError (γ a : ℝ) (n : ℕ) : ℝ :=
  (errorPair (1 - a * γ) (a * (1 - γ)) n).1

theorem unitStepError_recurrence (γ a : ℝ) :
    ErrorRecurrence (1 - a * γ) (a * (1 - γ)) (unitStepError γ a) := by
  refine ⟨rfl, rfl, fun n => ?_⟩
  rfl

def admissibleDesign (R γ a : ℝ) : Prop :=
  0 ≤ γ ∧ γ ≤ 1 ∧ 0 < a ∧
    Monotone (fun n => 1 - unitStepError γ a n) ∧
    Tendsto (fun n => 1 - unitStepError γ a n) atTop (𝓝 1) ∧
    R ≤ C2.FirstOrder.oneSampleThreshold γ / a

def responseCost (η T γ a : ℝ) : ℝ :=
  cost η (area T (unitStepError γ a)) (area T (fun n => -unitStepError γ a (n + 1)))

def reserveOptimizerGamma (R : ℝ) : ℝ := 1 - reserveOptimizerX R ^ 2

theorem reserve_parameters_eq (R : ℝ) :
    (reserveOptimizerGamma R, reserveOptimizerGain R) =
      if R ≤ 2 then (1, 1)
      else if R < 9 then (1 - reserveX R ^ 2, 1 / (1 + reserveX R) ^ 2)
      else (3 / 4, 4 / R) := by
  unfold reserveOptimizerGamma reserveOptimizerX reserveOptimizerGain
  split_ifs <;> norm_num

theorem reserve_formula_endpoint_agreement :
    (1 - reserveX 2 ^ 2, 1 / (1 + reserveX 2) ^ 2) = ((1 : ℝ), (1 : ℝ)) ∧
    (1 - reserveX 9 ^ 2, 1 / (1 + reserveX 9) ^ 2) = ((3 / 4 : ℝ), (4 / 9 : ℝ)) := by
  rw [reserve_transition_two, reserve_transition_nine]
  norm_num

theorem admissible_iff_reserveFeasible {R γ a : ℝ}
    (hR : 0 ≤ R) (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (ha : 0 < a) :
    admissibleDesign R γ a ↔ ReserveFeasible R (Real.sqrt (1 - γ)) a := by
  let x := Real.sqrt (1 - γ)
  have hx : 0 ≤ x := Real.sqrt_nonneg _
  have hx2 : x ^ 2 = 1 - γ := Real.sq_sqrt (by linarith)
  have hx1 : x ≤ 1 := by nlinarith
  have hp : 0 < (1 + x) ^ 2 := by positivity
  have hmon := monotone_tracking_iff hγ0 hγ1 ha (unitStepError_recurrence γ a)
  have hreserve : R ≤ C2.FirstOrder.oneSampleThreshold γ / a ↔
      R * a * x ^ 2 ≤ 1 ∧ R * a * (1 - 2 * x ^ 2) ≤ 2 := by
    rw [le_div_iff₀ ha, C2.FirstOrder.le_oneSampleThreshold_iff hγ0 hγ1 (mul_nonneg hR ha.le)]
    rw [hx2]
    ring_nf
  constructor
  · rintro ⟨_, _, _, hm, hl, hr⟩
    have hma := hmon.mp ⟨hm, hl⟩
    have hbound : a * (1 + x) ^ 2 ≤ 1 := (le_div_iff₀ hp).mp hma
    exact ⟨hx, hx1, ha, hbound, (hreserve.mp hr).1, (hreserve.mp hr).2⟩
  · rintro ⟨_, _, _, hm, hr₁, hr₂⟩
    have hma : a ≤ 1 / (1 + x) ^ 2 := (le_div_iff₀ hp).mpr hm
    have ht := hmon.mpr hma
    exact ⟨hγ0, hγ1, ha, ht.1, ht.2, hreserve.mpr ⟨hr₁, hr₂⟩⟩

theorem reserved_uncertain_gain_stable {R γ a q : ℝ}
    (h : admissibleDesign R γ a) (hq0 : 0 < q) (hqR : q < R) :
    C2.FirstOrder.Stable 0 γ (q * a) := by
  rw [C2.FirstOrder.integrator_piecewise_region h.1 h.2.1]
  have ha := h.2.2.1
  have hmargin := (le_div_iff₀ ha).mp h.2.2.2.2.2
  exact ⟨mul_pos hq0 ha, (mul_lt_mul_of_pos_right hqR ha).trans_le hmargin⟩

theorem reserveFeasible_to_admissible {R x a : ℝ}
    (hR : 0 ≤ R) (h : ReserveFeasible R x a) : admissibleDesign R (1 - x ^ 2) a := by
  have hγ0 : 0 ≤ 1 - x ^ 2 := by nlinarith [h.1, h.2.1]
  have hγ1 : 1 - x ^ 2 ≤ 1 := by nlinarith [sq_nonneg x]
  apply (admissible_iff_reserveFeasible hR hγ0 hγ1 h.2.2.1).mpr
  have hs : Real.sqrt (1 - (1 - x ^ 2)) = x := by
    rw [show 1 - (1 - x ^ 2) = x ^ 2 by ring, Real.sqrt_sq h.1]
  simpa only [hs] using h

theorem responseCost_eq_nominalCost {R γ a η T : ℝ} (hT : 0 ≤ T)
    (h : admissibleDesign R γ a) : responseCost η T γ a = nominalCost η T a := by
  have hbound := (monotone_tracking_iff h.1 h.2.1 h.2.2.1
    (unitStepError_recurrence γ a)).mp ⟨h.2.2.2.1, h.2.2.2.2.1⟩
  obtain ⟨he, hv, _⟩ := monotone_response_areas h.1 h.2.1 h.2.2.1 hT
    (η := η) (unitStepError_recurrence γ a) (fun n => rfl) hbound
  unfold responseCost nominalCost
  rw [he, hv]

/-- A literal unique optimizer for the actual-response absolute-area MIACE
criterion under monotonicity and the true critical-gain ratio. The threshold
is separately proved to be the supremum of the actual-root stable gains. -/
theorem exact_monotone_miace_reserve_optimizer {R η T : ℝ}
    (hR : 1 < R) (hη : 0 < η) (hT : 0 < T) :
    admissibleDesign R (reserveOptimizerGamma R) (reserveOptimizerGain R) ∧
    (∀ γ a, admissibleDesign R γ a →
      responseCost η T (reserveOptimizerGamma R) (reserveOptimizerGain R) ≤
        responseCost η T γ a) ∧
    (∀ γ a, admissibleDesign R γ a →
      responseCost η T γ a ≤
        responseCost η T (reserveOptimizerGamma R) (reserveOptimizerGain R) →
      γ = reserveOptimizerGamma R ∧ a = reserveOptimizerGain R) := by
  obtain ⟨hf, hmin, huniq⟩ := nominalCost_unique_reserve_minimum hη hT hR
  have hR0 : 0 ≤ R := by linarith
  have hadm := reserveFeasible_to_admissible hR0 hf
  change admissibleDesign R (reserveOptimizerGamma R) (reserveOptimizerGain R) at hadm
  refine ⟨hadm, ?_, ?_⟩
  · intro γ a h
    have hg := (admissible_iff_reserveFeasible hR0 h.1 h.2.1 h.2.2.1).mp h
    rw [responseCost_eq_nominalCost hT.le hadm, responseCost_eq_nominalCost hT.le h]
    exact hmin _ _ hg
  · intro γ a h hc
    have hg := (admissible_iff_reserveFeasible hR0 h.1 h.2.1 h.2.2.1).mp h
    rw [responseCost_eq_nominalCost hT.le h, responseCost_eq_nominalCost hT.le hadm] at hc
    obtain ⟨hx, ha⟩ := huniq _ _ hg hc
    refine ⟨?_, ha⟩
    have hs := Real.sq_sqrt (show 0 ≤ 1 - γ by linarith [h.2.1])
    rw [hx] at hs
    dsimp [reserveOptimizerGamma]
    linarith

end C2.MIACE
