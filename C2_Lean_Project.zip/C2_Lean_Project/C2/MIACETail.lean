import C2.MIACEAreas

/-!
# MIACE truncation and uniform convergence

The statements here start from an explicit uniform geometric envelope. The
separate implication from a compact family of Schur-stable matrices to such
an envelope is not assumed to have been formalized by these lemmas.
-/

noncomputable section
open scoped BigOperators Topology
open Filter

namespace C2.MIACE

def partialArea (T : ℝ) (s : ℕ → ℝ) (N : ℕ) : ℝ :=
  T * ∑ n ∈ Finset.range N, |s n|

theorem cost_nonneg (η a b : ℝ) : 0 ≤ cost η a b := Real.sqrt_nonneg _

theorem cost_sq {η : ℝ} (hη : 0 ≤ η) (a b : ℝ) :
    cost η a b ^ 2 = a ^ 2 + η * b ^ 2 := by
  exact Real.sq_sqrt (by positivity)

theorem cost_mono {η a b c d : ℝ} (hη : 0 ≤ η)
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hac : a ≤ c) (hbd : b ≤ d) :
    cost η a b ≤ cost η c d := by
  apply Real.sqrt_le_sqrt
  have h₁ : a ^ 2 ≤ c ^ 2 := by nlinarith
  have h₂ : η * b ^ 2 ≤ η * d ^ 2 := by
    apply mul_le_mul_of_nonneg_left _ hη
    nlinarith
  linarith

theorem cost_mul {η k : ℝ} (hk : 0 ≤ k) (a b : ℝ) :
    cost η (k * a) (k * b) = k * cost η a b := by
  dsimp [cost]
  rw [show (k * a) ^ 2 + η * (k * b) ^ 2 =
    k ^ 2 * (a ^ 2 + η * b ^ 2) by ring]
  rw [Real.sqrt_mul (sq_nonneg k), Real.sqrt_sq hk]

theorem cost_triangle {η : ℝ} (hη : 0 ≤ η) (a b c d : ℝ) :
    cost η (a + c) (b + d) ≤ cost η a b + cost η c d := by
  have hcs := Real.sum_mul_le_sqrt_mul_sqrt Finset.univ
    (![a, Real.sqrt η * b] : Fin 2 → ℝ)
    (![c, Real.sqrt η * d] : Fin 2 → ℝ)
  simp only [Fin.sum_univ_two, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_fin_one] at hcs
  have hηsq := Real.sq_sqrt hη
  have hab : (Real.sqrt η * b) ^ 2 = η * b ^ 2 := by nlinarith
  have hcd : (Real.sqrt η * d) ^ 2 = η * d ^ 2 := by nlinarith
  have hbd : Real.sqrt η * b * (Real.sqrt η * d) = η * b * d := by
    nlinarith
  rw [hab, hcd, hbd] at hcs
  change a * c + η * b * d ≤ cost η a b * cost η c d at hcs
  have hs₁ := cost_sq hη a b
  have hs₂ := cost_sq hη c d
  have hs₃ := cost_sq hη (a + c) (b + d)
  have hn₁ := cost_nonneg η a b
  have hn₂ := cost_nonneg η c d
  have hn₃ := cost_nonneg η (a + c) (b + d)
  nlinarith

theorem area_tail_identity (T : ℝ) (s : ℕ → ℝ)
    (hs : Summable (fun n => |s n|)) (N : ℕ) :
    area T s - partialArea T s N = T * ∑' n, |s (n + N)| := by
  have h := hs.sum_add_tsum_nat_add N
  dsimp [area, partialArea]
  rw [← h]
  ring

theorem summable_of_geometric_bound {s : ℕ → ℝ} {C q : ℝ}
    (hq0 : 0 ≤ q) (hq1 : q < 1) (hbound : ∀ n, |s n| ≤ C * q ^ n) :
    Summable (fun n => |s n|) := by
  apply Summable.of_nonneg_of_le (fun n => abs_nonneg _) hbound
  exact (summable_geometric_of_lt_one hq0 hq1).mul_left C

theorem absolute_tail_bound {s : ℕ → ℝ} {C q : ℝ}
    (hq0 : 0 ≤ q) (hq1 : q < 1) (hbound : ∀ n, |s n| ≤ C * q ^ n)
    (N : ℕ) :
    (∑' n, |s (n + N)|) ≤ C * q ^ N / (1 - q) := by
  have hs := summable_of_geometric_bound hq0 hq1 hbound
  have htail := (summable_nat_add_iff N).2 hs
  have hg := (summable_geometric_of_lt_one hq0 hq1).mul_left (C * q ^ N)
  have hb : ∀ n, |s (n + N)| ≤ (C * q ^ N) * q ^ n := by
    intro n
    convert hbound (n + N) using 1 <;> rw [pow_add] <;> ring
  have ht := tsum_le_tsum hb htail hg
  rw [tsum_mul_left, tsum_geometric_of_lt_one hq0 hq1] at ht
  simpa [div_eq_mul_inv, mul_assoc] using ht

theorem area_tail_bounds {T Tmax C q : ℝ} {s : ℕ → ℝ}
    (hT : 0 ≤ T) (hTmax : T ≤ Tmax) (hC : 0 ≤ C)
    (hq0 : 0 ≤ q) (hq1 : q < 1) (hbound : ∀ n, |s n| ≤ C * q ^ n)
    (N : ℕ) :
    0 ≤ area T s - partialArea T s N ∧
      area T s - partialArea T s N ≤ Tmax * C * q ^ N / (1 - q) := by
  rw [area_tail_identity T s (summable_of_geometric_bound hq0 hq1 hbound) N]
  have ht0 : 0 ≤ ∑' n, |s (n + N)| := tsum_nonneg (fun n => abs_nonneg _)
  constructor
  · exact mul_nonneg hT ht0
  · calc
      T * (∑' n, |s (n + N)|) ≤ Tmax * (∑' n, |s (n + N)|) :=
        mul_le_mul_of_nonneg_right hTmax ht0
      _ ≤ Tmax * (C * q ^ N / (1 - q)) :=
        mul_le_mul_of_nonneg_left (absolute_tail_bound hq0 hq1 hbound N)
          (le_trans hT hTmax)
      _ = Tmax * C * q ^ N / (1 - q) := by ring

/-- Exact two-area remainder constant, including the nonnegative lower
bound. Here `Ce` and `Cu` are the geometric envelopes of the output signals. -/
theorem miace_tail_bound {T Tmax Ce Cu q η : ℝ} {e v : ℕ → ℝ}
    (hT : 0 ≤ T) (hTmax : T ≤ Tmax) (hCe : 0 ≤ Ce) (hCu : 0 ≤ Cu)
    (hq0 : 0 ≤ q) (hq1 : q < 1) (hη : 0 ≤ η)
    (he : ∀ n, |e n| ≤ Ce * q ^ n) (hv : ∀ n, |v n| ≤ Cu * q ^ n)
    (N : ℕ) :
    0 ≤ cost η (area T e) (area T v) -
      cost η (partialArea T e N) (partialArea T v N) ∧
    cost η (area T e) (area T v) -
      cost η (partialArea T e N) (partialArea T v N) ≤
        (Tmax * q ^ N / (1 - q)) * Real.sqrt (Ce ^ 2 + η * Cu ^ 2) := by
  obtain ⟨he0, he1⟩ := area_tail_bounds hT hTmax hCe hq0 hq1 he N
  obtain ⟨hv0, hv1⟩ := area_tail_bounds hT hTmax hCu hq0 hq1 hv N
  have hpe : 0 ≤ partialArea T e N := by dsimp [partialArea]; positivity
  have hpv : 0 ≤ partialArea T v N := by dsimp [partialArea]; positivity
  have hmono := cost_mono hη hpe hpv (by linarith : partialArea T e N ≤ area T e)
    (by linarith : partialArea T v N ≤ area T v)
  refine ⟨sub_nonneg.mpr hmono, ?_⟩
  have htri := cost_triangle hη (partialArea T e N) (partialArea T v N)
    (area T e - partialArea T e N) (area T v - partialArea T v N)
  simp only [add_sub_cancel] at htri
  let K := Tmax * q ^ N / (1 - q)
  have hTm : 0 ≤ Tmax := hT.trans hTmax
  have hden : 0 < 1 - q := sub_pos.mpr hq1
  have hK : 0 ≤ K := by dsimp [K]; positivity
  have heK : area T e - partialArea T e N ≤ K * Ce := by
    dsimp [K]
    convert he1 using 1 <;> ring
  have hvK : area T v - partialArea T v N ≤ K * Cu := by
    dsimp [K]
    convert hv1 using 1 <;> ring
  have hc := cost_mono hη he0 hv0 heK hvK
  rw [cost_mul hK] at hc
  change cost η (area T e) (area T v) -
    cost η (partialArea T e N) (partialArea T v N) ≤ K * cost η Ce Cu
  linarith

theorem uniform_area_series {X : Type*} (s : ℕ → X → ℝ) {C q : ℝ}
    (hq0 : 0 ≤ q) (hq1 : q < 1) (hbound : ∀ n x, |s n x| ≤ C * q ^ n) :
    TendstoUniformly (fun N x => ∑ n ∈ Finset.range N, |s n x|)
      (fun x => ∑' n, |s n x|) atTop := by
  apply tendstoUniformly_tsum_nat ((summable_geometric_of_lt_one hq0 hq1).mul_left C)
  intro n x
  simpa only [Real.norm_eq_abs, abs_abs] using hbound n x

theorem continuous_area_of_geometric_bound {X : Type*} [TopologicalSpace X]
    (s : ℕ → X → ℝ) (T : X → ℝ) {C q : ℝ}
    (hs : ∀ n, Continuous (s n)) (hT : Continuous T)
    (hq0 : 0 ≤ q) (hq1 : q < 1) (hbound : ∀ n x, |s n x| ≤ C * q ^ n) :
    Continuous (fun x => area (T x) (fun n => s n x)) := by
  apply hT.mul
  apply continuous_tsum (fun n => (hs n).abs)
    ((summable_geometric_of_lt_one hq0 hq1).mul_left C)
  intro n x
  simpa only [Real.norm_eq_abs, abs_abs] using hbound n x

theorem miace_continuous_and_attains_minimum
    {X : Type*} [TopologicalSpace X] [CompactSpace X] [Nonempty X]
    (e v : ℕ → X → ℝ) (T : X → ℝ) (η : ℝ) {Ce Cu q : ℝ}
    (he : ∀ n, Continuous (e n)) (hv : ∀ n, Continuous (v n))
    (hT : Continuous T) (hq0 : 0 ≤ q) (hq1 : q < 1)
    (hbe : ∀ n x, |e n x| ≤ Ce * q ^ n) (hbv : ∀ n x, |v n x| ≤ Cu * q ^ n) :
    Continuous (fun x => cost η (area (T x) (fun n => e n x))
      (area (T x) (fun n => v n x))) ∧
    ∃ x, ∀ y, cost η (area (T x) (fun n => e n x)) (area (T x) (fun n => v n x)) ≤
      cost η (area (T y) (fun n => e n y)) (area (T y) (fun n => v n y)) := by
  have hAe := continuous_area_of_geometric_bound e T he hT hq0 hq1 hbe
  have hAu := continuous_area_of_geometric_bound v T hv hT hq0 hq1 hbv
  have hM : Continuous (fun x => cost η (area (T x) (fun n => e n x))
      (area (T x) (fun n => v n x))) := by
    exact ((hAe.pow 2).add (continuous_const.mul (hAu.pow 2))).sqrt
  refine ⟨hM, ?_⟩
  obtain ⟨x, _, hx⟩ := isCompact_univ.exists_isMinOn Set.univ_nonempty hM.continuousOn
  exact ⟨x, fun y => hx (Set.mem_univ y)⟩

end C2.MIACE
