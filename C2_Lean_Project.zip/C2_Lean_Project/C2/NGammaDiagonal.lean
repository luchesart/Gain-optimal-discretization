import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.LinearAlgebra.Matrix.ToLinearEquiv
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Data.Complex.Norm
import Mathlib.Tactic

/-! # Independent diagonal weights preserve diagonal dissipativity

The hypotheses below are the coordinate form of a positive diagonal Lyapunov
matrix and `Aᵀ P + P A ≺ 0`.  The proof uses the actual homogeneous difference
equation.  No stability or contraction conclusion is assumed.
-/

noncomputable section
namespace C2.NGamma
open scoped BigOperators
open Matrix
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The quadratic form of the positive diagonal matrix with entries `p`. -/
def energy (p : ι → ℝ) (v : ι → ℝ) : ℝ := ∑ i, p i * (v i)^2

/-- Half of the quadratic form of `Aᵀ P + P A`. -/
def dissipation (p : ι → ℝ) (A : Matrix ι ι ℝ) (v : ι → ℝ) : ℝ :=
  ∑ i, p i * v i * (A *ᵥ v) i

/-- Strict diagonal dissipativity, in exact coordinates. -/
def DiagonallyDissipative (p : ι → ℝ) (A : Matrix ι ι ℝ) : Prop :=
  ∀ v : ι → ℝ, v ≠ 0 → dissipation p A v < 0

/-- The unforced generalized-theta difference equation. -/
def HomogeneousStep (T : ℝ) (γ : ι → ℝ) (A : Matrix ι ι ℝ)
    (x xp : ι → ℝ) : Prop :=
  ∀ i, xp i - x i = T * (γ i * (A *ᵥ xp) i + (1-γ i) * (A *ᵥ x) i)

def stepE (T : ℝ) (γ : ι → ℝ) (A : Matrix ι ι ℝ) : Matrix ι ι ℝ :=
  1 - T • (diagonal γ * A)

def stepF (T : ℝ) (γ : ι → ℝ) (A : Matrix ι ι ℝ) : Matrix ι ι ℝ :=
  1 + T • (diagonal (fun i => 1 - γ i) * A)

lemma energy_nonneg {p : ι → ℝ} (hp : ∀ i, 0 ≤ p i) (v : ι → ℝ) :
    0 ≤ energy p v := by
  exact Finset.sum_nonneg fun i _ => mul_nonneg (hp i) (sq_nonneg _)

lemma energy_pos {p : ι → ℝ} (hp : ∀ i, 0 < p i) {v : ι → ℝ} (hv : v ≠ 0) :
    0 < energy p v := by
  obtain ⟨i, hi⟩ : ∃ i, v i ≠ 0 := by
    by_contra h
    push_neg at h
    exact hv (funext h)
  exact Finset.sum_pos' (fun j _ => mul_nonneg (hp j).le (sq_nonneg _))
    ⟨i, Finset.mem_univ _, mul_pos (hp i) (sq_pos_of_ne_zero hi)⟩

@[simp] lemma energy_zero (p : ι → ℝ) : energy p 0 = 0 := by simp [energy]

lemma DiagonallyDissipative.ker {p : ι → ℝ} {A : Matrix ι ι ℝ}
    (hA : DiagonallyDissipative p A) {v : ι → ℝ} (hv : A *ᵥ v = 0) : v = 0 := by
  by_contra h
  have hn := hA v h
  simp [dissipation, hv] at hn

/-- The paper's strict Lyapunov hypothesis is exactly strict diagonal
 dissipativity; this identity includes both real bilinear terms. -/
lemma lyapunov_quadratic (p : ι → ℝ) (A : Matrix ι ι ℝ) (v : ι → ℝ) :
    dotProduct v ((A.transpose * diagonal p + diagonal p * A) *ᵥ v) =
      2 * dissipation p A v := by
  simp only [add_mulVec, dotProduct_add, ← mulVec_mulVec]
  rw [dotProduct_mulVec, vecMul_transpose]
  simp only [dotProduct, mulVec_diagonal, Pi.mul_apply, dissipation]
  rw [← Finset.sum_add_distrib, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  ring

lemma homogeneousStep_iff (T : ℝ) (γ : ι → ℝ) (A : Matrix ι ι ℝ)
    (x xp : ι → ℝ) :
    HomogeneousStep T γ A x xp ↔ stepE T γ A *ᵥ xp = stepF T γ A *ᵥ x := by
  simp only [stepE, stepF, sub_mulVec, add_mulVec, smul_mulVec_assoc, one_mulVec,
    ← mulVec_mulVec, mulVec_diagonal, HomogeneousStep, funext_iff, Pi.sub_apply,
    Pi.add_apply, Pi.smul_apply, smul_eq_mul, Pi.mul_apply]
  constructor <;> intro h i <;> specialize h i <;> linarith

/-- Exact discrete energy balance, before imposing positivity hypotheses. -/
theorem homogeneous_energy_identity (p γ : ι → ℝ) (A : Matrix ι ι ℝ)
    (T : ℝ) {x xp : ι → ℝ} (h : HomogeneousStep T γ A x xp) :
    T * (energy p (A *ᵥ xp) - energy p (A *ᵥ x)) =
      2 * dissipation p A (xp-x) -
      2*T * ∑ i, p i * (γ i - 1/2) * ((A *ᵥ (xp-x)) i)^2 := by
  simp only [energy, dissipation, mulVec_sub, Pi.sub_apply]
  rw [← Finset.sum_sub_distrib, Finset.mul_sum, Finset.mul_sum, Finset.mul_sum,
    ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro i _
  rw [h i]
  ring

/-- Every nonstationary homogeneous step strictly decreases the weighted
 energy of `A x`.  In particular the result does not assume invertibility of E. -/
theorem homogeneous_energy_strict {p γ : ι → ℝ} {A : Matrix ι ι ℝ} {T : ℝ}
    (hp : ∀ i, 0 < p i) (hγ : ∀ i, 1/2 ≤ γ i) (hT : 0 < T)
    (hA : DiagonallyDissipative p A) {x xp : ι → ℝ}
    (h : HomogeneousStep T γ A x xp) (hne : xp ≠ x) :
    energy p (A *ᵥ xp) < energy p (A *ᵥ x) := by
  have hδ : xp-x ≠ 0 := sub_ne_zero.mpr hne
  have hd := hA (xp-x) hδ
  have hn : 0 ≤ ∑ i, p i * (γ i - 1/2) * ((A *ᵥ (xp-x)) i)^2 :=
    Finset.sum_nonneg fun i _ => mul_nonneg (mul_nonneg (hp i).le (sub_nonneg.mpr (hγ i))) (sq_nonneg _)
  have he := homogeneous_energy_identity p γ A T h
  nlinarith

/-- Strict dissipativity rules out a nonzero fixed state. -/
lemma homogeneous_ne {p γ : ι → ℝ} {A : Matrix ι ι ℝ} {T : ℝ}
    (hT : 0 < T) (hA : DiagonallyDissipative p A) {x xp : ι → ℝ}
    (h : HomogeneousStep T γ A x xp) (hx : x ≠ 0) : xp ≠ x := by
  intro he
  subst xp
  have hz : A *ᵥ x = 0 := by
    ext i
    have hh := h i
    have ht : T ≠ 0 := ne_of_gt hT
    have : T * (A *ᵥ x) i = 0 := by nlinarith [hh]
    exact (mul_eq_zero.mp this).resolve_left ht
  exact hx (hA.ker hz)

/-- The implicit step matrix is actually nonsingular for every admissible T
 and every diagonal weight gamma >= 1/2. -/
theorem stepE_det_ne_zero {p γ : ι → ℝ} {A : Matrix ι ι ℝ} {T : ℝ}
    (hp : ∀ i, 0 < p i) (hγ : ∀ i, 1/2 ≤ γ i) (hT : 0 < T)
    (hA : DiagonallyDissipative p A) : (stepE T γ A).det ≠ 0 := by
  intro he
  obtain ⟨v, hv, hev⟩ := Matrix.exists_mulVec_eq_zero_iff.mpr he
  have hs : HomogeneousStep T γ A 0 v :=
    (homogeneousStep_iff T γ A 0 v).mpr (by simpa using hev)
  have hh := homogeneous_energy_strict hp hγ hT hA hs hv
  simp only [Matrix.mulVec_zero, energy_zero] at hh
  exact (not_lt_of_ge (energy_nonneg (fun i => (hp i).le) (A *ᵥ v)) hh)


def stepMatrix (T : ℝ) (γ : ι → ℝ) (A : Matrix ι ι ℝ) : Matrix ι ι ℝ :=
  (stepE T γ A)⁻¹ * stepF T γ A

lemma stepMatrix_step {p γ : ι → ℝ} {A : Matrix ι ι ℝ} {T : ℝ}
    (hp : ∀ i, 0 < p i) (hγ : ∀ i, 1/2 ≤ γ i) (hT : 0 < T)
    (hA : DiagonallyDissipative p A) (x : ι → ℝ) :
    HomogeneousStep T γ A x (stepMatrix T γ A *ᵥ x) := by
  apply (homogeneousStep_iff T γ A x _).mpr
  rw [stepMatrix, Matrix.mulVec_mulVec,
    Matrix.mul_nonsing_inv_cancel_left _ _ (isUnit_iff_ne_zero.mpr (stepE_det_ne_zero hp hγ hT hA))]

lemma stepMatrix_energy_lt {p γ : ι → ℝ} {A : Matrix ι ι ℝ} {T : ℝ}
    (hp : ∀ i, 0 < p i) (hγ : ∀ i, 1/2 ≤ γ i) (hT : 0 < T)
    (hA : DiagonallyDissipative p A) {x : ι → ℝ} (hx : x ≠ 0) :
    energy p (A *ᵥ (stepMatrix T γ A *ᵥ x)) < energy p (A *ᵥ x) := by
  have hs := stepMatrix_step hp hγ hT hA x
  exact homogeneous_energy_strict hp hγ hT hA hs (homogeneous_ne hT hA hs hx)

lemma stepMatrix_energy_le {p γ : ι → ℝ} {A : Matrix ι ι ℝ} {T : ℝ}
    (hp : ∀ i, 0 < p i) (hγ : ∀ i, 1/2 ≤ γ i) (hT : 0 < T)
    (hA : DiagonallyDissipative p A) (x : ι → ℝ) :
    energy p (A *ᵥ (stepMatrix T γ A *ᵥ x)) ≤ energy p (A *ᵥ x) := by
  by_cases hx : x = 0
  · simp [hx]
  · exact (stepMatrix_energy_lt hp hγ hT hA hx).le

lemma energy_rotation (p : ι → ℝ) (u v : ι → ℝ) (a b : ℝ) :
    energy p (a • u - b • v) + energy p (b • u + a • v) =
      (a^2+b^2)*(energy p u + energy p v) := by
  simp only [energy, Pi.sub_apply, Pi.add_apply, Pi.smul_apply, smul_eq_mul]
  rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  ring

/-- Real matrices are embedded in the complex field, so the stability
 statement below concerns actual complex eigenvalues. -/
def complexify (A : Matrix ι ι ℝ) : Matrix ι ι ℂ := A.map Complex.ofReal

lemma complexify_mulVec_re (A : Matrix ι ι ℝ) (v : ι → ℂ) :
    (fun i => ((complexify A *ᵥ v) i).re) = A *ᵥ (fun i => (v i).re) := by
  ext i
  simp [complexify, Matrix.mulVec, dotProduct, Complex.mul_re]

lemma complexify_mulVec_im (A : Matrix ι ι ℝ) (v : ι → ℂ) :
    (fun i => ((complexify A *ᵥ v) i).im) = A *ᵥ (fun i => (v i).im) := by
  ext i
  simp [complexify, Matrix.mulVec, dotProduct, Complex.mul_im]

/-- Every actual complex eigenvalue of the implicit step lies strictly inside
 the unit disk. The proof follows from the derived, not assumed, energy law. -/
theorem stepMatrix_eigenvalue_norm_lt_one {p γ : ι → ℝ} {A : Matrix ι ι ℝ} {T : ℝ}
    (hp : ∀ i, 0 < p i) (hγ : ∀ i, 1/2 ≤ γ i) (hT : 0 < T)
    (hA : DiagonallyDissipative p A) {z : ℂ} {v : ι → ℂ} (hv : v ≠ 0)
    (he : complexify (stepMatrix T γ A) *ᵥ v = z • v) : ‖z‖ < 1 := by
  let u : ι → ℝ := fun i => (v i).re
  let w : ι → ℝ := fun i => (v i).im
  have huw : u ≠ 0 ∨ w ≠ 0 := by
    by_contra h
    push_neg at h
    apply hv
    funext i
    apply Complex.ext
    · exact congrFun h.1 i
    · exact congrFun h.2 i
  have hr : stepMatrix T γ A *ᵥ u = z.re • u - z.im • w := by
    rw [← complexify_mulVec_re, he]
    ext i
    simp [u, w, Complex.mul_re]
  have hi : stepMatrix T γ A *ᵥ w = z.im • u + z.re • w := by
    rw [← complexify_mulVec_im, he]
    ext i
    simp [u, w, Complex.mul_im]
    ring
  have hsum : 0 < energy p (A *ᵥ u) + energy p (A *ᵥ w) := by
    rcases huw with hu | hw
    · exact add_pos_of_pos_of_nonneg (energy_pos hp (fun h => hu (hA.ker h)))
        (energy_nonneg (fun i => (hp i).le) _)
    · exact add_pos_of_nonneg_of_pos (energy_nonneg (fun i => (hp i).le) _)
        (energy_pos hp (fun h => hw (hA.ker h)))
  have hstrict : energy p (A *ᵥ (stepMatrix T γ A *ᵥ u)) +
      energy p (A *ᵥ (stepMatrix T γ A *ᵥ w)) <
      energy p (A *ᵥ u) + energy p (A *ᵥ w) := by
    rcases huw with hu | hw
    · exact add_lt_add_of_lt_of_le (stepMatrix_energy_lt hp hγ hT hA hu)
        (stepMatrix_energy_le hp hγ hT hA w)
    · exact add_lt_add_of_le_of_lt (stepMatrix_energy_le hp hγ hT hA u)
        (stepMatrix_energy_lt hp hγ hT hA hw)
  rw [hr, hi, Matrix.mulVec_sub, Matrix.mulVec_add, Matrix.mulVec_smul,
    Matrix.mulVec_smul, Matrix.mulVec_smul, Matrix.mulVec_smul, energy_rotation] at hstrict
  have hq : z.re^2 + z.im^2 < 1 := by nlinarith
  have hn := Complex.sq_norm z
  rw [Complex.normSq_apply] at hn
  nlinarith [norm_nonneg z]

lemma eval_charpoly (M : Matrix ι ι ℂ) (z : ℂ) :
    M.charpoly.eval z = (z • 1 - M).det := by
  rw [Matrix.charpoly, Matrix.eval_det, Matrix.matPolyEquiv_eval_eq_map]
  congr 1
  ext i j
  by_cases hij : i = j
  · subst j
    simp [Matrix.charmatrix_apply_eq, Matrix.map_apply]
  · simp [Matrix.charmatrix_apply_ne _ _ _ hij, Matrix.map_apply, hij]

/-- Root-based strict Schur stability for a real square matrix. -/
def MatrixSchurStable (M : Matrix ι ι ℝ) : Prop :=
  ∀ z : ℂ, (complexify M).charpoly.eval z = 0 → ‖z‖ < 1

/-- Full diagonal-stability conclusion: nonsingular implicit solve and actual
 complex-root Schur stability of E^-1 F for every T>0 and gamma>=1/2. -/
theorem diagonal_stability {p γ : ι → ℝ} {A : Matrix ι ι ℝ} {T : ℝ}
    (hp : ∀ i, 0 < p i) (hγ : ∀ i, 1/2 ≤ γ i) (hT : 0 < T)
    (hA : DiagonallyDissipative p A) :
    (stepE T γ A).det ≠ 0 ∧ MatrixSchurStable (stepMatrix T γ A) := by
  refine ⟨stepE_det_ne_zero hp hγ hT hA, ?_⟩
  intro z hz
  rw [eval_charpoly] at hz
  obtain ⟨v, hv, he⟩ := Matrix.exists_mulVec_eq_zero_iff.mpr hz
  have hev : complexify (stepMatrix T γ A) *ᵥ v = z • v := by
    rw [Matrix.sub_mulVec, Matrix.smul_mulVec_assoc, Matrix.one_mulVec] at he
    exact (sub_eq_zero.mp he).symm
  exact stepMatrix_eigenvalue_norm_lt_one hp hγ hT hA hv hev

/-- The proposition stated with the literal positive/negative definite matrix
 hypotheses used in the manuscript. -/
theorem diagonal_stability_of_lyapunov {p γ : ι → ℝ} {A : Matrix ι ι ℝ} {T : ℝ}
    (hp : (diagonal p).PosDef) (hγ : ∀ i, 1/2 ≤ γ i) (hT : 0 < T)
    (hL : (-(A.transpose * diagonal p + diagonal p * A)).PosDef) :
    (stepE T γ A).det ≠ 0 ∧ MatrixSchurStable (stepMatrix T γ A) := by
  have hpp : ∀ i, 0 < p i := by
    intro i
    have h := hp.2 (Pi.single i 1) (by simp)
    simpa [Matrix.mulVec_diagonal, dotProduct, Pi.single_apply] using h
  apply diagonal_stability hpp hγ hT
  intro v hv
  have h := hL.2 v hv
  simp only [star_trivial, Matrix.neg_mulVec, dotProduct_neg] at h
  rw [lyapunov_quadratic] at h
  linarith

end C2.NGamma
