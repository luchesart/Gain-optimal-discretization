import C2.CommonDegree

/-! Exact value and derivative at the transformed simple integrator pole. -/
noncomputable section
open Polynomial Finset
namespace C2.GeneralCompletion

/-- The simple-zero hypotheses used below are exactly the manuscript's
factorization A(s)=s*A0(s), A0(0)≠0. -/
theorem simple_origin_iff_integrator_factor (A : Polynomial ℝ) :
    (A.eval 0 = 0 ∧ A.derivative.eval 0 ≠ 0) ↔
      ∃ A₀ : Polynomial ℝ, A = Polynomial.X*A₀ ∧ A₀.eval 0 ≠ 0 := by
  constructor
  · rintro ⟨hA0,hAd⟩
    have hx : Polynomial.X ∣ A := by
      simpa using (dvd_iff_isRoot.mpr hA0 : (Polynomial.X-Polynomial.C (0 : ℝ)) ∣ A)
    obtain ⟨A₀,hA₀⟩ := hx
    refine ⟨A₀,hA₀,?_⟩
    simpa [hA₀,Polynomial.derivative_mul] using hAd
  · rintro ⟨A₀,rfl,hA₀⟩
    simpa [Polynomial.derivative_mul] using hA₀

theorem theta_transform_eval_one (p : Polynomial ℝ) (d : ℕ) (T γ : ℝ) :
    (C2.commonDegreeTransform p d (C2.thetaScale T γ) C2.thetaNumerator).eval 1 =
      T^d*p.eval 0 := by
  rw [C2.commonDegreeTransform_eval]
  have hU : (C2.thetaScale T γ).eval 1 = T := by simp [C2.thetaScale]
  have hV : (C2.thetaNumerator : Polynomial ℝ).eval 1 = 0 := by simp [C2.thetaNumerator]
  rw [hU,hV]
  rw [Finset.sum_eq_single 0]
  · simp [mul_comm,Polynomial.coeff_zero_eq_eval_zero]
  · intro j hj hj0
    simp [zero_pow hj0]
  · simp

theorem theta_transform_derivative_at_integrator
    (A : Polynomial ℝ) (d : ℕ) (T γ : ℝ) (hd : 1 ≤ d) (hA0 : A.eval 0 = 0) :
    (C2.commonDegreeTransform A d (C2.thetaScale T γ) C2.thetaNumerator).derivative.eval 1 =
      T^(d-1)*A.derivative.eval 0 := by
  have hcoeff0 : A.coeff 0 = 0 := (Polynomial.coeff_zero_eq_eval_zero A).trans hA0
  have hU : (C2.thetaScale T γ).eval 1 = T := by simp [C2.thetaScale]
  have hV : (C2.thetaNumerator : Polynomial ℝ).eval 1 = 0 := by simp [C2.thetaNumerator]
  have hV' : (C2.thetaNumerator : Polynomial ℝ).derivative.eval 1 = 1 := by
    simp [C2.thetaNumerator]
  unfold C2.commonDegreeTransform
  rw [Polynomial.derivative_sum,Polynomial.eval_finset_sum]
  rw [Finset.sum_eq_single 1]
  · simp [Polynomial.derivative_mul,Polynomial.derivative_pow,hU,hV,hV',mul_comm,
      ← Polynomial.coeff_zero_eq_eval_zero,Polynomial.coeff_derivative]
  · intro j hj hj1
    by_cases hj0 : j = 0
    · simp [hj0,hcoeff0]
    · have hjpred : j-1 ≠ 0 := by omega
      simp [Polynomial.derivative_mul,Polynomial.derivative_pow,hU,hV,hV',
        hj0,hjpred]
  · intro hnot
    exact False.elim (hnot (Finset.mem_range.mpr (by omega)))

theorem theta_integrator_residue
    (A B : Polynomial ℝ) (d : ℕ) (T γ : ℝ) (hd : 1 ≤ d)
    (hT : T ≠ 0) (hA0 : A.eval 0 = 0) (hA' : A.derivative.eval 0 ≠ 0) :
    (C2.commonDegreeTransform B d (C2.thetaScale T γ) C2.thetaNumerator).eval 1 /
      (C2.commonDegreeTransform A d (C2.thetaScale T γ) C2.thetaNumerator).derivative.eval 1 =
      T*(B.eval 0/A.derivative.eval 0) := by
  rw [theta_transform_eval_one,theta_transform_derivative_at_integrator A d T γ hd hA0]
  have hpow : T^d = T^(d-1)*T := by
    rw [← pow_succ]
    congr 1
    omega
  rw [hpow]
  field_simp
  <;> ring

theorem delayed_integrator_derivative_one (D : Polynomial ℝ) (m : ℕ)
    (hD0 : D.eval 1 = 0) :
    (Polynomial.X^m*D).derivative.eval 1 = D.derivative.eval 1 := by
  simp [Polynomial.derivative_mul,Polynomial.derivative_pow,hD0]

end C2.GeneralCompletion
