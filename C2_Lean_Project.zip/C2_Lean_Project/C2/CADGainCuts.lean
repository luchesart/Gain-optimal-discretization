import C2.CADCells
import C2.CADProjectionRegularity

/-! Bounded algebraic gain cuts and their actual adjacent open cells. -/
noncomputable section
open Polynomial Set
namespace C2.CADGainCuts

def cuts (p : ℚ[X]) (hp : p ≠ 0) (K : ℚ) : Finset ℝ := by
  classical
  exact ((CADProjection.rational_zero_set_finite p hp).toFinset.filter
    fun x => x ∈ Icc (0 : ℝ) (K : ℝ)) ∪ {0,(K : ℝ)}

theorem mem_cuts_iff (p : ℚ[X]) (hp : p ≠ 0) (K : ℚ) (x : ℝ) :
    x ∈ cuts p hp K ↔
      (p.eval₂ (algebraMap ℚ ℝ) x = 0 ∧ x ∈ Icc 0 (K : ℝ)) ∨
      x = 0 ∨ x = (K : ℝ) := by
  classical
  simp [cuts,or_assoc,or_left_comm,or_comm]

theorem zero_mem (p : ℚ[X]) (hp : p ≠ 0) (K : ℚ) :
    (0 : ℝ) ∈ cuts p hp K := (mem_cuts_iff p hp K 0).mpr (Or.inr (Or.inl rfl))

theorem upper_mem (p : ℚ[X]) (hp : p ≠ 0) (K : ℚ) :
    (K : ℝ) ∈ cuts p hp K :=
  (mem_cuts_iff p hp K (K : ℝ)).mpr (Or.inr (Or.inr rfl))

theorem cuts_bounded (p : ℚ[X]) (hp : p ≠ 0) {K : ℚ} (hK : 0 ≤ K) :
    ∀ x ∈ cuts p hp K, x ∈ Icc (0 : ℝ) (K : ℝ) := by
  intro x hx
  have hK' : (0 : ℝ) ≤ (K : ℝ) := by exact_mod_cast hK
  rcases (mem_cuts_iff p hp K x).mp hx with hx | rfl | rfl
  · exact hx.2
  · exact ⟨le_rfl,hK'⟩
  · exact ⟨hK',le_rfl⟩

theorem rational_isAlgebraic (q : ℚ) : IsAlgebraic ℚ (q : ℝ) := by
  refine ⟨X - C q, Polynomial.X_sub_C_ne_zero q, ?_⟩
  simp

theorem cuts_algebraic (p : ℚ[X]) (hp : p ≠ 0) (K : ℚ) :
    ∀ x ∈ cuts p hp K, IsAlgebraic ℚ x := by
  intro x hx
  rcases (mem_cuts_iff p hp K x).mp hx with hx | rfl | rfl
  · exact CADProjection.rational_zero_isAlgebraic p hp hx.1
  · simpa using rational_isAlgebraic 0
  · exact rational_isAlgebraic K

theorem nonzero_on_cell (p : ℚ[X]) (hp : p ≠ 0) {K : ℚ} (hK : 0 ≤ K)
    {a b : ℝ} (hab : CADCells.Adjacent (cuts p hp K) a b)
    {x : ℝ} (hx : x ∈ Ioo a b) : p.eval₂ (algebraMap ℚ ℝ) x ≠ 0 := by
  intro heq
  have hbound := cuts_bounded p hp hK
  have hxbound : x ∈ Icc 0 (K : ℝ) :=
    ⟨(hbound a hab.1).1.trans hx.1.le,hx.2.le.trans (hbound b hab.2.1).2⟩
  exact CADCells.no_cut_inside hab hx
    ((mem_cuts_iff p hp K x).mpr (Or.inl ⟨heq,hxbound⟩))

theorem exact_cell_cover (p : ℚ[X]) (hp : p ≠ 0) {K : ℚ} (hK : 0 ≤ K) :
    {x : ℝ | ∃ c ∈ CADCells.cells (cuts p hp K), x ∈ Ioo c.1 c.2} =
      Ioo 0 (K : ℝ) \ (cuts p hp K : Set ℝ) := by
  exact CADCells.cut_union_coverage (zero_mem p hp K) (upper_mem p hp K)
    (cuts_bounded p hp hK)

theorem cells_are_projection_free (p : ℚ[X]) (hp : p ≠ 0)
    {K : ℚ} (hK : 0 ≤ K) {a b : ℝ}
    (hab : (a,b) ∈ CADCells.cells (cuts p hp K)) :
    IsPreconnected (Ioo a b) ∧
      ∀ k ∈ Ioo a b, p.eval₂ (algebraMap ℚ ℝ) k ≠ 0 := by
  exact ⟨isPreconnected_Ioo,fun _ hk =>
    nonzero_on_cell p hp hK ((CADCells.mem_cells_iff _ _ _).mp hab) hk⟩

end C2.CADGainCuts
