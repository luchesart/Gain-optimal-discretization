import Mathlib

/-! Executable search over an explicitly encoded type. No Countable.choose or
classical decision procedure is introduced: encoding and acceptance are data
arguments. Existence is used only in the erased termination proof of Nat.find. -/
namespace C2.CADEffective

variable {α : Type*} [Encodable α]

def acceptedCode (accept : α → Bool) (n : ℕ) : Bool :=
  (Encodable.decode (α := α) n).any accept

theorem exists_acceptedCode (accept : α → Bool)
    (h : ∃ a, accept a = true) : ∃ n, acceptedCode accept n = true := by
  obtain ⟨a, ha⟩ := h
  exact ⟨Encodable.encode a, by simp [acceptedCode, ha]⟩

def searchIndex (accept : α → Bool) (h : ∃ a, accept a = true) : ℕ :=
  Nat.find (exists_acceptedCode accept h)

theorem searchIndex_accepted (accept : α → Bool) (h : ∃ a, accept a = true) :
    acceptedCode accept (searchIndex accept h) = true :=
  Nat.find_spec (exists_acceptedCode accept h)

theorem searchIndex_le_code (accept : α → Bool) (h : ∃ a, accept a = true)
    (a : α) (ha : accept a = true) : searchIndex accept h ≤ Encodable.encode a := by
  apply Nat.find_min'
  simp [acceptedCode, ha]

theorem searchIndex_minimal (accept : α → Bool) (h : ∃ a, accept a = true)
    {n : ℕ} (hn : n < searchIndex accept h) : acceptedCode accept n = false := by
  have hh := Nat.find_min (exists_acceptedCode accept h) hn
  simpa using hh

def search (accept : α → Bool) (h : ∃ a, accept a = true) : α :=
  (Encodable.decode (α := α) (searchIndex accept h)).get (by
    have hh := searchIndex_accepted accept h
    cases he : Encodable.decode (α := α) (searchIndex accept h) with
    | none => simp [acceptedCode, he] at hh
    | some a => simp)

theorem search_accepted (accept : α → Bool) (h : ∃ a, accept a = true) :
    accept (search accept h) = true := by
  have hh := searchIndex_accepted accept h
  have he : Encodable.decode (α := α) (searchIndex accept h) = some (search accept h) :=
    Option.eq_some_of_isSome _
  simpa only [acceptedCode, he, Option.any_some] using hh

/-- A finite prefix implementation of the same enumeration, returning the first
accepted decoding before the fuel is exhausted. -/
def scanFrom (accept : α → Bool) : ℕ → ℕ → Option α
  | _, 0 => none
  | n, fuel + 1 =>
      match Encodable.decode (α := α) n with
      | none => scanFrom accept (n + 1) fuel
      | some a => if accept a then some a else scanFrom accept (n + 1) fuel

theorem scanFrom_sound (accept : α → Bool) (n fuel : ℕ) {a : α}
    (h : scanFrom accept n fuel = some a) : accept a = true := by
  induction fuel generalizing n with
  | zero => simp [scanFrom] at h
  | succ fuel ih =>
      simp only [scanFrom] at h
      split at h
      · exact ih _ h
      · split at h
        · cases h; assumption
        · exact ih _ h

theorem scanFrom_exists_of_hit (accept : α → Bool) (n fuel : ℕ)
    (h : ∃ j, n ≤ j ∧ j < n + fuel ∧ acceptedCode accept j = true) :
    ∃ a, scanFrom accept n fuel = some a := by
  induction fuel generalizing n with
  | zero => obtain ⟨j, h1, h2, h3⟩ := h; omega
  | succ fuel ih =>
      obtain ⟨j, hnj, hj, ha⟩ := h
      cases he : Encodable.decode (α := α) n with
      | none =>
          have hjne : j ≠ n := by
            intro e; subst j; simp [acceptedCode, he] at ha
          have ht : ∃ a, scanFrom accept (n + 1) fuel = some a :=
            ih (n + 1) ⟨j, by omega, by omega, ha⟩
          simpa [scanFrom, he] using ht
      | some a =>
          by_cases hac : accept a = true
          · exact ⟨a, by simp [scanFrom, he, hac]⟩
          · have hjne : j ≠ n := by
              intro e; subst j; simp [acceptedCode, he, hac] at ha
            have ht : ∃ a, scanFrom accept (n + 1) fuel = some a :=
              ih (n + 1) ⟨j, by omega, by omega, ha⟩
            simpa [scanFrom, he, hac] using ht

theorem search_has_finite_execution (accept : α → Bool) (h : ∃ a, accept a = true) :
    ∃ a, scanFrom accept 0 (searchIndex accept h + 1) = some a ∧ accept a = true := by
  obtain ⟨a, ha⟩ := scanFrom_exists_of_hit accept 0 (searchIndex accept h + 1)
    ⟨searchIndex accept h, Nat.zero_le _, by omega, searchIndex_accepted accept h⟩
  exact ⟨a, ha, scanFrom_sound accept 0 _ ha⟩

end C2.CADEffective
