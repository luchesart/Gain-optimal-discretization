import C2.NGammaAllocation
import Mathlib.Analysis.SpecialFunctions.Sqrt

/-!
# Joint regularity of the exact clipped allocation

These results concern the explicit functions used in the fixed-frequency theorem,
including their behavior when an active clipping constraint changes.
-/
noncomputable section
open scoped BigOperators
namespace C2.NGamma

theorem frequencyFree_joint_continuous (r : ℝ) :
    Continuous (fun p : ℝ × ℝ => frequencyFree r p.1 p.2) := by
  unfold frequencyFree
  continuity

theorem frequencyAllocation_joint_continuous (r : ℝ) :
    Continuous (fun p : ℝ × ℝ => frequencyAllocation r p.1 p.2) := by
  unfold frequencyAllocation
  exact continuous_const.min (continuous_const.max (frequencyFree_joint_continuous r))

theorem allocationPhase_joint_continuousAt (r : ℝ) {p : ℝ × ℝ}
    (hw : p.2 ≠ 0) :
    ContinuousAt (fun p : ℝ × ℝ => allocationPhase r p.1 p.2) p := by
  unfold allocationPhase
  exact (Real.continuousAt_arctan.comp ((continuousAt_fst.add continuousAt_const).div continuousAt_snd hw)).sub
    (Real.continuousAt_arctan.comp (continuousAt_fst.div continuousAt_snd hw))

theorem allocationLogGain_joint_continuousAt {r : ℝ} (hr : 0 < r)
    {p : ℝ × ℝ} (hw : 0 < p.2) :
    ContinuousAt (fun p : ℝ × ℝ => allocationLogGain r p.1 p.2) p := by
  have hn : (r*p.1+2)^2+(r*p.2)^2 ≠ 0 := ne_of_gt (by positivity)
  have hd : p.1^2+p.2^2 ≠ 0 := ne_of_gt (by positivity)
  unfold allocationLogGain
  have hN : ContinuousAt (fun p : ℝ × ℝ => (r*p.1+2)^2+(r*p.2)^2) p := by fun_prop
  have hD : ContinuousAt (fun p : ℝ × ℝ => p.1^2+p.2^2) p := by fun_prop
  exact ((hN.log hn).sub (hD.log hd)).div_const 2

/-- Total derivative along any differentiable coordinate curve.  The second
term vanishes on the unconstrained inverse-marginal curve. -/
theorem allocationLagrangian_curve_hasDerivAt {r w l g' : ℝ} (hr : 0 < r)
    (hw : 0 < w) {g : ℝ → ℝ} (hg : HasDerivAt g g' w)
    (hP : r*g w+1 ≠ 0) :
    HasDerivAt (fun v => allocationLagrangian r v l (g v))
      (phaseDerivative r (g w) w * (1+l*allocationMarginal r (g w) w) +
       (allocationMarginal r (g w) w-l)*phaseDerivative r (g w) w*g') w := by
  have hN : 0 < (r*g w+2)^2+(r*w)^2 := by positivity
  have hD : 0 < (g w)^2+w^2 := by positivity
  have hN' : 0 < (r*g w+2)^2+r^2*w^2 := by positivity
  have hA : 0 < 1+((g w+2/r)/w)^2 := by positivity
  have hB : 0 < 1+(g w/w)^2 := by positivity
  have hn := (((hg.const_mul r).add_const 2).pow 2).add
    (((hasDerivAt_id w).const_mul r).pow 2)
  have hd := (hg.pow 2).add ((hasDerivAt_id w).pow 2)
  have hl := ((hn.log (ne_of_gt hN)).sub (hd.log (ne_of_gt hD))).div_const 2
  have hp := (((hg.add_const (2/r)).div (hasDerivAt_id w) (ne_of_gt hw)).arctan).sub
    ((hg.div (hasDerivAt_id w) (ne_of_gt hw)).arctan)
  have h := hl.sub (hp.const_mul l)
  unfold allocationLagrangian allocationLogGain allocationPhase
  convert h using 1
  unfold allocationMarginal phaseDerivative
  simp only [id_eq, Nat.cast_ofNat, Nat.reduceSub, pow_one, mul_one]
  field_simp
  <;> ring

theorem allocationLagrangian_frequency_hasDerivAt {r w x l : ℝ}
    (hr : 0 < r) (hw : 0 < w) (hx : r*x+1 ≠ 0) :
    HasDerivAt (fun v => allocationLagrangian r v l x)
      (phaseDerivative r x w * (1+l*allocationMarginal r x w)) w := by
  have h := allocationLagrangian_curve_hasDerivAt hr hw
    (g := fun _ => x) (l := l) (hasDerivAt_const w x) hx
  simpa using h

theorem frequencyAllocation_lagrangian_joint_continuousAt {r : ℝ} (hr : 0 < r)
    {p : ℝ × ℝ} (hw : 0 < p.1) :
    ContinuousAt (fun p : ℝ × ℝ =>
      allocationLagrangian r p.1 p.2 (frequencyAllocation r p.1 p.2)) p := by
  have hx := (frequencyAllocation_joint_continuous r).continuousAt (x := p)
  have hc : ContinuousAt (fun p : ℝ × ℝ => (frequencyAllocation r p.1 p.2,p.1)) p :=
    hx.prodMk continuousAt_fst
  have hlog := (allocationLogGain_joint_continuousAt hr hw).comp hc
  have hphase := (allocationPhase_joint_continuousAt r (ne_of_gt hw)).comp hc
  exact hlog.sub (continuousAt_snd.mul hphase)

theorem frequencyFree_frequency_hasDerivAt {r : ℝ} (hr : 0 < r) (l w : ℝ) :
    HasDerivAt (fun v => frequencyFree r v l)
      (l+(1+l^2)*r*w/Real.sqrt (1+(1+l^2)*r^2*w^2)) w := by
  have hn : 0 < 1+(1+l^2)*r^2*w^2 := by positivity
  have hs : Real.sqrt (1+(1+l^2)*r^2*w^2) ≠ 0 :=
    ne_of_gt (Real.sqrt_pos.2 hn)
  have hp := (((hasDerivAt_id w).pow 2).const_mul ((1+l^2)*r^2)).const_add 1
  have h := ((hasDerivAt_id w).const_mul l).add
    (((hp.sqrt (ne_of_gt hn)).sub_const 1).div_const r)
  unfold frequencyFree
  convert h using 1
  simp only [id_eq, Nat.cast_ofNat, Nat.reduceSub, pow_one, mul_one]
  field_simp
  <;> ring

theorem frequencyFree_lagrangian_hasDerivAt {r w l : ℝ}
    (hr : 0 < r) (hw : 0 < w) :
    HasDerivAt (fun v => allocationLagrangian r v l (frequencyFree r v l))
      (phaseDerivative r (frequencyFree r w l) w * (1+l^2)) w := by
  have h := allocationLagrangian_curve_hasDerivAt hr hw
    (l := l) (frequencyFree_frequency_hasDerivAt hr l w)
    (ne_of_gt (frequencyFree_den_pos hr hw))
  simpa only [frequencyFree_marginal hr hw, sub_self, zero_mul, add_zero, pow_two] using h

end C2.NGamma
