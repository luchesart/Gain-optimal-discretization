import Mathlib

/-! Basic exact algebra of the common-parameter rational-delay family.
The hypotheses on transformed polynomial degrees remain explicit. This file
proves fixed degree, fixed leading coefficient and the denominator-cleared
feedback equation. It does not claim a full root-count or coprimeness theorem. -/
noncomputable section
namespace C2
open Polynomial

/-- Characteristic polynomial of the rational digital loop with integer delay. -/
def delayedCharacteristic (D N : ℝ[X]) (m : ℕ) (k : ℝ) : ℝ[X] :=
  X^m * D + C k * N

/-- Pure delay keeps the leading degree independent of the feedback gain. -/
theorem delayedCharacteristic_natDegree {D N : ℝ[X]} {m : ℕ} (k : ℝ)
    (hD : D ≠ 0) (hm : 0 < m) (hN : N.natDegree ≤ D.natDegree) :
    (delayedCharacteristic D N m k).natDegree = D.natDegree + m := by
  have hlow : (C k * N).natDegree < (X^m * D).natDegree := by
    rw [natDegree_X_pow_mul m hD]
    exact lt_of_le_of_lt (natDegree_C_mul_le k N) (by omega)
  unfold delayedCharacteristic
  rw [natDegree_add_eq_left_of_natDegree_lt hlow, natDegree_X_pow_mul m hD]

/-- The leading coefficient also does not depend on gain. -/
theorem delayedCharacteristic_leadingCoeff {D N : ℝ[X]} {m : ℕ} (k : ℝ)
    (hD : D ≠ 0) (hm : 0 < m) (hN : N.natDegree ≤ D.natDegree) :
    (delayedCharacteristic D N m k).leadingCoeff = D.leadingCoeff := by
  have hlow : (C k * N).natDegree < (X^m * D).natDegree := by
    rw [natDegree_X_pow_mul m hD]
    exact lt_of_le_of_lt (natDegree_C_mul_le k N) (by omega)
  unfold delayedCharacteristic
  rw [leadingCoeff_add_of_degree_lt' (degree_lt_degree hlow)]
  simp

/-- Common-degree clearing leaves the rational quotient unchanged. -/
theorem common_degree_quotient {𝕜 : Type*} [Field 𝕜] (x a b : 𝕜) (d : ℕ) (hx : x ≠ 0) :
    (x^d*b)/(x^d*a) = b/a := by
  exact mul_div_mul_left b a (pow_ne_zero d hx)

/-- The scalar negative-feedback equation clears to the stated characteristic
expression when the open-loop rational value is defined. -/
theorem delayed_feedback_equation {𝕜 : Type*} [Field 𝕜] (z D N k : 𝕜) (m : ℕ)
    (hz : z ≠ 0) (hD : D ≠ 0) :
    (1 + k * N / (z^m * D) = 0) ↔ z^m * D + k*N = 0 := by
  have hd : z^m * D ≠ 0 := mul_ne_zero (pow_ne_zero m hz) hD
  constructor <;> intro h
  · field_simp [hd] at h
    exact h
  · field_simp [hd]
    exact h

/-- The old integrator characteristic expression is recovered identically. -/
theorem integrator_characteristic_recovery (z T γ k : ℝ) (m : ℕ) :
    z^m*(z-1) + k*(T*(γ*z+1-γ)) =
      z^m*(z-1) + (k*T)*(γ*z+1-γ) := by ring



end C2
