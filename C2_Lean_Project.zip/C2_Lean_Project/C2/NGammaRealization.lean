import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.LinearAlgebra.Matrix.ToLinearEquiv
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Data.Complex.Norm
import Mathlib.Tactic

/-! # State-realization algebra for independently weighted discretizations

These identities retain the chosen state realization.  Gamma is an actual
matrix, so the algebra also proves the similarity-coordinate qualification.
-/

noncomputable section
namespace C2.NGamma.Realization
open Matrix
variable {ι : Type*} [Fintype ι] [DecidableEq ι]
variable {𝕜 : Type*} [Field 𝕜]

def E (T : 𝕜) (Γ A : Matrix ι ι 𝕜) := 1 - T • (Γ*A)
def F (T : 𝕜) (Γ A : Matrix ι ι 𝕜) := 1 + T • ((1-Γ)*A)
def Q (Γ : Matrix ι ι 𝕜) (z : 𝕜) := 1-Γ+z • Γ
def M (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (z : 𝕜) := z • E T Γ A - F T Γ A

theorem pencil_identity (T z : 𝕜) (Γ A : Matrix ι ι 𝕜) :
    M T Γ A z = (z-1) • (1 : Matrix ι ι 𝕜) - T • (Q Γ z * A) := by
  simp only [M, E, F, Q, smul_sub, smul_add, sub_smul, one_smul,
    Matrix.add_mul, Matrix.sub_mul, Matrix.one_mul, Matrix.smul_mul,
    smul_smul]
  rw [mul_comm T z]
  abel

/-- Exact transform equation obtained by collecting the current and previous
 state terms. -/
theorem transform_equation (T z u : 𝕜) (Γ A : Matrix ι ι 𝕜) (B x : ι → 𝕜) :
    (z-1) • x = T • (Q Γ z *ᵥ (A *ᵥ x + u • B)) ↔
      M T Γ A z *ᵥ x = (T*u) • (Q Γ z *ᵥ B) := by
  rw [pencil_identity]
  simp only [Matrix.sub_mulVec, Matrix.smul_mulVec_assoc, Matrix.one_mulVec,
    ← Matrix.mulVec_mulVec, Matrix.mulVec_add, Matrix.mulVec_smul, smul_add,
    smul_smul]
  constructor <;> intro h <;> apply_fun (fun v : ι → 𝕜 => v) at h
  · rw [h]
    abel
  · rw [sub_eq_iff_eq_add] at h
    rw [h]
    abel

/-- State matrix and input terms in the causal shifted realization. -/
def Ad (T : 𝕜) (Γ A : Matrix ι ι 𝕜) := (E T Γ A)⁻¹ * F T Γ A
def B0 (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B : ι → 𝕜) :=
  T • ((E T Γ A)⁻¹ *ᵥ (Γ *ᵥ B))
def B1 (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B : ι → 𝕜) :=
  T • ((E T Γ A)⁻¹ *ᵥ ((1-Γ) *ᵥ B))
def Bd (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B : ι → 𝕜) :=
  Ad T Γ A *ᵥ B0 T Γ A B + B1 T Γ A B

/-- The actual two-time-level state scheme, before introducing a transform. -/
theorem state_scheme_collected (T u up : 𝕜) (Γ A : Matrix ι ι 𝕜) (B x xp : ι → 𝕜) :
    (xp-x = T • (Γ *ᵥ (A *ᵥ xp + up • B) + (1-Γ) *ᵥ (A *ᵥ x + u • B))) ↔
      E T Γ A *ᵥ xp = F T Γ A *ᵥ x + (T*up) • (Γ *ᵥ B) +
        (T*u) • ((1-Γ) *ᵥ B) := by
  simp only [E, F, Matrix.sub_mulVec, Matrix.add_mulVec, Matrix.smul_mulVec_assoc,
    Matrix.one_mulVec, ← Matrix.mulVec_mulVec, Matrix.mulVec_add, Matrix.mulVec_smul,
    Matrix.mulVec_sub, smul_add, smul_sub, smul_smul]
  constructor <;> intro h <;> apply sub_eq_iff_eq_add.mpr
  · convert sub_eq_iff_eq_add.mp h using 1 <;> abel
  · convert sub_eq_iff_eq_add.mp h using 1 <;> abel

/-- Nonsingularity of E solves the state scheme, with precisely the advance
 and current input coefficients used in the coordinate shift. -/
theorem collected_step_solved (T u up : 𝕜) (Γ A : Matrix ι ι 𝕜) (B x xp : ι → 𝕜)
    (hE : (E T Γ A).det ≠ 0)
    (h : E T Γ A *ᵥ xp = F T Γ A *ᵥ x + (T*up) • (Γ *ᵥ B) +
        (T*u) • ((1-Γ) *ᵥ B)) :
    xp = Ad T Γ A *ᵥ x + up • B0 T Γ A B + u • B1 T Γ A B := by
  have hh := congrArg (fun v => (E T Γ A)⁻¹ *ᵥ v) h
  dsimp only at hh
  rw [Matrix.mulVec_mulVec, Matrix.nonsing_inv_mul _ (isUnit_iff_ne_zero.mpr hE),
    Matrix.one_mulVec] at hh
  simp only [Matrix.mulVec_add, Matrix.mulVec_smul, Matrix.mulVec_mulVec] at hh
  rw [hh]
  simp only [Ad, B0, B1, smul_smul]
  rw [mul_comm T up, mul_comm T u]
  simp only [Matrix.mulVec_mulVec]

/-- The coordinate shift removes the apparent advance input exactly. -/
theorem causal_shift (T u up : 𝕜) (Γ A : Matrix ι ι 𝕜) (B x xp : ι → 𝕜)
    (h : xp = Ad T Γ A *ᵥ x + up • B0 T Γ A B + u • B1 T Γ A B) :
    xp - up • B0 T Γ A B =
      Ad T Γ A *ᵥ (x-u • B0 T Γ A B) + u • Bd T Γ A B := by
  rw [h]
  simp only [Bd, Matrix.mulVec_sub, Matrix.mulVec_smul, smul_add]
  abel

/-- Output equation in the same shifted coordinates. -/
theorem causal_output (C x b : ι → 𝕜) (D u : 𝕜) :
    dotProduct C x + D*u = dotProduct C (x-u • b) + (D+dotProduct C b)*u := by
  simp only [dotProduct_sub, dotProduct_smul, smul_eq_mul]
  ring

/-- The implicit pencil factors through the actual causal state matrix. -/
theorem pencil_factor (T z : 𝕜) (Γ A : Matrix ι ι 𝕜)
    (hE : (E T Γ A).det ≠ 0) :
    M T Γ A z = E T Γ A * (z • 1 - Ad T Γ A) := by
  rw [Matrix.mul_sub, Matrix.mul_smul, Matrix.mul_one, Ad,
    Matrix.mul_nonsing_inv_cancel_left _ _ (isUnit_iff_ne_zero.mpr hE)]
  rfl

/-- The uncancelled denominator retains det E as its leading factor. -/
theorem determinant_factor (T z : 𝕜) (Γ A : Matrix ι ι 𝕜)
    (hE : (E T Γ A).det ≠ 0) :
    (M T Γ A z).det = (E T Γ A).det * (z • 1 - Ad T Γ A).det := by
  rw [pencil_factor T z Γ A hE, Matrix.det_mul]

/-- Wherever the transform pencil is nonsingular, its equation has the stated
 inverse solution. This is an actual finite-dimensional solve. -/
theorem transform_solution (T z u : 𝕜) (Γ A : Matrix ι ι 𝕜) (B x : ι → 𝕜)
    (hM : (M T Γ A z).det ≠ 0)
    (hx : M T Γ A z *ᵥ x = (T*u) • (Q Γ z *ᵥ B)) :
    x = (T*u) • ((M T Γ A z)⁻¹ *ᵥ (Q Γ z *ᵥ B)) := by
  have h := congrArg (fun v => (M T Γ A z)⁻¹ *ᵥ v) hx
  dsimp only at h
  rw [Matrix.mulVec_mulVec, Matrix.nonsing_inv_mul _ (isUnit_iff_ne_zero.mpr hM),
    Matrix.one_mulVec, Matrix.mulVec_smul] at h
  exact h

/-- Multiplication by E recovers the two implicit input coefficients. -/
lemma E_B0 (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B : ι → 𝕜)
    (hE : (E T Γ A).det ≠ 0) :
    E T Γ A *ᵥ B0 T Γ A B = T • (Γ *ᵥ B) := by
  rw [B0, Matrix.mulVec_smul, Matrix.mulVec_mulVec,
    Matrix.mul_nonsing_inv _ (isUnit_iff_ne_zero.mpr hE), Matrix.one_mulVec]

lemma E_B1 (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B : ι → 𝕜)
    (hE : (E T Γ A).det ≠ 0) :
    E T Γ A *ᵥ B1 T Γ A B = T • ((1-Γ) *ᵥ B) := by
  rw [B1, Matrix.mulVec_smul, Matrix.mulVec_mulVec,
    Matrix.mul_nonsing_inv _ (isUnit_iff_ne_zero.mpr hE), Matrix.one_mulVec]

/-- The transform of the shifted causal state has exactly the original input
 column; this links the causal state realization to the implicit pencil. -/
lemma causal_input_identity (T z : 𝕜) (Γ A : Matrix ι ι 𝕜) (B : ι → 𝕜)
    (hE : (E T Γ A).det ≠ 0) :
    M T Γ A z *ᵥ B0 T Γ A B + E T Γ A *ᵥ Bd T Γ A B = T • (Q Γ z *ᵥ B) := by
  rw [M, Bd, Matrix.sub_mulVec, Matrix.smul_mulVec_assoc, Matrix.mulVec_add,
    Matrix.mulVec_mulVec, Ad,
    Matrix.mul_nonsing_inv_cancel_left _ _ (isUnit_iff_ne_zero.mpr hE),
    E_B0 T Γ A B hE, E_B1 T Γ A B hE]
  simp only [Q, Matrix.add_mulVec, Matrix.smul_mulVec_assoc, smul_add, smul_smul]
  rw [mul_comm z T]
  abel

/-- Resolvent identity proving equality of the causal and implicit transfer
 functions wherever their common state denominator is nonsingular. -/
theorem causal_resolvent (T z : 𝕜) (Γ A : Matrix ι ι 𝕜) (B : ι → 𝕜)
    (hE : (E T Γ A).det ≠ 0)
    (hH : (z • (1 : Matrix ι ι 𝕜) - Ad T Γ A).det ≠ 0) :
    B0 T Γ A B + (z • (1 : Matrix ι ι 𝕜) - Ad T Γ A)⁻¹ *ᵥ Bd T Γ A B =
      T • ((M T Γ A z)⁻¹ *ᵥ (Q Γ z *ᵥ B)) := by
  have hm : (M T Γ A z).det ≠ 0 := by
    rw [determinant_factor T z Γ A hE]
    exact mul_ne_zero hE hH
  have hv : M T Γ A z *ᵥ
      (B0 T Γ A B + (z • (1 : Matrix ι ι 𝕜) - Ad T Γ A)⁻¹ *ᵥ Bd T Γ A B) =
        (T*1) • (Q Γ z *ᵥ B) := by
    rw [Matrix.mulVec_add, Matrix.mulVec_mulVec, pencil_factor T z Γ A hE,
      Matrix.mul_assoc, Matrix.mul_nonsing_inv _ (isUnit_iff_ne_zero.mpr hH),
      Matrix.mul_one, mul_one]
    simpa only [pencil_factor T z Γ A hE] using causal_input_identity T z Γ A B hE
  simpa only [mul_one] using transform_solution T z 1 Γ A B _ hm hv

/-- Equality of the causal and implicit transfer functions, including the
 feedthrough term generated by the coordinate shift. -/
theorem causal_transfer (T z : 𝕜) (Γ A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D : 𝕜)
    (hE : (E T Γ A).det ≠ 0)
    (hH : (z • (1 : Matrix ι ι 𝕜) - Ad T Γ A).det ≠ 0) :
    (D + dotProduct C (B0 T Γ A B)) +
        dotProduct C ((z • (1 : Matrix ι ι 𝕜) - Ad T Γ A)⁻¹ *ᵥ Bd T Γ A B) =
      D + T * dotProduct C ((M T Γ A z)⁻¹ *ᵥ (Q Γ z *ᵥ B)) := by
  rw [add_assoc, ← dotProduct_add, causal_resolvent T z Γ A B hE hH,
    dotProduct_smul, smul_eq_mul]

end C2.NGamma.Realization
