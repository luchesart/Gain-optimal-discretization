import C2.GainProjection

/-!
# Rational interior witnesses for strict parameter inequalities

This closes the endpoint-witness step of the projection argument.  CAD
delineability and real-algebraic root isolation are separate obligations.
-/
noncomputable section
open Set
namespace C2.GainProjection

/-- A finite system of strict continuous inequalities feasible anywhere in
the closed parameter interval has a rational witness in its interior. -/
theorem exists_rational_interior_witness {ι : Type*} [Finite ι]
    (f : ℝ → ι → ℝ) (hf : ∀ i, Continuous (fun γ => f γ i))
    {γ : ℝ} (hγ : γ ∈ Icc (0 : ℝ) 1) (hpos : ∀ i, 0 < f γ i) :
    ∃ q : ℚ, 0 < (q : ℝ) ∧ (q : ℝ) < 1 ∧ ∀ i, 0 < f q i := by
  let S : Set ℝ := ⋂ i, {x | 0 < f x i}
  have hS : IsOpen S := isOpen_iInter_of_finite
    (fun i => isOpen_lt continuous_const (hf i))
  have hmem : γ ∈ S := by simpa [S] using hpos
  obtain ⟨ε, hε, hball⟩ := Metric.isOpen_iff.mp hS γ hmem
  let a := max 0 (γ - ε/2)
  let b := min 1 (γ + ε/2)
  have hab : a < b := by
    dsimp [a, b]
    apply max_lt
    · apply lt_min
      · norm_num
      · linarith [hγ.1]
    · apply lt_min
      · linarith [hγ.2]
      · linarith
  obtain ⟨q, hqa, hqb⟩ := exists_rat_btwn hab
  have hq0 : 0 < (q : ℝ) := (le_max_left 0 (γ-ε/2)).trans_lt hqa
  have hq1 : (q : ℝ) < 1 := hqb.trans_le (min_le_left 1 (γ+ε/2))
  have hqa' : γ-ε/2 < (q : ℝ) := (le_max_right 0 (γ-ε/2)).trans_lt hqa
  have hqb' : (q : ℝ) < γ+ε/2 := hqb.trans_le (min_le_right 1 (γ+ε/2))
  have hdist : dist (q : ℝ) γ < ε := by
    rw [Real.dist_eq]
    apply abs_lt.mpr
    constructor <;> linarith
  have hqs : (q : ℝ) ∈ S := hball hdist
  exact ⟨q, hq0, hq1, by simpa [S] using hqs⟩

/-- Rational interior witnesses suffice for the full closed-interval gain
projection, including feasible parameters at gamma=0 or gamma=1. -/
theorem feasibleGains_iff_rational_interior {ι : Type*} [Finite ι]
    (f : ℝ → ℝ → ι → ℝ)
    (hf : ∀ k i, Continuous (fun γ => f γ k i)) (k : ℝ) :
    k ∈ feasibleGains (Icc (0 : ℝ) 1) f ↔
      ∃ q : ℚ, 0 < (q : ℝ) ∧ (q : ℝ) < 1 ∧ ∀ i, 0 < f q k i := by
  constructor
  · rintro ⟨γ, hγ, hpos⟩
    exact exists_rational_interior_witness (fun γ i => f γ k i) (hf k) hγ hpos
  · rintro ⟨q, hq0, hq1, hpos⟩
    exact ⟨q, ⟨hq0.le, hq1.le⟩, hpos⟩

end C2.GainProjection
