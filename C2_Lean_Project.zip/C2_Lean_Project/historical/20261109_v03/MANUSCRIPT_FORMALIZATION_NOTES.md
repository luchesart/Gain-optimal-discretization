# C2 — correspondence between manuscript and Lean

The current development map records 44 of 45 numbered results as COMPLETE and one, `thm:exact-gain-projection`, as PARTIAL. COMPLETE refers to the mathematical assumptions and conclusions, not line-by-line identity of the written and formal proofs. All 13 arbitrary-order results remain covered; their correspondence notes are preserved below. The subsequent sections record the scope and proof routes for the 25 entries updated on 9 November 2026.

The coordinates are related by x = 2 gamma - 1. NGammaParameterization proves the inverse map, both cube correspondences, the actual numerator-factor identity, and preservation of vector uniqueness.

## lem:ngamma-phase-ratio

Strict monotonicity under exactly 0<=x<=1 and a>x; zero limit at t→0+, finite limit 1/x−1/a for x>0, divergence for x=0.

**Formal proof route:** Uses derivative/arctangent scale-ratio comparisons rather than differentiating a quotient of two unbounded kernel integrals.

**Primary declarations:**

- `C2.NGamma.Phase.normalized_phase_contribution`

## lem:ngamma-root-count

Actual roots outside the closed unit disk, counted with multiplicity, equal 2*floor((Psi(tb)+pi)/(2*pi)); unique magnitude crossing and no unit roots derived. The code proves the stronger scope xi>=0 without requiring xi<=1.

**Formal proof route:** Replaces the invoked analytic argument principle by a proved polynomial-factorization argument: each interior linear factor contributes 2pi and each exterior factor zero. Continuous-lift uniqueness uses disconnectedness of the integer lattice. Special phase lift matches the paper branch construction.

**Primary declarations:**

- `C2.NGamma.Cayley.root_count`
- `C2.NGamma.Cayley.existsUnique_amplitude_crossing_in_range`
- `C2.NGamma.RootCountBridge.exterior_count_of_cayley_argument`

## thm:ngamma-gain-interval

Both endpoint and interior cases; all b>=0; exact Schur iff b<Bcrit; unique first crossing; actual limiting unit-circle root. Conjugate root obtained using characteristic_eval_conj.

**Formal proof route:** Small gains use a direct factor norm inequality instead of root continuation. Intermediate gains use the fully proved root-count formula. All high gains are excluded by a right-half-plane lift giving exactly d exterior roots unless -1 is already a root.

**Primary declarations:**

- `C2.NGamma.Cayley.single_sample_exact_gain_interval`
- `C2.NGamma.Cayley.single_sample_endpoint_interval`
- `C2.NGamma.Cayley.single_sample_interior_interval`
- `C2.NGamma.Cayley.schur_iff_phase_lt_pi_at_magnitude_crossing`

## cor:ngamma-multiple-delay

For arbitrary d>=2 and n>=1: unique positive first crossing, strict t<tan(pi/(2d)), exact full stable gain interval and actual boundary unit root.

**Formal proof route:** Same normalized phase ordering, with the actual-root gain-interval bridge proved separately rather than assumed.

**Primary declarations:**

- `C2.NGamma.Cayley.multiple_delay_exact_gain_interval`
- `C2.NGamma.Phase.multiple_delay_unique_phase_crossing`

## thm:ngamma-endpoint-allocation

All numbered clauses: feasibility iff S1<=1; equality all-one uniqueness; unique positive scalar and clipped optimum under strict feasibility; saturated S=1; exact double root at -1 and every other actual root strictly inside; exact open stable interval and its actual supremum. EndpointFinal discharges the stability-below premise.

**Formal proof route:** Uses explicit one-dimensional marginal/Lagrangian inequalities and strict comparisons. Double-root multiplicity is proved from actual shifted polynomial derivatives; remaining roots use factorization-based closed-disk bounds instead of an enumerated root-continuity theorem.

**Primary declarations:**

- `C2.NGamma.endpoint_feasible_iff`
- `C2.NGamma.endpoint_feasible_equality_unique`
- `C2.NGamma.existsUnique_endpoint_scalar`
- `C2.NGamma.exists_endpoint_optimizer`
- `C2.NGamma.PolynomialModel.saturated_endpoint_spectrum`
- `C2.NGamma.Cayley.single_sample_endpoint_interval`
- `C2.NGamma.PolynomialModel.initialGainMargin_eq_of_exact_interval`

## lem:ngamma-concave-allocation

For every positive feasible w: scalar multiplier exists, explicit clipped formula gives feasible unique gain-maximizing vector; actual product of complex magnitudes used; multiplier uniqueness not falsely asserted.

**Formal proof route:** Proves separable Lagrangian strict inequalities directly, then sums them and converts log gain to actual magnitude product, avoiding a separate abstract concave-program/KKT existence theorem.

**Primary declarations:**

- `C2.NGamma.exists_unique_frequency_gain_optimizer`
- `C2.NGamma.frequencyFree`
- `C2.NGamma.frequencyAllocation`
- `C2.NGamma.allocationGain_eq_complexNorm`

## lem:ngamma-frequency-interval

Both interval cases in w=1/t, endpoint equations and unique endpoint vectors, n>=1 and ri>0.

**Formal proof route:** Follows manuscript normalized-ratio monotonicity and intermediate-value argument; generic existence/order lemmas are separated.

**Primary declarations:**

- `C2.NGamma.Global.feasible_frequency_interval`
- `C2.NGamma.Global.upper_frequency_existsUnique`
- `C2.NGamma.Global.lower_frequency_existsUnique`
- `C2.NGamma.Global.upper_frequency_vector_unique`
- `C2.NGamma.Global.lower_frequency_vector_unique`

## thm:ngamma-outer-monotonicity

Actual constrained optimal log gain is continuous and strictly decreasing on entire positive feasible interval, including clipping changes and positive feasible endpoints.

**Formal proof route:** Uses a compact dual minimum and differentiable upper supports. This avoids the manuscript local-Lipschitz/almost-everywhere derivative route while proving the same global conclusion without regularity hypotheses.

**Primary declarations:**

- `C2.NGamma.Global.frequencyValue_is_unique_maximum`
- `C2.NGamma.Global.frequencyValue_continuousOn_feasible`
- `C2.NGamma.Global.frequencyValue_strictAntiOn_feasible`

## thm:ngamma-global-half-cube

All three S1 regimes have explicit unique optimizer descriptions. Actual initialGainMargin equals the critical gain, all b>=0 satisfy the exact stable interval, and the limiting characteristic has a unit-circle root and is not strictly stable. Margin and boundary wrappers compiled.

**Formal proof route:** Uses compact maximizing sequences to bound zero-frequency limits and strict dual-value monotonicity; actual margin is the supremum of stable gains and is identified through exact Schur intervals, not defined as an analytic critical gain.

**Primary declarations:**

- `C2.NGamma.Global.half_cube_global_gain_theorem`
- `C2.NGamma.Global.OptimalGainDescription`

## cor:ngamma-full-cube-initial-margin

Actual sSup initial margin on [-1,1]^n; unique optimizer is the half-cube optimizer; strict reflection dominance for admissible negative coordinates; margin zero for inadmissible zero-gain factors. Final wrapper compiled. No claim about isolated stable components away from zero.

**Formal proof route:** Uses explicit root-factor lower bounds to exclude stable small gains near a zero-gain exterior root instead of general polynomial-root continuity. Reflection is applied to the actual initial margin using unit-root upper bounds and the proved half-cube exact interval.

**Primary declarations:**

- `C2.NGamma.Global.full_cube_initial_margin_global_theorem`
- `C2.NGamma.Global.OptimalGainDescription`

## cor:ngamma-identical-global

Both regimes give the actual initialGainMargin supremum, exact actual-root Schur interval and unique global optimizer. Finite regime includes the unique sine-quotient angle and sine-power gain; both explicit exponential roots and unit norms are proved for the actual characteristic, with distinctness. Endpoint formula covers n=1 and n=2. Threshold formulas agree at r=n−2. All wrappers compiled.

**Formal proof route:** Specializes the proved generic resource optimizer for the endpoint formula. The actual all-one phase condition uniquely identifies the sine angle and algebra identifies its gain. Generic global analytic optimization and the proved criticalGain-to-Schur/margin bridge complete the corollary.

**Primary declarations:**

- `C2.NGammaEqual.identical_endpoint_margin`
- `C2.NGammaEqual.identical_finite_margin`
- `C2.NGammaEqual.identical_finite_boundary_roots`
- `C2.NGammaEqual.identical_finite_boundary_distinct`
- `C2.NGammaEqual.identical_endpoint_boundary`
- `C2.NGammaEqual.endpoint_boundary_agreement`
- `C2.NGammaEqual.identical_order_three_margin`
- `C2.NGammaEqual.identical_order_four_margin`

## thm:ngamma-realization

Uncancelled transfer numerator/denominator, degrees n and <=n, actual augmented (n+d)-state matrix characteristic, and equivalence with decay of every homogeneous trajectory. detE!=0 and d>0 match manuscript. Transfer evaluation naturally excludes poles.

**Formal proof route:** Algebraic transform/causal identities, recursive appended-delay realization, determinant/adjugate identities and polynomial extension are verified. Dynamical equivalence uses spectral-radius power decay. A formal Z-transform operator is not introduced; unnumbered companion/cascade realization formulas are outside this numbered theorem.

**Primary declarations:**

- `C2.NGamma.Realization.transfer_quotient`
- `C2.NGamma.Realization.polynomial_degrees`
- `C2.NGamma.Realization.aligned_characteristic`
- `C2.NGamma.Realization.aligned_characteristic_eval`
- `C2.NGamma.Realization.aligned_state_count`
- `C2.NGamma.Realization.aligned_asymptotic_stability_iff`

## prop:ngamma-diagonal-stability

Positive diagonal P, negative definite A^T P+P A, T>0 and gamma>=1/2 imply invertible E and actual Schur stability of E^-1F; no diagonalizability or nominal-step stability premise. The bridge identifies the step matrix with the realization E^-1F. The accompanying Hurwitz-only counterexample and its explicit exterior root are also proved.

**Formal proof route:** Proves the equivalent discrete energy identity directly in state increments, avoiding an explicit A^-1 expression; complex eigenvalue contraction gives Schur stability.

**Primary declarations:**

- `C2.NGamma.diagonal_stability_of_lyapunov`
- `C2.NGamma.diagonal_stability`
- `C2.NGamma.realization_diagonal_stability`
- `C2.NGamma.hurwitz_not_sufficient`
- `C2.NGamma.counter_unstable_root`

## Results completed or extended on 9 November 2026

These notes follow the numbered manuscript labels. References point to the per-block evidence and exact Lean declarations; the CAD entry records its remaining mathematical and algorithmic obligations.

## thm:general-characteristic

**Status: COMPLETE.** Together with existing CommonDegree and RationalTransform, covers exact polynomial, degree and leading coefficient, transformed coprimeness, every common divisor dividing X^m, and actual augmented-state characteristic and trajectory-decay equivalence. The realization premise contains only rational transfer equality (cross-product) and degree-minimal state dimension; the characteristic polynomial and stability equivalence are proved conclusions.

**Formal proof route:** Combines the common-degree rational transform and coprimeness identities with a proved state-realization bridge. Rational transfer equality forces the coprime denominator to divide every realization characteristic; equality of the state dimension and denominator degree identifies the normalization. The recursively appended delay realization then yields the actual augmented characteristic and equivalence with decay of every homogeneous trajectory. Every common divisor of the delayed denominator and numerator divides the delay power, so cancelled modes can only be at zero.

**Scope convention / remaining work:** Minimal scalar rational realization means a realization with dim=deg D (McMillan-degree convention). The dimension lower bound for every realization of the coprime quotient is proved. No companion-construction/existence theorem is claimed; the manuscript clause is conditional on using a minimal realization.

**Primary declarations:**

- `C2.commonDegreeTransform_eval_div`
- `C2.thetaTransform_coprime`
- `C2.delayed_common_zero_is_zero`
- `C2.transformedDelayedCharacteristic_natDegree`
- `C2.delayedCharacteristic_leadingCoeff`
- `C2.delayed_feedback_equation`
- `C2.GeneralCompletion.common_divisor_dvd_delay_power`
- `C2.GeneralCompletion.realization_transfer_quotient`
- `C2.GeneralCompletion.realization_dimension_lower_bound`
- `C2.GeneralCompletion.minimal_realization_polynomials`
- `C2.GeneralCompletion.minimal_delayed_characteristic`
- `C2.GeneralCompletion.minimal_delayed_dimension`
- `C2.GeneralCompletion.minimal_delayed_asymptotic_stability_iff`

**Modules:** `C2.CommonDegree`, `C2.RationalTransform`, `C2.GeneralCompletionRealization`.

**Evidence:** [validation/general_completion_20261109.json](validation/general_completion_20261109.json).

## prop:general-small-gain

**Status: COMPLETE.** Both numbered branches complete. Strictly stable denominators: quantitative factorization gap proves stability of all roots for a full small-gain neighborhood. Simple integrator: direct exterior-root estimates prove actual Schur stability for all sufficiently small positive gains; scalar local inversion provides the real root branch, exact derivative, and quantified C*k^2 remainder. The final theta_integrator_small_gain_full states the exact coefficient -T*B(0)/A'(0), proves the common-transform value and derivative identities including arbitrary integer delay, and retains all transformed nonzero-pole stability hypotheses. simple_origin_iff_integrator_factor proves equivalence of the simple-zero hypotheses to A(s)=s*A0(s), A0(0)!=0.

**Formal proof route:** The stable-denominator branch uses a quantitative polynomial factorization gap. For the simple-integrator branch, a hypothetical exterior root first satisfies a linear displacement bound; a second polynomial expansion gives a quadratic remainder and contradicts its norm being at least one. Scalar local inversion constructs the actual real root branch and its quadratic estimate. Exact common-transform and delay-derivative identities identify the manuscript coefficient −T B(0)/A′(0). No root-continuity conclusion is assumed.

**Primary declarations:**

- `C2.GeneralCompletion.delayed_small_positive_gains`
- `C2.GeneralCompletion.simple_integrator_small_positive_gains`
- `C2.GeneralCompletion.real_simple_root_small_positive_gains`
- `C2.GeneralCompletion.simple_origin_iff_integrator_factor`
- `C2.GeneralCompletion.theta_transform_eval_one`
- `C2.GeneralCompletion.theta_transform_derivative_at_integrator`
- `C2.GeneralCompletion.theta_integrator_residue`
- `C2.GeneralCompletion.delayed_integrator_derivative_one`
- `C2.GeneralCompletion.exists_local_real_root_branch_quadratic`
- `C2.GeneralCompletion.theta_integrator_small_gain_full`

**Modules:** `C2.GeneralCompletionSmallGain`, `C2.GeneralCompletionIntegrator`, `C2.GeneralCompletionTransformDerivative`, `C2.GeneralCompletionLocalRoot`, `C2.GeneralCompletionIntegratorTransform`.

**Evidence:** [validation/general_completion_20261109.json](validation/general_completion_20261109.json).

## thm:general-boundaries

**Status: COMPLETE.** Exact Chebyshev cross-product identity; literal equality to the manuscript grouped coefficient formula c_q; degree Q<=degH-1; finite explicitly retained positive gain candidates from roots in (-1,1) and +/-1, excluding zero denominators; iff actual unit-circle root; actual inside-root count with multiplicity constant on every preconnected boundary-free positive gain set (hence every connected component); one exact Schur test determines each component; candidate points not Schur-stable; at most L+1 candidate points and retained gains for L=degH>0.

**Formal proof route:** Integer-index Chebyshev U first proves the double-sum trigonometric identity. Signed-index grouping proves literal polynomial equality to sum c_q U_(q-1). Root-count persistence uses a proved local Rouche comparison: nearby polynomial quotient has positive real part, a continuous argument with zero endpoint increment, and the previously proved polynomial argument principle counts actual roots. Circle compactness yields a gain neighborhood; Nat-valued local constancy gives every preconnected component.

**Primary declarations:**

- `C2.unitCircleRoot_iff_boundary`
- `C2.GeneralBoundaryCandidates.complete_fixed_parameter_decomposition`
- `C2.GeneralBoundaryCandidates.chebyshev_identity`
- `C2.GeneralBoundaryCandidates.chebyshev_identity_on_circle`
- `C2.GeneralBoundaryCandidates.Q_eq_groupedQ`
- `C2.GeneralBoundaryCandidates.differenceCoefficient_eq`
- `C2.GeneralBoundaryCandidates.Q_natDegree_le`
- `C2.GeneralBoundaryCandidates.unitCircleRoot_iff_candidate`
- `C2.GeneralBoundaryCandidates.candidateGains_finite`
- `C2.GeneralBoundaryCandidates.candidate_cardinality_bound`
- `C2.GeneralBoundary.count_constant_on_preconnected`
- `C2.GeneralBoundary.schur_constant_on_preconnected`
- `C2.GeneralBoundary.boundary_point_not_schur`

**Modules:** `C2.Boundary`, `C2.GeneralBoundaryCandidatesChebyshev`, `C2.GeneralBoundaryCandidates`, `C2.GeneralBoundaryCandidatesDecomposition`, `C2.GeneralBoundaryRootCount`, `C2.GeneralBoundaryChebyshevDegree`, `C2.GeneralBoundaryCandidateCardinality`, `C2.GeneralBoundaryGroupedCoefficients`.

**Evidence:** [validation/general_boundaries_completion_20261109.json](validation/general_boundaries_completion_20261109.json).

## prop:general-first-margin

**Status: COMPLETE.** Under the inherited real-polynomial framework hypotheses (nonzero numerator, lower numerator degree, no common unit-circle zero), nonzero Chebyshev Q and small-positive-gain stability imply: candidate set nonempty; least positive candidate c exists; all 0<k<c are actually Schur; c is not Schur; c is greatest possible initial-interval endpoint and its exact supremum. The endpoint set is proved equal to (0,c]. Additional stable components above c are unrestricted. No numbered clause remains.

**Formal proof route:** Large gains excluded by the actual-root coefficient bound. Empty candidate set would transport one small stable gain to arbitrarily large gain, contradiction. Finite set has a least element; root-count constancy transports stability across every boundary-free interval below it. Candidate equivalence supplies actual boundary instability, giving maximality and sSup.

**Primary declarations:**

- `C2.GeneralCompletion.first_boundary_nonempty`
- `C2.GeneralCompletion.finite_first_boundary_margin`
- `C2.GeneralCompletion.realGainSchur_bounded`
- `C2.GeneralCompletion.realGainSchur_not_at_candidate`
- `C2.GeneralCompletion.realGainSchur_interval_transport`
- `C2.GeneralCompletion.general_first_margin`

**Modules:** `C2.GeneralCompletionFirstMarginCore`, `C2.GeneralCompletionFirstMargin`, `C2.GeneralCompletionBounds`, `C2.GeneralBoundaryRootCount`, `C2.GeneralBoundaryCandidates`.

**Evidence:** [validation/first_margin_completion_20261109.json](validation/first_margin_completion_20261109.json).

## prop:explicit-uniform-gain-bound

**Status: COMPLETE.** Exact actual-root binomial coefficient bound, actual symbolic polynomial-in-gamma coefficient one-norm envelopes H0/E0, explicit lower bound mu0, existence of a nonvanishing node among j=1,...,d+1, k<=K0 and k<ceil(K0)+1. The real-input statement is stronger than the rational specialization. Singular transformed degree parameters are explicitly excluded. No coefficient-bound or sampled-domain premise is assumed in the final theorem.

**Formal proof route:** Normalize an actual Schur polynomial and bound its coefficients by binomial coefficients. Evaluate the transformed numerator at a prescribed negative sampling node to obtain a uniform nonzero coefficient lower bound. Symbolic polynomial-in-gamma transforms supply the coefficient one-norm envelopes H0 and E0. Their combination gives k≤K0, while a root-count argument guarantees an admissible node among j=1,…,d+1 and k<ceil(K0)+1.

**Primary declarations:**

- `C2.GeneralCompletion.coefficient_bound_of_closed_disk`
- `C2.GeneralCompletion.real_coefficient_bound`
- `C2.GeneralCompletion.affine_gain_bound`
- `C2.GeneralCompletion.transformed_numerator_coefficient_lower_bound`
- `C2.GeneralCompletion.symbolicTransform_evaluate`
- `C2.GeneralCompletion.symbolicDelayedDenominator_evaluate`
- `C2.GeneralCompletion.denominatorCoefficientEnvelope`
- `C2.GeneralCompletion.leadingCoefficientEnvelope`
- `C2.GeneralCompletion.uniform_gain_bound`
- `C2.GeneralCompletion.exists_paper_node`
- `C2.GeneralCompletion.strict_search_bound`

**Modules:** `C2.GeneralCompletionBounds`, `C2.GeneralCompletionUniform`.

**Evidence:** [validation/general_completion_20261109.json](validation/general_completion_20261109.json).

## thm:exact-gain-projection

**Status: PARTIAL.** Proved: the explicit uniform gain bound, openness of the gain projection of finite strict inequalities, preservation of upper bounds and nonemptiness after deleting finitely many exceptional gains, and a rational parameter witness in (0,1) for every feasible gain, including feasibility originally witnessed at a parameter endpoint. These results apply to all stable components. The four-step rational CAD projection/lifting algorithm, its termination, and its real-algebraic supremum conclusion are not proved.

**Formal proof route:** The completed stages use continuity, openness, density of rational numbers, and the proved actual-root coefficient bound. The manuscript now fixes the auxiliary integer K=ceil(K0)+1, so k−K is a rational projection polynomial and the bound k≤K0<K gives sup≤K0<K. Existing classical factorization and finite-root APIs do not discharge the missing algorithmic theorem.

**Scope convention / remaining work:** Remaining obligations are an exact bivariate factor basis, verified resultant/discriminant specialization criteria, projection-free root delineability and sign invariance, certified rational-polynomial root isolation with termination, and correctness of the marked-cell endpoint algorithm. The completed fixed-parameter Chebyshev decomposition includes grouped coefficients, degree L−1, and cardinality L+1; it does not replace generic two-variable CAD. See [the precise completion-boundary audit](validation/cad_remaining_20261109.md).

**Primary declarations:**

- `C2.GainProjection.feasibleGains_isOpen`
- `C2.GainProjection.open_nonempty_infinite`
- `C2.GainProjection.upperBounds_diff_finite`
- `C2.GainProjection.isLUB_diff_finite_iff`
- `C2.GainProjection.feasibleGains_isLUB_iff`
- `C2.GainProjection.polynomial_feasibleGains_isOpen`
- `C2.GainProjection.polynomial_feasibleGains_isLUB_iff`
- `C2.GainProjection.exists_rational_interior_witness`
- `C2.GainProjection.feasibleGains_iff_rational_interior`

**Modules:** `C2.GainProjection`, `C2.ProjectionCompletionWitness`.

**Evidence:** [validation/general_completion_20261109.json](validation/general_completion_20261109.json).
The detailed remaining-scope audit supersedes generic completion wording for this entry.

## prop:lag-region

**Status: COMPLETE.** Actual-root Jury equivalence; all four displayed positive-gain regions; exact lower-half nonemptiness condition r<(1+2q)/q^2. No numbered clause remains.

**Formal proof route:** Rearranges the proved actual-root quadratic Jury criterion separately below, at, and above gamma=1/2, including gamma=1. A direct difference-of-endpoints identity proves the exact lower-half nonemptiness condition.

**Primary declarations:**

- `C2.FirstOrder.stable_iff_jury`
- `C2.FirstOrder.stable_lower_half_iff`
- `C2.FirstOrder.stable_half_iff`
- `C2.FirstOrder.stable_upper_half_iff`
- `C2.FirstOrder.stable_one_iff`
- `C2.FirstOrder.lower_half_interval_nonempty`

**Modules:** `C2.FirstOrderSchur`, `C2.RegionCompletionFirstOrder`.

**Evidence:** [validation/regions_completion_20261109.json](validation/regions_completion_20261109.json).

## prop:polezero-jury

**Status: COMPLETE.** Actual-root stability iff the two affine Jury inequalities; explicit theorem that the positive stable set is empty or a bounded open interval. No assumption that its lower endpoint is zero. No numbered clause remains.

**Formal proof route:** Uses the actual-root quadratic Jury criterion. The strict affine inequalities give openness and order convexity; their combination supplies an upper bound. Infimum and supremum arguments identify every nonempty stable set with one bounded open interval, without assuming its lower endpoint is zero.

**Primary declarations:**

- `C2.PoleZero.stable_iff_jury`
- `C2.PoleZero.stable_gain_set_isOpen`
- `C2.PoleZero.stable_gain_set_ordConnected`
- `C2.PoleZero.stable_gain_set_bddAbove`
- `C2.PoleZero.stable_gain_set_empty_or_open_interval`

**Modules:** `C2.PoleZeroSchur`, `C2.RegionCompletionPoleZero`.

**Evidence:** [validation/regions_completion_20261109.json](validation/regions_completion_20261109.json).

## cor:second-order-isolation

**Status: COMPLETE.** Executable rational bisection starting at [0,1]; nested brackets containing the unique root; exact width 2^-n; finite termination for arbitrary positive epsilon; eventual endpoints strictly inside(0,1); rigorous gamma and gain enclosures. Existing exact root/optimizer uniqueness theorem retained. No numbered clause remains.

**Formal proof route:** Defines rational midpoint bisection with an exact sign decision, proves bracket invariants and the width 2^(-n), and uses geometric convergence to establish finite termination for every positive tolerance. Uniqueness and continuity of the existing optimal root transfer the nested brackets to parameter and gain enclosures. This special-purpose isolator does not claim arbitrary-polynomial root isolation.

**Primary declarations:**

- `C2.SecondOrder.exists_unique_optimal_root`
- `C2.SecondOrder.root_bracket_of_signs`
- `C2.SecondOrder.root_enclosures`
- `C2.SecondOrder.optimum_strict_antitone`
- `C2.SecondOrder.rationalBisect`
- `C2.SecondOrder.rationalBisect_invariants`
- `C2.SecondOrder.rationalBisect_nested`
- `C2.SecondOrder.rationalBisect_exact_width`
- `C2.SecondOrder.rationalBisect_termination`
- `C2.SecondOrder.rationalBisect_eventually_interior`
- `C2.SecondOrder.rationalBisect_optimizer_enclosures`
- `C2.SecondOrder.rational_isolation_complete`

**Modules:** `C2.SecondOrder`, `C2.RootIsolation`.

**Evidence:** [validation/regions_completion_20261109.json](validation/regions_completion_20261109.json).

## lem:two-gamma-connected

**Status: COMPLETE.** Actual manuscript gamma-coordinate polynomial, r1,r2>0 and gamma1,gamma2 in [1/2,1]. Existence of finite B>0 with the complete nonnegative stable gain set equal to [0,B). No remaining numbered clause.

**Formal proof route:** Exact specialization of the already proved arbitrary-order Schur interval theorem. The affine parameter map and exact characteristic polynomial identity are checked.

**Primary declarations:**

- `C2.TwoGamma.characteristic_eq_generic`
- `C2.TwoGamma.connected_stable_gain_interval`

**Modules:** `C2.TwoGammaBasic`, `C2.TwoGammaConnected`.

**Evidence:** [validation/two_gamma_completion_20261109.json](validation/two_gamma_completion_20261109.json).

## thm:two-gamma-optimum

**Status: COMPLETE.** Exact square-root B and displayed gamma pair; both gamma values in (1/2,1); actual-root stability iff 0<=b<B for the pair; exclusion at B; IsLUB of all half-square stable gains; unique pair attaining the supremum; strict improvement over global shared optimum iff unequal poles. Full-square uniqueness theorem specializes to the half square. No remaining numbered clause.

**Formal proof route:** Derives closed-form allocations from B through the quadratic identity and stationary resource equation, identifies the generic unique scalar and optimizer, and transfers exact stable intervals. The shared optimizer is supplied unconditionally by the existing SecondOrder optimal-root theorem and compared through actual characteristic polynomials.

**Primary declarations:**

- `C2.TwoGamma.gain`
- `C2.TwoGamma.optimalGamma`
- `C2.TwoGamma.optimalGamma_interior`
- `C2.TwoGamma.optimal_pair_stable_iff`
- `C2.TwoGamma.half_square_isLUB`
- `C2.TwoGamma.optimal_pair_isLUB`
- `C2.TwoGamma.full_square_optimal_pair_unique`
- `C2.TwoGamma.strict_improvement_iff`
- `C2.TwoGamma.shared_global_supremum_comparison`

**Modules:** `C2.TwoGammaAlgebra`, `C2.TwoGammaExplicit`, `C2.TwoGammaOptimum`, `C2.TwoGammaShared`, `C2.TwoGammaFinal`.

**Evidence:** [validation/two_gamma_completion_20261109.json](validation/two_gamma_completion_20261109.json).

## cor:two-gamma-full-square

**Status: COMPLETE.** All gamma in [0,1]^2 and every nonnegative stable gain, including any isolated stable component: b<B. Exact global IsLUB, unique optimal pair for the supremum of all gains, and strict improvement over shared gamma in [0,1] iff unequal poles. No remaining numbered clause.

**Formal proof route:** Proves actual cubic Schur stability implies strict Cayley/Hurwitz coefficient inequalities. Centered polynomial identities give an algebraic contradiction for all b>=B whenever either transformed coordinate is nonpositive. Closed inequalities exclude nonpositive limiting optimizer coordinates; closedness plus the connected half-square theorem proves uniqueness for suprema of all stable gains. It does not assume stable intervals are connected outside the half square.

**Primary declarations:**

- `C2.TwoGamma.stable_necessary`
- `C2.TwoGamma.closed_high_gain_exclusion_left`
- `C2.TwoGamma.closed_high_gain_exclusion_right`
- `C2.TwoGamma.full_square_gain_bound`
- `C2.TwoGamma.full_square_isLUB`
- `C2.TwoGamma.full_square_optimal_pair_unique`
- `C2.TwoGamma.shared_global_supremum_comparison`

**Modules:** `C2.TwoGammaCoefficients`, `C2.TwoGammaCubic`, `C2.TwoGammaFullSquare`, `C2.TwoGammaShared`, `C2.TwoGammaFinal`.

**Evidence:** [validation/two_gamma_completion_20261109.json](validation/two_gamma_completion_20261109.json).

## thm:n1

**Status: COMPLETE.** Actual-root Schur stability iff the displayed piecewise threshold; both branches include their shared endpoint; unique maximum threshold 4 at gamma=3/4. The threshold is also proved to be the actual stable-gain supremum. No numbered clause remains.

**Formal proof route:** Specializes the actual-root Jury criterion to the integrator and proves both threshold branches, including gamma=3/4. Direct inequalities establish the unique maximum, and the open stable interval identifies its actual least upper bound.

**Primary declarations:**

- `C2.FirstOrder.stable_iff_jury`
- `C2.FirstOrder.integrator_stable_optimum_iff`
- `C2.FirstOrder.stable_maximizing_parameter_iff`
- `C2.FirstOrder.integrator_piecewise_region`
- `C2.FirstOrder.integrator_lower_branch`
- `C2.FirstOrder.integrator_upper_branch`
- `C2.FirstOrder.oneSampleThreshold_unique_max`
- `C2.FirstOrder.oneSampleThreshold_isLUB`

**Modules:** `C2.FirstOrderSchur`, `C2.RegionCompletionFirstOrder`.

**Evidence:** [validation/regions_completion_20261109.json](validation/regions_completion_20261109.json).

## prop:robust

**Status: COMPLETE.** For the full closed independent parameter rectangle, actual complex-root Schur stability of every member is equivalent to the exact strict nominal gain bound. All endpoints and allowed delta/rho ranges are included.

**Formal proof route:** The actual-root Jury inequalities are checked at the extremal parameter/gain corner for necessity. Monotonic bounds across the full closed rectangle prove sufficiency and retain the strict nominal-gain inequality.

**Primary declarations:**

- `C2.Robustness.exact_rectangular_budget`

**Modules:** `C2.Robustness`.

**Evidence:** [validation/root_completion_20261109.json](validation/root_completion_20261109.json).

## lem:phase

**Status: COMPLETE.** Exact printed phase equation using the actual principal complex argument of the chord; unique frequency in [pi/(2n+1),pi/(2n-1)], positive gain 2*tan(w/2)*sin(n*w), actual unit-circle root exp(i*w), strict increase of frequency with gamma. No remaining numbered clause.

**Formal proof route:** Centered-chord argument identity, derivative positivity on the low-frequency interval, intermediate value theorem and explicit Cayley polar identity.

**Primary declarations:**

- `C2.IntegratorDelay.low_frequency_boundary_theorem`
- `C2.IntegratorDelay.manuscript_frequency_strictMonoOn`
- `C2.IntegratorDelay.chordPhase_eq_centered`
- `C2.IntegratorDelay.frequency_boundary_root`

**Modules:** `C2.IntegratorDelayFinal`, `C2.IntegratorDelayManuscript`, `C2.IntegratorDelayPhase`, `C2.IntegratorDelayRegion`.

**Evidence:** [validation/integer_delay_completion_20261109.json](validation/integer_delay_completion_20261109.json).

## lem:gainmonotone

**Status: COMPLETE.** Strict increase on the entire closed frequency interval for every n≥2, positive derivative except the n=2 upper endpoint, where the derivative is proved to be zero. No remaining numbered clause.

**Formal proof route:** Explicit derivative and sharp trigonometric lower bound; n=2 and n>=3 estimates separated.

**Primary declarations:**

- `C2.IntegratorDelay.boundaryGain_strictMonoOn`
- `C2.IntegratorDelay.boundaryGain_deriv_pos`
- `C2.IntegratorDelay.boundaryGain_deriv_two_upper`

**Modules:** `C2.IntegratorDelayGain`.

**Evidence:** [validation/integer_delay_completion_20261109.json](validation/integer_delay_completion_20261109.json).

## lem:outward

**Status: COMPLETE.** Every actual unit root under the strict constant-term barrier has nonzero characteristic derivative. An actual differentiable local root branch is constructed by the complex inverse function theorem, with positive logarithmic radial velocity and positive derivative of squared norm. Stronger scope n>=1. No remaining numbered clause.

**Formal proof route:** Exact norm identities R*(1+a^2*gamma*(1-gamma))=1 and R>=(2*gamma-1)^2 imply 2*R>2*gamma-1. Derivative and inverse-function arguments are fully proved.

**Primary declarations:**

- `C2.IntegratorDelay.unit_root_transversality`
- `C2.IntegratorDelay.exists_outward_root_branch`
- `C2.IntegratorDelay.constant_term_barrier`
- `C2.IntegratorDelay.root_derivative_logSlope`

**Modules:** `C2.IntegratorDelayOutward`, `C2.IntegratorDelayRootBranch`.

**Evidence:** [validation/integer_delay_completion_20261109.json](validation/integer_delay_completion_20261109.json).

## thm:general

**Status: COMPLETE.** For every n>=2, gamma in [0,1] and every real gain, actual complex-root Schur stability iff 0<a<criticalGain. The gain is the actual least upper bound, strictly increases with gamma, and has unique maximizing parameter gamma=1 with formula 2*sin(pi/(4*n-2)). Actual limiting unit root and all high-gain exclusions proved. No remaining numbered clause.

**Formal proof route:** New r=0 integrator amplitude/phase lift, explicit magnitude crossing, polynomial-factorization argument principle with root multiplicities, and a right-half-plane high-gain lift. The theorem is not obtained by an invalid r=0 substitution into strictly-positive-pole results.

**Primary declarations:**

- `C2.IntegratorDelay.complete_region`
- `C2.IntegratorDelay.criticalGain_isLUB`
- `C2.IntegratorDelay.criticalGain_strictMonoOn`
- `C2.IntegratorDelay.criticalGain_one`
- `C2.IntegratorDelay.maximizing_parameter_iff`
- `C2.IntegratorDelay.criticalGain_boundary_root`
- `C2.IntegratorDelay.integrator_root_count`
- `C2.IntegratorDelay.not_schur_of_high_gain`

**Modules:** `C2.IntegratorDelayRegion`, `C2.IntegratorDelayOptimum`, `C2.IntegratorDelayRootCount`, `C2.IntegratorDelayHighGain`, `C2.IntegratorDelayCayley`, `C2.IntegratorDelayAmplitude`, `C2.IntegratorDelayLift`.

**Evidence:** [validation/integer_delay_completion_20261109.json](validation/integer_delay_completion_20261109.json).

## cor:n2

**Status: COMPLETE.** Actual cubic-root stability iff a>0 and a+(1-gamma)^2*a^2<1, equivalent to the closed-form threshold 2/(1+sqrt(1+4*(1-gamma)^2)), including gamma=1. No remaining numbered clause.

**Formal proof route:** Existing proved actual-root cubic Jury criterion, exact algebra and positive-root comparison.

**Primary declarations:**

- `C2.IntegratorDelay.two_stable_iff`
- `C2.IntegratorDelay.two_stable_iff_threshold`
- `C2.IntegratorDelay.twoThreshold_equation`
- `C2.IntegratorDelay.two_threshold_strictMono`
- `C2.IntegratorDelay.two_threshold_unique_max`

**Modules:** `C2.IntegratorDelayTwo`.

**Evidence:** [validation/integer_delay_completion_20261109.json](validation/integer_delay_completion_20261109.json).

## cor:global

**Status: COMPLETE.** Union of actual physical stable gains over n>=1 and gamma in [0,1] is exactly (0,4). The unique pair attaining the margin supremum 4 is n=1,gamma=3/4; controller-gain threshold is 4/(K*tau) for K,tau>0. Fine-sampling physical thresholds are actual IsLUBs, decrease strictly from 2 at n=2, and converge to pi/2. No remaining numbered clause.

**Formal proof route:** Actual region and one-sample specialization, positive scaling, exact least-upper-bound comparisons, elementary trigonometric derivative estimate and continuous divided differences for the limit.

**Primary declarations:**

- `C2.IntegratorDelay.physical_gain_projection`
- `C2.IntegratorDelay.global_physical_gain_isLUB`
- `C2.IntegratorDelay.global_physical_maximizer_iff`
- `C2.IntegratorDelay.physical_controller_gain_projection`
- `C2.IntegratorDelay.fine_physicalThreshold_isLUB`
- `C2.IntegratorDelay.physicalThreshold_strictAntiOn`
- `C2.IntegratorDelay.physicalThreshold_two`
- `C2.IntegratorDelay.physicalThreshold_tendsto`

**Modules:** `C2.IntegratorDelayGlobal`, `C2.IntegratorDelaySampling`, `C2.IntegratorDelayOptimum`, `C2.IntegratorDelayRegion`.

**Evidence:** [validation/integer_delay_completion_20261109.json](validation/integer_delay_completion_20261109.json).

## thm:norms

**Status: COMPLETE.** Actual unit-circle supremum of complex rational transfer norms; sensitivity peak location and value, both complementary-sensitivity regimes, strict second-branch value above one, and explicit unit-circle points attaining the maxima. Uses algebraic square identities instead of derivative sign arguments.

**Formal proof route:** Reduces the complex unit-circle transfer norms to real algebraic expressions and proves exact square inequalities for their maxima. Explicit unit-circle witnesses establish attainment in each regime, including the strict complementary-sensitivity peak above one.

**Primary declarations:**

- `C2.Sensitivity.exact_sensitivity_peak`
- `C2.Sensitivity.exact_complementary_low_peak`
- `C2.Sensitivity.exact_complementary_high_peak`
- `C2.Sensitivity.sensitivity_peak_attained`
- `C2.Sensitivity.complementary_high_peak_attained`

**Modules:** `C2.Sensitivity`.

**Evidence:** [validation/root_completion_20261109.json](validation/root_completion_20261109.json).

## prop:radius

**Status: COMPLETE.** Radius is defined as the supremum of actual complex-root norms, not by the claimed formula. Proved attained maximum in both regimes, both displayed formulas, and unique minimum R(4/9)=1/3 for 0<a<4. No numbered clause remains.

**Formal proof route:** Factors the actual quadratic in the real-root regime and proves nonnegative ordered roots. In the conjugate-root regime, the polynomial equation determines the common root norm. These facts identify the attained supremum of root norms in both regimes and prove the unique minimum at a=4/9.

**Primary declarations:**

- `C2.PoleRadius.low_radius_isGreatest`
- `C2.PoleRadius.high_radius_isGreatest`
- `C2.PoleRadius.low_radius_formula`
- `C2.PoleRadius.high_radius_formula`
- `C2.PoleRadius.radius_at_minimum`
- `C2.PoleRadius.radius_unique_minimum`

**Modules:** `C2.Schur`, `C2.PoleRadius`.

**Evidence:** [validation/regions_completion_20261109.json](validation/regions_completion_20261109.json).

## prop:miace-pure-delay

**Status: COMPLETE.** Literal zero-prehistory d-sample plant, absolute tracking and centred-command series, Ae=dT+Au, same minimizers for every positive eta. Works even for d=0, hence includes d>=1.

**Formal proof route:** Derives the initial d errors and subsequent shifted command-error sequence directly from the zero-prehistory plant. Splitting the absolutely convergent series yields Ae=dT+Au; strict monotonicity of the MIACE cost along that affine relation proves equality of minimizers for every positive weight.

**Primary declarations:**

- `C2.MIACE.pure_delay_plant_area_identity`
- `C2.MIACE.pure_delay_command_summable`
- `C2.MIACE.pure_delay_plant_minimizer_iff`

**Modules:** `C2.MIACEAreas`, `C2.MIACEDelay`.

**Evidence:** [validation/miace_completion_20261109.json](validation/miace_completion_20261109.json).

## thm:miace-monotone-reserve

**Status: COMPLETE.** Actual recursively defined zero-state one-delay response; exact monotone-convergence iff; absolute-area formulas; actual critical-gain reserve; all three regimes and unique global actual MIACE minimizer; endpoint agreement, monotone bounded command, strict stability for every 0<q<R.

**Formal proof route:** Negative discriminant contradicts positive successive-error ratios via fixed decrement, replacing the manuscript sine oscillation argument.

**Primary declarations:**

- `C2.MIACE.monotone_tracking_iff`
- `C2.MIACE.monotone_response_areas`
- `C2.MIACE.exact_monotone_miace_reserve_optimizer`
- `C2.MIACE.reserve_parameters_eq`
- `C2.MIACE.reserve_formula_endpoint_agreement`
- `C2.MIACE.response_and_command_bounds`
- `C2.MIACE.reserved_uncertain_gain_stable`
- `C2.FirstOrder.oneSampleThreshold_isLUB`

**Modules:** `C2.MIACERecurrence`, `C2.MIACEReserve`, `C2.MIACEResponse`, `C2.MIACEComplete`, `C2.RegionCompletionFirstOrder`.

**Evidence:** [validation/miace_completion_20261109.json](validation/miace_completion_20261109.json).

## prop:miace-tail-existence

**Status: COMPLETE.** Continuous compact family of actual real Schur-stable matrices and varying initial state/output rows/sampling period; uniform convergence of actual T-weighted absolute-area series, continuous MIACE, attained minimum. Exact explicit Tmax*C*q^N/(1-q)*sqrt(E^2+eta*U^2) tail bound from normed-space state/output envelopes. Empty state index handled separately.

**Formal proof route:** Finite subcover and common contracting power, followed by Bernoulli geometric ratio, replaces Lyapunov-equation continuity.

**Primary declarations:**

- `C2.MIACE.compact_schur_output_envelopes`
- `C2.MIACE.compact_schur_miace_existence`
- `C2.MIACE.state_output_tail_bound`

**Modules:** `C2.CompactSchur`, `C2.MIACETail`, `C2.MIACECompact`, `C2.MIACEStateTail`.

**Evidence:** [validation/miace_completion_20261109.json](validation/miace_completion_20261109.json).
