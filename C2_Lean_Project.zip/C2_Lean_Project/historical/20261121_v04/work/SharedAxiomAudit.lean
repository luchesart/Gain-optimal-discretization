import C2
import Lean.Util.CollectAxioms
import Lean.Elab.Command

/- Audit code only. The original collector reads the checked kernel environment,
traversing definition/theorem/opaque types and bodies, constructor and recursor
types, and inductive types plus constructors. Sharing its visited set computes
the union of reachable axioms without rescanning common dependencies.
No replacement collector or proof-source declarations are introduced. -/
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0

run_cmd do
  let rootText ← IO.FS.readFile "work/SharedAxiomAudit.roots.txt"
  let roots := ((rootText.splitOn "\n").filter (· != "")).toArray.map String.toName
  let env ← getEnv
  let checked := env.checked.get
  for root in roots do
    unless (checked.find? root).isSome do
      throwError "Missing public declaration in checked kernel environment: {root}"
  let stdout ← IO.getStdout
  stdout.putStrLn s!"C2_SHARED_AXIOM_AUDIT_START roots={roots.size}"
  stdout.flush
  let mut state : Lean.CollectAxioms.State := {}
  let mut completed := 0
  for root in roots do
    let (_, next) := ((Lean.CollectAxioms.collect root).run env).run state
    state := next
    completed := completed + 1
    if completed == 1 || completed % 100 == 0 || completed == roots.size then
      stdout.putStrLn s!"C2_SHARED_AXIOM_AUDIT_PROGRESS roots={completed}/{roots.size} axioms={state.axioms.size}"
      stdout.flush
  let axioms := state.axioms.qsort Name.lt
  let allowed : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let unexpected := axioms.filter (fun name => !allowed.contains name)
  let report := Json.mkObj [
    ("schema", toJson "c2.shared-axiom-union.v1"),
    ("collector", toJson "Lean.CollectAxioms.collect (unchanged official implementation)"),
    ("inventory_sha256", toJson "d19605ab1d35f70a5bee321e6c295661f7f62be2488d401c9a55c25e91c7d190"),
    ("root_list_sha256", toJson "6dc48335773732b7382b11ed021e43b3a9230239906e0f42d17a6cc0170067cc"),
    ("expected_count", toJson 2176),
    ("checked_root_count", toJson completed),
    ("all_roots_exist_in_checked_kernel_environment", toJson true),
    ("roots", toJson (roots.map Name.toString)),
    ("axiom_union", toJson (axioms.map Name.toString)),
    ("allowed_axioms", toJson (allowed.map Name.toString)),
    ("unexpected_axioms", toJson (unexpected.map Name.toString)),
    ("passed", toJson (unexpected.isEmpty && completed == 2176))]
  IO.FS.writeFile "work/SharedAxiomAudit.raw.json" (report.pretty ++ "\n")
  unless unexpected.isEmpty do
    throwError "Unexpected transitive axioms: {unexpected}"
  unless completed == 2176 do
    throwError "Public root count changed: {completed}"
  stdout.putStrLn "C2_SHARED_AXIOM_AUDIT_COMPLETE"
  stdout.flush
