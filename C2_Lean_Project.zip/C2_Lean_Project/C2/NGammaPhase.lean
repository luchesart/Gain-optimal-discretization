import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Analysis.Calculus.Deriv.Slope
import Mathlib.Topology.Algebra.Order.Field
import Mathlib.Tactic
import C2.NGammaPhaseScale

/-!
# Normalized phase contribution for independent discretization parameters

This file concerns the real analytic lemma `lem:ngamma-phase-ratio`.
It does not replace the separate complex root-count obligation.
-/

noncomputable section
open Set Filter
open scoped Topology

namespace C2.NGamma.Phase

def contribution (a x t : ℝ) : ℝ := Real.arctan (a*t) - Real.arctan (x*t)

def ratio (a x t : ℝ) : ℝ := contribution a x t / Real.arctan (1/t)

theorem arctan_pos {u : ℝ} (hu : 0 < u) : 0 < Real.arctan u := by
  simpa only [Real.arctan_zero] using Real.arctan_strictMono hu

theorem arctan_upper_bound {u : ℝ} (hu : 0 < u) : Real.arctan u ≤ u := by
  have h := Real.lt_tan (arctan_pos hu) (Real.arctan_lt_pi_div_two u)
  simpa only [Real.tan_arctan] using h.le

theorem arctan_lower_bound (u : ℝ) (hu : 0 ≤ u) :
    u / (1+u^2) ≤ Real.arctan u := by
  let f : ℝ → ℝ := fun v => Real.arctan v - v/(1+v^2)
  have hd (v : ℝ) : HasDerivAt f (2*v^2/(1+v^2)^2) v := by
    have h := (Real.hasDerivAt_arctan v).sub
      ((hasDerivAt_id v).div
        ((hasDerivAt_const v (1:ℝ)).add ((hasDerivAt_id v).pow 2))
        (by positivity : (1+v^2:ℝ) ≠ 0))
    convert h using 1 <;> dsimp [f]
    field_simp
    <;> ring
  have hm : Monotone f := monotone_of_hasDerivAt_nonneg hd (by
    intro v
    positivity)
  have he := hm hu
  simpa [f] using he

theorem contribution_pos {a x t : ℝ} (hax : x < a) (ht : 0 < t) :
    0 < contribution a x t := by
  unfold contribution
  exact sub_pos.mpr (Real.arctan_strictMono (mul_lt_mul_of_pos_right hax ht))

theorem contribution_hasDerivAt (a x t : ℝ) :
    HasDerivAt (contribution a x)
      ((a-x)*(1-a*x*t^2)/((1+a^2*t^2)*(1+x^2*t^2))) t := by
  have h := ((Real.hasDerivAt_arctan (a*t)).comp t
    ((hasDerivAt_id t).const_mul a)).sub
    ((Real.hasDerivAt_arctan (x*t)).comp t ((hasDerivAt_id t).const_mul x))
  convert h using 1 <;> dsimp [contribution]
  field_simp
  <;> ring

theorem inverse_arctan_hasDerivAt {t : ℝ} (ht : t ≠ 0) :
    HasDerivAt (fun v : ℝ => Real.arctan (1/v)) (-1/(1+t^2)) t := by
  have h := (Real.hasDerivAt_arctan (1/t)).comp t
    ((hasDerivAt_const t (1:ℝ)).div (hasDerivAt_id t) ht)
  convert h using 1
  field_simp
  <;> ring

theorem ratio_hasDerivAt {a x t : ℝ} (ht : 0 < t) :
    HasDerivAt (ratio a x)
      ((((a-x)*(1-a*x*t^2)/((1+a^2*t^2)*(1+x^2*t^2))) *
        Real.arctan (1/t) + contribution a x t/(1+t^2)) /
        (Real.arctan (1/t))^2) t := by
  have h := (contribution_hasDerivAt a x t).div
    (inverse_arctan_hasDerivAt ht.ne')
    ((arctan_pos (by positivity : 0 < (1/t:ℝ))).ne')
  convert h using 1 <;> dsimp [ratio]
  ring

theorem contribution_arctan {a x t : ℝ} (hx : 0 ≤ x) (hax : x < a)
    (ht : 0 < t) :
    contribution a x t = Real.arctan ((a-x)*t/(1+a*x*t^2)) := by
  have ha : 0 < a := lt_of_le_of_lt hx hax
  have hprod : a*t*(-(x*t)) < 1 := by
    have : 0 ≤ a*x*t^2 := by positivity
    nlinarith
  have h := Real.arctan_add hprod
  rw [Real.arctan_neg] at h
  calc
    contribution a x t = Real.arctan ((a*t + -(x*t))/(1-a*t*(-(x*t)))) := by
      exact h
    _ = _ := by congr 1; congr 1 <;> ring

theorem contribution_lower_bound {a x t : ℝ} (hx : 0 ≤ x)
    (hax : x < a) (ht : 0 < t) :
    (a-x)*t*(1+a*x*t^2)/((1+a^2*t^2)*(1+x^2*t^2)) ≤
      contribution a x t := by
  have ha : 0 < a := lt_of_le_of_lt hx hax
  have hA : 0 < a-x := sub_pos.mpr hax
  rw [contribution_arctan hx hax ht]
  have h := arctan_lower_bound ((a-x)*t/(1+a*x*t^2)) (by positivity)
  convert h using 1
  field_simp
  <;> ring

theorem ratio_derivative_pos_of_le_one {a x t : ℝ} (hx : 0 ≤ x)
    (hax : x < a) (ha : a ≤ 1) (ht : 0 < t) :
    0 < deriv (ratio a x) t := by
  rw [(ratio_hasDerivAt ht).deriv]
  apply div_pos _ (sq_pos_of_pos (arctan_pos (by positivity)))
  have hapos : 0 < a := lt_of_le_of_lt hx hax
  have hP : 0 < (1+a^2*t^2)*(1+x^2*t^2) := by positivity
  have hA : 0 < a-x := sub_pos.mpr hax
  have hN := contribution_pos hax ht
  have hD := arctan_pos (by positivity : 0 < (1/t:ℝ))
  by_cases hc : 0 ≤ 1-a*x*t^2
  · exact add_pos_of_nonneg_of_pos
      (mul_nonneg (div_nonneg (mul_nonneg hA.le hc) hP.le) hD.le)
      (div_pos hN (by positivity))
  · have hc' : (a-x)*(1-a*x*t^2)/((1+a^2*t^2)*(1+x^2*t^2)) < 0 :=
      div_neg_of_neg_of_pos (mul_neg_of_pos_of_neg hA (lt_of_not_ge hc)) hP
    have hDupper := arctan_upper_bound (by positivity : 0 < (1/t:ℝ))
    have hNlower := contribution_lower_bound hx hax ht
    have haxbound : a*x ≤ 1 := by
      have hxone : x ≤ 1 := le_trans hax.le ha
      nlinarith [mul_nonneg (by linarith : 0 ≤ 1-a) (by linarith : 0 ≤ 1-x)]
    have hlower : 0 <
        (a-x)*(1-a*x*t^2)/((1+a^2*t^2)*(1+x^2*t^2))*(1/t) +
        ((a-x)*t*(1+a*x*t^2)/((1+a^2*t^2)*(1+x^2*t^2)))/(1+t^2) := by
      have he :
          (a-x)*(1-a*x*t^2)/((1+a^2*t^2)*(1+x^2*t^2))*(1/t) +
          ((a-x)*t*(1+a*x*t^2)/((1+a^2*t^2)*(1+x^2*t^2)))/(1+t^2) =
          (a-x)*(1+(2-a*x)*t^2)/(t*((1+a^2*t^2)*(1+x^2*t^2))*(1+t^2)) := by
        field_simp
        <;> ring
      rw [he]
      have htwo : 0 < 2-a*x := by linarith
      positivity
    exact lt_of_lt_of_le hlower (add_le_add
      (mul_le_mul_of_nonpos_left hDupper hc'.le)
      (div_le_div_of_nonneg_right hNlower (by positivity)))

theorem ratio_strictMonoOn_of_le_one {a x : ℝ} (hx : 0 ≤ x)
    (hax : x < a) (ha : a ≤ 1) : StrictMonoOn (ratio a x) (Ioi 0) := by
  apply strictMonoOn_of_deriv_pos (convex_Ioi 0)
  · intro t ht
    exact (ratio_hasDerivAt ht).continuousAt.continuousWithinAt
  · intro t ht
    exact ratio_derivative_pos_of_le_one hx hax ha (by simpa using ht)

theorem ratio_strictMonoOn_of_zero {a : ℝ} (ha : 0 < a) :
    StrictMonoOn (ratio a 0) (Ioi 0) := by
  intro s hs t ht hst
  have hs0 : 0 < s := hs
  have ht0 : 0 < t := ht
  have hN : Real.arctan (a*s) < Real.arctan (a*t) :=
    Real.arctan_strictMono (mul_lt_mul_of_pos_left hst ha)
  have hDs : 0 < Real.arctan (1/s) := arctan_pos (one_div_pos.mpr hs0)
  have hDt : 0 < Real.arctan (1/t) := arctan_pos (one_div_pos.mpr ht0)
  have hD : Real.arctan (1/t) ≤ Real.arctan (1/s) :=
    Real.arctan_strictMono.monotone (one_div_le_one_div_of_le hs hst.le)
  dsimp [ratio, contribution]
  simp only [zero_mul, Real.arctan_zero, sub_zero]
  exact lt_of_lt_of_le (div_lt_div_of_pos_right hN hDs)
    (div_le_div_of_nonneg_left (arctan_pos (mul_pos ha ht)).le hDt hD)

theorem ratio_eq_scale_difference {a x t : ℝ} (hx : 0 < x)
    (ha : 0 < a) (ht : 0 < t) :
    ratio a x t = PhaseScale.scaleRatio (1/x) (1/t) -
      PhaseScale.scaleRatio (1/a) (1/t) := by
  have hi (c : ℝ) (hc : 0 < c) :
      Real.arctan ((1/c)*(1/t)) = Real.pi/2 - Real.arctan (c*t) := by
    convert Real.arctan_inv_of_pos (mul_pos hc ht) using 1 <;> field_simp
  dsimp [ratio, contribution, PhaseScale.scaleRatio]
  rw [hi x hx, hi a ha]
  ring

theorem ratio_strictMonoOn {a x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (hax : x < a) : StrictMonoOn (ratio a x) (Ioi 0) := by
  by_cases hx0 : x = 0
  · subst x
    exact ratio_strictMonoOn_of_zero hax
  have hxpos : 0 < x := lt_of_le_of_ne hx (Ne.symm hx0)
  by_cases ha1 : a ≤ 1
  · exact ratio_strictMonoOn_of_le_one hx hax ha1
  have ha : 1 < a := lt_of_not_ge ha1
  have hapos : 0 < a := by linarith
  intro s hs t ht hst
  have hs0 : 0 < s := hs
  have ht0 : 0 < t := ht
  rw [ratio_eq_scale_difference hxpos hapos hs,
    ratio_eq_scale_difference hxpos hapos ht]
  have hsi : 0 < (1/s:ℝ) := one_div_pos.mpr hs0
  have hti : 0 < (1/t:ℝ) := one_div_pos.mpr ht0
  have hist : (1/t:ℝ) < 1/s := one_div_lt_one_div_of_lt hs hst
  have hfirst : PhaseScale.scaleRatio (1/x) (1/s) ≤ PhaseScale.scaleRatio (1/x) (1/t) := by
    by_cases hxone : x = 1
    · subst x
      have hsn : Real.arctan s⁻¹ ≠ 0 := by simpa only [one_div] using (arctan_pos hsi).ne'
      have htn : Real.arctan t⁻¹ ≠ 0 := by simpa only [one_div] using (arctan_pos hti).ne'
      simp [PhaseScale.scaleRatio, hsn, htn]
    · have hxlt : x < 1 := lt_of_le_of_ne hx1 hxone
      exact (PhaseScale.scaleRatio_strictAntiOn
        ((one_lt_div hxpos).mpr (by simpa using hxlt)) hti hsi hist).le
  have hsecond : PhaseScale.scaleRatio (1/a) (1/t) < PhaseScale.scaleRatio (1/a) (1/s) :=
    PhaseScale.scaleRatio_strictMonoOn (by positivity)
      ((div_lt_one hapos).mpr ha) hti hsi hist
  linarith

theorem ratio_tendsto_zero (a x : ℝ) :
    Tendsto (ratio a x) (𝓝[>] 0) (𝓝 0) := by
  have hn : Tendsto (contribution a x) (𝓝[>] 0) (𝓝 0) := by
    have h : Continuous (contribution a x) := by
      unfold contribution
      exact (Real.continuous_arctan.comp (continuous_const.mul continuous_id)).sub
        (Real.continuous_arctan.comp (continuous_const.mul continuous_id))
    simpa [contribution] using
      (h.continuousAt (x := 0)).tendsto.mono_left (nhdsWithin_le_nhds (s := Ioi 0))
  have hd : Tendsto (fun t : ℝ => Real.arctan (1/t)) (𝓝[>] 0) (𝓝 (Real.pi/2)) := by
    simpa only [one_div] using
      Real.tendsto_arctan_atTop.mono_right nhdsWithin_le_nhds |>.comp tendsto_inv_nhdsGT_zero
  change Tendsto (fun t => contribution a x t / Real.arctan (1/t)) _ _
  simpa only [zero_div] using hn.div hd (by positivity : Real.pi/2 ≠ 0)

theorem arctan_difference_ratio_tendsto (c d : ℝ) :
    Tendsto (fun u : ℝ => (Real.arctan (c*u)-Real.arctan (d*u))/Real.arctan u)
      (𝓝[>] 0) (𝓝 (c-d)) := by
  have hf : HasDerivAt (fun u : ℝ => Real.arctan (c*u)-Real.arctan (d*u))
      (c-d) 0 := by
    convert ((Real.hasDerivAt_arctan (c*0)).comp 0
      ((hasDerivAt_id 0).const_mul c)).sub
      ((Real.hasDerivAt_arctan (d*0)).comp 0 ((hasDerivAt_id 0).const_mul d)) using 1 <;> simp
  have hn : Tendsto (fun u : ℝ => (Real.arctan (c*u)-Real.arctan (d*u))/u)
      (𝓝[>] 0) (𝓝 (c-d)) := by
    simpa [div_eq_mul_inv, mul_comm] using hf.tendsto_slope_zero_right
  have hd : Tendsto (fun u : ℝ => Real.arctan u/u) (𝓝[>] 0) (𝓝 1) := by
    simpa [div_eq_mul_inv, mul_comm] using (Real.hasDerivAt_arctan 0).tendsto_slope_zero_right
  have h := hn.div hd (by norm_num : (1:ℝ) ≠ 0)
  simp only [div_one] at h
  apply h.congr'
  filter_upwards [self_mem_nhdsWithin] with u hu
  have hu' : u ≠ 0 := ne_of_gt hu
  dsimp
  field_simp

theorem ratio_tendsto_atTop_of_pos {a x : ℝ} (hx : 0 < x) (hax : x < a) :
    Tendsto (ratio a x) atTop (𝓝 (1/x-1/a)) := by
  have ha : 0 < a := lt_trans hx hax
  have h := (arctan_difference_ratio_tendsto (1/x) (1/a)).comp tendsto_inv_atTop_nhdsGT_zero
  apply h.congr'
  filter_upwards [eventually_gt_atTop (0:ℝ)] with t ht
  have hi (c : ℝ) (hc : 0 < c) :
      Real.arctan ((1/c)*t⁻¹) = Real.pi/2 - Real.arctan (c*t) := by
    convert Real.arctan_inv_of_pos (mul_pos hc ht) using 1 <;> field_simp
  dsimp [ratio, contribution]
  rw [hi x hx, hi a ha]
  simp only [one_div]
  ring

theorem ratio_tendsto_atTop_of_zero {a : ℝ} (ha : 0 < a) :
    Tendsto (ratio a 0) atTop atTop := by
  have hn : Tendsto (fun t : ℝ => Real.arctan (a*t)) atTop (𝓝 (Real.pi/2)) :=
    (Real.tendsto_arctan_atTop.mono_right nhdsWithin_le_nhds).comp
      (tendsto_id.const_mul_atTop ha)
  have hd : Tendsto (fun t : ℝ => Real.arctan (1/t)) atTop (𝓝[>] 0) := by
    apply tendsto_nhdsWithin_iff.mpr
    constructor
    · have h := Real.continuous_arctan.continuousAt.tendsto.comp
        (tendsto_inv_atTop_zero : Tendsto (fun t : ℝ => t⁻¹) atTop (𝓝 0))
      simpa [one_div] using h
    · filter_upwards [eventually_gt_atTop (0:ℝ)] with t ht
      exact arctan_pos (by positivity)
  change Tendsto (fun t => contribution a 0 t / Real.arctan (1/t)) atTop atTop
  simpa [contribution, div_eq_mul_inv] using
    hn.pos_mul_atTop (by positivity : 0 < Real.pi/2) hd.inv_tendsto_nhdsGT_zero

/-- Complete analytic statement of paper Lemma `lem:ngamma-phase-ratio`. -/
theorem normalized_phase_contribution {a x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (hax : x < a) :
    StrictMonoOn (ratio a x) (Ioi 0) ∧
    Tendsto (ratio a x) (𝓝[>] 0) (𝓝 0) ∧
    (0 < x → Tendsto (ratio a x) atTop (𝓝 (1/x-1/a))) ∧
    (x = 0 → Tendsto (ratio a x) atTop atTop) := by
  refine ⟨ratio_strictMonoOn hx hx1 hax, ratio_tendsto_zero a x,
    fun hxpos => ratio_tendsto_atTop_of_pos hxpos hax, ?_⟩
  intro hxzero
  subst x
  exact ratio_tendsto_atTop_of_zero hax

end C2.NGamma.Phase
