# C2 axiom and coverage checklist — version 0.4.0, 2026-11-09

- [x] Lean 4.19.0 and the pinned mathlib revision were checked.
- [x] All 208 proof modules compile individually; the complete umbrella import passes.
- [x] The generated standalone file passes an independent Lean check.
- [x] All 2176 explicit public declarations resolve in the axiom audit.
- [x] Transitive axiom dependencies are limited to propext, Classical.choice and Quot.sound.
- [x] No sorryAx, custom axiom, admitted proof or unsafe source declaration is accepted.
- [x] Source inventory handles namespaces, private declarations and same-line attributes.
- [x] All 156 version 0.3.0 proof modules remain byte-identical.
- [x] All 45 numbered manuscript claims are COMPLETE.
- [x] Root counts and Schur predicates concern actual complex roots with multiplicity.
- [x] Initial margins are least upper bounds of actual stable intervals.
- [x] MIACE proofs include the zero-prehistory recurrence, parameter regimes and endpoints.
- [x] The two-parameter optimum includes the full square and uniqueness.
- [x] Integer-delay stability includes all real gains and excludes later stable components.
- [x] The realization theorem explicitly uses the degree-minimal convention.
- [x] The general CAD program internally constructs and verifies factor and Bézout data.
- [x] Squarefree reduction and certified dyadic root isolation have terminating exact searches.
- [x] Computed rational samples and finite marks decide the original closed-parameter inequalities.
- [x] The actual native CAD output is empty exactly for infeasibility, or describes the unique algebraic global supremum.

There are 1741 explicit public theorems and lemmas, not 1741 independent
manuscript claims. Private helper declarations and generated constants are
not counted as public results; their dependencies are checked transitively.
The official collector shares its visited set over all public roots. The
resulting union contains only the three allowed axioms, which is equivalent
to the same condition for every root. Exact per-root lists are not claimed.

Theorem 3 is covered by `C2.CADNative.native_gain_projection_correct` and its
supporting execution and correctness theorems. The runtime uses dense rational
lists, finite natural root ranks and proved terminating searches. The real
root interpretation is proof-only; no factorization or real-root oracle is
an input to the native program. Exhaustive witness enumeration is total but
may be impractically slow. The separate literal SymPy/resultant code remains
unverified; its verification is not needed for the stated Lean theorem.

See README.txt for reproduction commands, MANUSCRIPT_FORMALIZATION_NOTES.md
for mathematical scope, and VERIFICATION.json for the checks actually run.
Older evidence is retained under historical/20261108 and the version 0.3.0
documents under historical/20261109_v03. No online live.lean website session
or fresh numerical experiment is claimed.
