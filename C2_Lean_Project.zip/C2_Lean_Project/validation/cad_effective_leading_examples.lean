import C2.CADEffectiveLeading
open C2.CADEffective
#eval Bivariate.leadingCoeff [[1,2], [0], [3], [], [0,0]]
#eval Bivariate.leadingCoeff [[0,0], [], [0]]
#eval Bivariate.gammaEval [[1,2], [0], [3], [], [0,0]] 2
#eval Dense.eqb (Bivariate.gammaEval [[1,2], [0], [3], [], [0,0]] 2) [13,2]
#eval Dense.eqb (Bivariate.leadingCoeff [[0,0], [], [0]]) []
#eval Dense.eqb (Bivariate.gammaEval [[1,2], [0], [3]] 0) [1,2]
#eval Dense.eqb (Bivariate.gammaEval [[1,2], [0], [3]] 1) [4,2]
