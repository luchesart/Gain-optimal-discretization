import C2.CADEffectiveWitnessSearch
import C2.CADEffectiveProjection
import C2.CADDriver

/-! The complete native CAD entry point. Its runtime inputs are only dense
rational bivariate polynomials and a positive rational gain bound. Factor data,
projection data, root isolation, rational test points and the selected output
are all constructed internally by proved terminating procedures. -/
namespace C2.CADNative
open C2.CADEffective

structure Output where
  isolation : C2.CADDriver.Isolation
  rank : ℕ

/-- The internally generated exact rational projection polynomial. -/
def projection (F : List Bivariate.Poly)
    (hF : ∀ i : Fin F.length, Bivariate.inputFamily F i ≠ 0) : Dense.Poly :=
  Bivariate.totalProjection F (Bivariate.produceWitness F hF)

theorem projection_nonzero (F : List Bivariate.Poly)
    (hF : ∀ i : Fin F.length, Bivariate.inputFamily F i ≠ 0) :
    Dense.denote (projection F hF) ≠ 0 :=
  Bivariate.totalProjection_nonzero_of_valid F _
    (Bivariate.produceWitness_correct F hF).1 (Bivariate.produceWitness_correct F hF).2

/-- Every witness and sample is computed from the original polynomial system. -/
def runNonzero (F : List Bivariate.Poly)
    (hF : ∀ i : Fin F.length, Bivariate.inputFamily F i ≠ 0)
    (K : ℚ) (hK : 0 < K) : C2.CADDriver.Run :=
  C2.CADDriver.runWithProjection F (projection F hF) (projection_nonzero F hF) K hK.le

/-- The user-facing total CAD program. A zero original inequality is immediately
infeasible; otherwise full projection and lifting are executed internally. -/
def run (F : List Bivariate.Poly) (K : ℚ) (hK : 0 < K) : Option Output :=
  if hz : Bivariate.nonzeroInputs F = true then
    let R := runNonzero F ((Bivariate.nonzeroInputs_iff F).mp hz) K hK
    R.result.map (fun r => ⟨R.isolation, r⟩)
  else none

theorem run_of_nonzero (F : List Bivariate.Poly)
    (hF : ∀ i : Fin F.length, Bivariate.inputFamily F i ≠ 0)
    (K : ℚ) (hK : 0 < K) :
    run F K hK = (runNonzero F hF K hK).result.map
      (fun r => ⟨(runNonzero F hF K hK).isolation, r⟩) := by
  simp only [run, (Bivariate.nonzeroInputs_iff F).mpr hF, dite_true]

theorem run_of_zero (F : List Bivariate.Poly) (K : ℚ) (hK : 0 < K)
    (hz : Bivariate.nonzeroInputs F = false) : run F K hK = none := by
  simp only [run, hz, Bool.false_eq_true, dite_false]

/-- The fast zero-input branch is semantically infeasible at every real gain. -/
theorem zero_guard_infeasible (F : List Bivariate.Poly)
    (hz : Bivariate.nonzeroInputs F = false) (k : ℝ) :
    ¬∃ x ∈ Set.Icc (0 : ℝ) 1,
      ∀ i, 0 < C2.CADProjection.value (Bivariate.inputFamily F i) k x := by
  classical
  have hn : ¬∀ i : Fin F.length, Bivariate.inputFamily F i ≠ 0 := by
    intro hh
    have ht := (Bivariate.nonzeroInputs_iff F).mpr hh
    rw [hz] at ht
    cases ht
  push_neg at hn
  obtain ⟨i, hi⟩ := hn
  rintro ⟨x, hx, hpos⟩
  have hh := hpos i
  simp [hi, C2.CADProjection.value, C2.CADProjection.specialize] at hh

theorem run_some_iff (F : List Bivariate.Poly)
    (hF : ∀ i : Fin F.length, Bivariate.inputFamily F i ≠ 0)
    (K : ℚ) (hK : 0 < K) (o : Output) :
    run F K hK = some o ↔ ∃ r,
      (runNonzero F hF K hK).result = some r ∧
      (⟨(runNonzero F hF K hK).isolation, r⟩ : Output) = o := by
  rw [run_of_nonzero F hF K hK, Option.map_eq_some_iff]

theorem run_none_iff_of_nonzero (F : List Bivariate.Poly)
    (hF : ∀ i : Fin F.length, Bivariate.inputFamily F i ≠ 0)
    (K : ℚ) (hK : 0 < K) :
    run F K hK = none ↔ (runNonzero F hF K hK).result = none := by
  rw [run_of_nonzero F hF K hK, Option.map_eq_none_iff]

/-- Every successful output is a unique real algebraic root descriptor, with
its dense polynomial, rational isolating grid and selected natural rank. -/
theorem run_some_unique_root (F : List Bivariate.Poly) (K : ℚ) (hK : 0 < K)
    {o : Output} (hout : run F K hK = some o) :
    ∃! x : ℝ, Dense.rootAtRank o.isolation.polynomial 0 K o.isolation.mesh o.rank x := by
  by_cases hz : Bivariate.nonzeroInputs F = true
  · let hF := (Bivariate.nonzeroInputs_iff F).mp hz
    obtain ⟨r,hr,rfl⟩ := (run_some_iff F hF K hK o).mp hout
    exact C2.CADDriver.selected_rank_unique_root F (projection F hF)
      (projection_nonzero F hF) K hK hr
  · have hf : Bivariate.nonzeroInputs F = false := Bool.eq_false_iff.mpr hz
    rw [run_of_zero F K hK hf] at hout
    cases hout

/-- The returned root polynomial is nonzero, so its descriptor certifies an
algebraic number rather than a root of the identically zero polynomial. -/
theorem run_some_polynomial_nonzero (F : List Bivariate.Poly) (K : ℚ) (hK : 0 < K)
    {o : Output} (hout : run F K hK = some o) :
    Dense.denote o.isolation.polynomial ≠ 0 := by
  by_cases hz : Bivariate.nonzeroInputs F = true
  · let hF := (Bivariate.nonzeroInputs_iff F).mp hz
    obtain ⟨r,hr,rfl⟩ := (run_some_iff F hF K hK o).mp hout
    exact C2.CADDriver.isolate_polynomial_nonzero (projection F hF)
      (projection_nonzero F hF) 0 K hK.le
  · have hf : Bivariate.nonzeroInputs F = false := Bool.eq_false_iff.mpr hz
    rw [run_of_zero F K hK hf] at hout
    cases hout

end C2.CADNative
