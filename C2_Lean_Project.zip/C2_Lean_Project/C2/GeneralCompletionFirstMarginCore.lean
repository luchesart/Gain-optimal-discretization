import Mathlib

/-! The first positive boundary determines the initial stable component.
This order-theoretic step retains possible stable components above it. -/

noncomputable section
open Set
namespace C2.GeneralCompletion

def initialIntervalEndpoints (P : ℝ → Prop) : Set ℝ :=
  {b | 0 < b ∧ ∀ k : ℝ, 0 < k → k < b → P k}

theorem first_boundary_nonempty {P : ℝ → Prop} {K : Set ℝ}
    (hsmall : ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℝ, 0 < k → k < ε → P k)
    (hbound : ∃ B : ℝ, ∀ k : ℝ, 0 < k → P k → k ≤ B)
    (htransfer : ∀ a b : ℝ, 0 < a → a ≤ b →
      (∀ k ∈ Icc a b, k ∉ K) → (P a ↔ P b)) : K.Nonempty := by
  by_contra hn
  have hK : K = ∅ := Set.not_nonempty_iff_eq_empty.mp hn
  obtain ⟨ε,hε,hs⟩ := hsmall
  obtain ⟨B,hB⟩ := hbound
  let b := max B 0 + 1
  have hb : 0 < b := by dsimp [b]; linarith [le_max_right B (0:ℝ)]
  let a := min ε b / 2
  have ha : 0 < a := div_pos (lt_min hε hb) (by norm_num)
  have hae : a < ε := by dsimp [a]; linarith [min_le_left ε b]
  have hab : a ≤ b := by
    change min ε b / 2 ≤ b
    exact (div_le_div_of_nonneg_right (min_le_right ε b) (by norm_num : (0:ℝ) ≤ 2)).trans
      (div_le_self hb.le (by norm_num : (1:ℝ) ≤ 2))
  have hPa : P a := hs a ha hae
  have hPb : P b := (htransfer a b ha hab (by simp [hK])).mp hPa
  have hh := hB b hb hPb
  dsimp [b] at hh
  linarith [le_max_left B (0:ℝ)]

/-- Finite candidates plus the independently proved interval-transport and
large-gain exclusion yield the least actual boundary and exact initial margin. -/
theorem finite_first_boundary_margin {P : ℝ → Prop} {K : Set ℝ}
    (hfinite : K.Finite) (hpositive : ∀ k ∈ K, 0 < k)
    (hboundary : ∀ k ∈ K, ¬P k)
    (hsmall : ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℝ, 0 < k → k < ε → P k)
    (hbound : ∃ B : ℝ, ∀ k : ℝ, 0 < k → P k → k ≤ B)
    (htransfer : ∀ a b : ℝ, 0 < a → a ≤ b →
      (∀ k ∈ Icc a b, k ∉ K) → (P a ↔ P b)) :
    ∃ c : ℝ, IsLeast K c ∧ 0 < c ∧
      (∀ k : ℝ, 0 < k → k < c → P k) ∧ ¬P c ∧
      IsGreatest (initialIntervalEndpoints P) c ∧
      initialIntervalEndpoints P = Ioc 0 c ∧ sSup (initialIntervalEndpoints P) = c := by
  have hne := first_boundary_nonempty hsmall hbound htransfer
  obtain ⟨c,hc⟩ := hfinite.isCompact.exists_isLeast hne
  have hcpos := hpositive c hc.1
  have hbelow : ∀ k : ℝ, 0 < k → k < c → P k := by
    intro k hk hkc
    obtain ⟨ε,hε,hs⟩ := hsmall
    let a := min ε k / 2
    have ha : 0 < a := div_pos (lt_min hε hk) (by norm_num)
    have hae : a < ε := by dsimp [a]; linarith [min_le_left ε k]
    have hak : a ≤ k := by dsimp [a]; linarith [min_le_right ε k]
    have hno : ∀ t ∈ Icc a k, t ∉ K := by
      intro t ht htk
      have hct := hc.2 htk
      linarith [ht.2]
    exact (htransfer a k ha hak hno).mp (hs a ha hae)
  have hnot := hboundary c hc.1
  have hgreat : IsGreatest (initialIntervalEndpoints P) c := by
    refine ⟨⟨hcpos,hbelow⟩,?_⟩
    intro b hb
    by_contra hcb
    have hlt : c < b := lt_of_not_ge hcb
    exact hnot (hb.2 c hcpos hlt)
  have hset : initialIntervalEndpoints P = Ioc 0 c := by
    ext b
    constructor
    · intro hb
      exact ⟨hb.1,hgreat.2 hb⟩
    · rintro ⟨hb,hbc⟩
      exact ⟨hb,fun k hk hkb => hbelow k hk (hkb.trans_le hbc)⟩
  exact ⟨c,hc,hcpos,hbelow,hnot,hgreat,hset,hgreat.csSup_eq⟩

end C2.GeneralCompletion
