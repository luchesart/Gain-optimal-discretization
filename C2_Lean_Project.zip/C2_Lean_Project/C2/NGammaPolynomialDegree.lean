import C2.NGammaPolynomial
import Mathlib.Algebra.Polynomial.Degree.SmallDegree
import Mathlib.Algebra.Polynomial.BigOperators

noncomputable section
open scoped BigOperators
open Polynomial
namespace C2.NGamma.PolynomialModel

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem factor_linear (r x : ℝ) :
    factor r x = C (1 + (r : ℂ) * (1 + x) / 2) * X +
      C ((r : ℂ) * (1 - x) / 2 - 1) := by
  apply Polynomial.funext
  intro z
  simp [factor_eval, q_eval]
  ring

theorem factor_natDegree {r x : ℝ} (hr : 0 < r) (hx : 0 ≤ x) :
    (factor r x).natDegree = 1 := by
  rw [factor_linear]
  apply natDegree_linear
  exact_mod_cast (ne_of_gt (by positivity : 0 < 1 + r * (1 + x) / 2))

theorem factor_ne_zero {r x : ℝ} (hr : 0 < r) (hx : 0 ≤ x) :
    factor r x ≠ 0 := by
  intro h
  have hd := factor_natDegree hr hx
  simp [h] at hd

theorem q_natDegree {x : ℝ} (hx : 0 ≤ x) : (q x).natDegree = 1 := by
  apply natDegree_linear
  exact_mod_cast (ne_of_gt (by positivity : 0 < (1 + x) / 2))

theorem characteristic_natDegree {r x : ι → ℝ} {d : ℕ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) (hd : 1 ≤ d) (b : ℝ) :
    (characteristic r x d b).natDegree = Fintype.card ι + d := by
  have hn : (∏ i, factor (r i) (x i)) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (fun i _ => factor_ne_zero (hr i) (hx i))
  have hD : (∏ i, factor (r i) (x i)).natDegree = Fintype.card ι := by
    rw [natDegree_prod _ _ (fun i _ => factor_ne_zero (hr i) (hx i))]
    simp only [factor_natDegree (hr _) (hx _), Finset.sum_const, Finset.card_univ, smul_eq_mul,
      mul_one]
  have hQ : (∏ i, q (x i)).natDegree ≤ Fintype.card ι := by
    calc
      _ ≤ ∑ i, (q (x i)).natDegree := natDegree_prod_le _ _
      _ = _ := by simp [q_natDegree (hx _)]
  have hterm : (C (b : ℂ) * ∏ i, q (x i)).natDegree ≤ Fintype.card ι := by
    exact (natDegree_C_mul_le _ _).trans hQ
  unfold characteristic
  rw [natDegree_add_eq_left_of_natDegree_lt]
  · rw [natDegree_X_pow_mul d hn, hD]
  · rw [natDegree_X_pow_mul d hn, hD]
    omega

theorem characteristic_ne_zero {r x : ι → ℝ} {d : ℕ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) (hd : 1 ≤ d) (b : ℝ) :
    characteristic r x d b ≠ 0 := by
  intro h
  have hh := characteristic_natDegree hr hx hd b
  simp only [h, natDegree_zero] at hh
  omega

end C2.NGamma.PolynomialModel
