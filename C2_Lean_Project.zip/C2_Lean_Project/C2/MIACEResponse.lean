import C2.MIACERecurrence
import C2.MIACETail
import C2.MIACEReserve

/-! Exact absolute areas and their relation to the reserve optimization. -/

noncomputable section
open scoped BigOperators Topology
open Filter

namespace C2.MIACE

theorem monotone_response_areas {γ a T η : ℝ} {e v : ℕ → ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (ha : 0 < a) (hT : 0 ≤ T)
    (h : ErrorRecurrence (1 - a * γ) (a * (1 - γ)) e)
    (hv : ∀ n, v n = -e (n + 1))
    (hbound : a ≤ 1 / (1 + Real.sqrt (1 - γ)) ^ 2) :
    area T e = T / a ∧ area T v = T * (1 / a - 1) ∧
      cost η (area T e) (area T v) =
        T * Real.sqrt ((1 / a) ^ 2 + η * (1 / a - 1) ^ 2) := by
  have he := (error_nonnegative_iff_monotone_bound hγ0 hγ1 ha h).mpr hbound
  have hs := nonnegative_error_summable hγ0 hγ1 ha h he
  have hsum := tracking_error_sum ha h hs
  have hAe : area T e = T / a := by
    dsimp [area]
    simp_rw [abs_of_nonneg (he _)]
    rw [hsum]
    ring
  have hsabs : Summable (fun n => |e n|) := by
    simpa only [abs_of_nonneg (he _)] using hs
  have harea := pure_delay_area_identity T 1 e v hsabs
    (fun n hn => by
      have hn0 : n = 0 := by omega
      simpa only [hn0] using h.1) hv
  have hAu : area T v = T * (1 / a - 1) := by
    rw [hAe] at harea
    norm_num at harea
    calc
      area T v = T / a - T := by linarith
      _ = T * (1 / a - 1) := by ring
  refine ⟨hAe, hAu, ?_⟩
  rw [hAe, hAu, div_eq_mul_one_div, cost_mul hT]
  rfl

def nominalCost (η T a : ℝ) : ℝ := cost η (T / a) (T * (1 / a - 1))

/-- The MIACE objective has the opposite order to gain throughout the
monotone region; this includes equality and therefore uniqueness. -/
theorem nominalCost_le_iff {η T a b : ℝ} (hη : 0 < η) (hT : 0 < T)
    (ha : 0 < a) (ha1 : a ≤ 1) (hb : 0 < b) (hb1 : b ≤ 1) :
    nominalCost η T a ≤ nominalCost η T b ↔ b ≤ a := by
  have hAe : T ≤ T / a := by
    apply (le_div_iff₀ ha).mpr
    nlinarith [mul_le_mul_of_nonneg_left ha1 hT.le]
  have hBe : T ≤ T / b := by
    apply (le_div_iff₀ hb).mpr
    nlinarith [mul_le_mul_of_nonneg_left hb1 hT.le]
  have hae : T * (1 / a - 1) = T / a - T := by ring
  have hbe : T * (1 / b - 1) = T / b - T := by ring
  unfold nominalCost
  rw [hae, hbe, cost_le_cost_iff_on_delay_line hη hT.le hAe hBe]
  exact div_le_div_iff_of_pos_left hT ha hb

theorem nominalCost_unique_reserve_minimum {η T R : ℝ}
    (hη : 0 < η) (hT : 0 < T) (hR : 1 < R) :
    ReserveFeasible R (reserveOptimizerX R) (reserveOptimizerGain R) ∧
    (∀ x a, ReserveFeasible R x a →
      nominalCost η T (reserveOptimizerGain R) ≤ nominalCost η T a) ∧
    (∀ x a, ReserveFeasible R x a →
      nominalCost η T a ≤ nominalCost η T (reserveOptimizerGain R) →
      x = reserveOptimizerX R ∧ a = reserveOptimizerGain R) := by
  obtain ⟨hf, hb, hu⟩ := reserve_three_regime_optimizer hR
  have hag := hf.2.2.1
  have hag1 := feasible_gain_le_one hf
  refine ⟨hf, ?_, ?_⟩
  · intro x a h
    exact (nominalCost_le_iff hη hT hag hag1 h.2.2.1 (feasible_gain_le_one h)).mpr (hb x a h)
  · intro x a h hcost
    have hga := (nominalCost_le_iff hη hT h.2.2.1 (feasible_gain_le_one h) hag hag1).mp hcost
    have heq : a = reserveOptimizerGain R := le_antisymm (hb x a h) hga
    exact ⟨hu x (by simpa only [← heq] using h), heq⟩

theorem reserve_transition_two : reserveX 2 = 0 := by
  norm_num [reserveX]

theorem reserve_transition_nine : reserveX 9 = 1 / 2 := by
  norm_num [reserveX]

theorem reserve_gamma_large {R : ℝ} (hR : 9 ≤ R) :
    1 - reserveOptimizerX R ^ 2 = 3 / 4 ∧ reserveOptimizerGain R = 4 / R := by
  have hR2 : ¬ R ≤ 2 := by linarith
  have hR9 : ¬ R < 9 := not_lt.mpr hR
  norm_num [reserveOptimizerX, reserveOptimizerGain, hR2, hR9]

end C2.MIACE
