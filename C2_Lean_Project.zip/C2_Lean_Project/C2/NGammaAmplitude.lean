import C2.NGammaPhaseEndpoint

noncomputable section
open scoped BigOperators Topology
open Filter
namespace C2.NGamma.Cayley

theorem amplitudeFactor_sq (r x t : ℝ) :
    (amplitudeFactor r x t)^2 = r^2 * (1+((x+2/r)*t)^2)/(1+(x*t)^2) := by
  simp only [amplitudeFactor, div_pow, mul_pow]
  rw [Real.sq_sqrt (by positivity), Real.sq_sqrt (by positivity)]

theorem amplitudeFactor_continuous (r x : ℝ) : Continuous (amplitudeFactor r x) := by
  unfold amplitudeFactor
  exact (continuous_const.mul (Real.continuous_sqrt.comp
    (continuous_const.add ((continuous_const.mul continuous_id).pow 2)))).div
    (Real.continuous_sqrt.comp (continuous_const.add ((continuous_const.mul continuous_id).pow 2)))
    (fun t => ne_of_gt (Real.sqrt_pos.2 (by positivity)))

theorem amplitudeFactor_strictMonoOn {r x : ℝ} (hr : 0 < r) (hx : 0 ≤ x) :
    StrictMonoOn (amplitudeFactor r x) (Set.Ici 0) := by
  intro u hu v hv huv
  have ha : x < x+2/r := by linarith [div_pos (by norm_num : (0:ℝ)<2) hr]
  have ha0 : 0 < x+2/r := lt_of_le_of_lt hx ha
  have hax : 0 < (x+2/r)^2-x^2 := by nlinarith
  have huv2 : 0 < v^2-u^2 := by have := hu; change 0 ≤ u at this; nlinarith
  have hprod := mul_pos hax huv2
  have hs : (amplitudeFactor r x u)^2 < (amplitudeFactor r x v)^2 := by
    rw [amplitudeFactor_sq, amplitudeFactor_sq]
    apply (div_lt_div_iff₀ (by positivity : 0 < 1+(x*u)^2)
      (by positivity : 0 < 1+(x*v)^2)).2
    nlinarith [mul_pos (sq_pos_of_pos hr) hprod]
  nlinarith [amplitudeFactor_pos hr x u, amplitudeFactor_pos hr x v]

theorem amplitude_continuous {n : ℕ} (r x : Fin n → ℝ) : Continuous (amplitude r x) := by
  exact continuous_finset_prod _ (fun i _ => amplitudeFactor_continuous (r i) (x i))

theorem amplitude_strictMonoOn {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) :
    StrictMonoOn (amplitude r x) (Set.Ici 0) := by
  intro u hu v hv huv
  unfold amplitude
  apply Finset.prod_lt_prod
  · intro i _
    exact amplitudeFactor_pos (hr i) (x i) u
  · intro i _
    exact le_of_lt (amplitudeFactor_strictMonoOn (hr i) (hx i) hu hv huv)
  · exact ⟨⟨0, hn⟩, Finset.mem_univ _, amplitudeFactor_strictMonoOn
      (hr _) (hx _) hu hv huv⟩

theorem amplitude_zero {n : ℕ} (r x : Fin n → ℝ) : amplitude r x 0 = ∏ i, r i := by
  simp [amplitude, amplitudeFactor]

theorem amplitudeFactor_rescale {r x t : ℝ} (ht : 0 < t) :
    amplitudeFactor r x t =
      r * Real.sqrt (t⁻¹^2+(x+2/r)^2) / Real.sqrt (t⁻¹^2+x^2) := by
  have he (a : ℝ) : Real.sqrt (1+(a*t)^2) = t * Real.sqrt (t⁻¹^2+a^2) := by
    have hid : 1+(a*t)^2 = t^2*(t⁻¹^2+a^2) := by field_simp; ring
    rw [hid, Real.sqrt_mul (sq_nonneg t), Real.sqrt_sq (le_of_lt ht)]
  unfold amplitudeFactor
  rw [he, he]
  field_simp

theorem amplitudeFactor_tendsto_atTop {r x : ℝ} (hr : 0 < r) (hx : 0 < x) :
    Tendsto (amplitudeFactor r x) atTop (𝓝 (r+2/x)) := by
  have ht := (tendsto_inv_atTop_zero : Tendsto (fun t : ℝ => t⁻¹) atTop (𝓝 0)).pow 2
  have h := ((tendsto_const_nhds : Tendsto (fun _ : ℝ => r) atTop (𝓝 r)).mul (Real.continuous_sqrt.continuousAt.tendsto.comp
    (ht.add_const ((x+2/r)^2)))).div
    (Real.continuous_sqrt.continuousAt.tendsto.comp (ht.add_const (x^2)))
    (show Real.sqrt (0^2+x^2) ≠ 0 by simpa [Real.sqrt_sq (le_of_lt hx)] using ne_of_gt hx)
  have hlim : r * Real.sqrt ((0:ℝ)^2+(x+2/r)^2) / Real.sqrt ((0:ℝ)^2+x^2) = r+2/x := by
    rw [zero_pow (by norm_num), zero_add, zero_add, Real.sqrt_sq (by positivity), Real.sqrt_sq (le_of_lt hx)]
    field_simp
    ring
  rw [hlim] at h
  apply h.congr'
  filter_upwards [eventually_gt_atTop (0:ℝ)] with t ht
  exact (amplitudeFactor_rescale ht).symm

theorem amplitude_tendsto_atTop {n : ℕ} {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) :
    Tendsto (amplitude r x) atTop (𝓝 (∏ i, (r i+2/x i))) := by
  exact tendsto_finset_prod _ (fun i _ => amplitudeFactor_tendsto_atTop (hr i) (hx i))

theorem amplitudeFactor_zero_lower {r t : ℝ} (hr : 0 < r) (ht : 0 ≤ t) :
    2*t ≤ amplitudeFactor r 0 t := by
  have hs := amplitudeFactor_sq r 0 t
  simp only [zero_add, zero_mul, zero_pow (by norm_num : (2:ℕ) ≠ 0), add_zero, div_one] at hs
  have he : r^2 * (1+(2/r*t)^2) = r^2+4*t^2 := by field_simp; ring
  rw [he] at hs
  nlinarith [amplitudeFactor_pos hr 0 t]

theorem amplitude_tendsto_atTop_of_zero {n : ℕ} {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) {j : Fin n} (hj : x j = 0) :
    Tendsto (amplitude r x) atTop atTop := by
  classical
  let c : ℝ := ∏ i ∈ Finset.univ.erase j, r i
  have hc : 0 < c := Finset.prod_pos (fun i _ => hr i)
  have hlow : ∀ t ≥ 0, c*(2*t) ≤ amplitude r x t := by
    intro t ht
    have hother : c ≤ ∏ i ∈ Finset.univ.erase j, amplitudeFactor (r i) (x i) t := by
      apply Finset.prod_le_prod
      · intro i _; exact (hr i).le
      · intro i _
        have h := (amplitudeFactor_strictMonoOn (hr i) (hx i)).monotoneOn
          (show (0:ℝ) ∈ Set.Ici 0 by simp) ht ht
        simpa [amplitudeFactor] using h
    have hzero : 2*t ≤ amplitudeFactor (r j) (x j) t := by
      rw [hj]
      exact amplitudeFactor_zero_lower (hr j) ht
    unfold amplitude
    rw [← Finset.mul_prod_erase _ _ (Finset.mem_univ j)]
    calc
      c*(2*t) = (2*t)*c := by ring
      _ ≤ amplitudeFactor (r j) (x j) t * ∏ i ∈ Finset.univ.erase j, amplitudeFactor (r i) (x i) t :=
        mul_le_mul hzero hother hc.le (amplitudeFactor_pos (hr j) (x j) t).le
  apply tendsto_atTop_mono' atTop ?_ ((tendsto_id.const_mul_atTop (by norm_num : (0:ℝ)<2)).const_mul_atTop hc)
  filter_upwards [eventually_ge_atTop (0:ℝ)] with t ht
  exact hlow t ht

theorem existsUnique_amplitude_crossing_of_upper {n : ℕ} (hn : 0 < n)
    {r x : Fin n → ℝ} (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i)
    {b : ℝ} (hb : (∏ i, r i) < b) (hupper : ∃ v, 0 < v ∧ b < amplitude r x v) :
    ∃! t : ℝ, 0 < t ∧ amplitude r x t = b := by
  obtain ⟨v, hv, hbv⟩ := hupper
  have hb0 : amplitude r x 0 < b := by simpa only [amplitude_zero] using hb
  obtain ⟨t, ht, he⟩ := intermediate_value_Icc hv.le
    (amplitude_continuous r x).continuousOn ⟨hb0.le,hbv.le⟩
  have htpos : 0 < t := by
    by_contra h
    have ht0 : t=0 := le_antisymm (le_of_not_gt h) ht.1
    rw [ht0] at he
    linarith
  refine ⟨t, ⟨htpos,he⟩, ?_⟩
  intro u hu
  exact (amplitude_strictMonoOn hn hr hx).injOn hu.1.le htpos.le (hu.2.trans he.symm)

theorem existsUnique_amplitude_crossing {n : ℕ} (hn : 0 < n)
    {r x : Fin n → ℝ} (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i)
    {b : ℝ} (hb : (∏ i, r i) < b) (hbinf : b < ∏ i, (r i+2/x i)) :
    ∃! t : ℝ, 0 < t ∧ amplitude r x t = b := by
  apply existsUnique_amplitude_crossing_of_upper hn hr (fun i => (hx i).le) hb
  have he := (amplitude_tendsto_atTop hr hx) (Ioi_mem_nhds hbinf)
  obtain ⟨v,hv,hvb⟩ := ((eventually_gt_atTop (0:ℝ)).and he).exists
  exact ⟨v,hv,hvb⟩

theorem existsUnique_amplitude_crossing_of_zero {n : ℕ} (hn : 0 < n)
    {r x : Fin n → ℝ} (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i)
    {j : Fin n} (hj : x j = 0) {b : ℝ} (hb : (∏ i, r i) < b) :
    ∃! t : ℝ, 0 < t ∧ amplitude r x t = b := by
  apply existsUnique_amplitude_crossing_of_upper hn hr hx hb
  have he := (amplitude_tendsto_atTop_of_zero hr hx hj) (eventually_gt_atTop b)
  obtain ⟨v,hv,hvb⟩ := ((eventually_gt_atTop (0:ℝ)).and he).exists
  exact ⟨v,hv,hvb⟩

end C2.NGamma.Cayley
