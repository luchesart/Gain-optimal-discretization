import C2.CADDriverValues
import C2.CADNativeProjection

/-! Exact product and specialization bridges for the native CAD lifting stage. -/
namespace C2.CADDriver
open Polynomial Set C2.CADEffective C2.CADIsolation

theorem realEval_product (ps : List Dense.Poly) (x : ℝ) :
    realEval (Dense.denote (product ps)) x =
      (ps.map (fun p => realEval (Dense.denote p) x)).prod := by
  rw [denote_product]
  simp only [realEval,Polynomial.eval₂_list_prod,List.map_map,Function.comp_def]

theorem product_root_of_factor (ps : List Dense.Poly) (p : Dense.Poly)
    (hp : p ∈ ps) (x : ℝ) (hz : realEval (Dense.denote p) x = 0) :
    realEval (Dense.denote (product ps)) x = 0 := by
  rw [realEval_product]
  apply List.prod_eq_zero
  exact List.mem_map.mpr ⟨p,hp,hz⟩

theorem product_roots_finite (ps : List Dense.Poly)
    (hp : Dense.denote (product ps) ≠ 0) :
    Set.Finite {x : ℝ | realEval (Dense.denote (product ps)) x = 0} := by
  have hp' : (Dense.denote (product ps)).map (algebraMap ℚ ℝ) ≠ 0 :=
    Polynomial.map_ne_zero (f:=algebraMap ℚ ℝ) hp
  simpa only [Polynomial.IsRoot,Polynomial.eval_map,realEval] using
    Polynomial.finite_setOf_isRoot hp'

theorem realEval_atGain_value (p : Bivariate.Poly) (gain : ℚ) (x : ℝ) :
    realEval (Dense.denote (Bivariate.atGain p gain)) x =
      CADProjection.value (Bivariate.denote p) (gain:ℝ) x := by
  simp only [realEval,Bivariate.denote_atGain,Polynomial.eval₂_map,
    CADProjection.value,CADProjection.specialize,Polynomial.eval_map]
  congr 1
  apply RingHom.ext
  intro q
  exact (Polynomial.eval₂_at_apply (p:=q) (algebraMap ℚ ℝ) gain).symm

@[simp] theorem rational_atGain_positive (p : Bivariate.Poly) (gain gamma : ℚ) :
    0 < Bivariate.eval p gamma gain ↔
      0 < CADProjection.value (Bivariate.denote p) (gain:ℝ) (gamma:ℝ) := by
  rw [← realEval_atGain_value, realEval_rat_pos]
  simp only [Bivariate.eval,Dense.eval_denote]

end C2.CADDriver
