import C2.CADIsolationBounds

/-! Rational cell tests for root isolation. Analytic meaning is separated from
any dense-polynomial executable representation. -/
namespace C2.CADIsolation
open Polynomial Set

noncomputable def slopeBound (p : ℚ[X]) (a b : ℚ) : ℚ :=
  1 + coeffBound p.derivative (intervalRadius a b) +
    coeffBound p.derivative.derivative (intervalRadius a b)

def midpoint (l u : ℚ) : ℚ := (l+u)/2

noncomputable def zeroFreeTest (p : ℚ[X]) (a b l u : ℚ) : Prop :=
  slopeBound p a b * (u-l) < |p.eval (midpoint l u)|

noncomputable def monotoneTest (p : ℚ[X]) (a b l u : ℚ) : Prop :=
  slopeBound p a b * (u-l) < |p.derivative.eval (midpoint l u)|

noncomputable def certifiedCell (p : ℚ[X]) (a b l u : ℚ) : Prop :=
  zeroFreeTest p a b l u ∨ monotoneTest p a b l u

theorem slopeBound_pos (p : ℚ[X]) (a b : ℚ) : 0 < slopeBound p a b := by
  have h₁ := coeffBound_nonneg p.derivative (intervalRadius_pos a b).le
  have h₂ := coeffBound_nonneg p.derivative.derivative (intervalRadius_pos a b).le
  dsimp [slopeBound]
  linarith

theorem derivative_bound_le (p : ℚ[X]) (a b : ℚ) :
    coeffBound p.derivative (intervalRadius a b) ≤ slopeBound p a b := by
  have h := coeffBound_nonneg p.derivative.derivative (intervalRadius_pos a b).le
  dsimp [slopeBound]
  linarith

theorem second_derivative_bound_le (p : ℚ[X]) (a b : ℚ) :
    coeffBound p.derivative.derivative (intervalRadius a b) ≤ slopeBound p a b := by
  have h := coeffBound_nonneg p.derivative (intervalRadius_pos a b).le
  dsimp [slopeBound]
  linarith

theorem midpoint_mem {l u : ℚ} (hlu : l ≤ u) :
    (midpoint l u : ℝ) ∈ Icc (l:ℝ) (u:ℝ) := by
  have h : (l:ℝ) ≤ (u:ℝ) := by exact_mod_cast hlu
  dsimp [midpoint]
  push_cast
  constructor <;> linarith

theorem midpoint_distance {l u : ℚ} (hlu : l ≤ u) {x : ℝ}
    (hx : x ∈ Icc (l:ℝ) (u:ℝ)) :
    |x-(midpoint l u:ℝ)| ≤ ((u-l:ℚ):ℝ) := by
  have h := midpoint_mem hlu
  rw [abs_le]
  push_cast
  constructor <;> linarith [h.1,h.2,hx.1,hx.2]

theorem variation_in_cell (p : ℚ[X]) {a b l u B : ℚ}
    (hal : a ≤ l) (hlu : l ≤ u) (hub : u ≤ b)
    (hB : coeffBound p.derivative (intervalRadius a b) ≤ B)
    (hB0 : 0 ≤ B) {x : ℝ} (hx : x ∈ Icc (l:ℝ) (u:ℝ)) :
    |realEval p x - realEval p (midpoint l u:ℝ)| ≤ (B:ℝ)*((u-l:ℚ):ℝ) := by
  have hal' : (a:ℝ) ≤ (l:ℝ) := by exact_mod_cast hal
  have hub' : (u:ℝ) ≤ (b:ℝ) := by exact_mod_cast hub
  have hm := midpoint_mem hlu
  have hvar := realEval_sub_le p a b
    (show (midpoint l u:ℝ) ∈ Icc (a:ℝ) (b:ℝ) from ⟨hal'.trans hm.1,hm.2.trans hub'⟩)
    (show x ∈ Icc (a:ℝ) (b:ℝ) from ⟨hal'.trans hx.1,hx.2.trans hub'⟩)
  have hB' : (coeffBound p.derivative (intervalRadius a b):ℝ) ≤ (B:ℝ) := by exact_mod_cast hB
  have hB0' : (0:ℝ) ≤ (B:ℝ) := by exact_mod_cast hB0
  exact hvar.trans ((mul_le_mul_of_nonneg_right hB' (abs_nonneg _)).trans
    (mul_le_mul_of_nonneg_left (midpoint_distance hlu hx) hB0'))

/-- The exact rational zero-free test excludes every real root in the cell. -/
theorem zeroFreeTest_sound (p : ℚ[X]) {a b l u : ℚ}
    (hal : a ≤ l) (hlu : l ≤ u) (hub : u ≤ b)
    (ht : zeroFreeTest p a b l u) :
    ∀ x ∈ Icc (l:ℝ) (u:ℝ), realEval p x ≠ 0 := by
  intro x hx hz
  have hv := variation_in_cell p hal hlu hub (derivative_bound_le p a b)
    (slopeBound_pos p a b).le hx
  have ht' : (slopeBound p a b:ℝ)*((u-l:ℚ):ℝ) < |realEval p (midpoint l u:ℝ)| := by
    rw [realEval_rat]
    exact_mod_cast ht
  rw [hz,zero_sub,abs_neg] at hv
  exact (not_lt_of_ge hv) ht'

/-- The derivative test supplies its sign on the entire cell. -/
theorem monotoneTest_derivative_sign (p : ℚ[X]) {a b l u : ℚ}
    (hal : a ≤ l) (hlu : l ≤ u) (hub : u ≤ b)
    (ht : monotoneTest p a b l u) :
    (∀ x ∈ Icc (l:ℝ) (u:ℝ), 0 < realEval p.derivative x) ∨
      (∀ x ∈ Icc (l:ℝ) (u:ℝ), realEval p.derivative x < 0) := by
  have ht' : (slopeBound p a b:ℝ)*((u-l:ℚ):ℝ) <
      |realEval p.derivative (midpoint l u:ℝ)| := by
    rw [realEval_rat]
    exact_mod_cast ht
  have hwidth : (0:ℝ) ≤ ((u-l:ℚ):ℝ) := by exact_mod_cast sub_nonneg.mpr hlu
  have hB : (0:ℝ) ≤ (slopeBound p a b:ℝ) := by exact_mod_cast (slopeBound_pos p a b).le
  have hc : realEval p.derivative (midpoint l u:ℝ) ≠ 0 := by
    intro h
    rw [h,abs_zero] at ht'
    exact (not_lt_of_ge (mul_nonneg hB hwidth)) ht'
  rcases lt_or_gt_of_ne hc with hc | hc
  · right
    intro x hx
    have hv := variation_in_cell p.derivative hal hlu hub
      (second_derivative_bound_le p a b) (slopeBound_pos p a b).le hx
    have hv' := (abs_le.mp hv).2
    rw [abs_of_neg hc] at ht'
    linarith
  · left
    intro x hx
    have hv := variation_in_cell p.derivative hal hlu hub
      (second_derivative_bound_le p a b) (slopeBound_pos p a b).le hx
    have hv' := (abs_le.mp hv).1
    rw [abs_of_pos hc] at ht'
    linarith

/-- Accepted derivative cells are genuinely strictly monotone. -/
theorem monotoneTest_sound (p : ℚ[X]) {a b l u : ℚ}
    (hal : a ≤ l) (hlu : l ≤ u) (hub : u ≤ b)
    (ht : monotoneTest p a b l u) :
    StrictMonoOn (realEval p) (Icc (l:ℝ) (u:ℝ)) ∨
      StrictAntiOn (realEval p) (Icc (l:ℝ) (u:ℝ)) := by
  rcases monotoneTest_derivative_sign p hal hlu hub ht with hp | hn
  · left
    apply strictMonoOn_of_deriv_pos (convex_Icc _ _) (realEval_continuous p).continuousOn
    intro x hx
    rw [(realEval_hasDerivAt p x).deriv]
    exact hp x (interior_subset hx)
  · right
    apply strictAntiOn_of_deriv_neg (convex_Icc _ _) (realEval_continuous p).continuousOn
    intro x hx
    rw [(realEval_hasDerivAt p x).deriv]
    exact hn x (interior_subset hx)

/-- Every accepted cell contains at most one distinct real root. -/
theorem certifiedCell_at_most_one (p : ℚ[X]) {a b l u : ℚ}
    (hal : a ≤ l) (hlu : l ≤ u) (hub : u ≤ b)
    (ht : certifiedCell p a b l u) {x y : ℝ}
    (hx : x ∈ Icc (l:ℝ) (u:ℝ)) (hy : y ∈ Icc (l:ℝ) (u:ℝ))
    (hpx : realEval p x = 0) (hpy : realEval p y = 0) : x = y := by
  rcases ht with hz | hm
  · exact (zeroFreeTest_sound p hal hlu hub hz x hx hpx).elim
  · rcases monotoneTest_sound p hal hlu hub hm with h | h
    · exact h.injOn hx hy (hpx.trans hpy.symm)
    · exact h.injOn hx hy (hpx.trans hpy.symm)

end C2.CADIsolation
