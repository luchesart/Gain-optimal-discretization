import C2.NGammaEnvelope
import C2.NGammaAllocation
import Mathlib.Analysis.Calculus.MeanValue

/-! Dual upper supports for the fixed-frequency optimum.  The clipped scalar
maximizer is allowed to change active sets. -/

noncomputable section
open scoped BigOperators Topology
open Filter Set

namespace C2.NGamma.Global

/-- Switching between branches with a common value and derivative preserves
the derivative. No regularity assumption on the switching set is needed. -/
theorem hasDerivAt_of_eventually_eq_or {f g h : ℝ → ℝ} {a d : ℝ}
    (hg : HasDerivAt g d a) (hh : HasDerivAt h d a)
    (hfg : f a = g a) (hfh : f a = h a)
    (hsel : ∀ᶠ z in 𝓝 a, f z = g z ∨ f z = h z) :
    HasDerivAt f d a := by
  apply hasDerivAt_iff_tendsto_slope.mpr
  intro s hs
  change ∀ᶠ z in 𝓝[≠] a, slope f a z ∈ s
  have hg' := (hasDerivAt_iff_tendsto_slope.mp hg) hs
  have hh' := (hasDerivAt_iff_tendsto_slope.mp hh) hs
  change ∀ᶠ z in 𝓝[≠] a, slope g a z ∈ s at hg'
  change ∀ᶠ z in 𝓝[≠] a, slope h a z ∈ s at hh'
  filter_upwards [hg', hh', hsel.filter_mono nhdsWithin_le_nhds] with z hgz hhz hz
  rcases hz with hz | hz
  · simpa only [slope_def_field, hfg, hz] using hgz
  · simpa only [slope_def_field, hfh, hz] using hhz

def dualValue {n : ℕ} (r : Fin n → ℝ) (w lam : ℝ) : ℝ :=
  2*lam*Real.arctan w + ∑ j,
    allocationLagrangian (r j) w lam (frequencyAllocation (r j) w lam)

theorem clipped_KKT {n : ℕ} (r : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {w lam : ℝ} (hw : 0 < w) :
    KKT r (fun j => frequencyAllocation (r j) w lam) w lam := by
  intro j
  have hk := frequencyAllocation_kkt (hr j) hw (l := lam)
  refine ⟨?_, ?_, ?_⟩
  · intro hz
    exact hk.2 (by dsimp at hz; rw [hz]; norm_num)
  · intro ho
    exact hk.1 (by dsimp at ho; rw [ho]; norm_num)
  · intro hp hl
    exact le_antisymm (hk.1 hp) (hk.2 hl)

theorem dualValue_eq_gain {n : ℕ} (r : Fin n → ℝ) {w lam : ℝ}
    (heq : frequencyAllocatedPhase r w lam = 2*Real.arctan w) :
    dualValue r w lam = ∑ j, allocationLogGain (r j) (frequencyAllocation (r j) w lam) w := by
  unfold dualValue allocationLagrangian
  rw [Finset.sum_sub_distrib, ← Finset.mul_sum]
  change 2*lam*Real.arctan w +
    ((∑ j, allocationLogGain (r j) (frequencyAllocation (r j) w lam) w) -
      lam*frequencyAllocatedPhase r w lam) = _
  rw [heq]
  ring

theorem gain_le_dualValue {n : ℕ} (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    (hx : ∀ j, x j ∈ Icc (0:ℝ) 1) {w lam : ℝ} (hw : 0 < w)
    (hphase : (∑ j, allocationPhase (r j) (x j) w) = 2*Real.arctan w) :
    (∑ j, allocationLogGain (r j) (x j) w) ≤ dualValue r w lam := by
  have hs := Finset.sum_le_sum (s := Finset.univ) fun j _ =>
    frequencyAllocation_lagrangian_max (hr j) hw (l := lam) (hx j)
  simp only [allocationLagrangian, Finset.sum_sub_distrib, ← Finset.mul_sum] at hs
  unfold dualValue allocationLagrangian
  rw [Finset.sum_sub_distrib, ← Finset.mul_sum]
  rw [hphase] at hs
  linarith

theorem clipped_envelope_neg {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) {w lam : ℝ} (hw : 0 < w)
    (heq : frequencyAllocatedPhase r w lam = 2*Real.arctan w)
    (hstrict : (∑ j, allocationPhase (r j) 1 w) < 2*Real.arctan w) :
    envelope r (fun j => frequencyAllocation (r j) w lam) w lam < 0 := by
  exact envelope_neg_of_KKT hn r _ hr (fun j => frequencyAllocation_mem _ _ _)
    hw (clipped_KKT r hr hw) heq hstrict

/-- Continuous functions with differentiable upper supports of nonpositive
slope are antitone. This form avoids differentiating a selected optimizer. -/
theorem antitoneOn_of_upper_support {f : ℝ → ℝ} {a b : ℝ}
    (hf : ContinuousOn f (Icc a b))
    (hs : ∀ x ∈ Icc a b, ∃ g : ℝ → ℝ, ∃ d : ℝ,
      HasDerivAt g d x ∧ d ≤ 0 ∧ g x = f x ∧ ∀ z ∈ Icc a b, f z ≤ g z) :
    AntitoneOn f (Icc a b) := by
  intro x hx y hy hxy
  have hsub : Icc x y ⊆ Icc a b := fun z hz =>
    ⟨le_trans hx.1 hz.1,le_trans hz.2 hy.2⟩
  apply image_le_of_liminf_slope_right_le_deriv_boundary (hf.mono hsub)
    (B := fun _ => f x) (B' := fun _ => 0) (le_refl _) continuousOn_const
    (fun z _ => (hasDerivAt_const z (f x)).hasDerivWithinAt) ?_ ⟨hxy,le_refl _⟩
  intro z hz q hq
  obtain ⟨g,d,hd,hd0,hgf,hmajor⟩ := hs z (hsub (Ico_subset_Icc_self hz))
  have he : ∀ᶠ t in 𝓝[>] z, slope g z t < q :=
    ((hasDerivAt_iff_tendsto_slope.mp hd).mono_left (nhdsGT_le_nhdsNE z))
      (Iio_mem_nhds (lt_of_le_of_lt hd0 hq))
  have hi : ∀ᶠ t in 𝓝[>] z, t ∈ Icc x y := Icc_mem_nhdsGT_of_mem hz
  have hp : ∀ᶠ t in 𝓝[>] z, z < t := self_mem_nhdsWithin
  apply Filter.Eventually.frequently
  filter_upwards [he,hi,hp] with t het hit hpt
  have hle : slope f z t ≤ slope g z t := by
    rw [slope_def_field,slope_def_field,hgf]
    exact div_le_div_of_nonneg_right (sub_le_sub_right (hmajor t (hsub hit)) _) (sub_nonneg.mpr hpt.le)
  exact lt_of_le_of_lt hle het

/-- Strictly negative upper-support slopes imply strict outer monotonicity,
even when no derivative of the optimum itself has been selected. -/
theorem strictAntiOn_of_upper_support {f : ℝ → ℝ} {a b : ℝ}
    (hf : ContinuousOn f (Icc a b))
    (hs : ∀ x ∈ Icc a b, ∃ g : ℝ → ℝ, ∃ d : ℝ,
      HasDerivAt g d x ∧ d < 0 ∧ g x = f x ∧ ∀ z ∈ Icc a b, f z ≤ g z) :
    StrictAntiOn f (Icc a b) := by
  have hanti := antitoneOn_of_upper_support hf (fun x hx => by
    obtain ⟨g,d,hd,hneg,heq,hbound⟩ := hs x hx
    exact ⟨g,d,hd,hneg.le,heq,hbound⟩)
  intro x hx y hy hxy
  obtain ⟨g,d,hd,hneg,heq,hbound⟩ := hs x hx
  have he : ∀ᶠ t in 𝓝[>] x, slope g x t < 0 :=
    ((hasDerivAt_iff_tendsto_slope.mp hd).mono_left (nhdsGT_le_nhdsNE x))
      (Iio_mem_nhds hneg)
  obtain ⟨t,ht,hti⟩ : ∃ t, slope g x t < 0 ∧ t ∈ Ioc x y :=
    (he.and (Ioc_mem_nhdsGT hxy)).exists
  have htmem : t ∈ Icc a b := ⟨le_trans hx.1 hti.1.le,le_trans hti.2 hy.2⟩
  have hlt : f t < f x := by
    have hgt : g t < g x := by
      rw [slope_def_field] at ht
      have hn := (div_lt_iff₀ (sub_pos.mpr hti.1)).mp ht
      exact sub_neg.mp (by simpa using hn)
    exact lt_of_le_of_lt (hbound t htmem) (heq ▸ hgt)
  exact lt_of_le_of_lt (hanti htmem hy hti.2) hlt

end C2.NGamma.Global
