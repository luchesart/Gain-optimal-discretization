#!/usr/bin/env python3
"""Check project sources using pinned Lean, without Lake's build scheduler.

First install lean-toolchain, restore the locked packages, and run
`lake exe cache get`. Then run `python3 tools/build_direct.py`.
The default target is the import closure of C2.lean; unimported draft files
are excluded. Use --all-modules deliberately to include every C2/*.lean.
Every selected source is checked afresh. Existing dependency caches are only
read. Lake is invoked once to obtain its environment, never to build targets.

Use --plan to inspect the source dependency order without invoking Lean or
Lake. Build logs, source hashes, commands and exit codes are saved together
in validation/direct_build_<UTC timestamp>/. Keep sources frozen during a run.
"""
from __future__ import annotations

import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time


ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def uncomment(source: str) -> str:
    """Remove nested Lean comments, preserving newlines and string contents."""
    out = []
    i, depth = 0, 0
    quoted = False
    while i < len(source):
        pair = source[i:i + 2]
        if depth:
            if pair == "/-":
                depth += 1
                i += 2
            elif pair == "-/":
                depth -= 1
                i += 2
            else:
                out.append("\n" if source[i] == "\n" else " ")
                i += 1
        elif not quoted and pair == "/-":
            depth = 1
            out.append(" ")
            i += 2
        elif not quoted and pair == "--":
            end = source.find("\n", i)
            i = len(source) if end < 0 else end
        elif quoted and source[i] == "\\":
            out.append(source[i:i + 2])
            i += 2
        else:
            if source[i] == '"':
                quoted = not quoted
            out.append(source[i])
            i += 1
    if depth:
        raise ValueError("Unclosed Lean block comment")
    return "".join(out)


def source_graph(targets: list[str], all_modules: bool):
    files = {".".join(p.relative_to(ROOT).with_suffix("").parts): p
             for p in (ROOT / "C2").rglob("*.lean")}
    files["C2"] = ROOT / "C2.lean"
    dependencies = {}
    for name, path in files.items():
        imports = []
        for line in uncomment(path.read_text()).splitlines():
            match = re.match(r"^\s*(?:public\s+)?import\s+(.+?)\s*$", line)
            if match:
                imports.extend(match.group(1).split())
        local = [x for x in imports if x == "C2" or x.startswith("C2.")]
        dependencies[name] = list(dict.fromkeys(local))
    order, active, visited = [], set(), set()

    def visit(name):
        if name not in files:
            raise ValueError(f"Unknown project target: {name}")
        if name in active:
            raise ValueError(f"Cyclic project import: {name}")
        if name in visited:
            return
        missing = set(dependencies[name]) - files.keys()
        if missing:
            raise ValueError(f"{name}: missing local sources {sorted(missing)}")
        active.add(name)
        for dep in dependencies[name]:
            visit(dep)
        active.remove(name)
        visited.add(name)
        order.append(name)

    for name in sorted(files) if all_modules else targets:
        visit(name)
    return files, dependencies, order


def command_output(args: list[str], env=None) -> str:
    return subprocess.check_output(args, cwd=ROOT, env=env, text=True).strip()


def pinned_environment():
    lake = shutil.which("lake")
    if not lake:
        raise RuntimeError("lake is absent from PATH; install lean-toolchain first")
    # This does not expose or store unrelated environment variables.
    keys = ["PATH", "LEAN_PATH", "LEAN_SRC_PATH", "LD_LIBRARY_PATH", "DYLD_LIBRARY_PATH"]
    get_env = "import os,json;print(json.dumps({k:os.environ.get(k) for k in " + repr(keys) + "}))"
    lake_env = json.loads(command_output([lake, "env", sys.executable, "-c", get_env]))
    env = os.environ.copy()
    for key, value in lake_env.items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    lean = shutil.which("lean", path=env["PATH"])
    if not lean:
        raise RuntimeError("Pinned Lean executable was not found in Lake's environment")
    toolchain = (ROOT / "lean-toolchain").read_text().strip()
    version = command_output([lean, "--version"], env)
    expected = toolchain.rsplit(":", 1)[-1].removeprefix("v")
    actual = re.search(r"Lean \(version ([^, )]+)", version)
    if actual is None or actual.group(1) != expected:
        raise RuntimeError(f"Toolchain mismatch: expected {toolchain}, got {version}")
    manifest = json.loads((ROOT / "lake-manifest.json").read_text())
    packages = []
    for package in manifest["packages"]:
        if package["type"] != "git":
            raise RuntimeError(f"Unpinned non-git dependency: {package['name']}")
        path = ROOT / manifest["packagesDir"] / package["name"]
        revision = command_output(["git", "-C", str(path), "rev-parse", "HEAD"])
        if revision != package["rev"]:
            raise RuntimeError(f"Dependency revision mismatch: {package['name']}")
        dirty = command_output(["git", "-C", str(path), "status", "--porcelain", "--untracked-files=no"])
        if dirty:
            raise RuntimeError(f"Tracked dependency files modified: {package['name']}")
        packages.append({"name": package["name"], "revision": revision})
    metadata = {"toolchain": toolchain, "lean_version": version,
                "lean_executable": lean, "lean_executable_sha256": sha256(Path(lean)),
                "lean_path": env.get("LEAN_PATH"), "packages": packages,
                "manifest_sha256": sha256(ROOT / "lake-manifest.json")}
    return lean, env, metadata


def write_json(path: Path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("targets", nargs="*", default=["C2"], help="Project modules; default C2")
    parser.add_argument("--all-modules", action="store_true", help="Include unimported project sources")
    parser.add_argument("--jobs", type=int, default=1, help="Maximum simultaneous Lean processes (default 1)")
    parser.add_argument("--plan", action="store_true", help="Print order without compiling or invoking Lake")
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    files, dependencies, order = source_graph(args.targets, args.all_modules)
    if args.plan:
        for i, name in enumerate(order, 1):
            print(f"{i:3d} {name}")
        print(f"{len(order)} project modules; at most {args.jobs} Lean processes, each -j1")
        return 0

    build = ROOT / ".lake/build/lib/lean"
    build.mkdir(parents=True, exist_ok=True)
    # Serialize direct-build invocations; other build tools must also be idle.
    with (ROOT / ".lake/build/direct-build.lock").open("w") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("Another direct build is already running")
        lean, env, metadata = pinned_environment()
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        report_dir = ROOT / "validation" / ("direct_build_" + timestamp)
        report_dir.mkdir(parents=True)
        hashes = {name: sha256(files[name]) for name in order}
        controls = [ROOT / p for p in
                    ("lean-toolchain", "lake-manifest.json", "lakefile.toml", "lakefile.lean", "tools/build_direct.py")]
        frozen = {p: sha256(p) for p in controls if p.exists()}
        report = {"started_at_utc": timestamp, "status": "running", "jobs": args.jobs,
                  "targets": args.targets, "all_modules": args.all_modules,
                  "environment": metadata, "module_order": order,
                  "build_control_sha256": {str(p.relative_to(ROOT)): digest for p, digest in frozen.items()},
                  "source_sha256": hashes, "results": []}
        report_path = report_dir / "results.json"
        write_json(report_path, report)
        print(f"Evidence: {report_dir.relative_to(ROOT)}", flush=True)

        def unchanged():
            changed = [str(p.relative_to(ROOT)) for p, digest in frozen.items() if sha256(p) != digest]
            changed += [name for name in order if sha256(files[name]) != hashes[name]]
            if changed:
                raise RuntimeError(f"Sources changed during build: {changed}")

        def compile_one(name):
            started = time.monotonic()
            log = report_dir / (name + ".log")
            result = {"module": name, "source_sha256": hashes[name],
                      "log": str(log.relative_to(ROOT)), "exit_code": None}
            try:
                unchanged()
                relative = Path(*name.split("."))
                destination = build / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                # Atomic replacement avoids truncating an olean that a running
                # checker may have memory-mapped. No old output is deleted.
                with tempfile.TemporaryDirectory(prefix=".direct-", dir=destination.parent) as temp:
                    temp_base = Path(temp) / relative.name
                    cmd = [lean, "-j1", "-o", str(temp_base.with_suffix(".olean")),
                           "-i", str(temp_base.with_suffix(".ilean")),
                           str(files[name].relative_to(ROOT))]
                    result["command"] = cmd
                    with log.open("w") as output:
                        process = subprocess.run(cmd, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
                    result["exit_code"] = process.returncode
                    if process.returncode == 0:
                        unchanged()
                        for extension in (".ilean", ".olean"):
                            produced = temp_base.with_suffix(extension)
                            result[extension[1:] + "_sha256"] = sha256(produced)
                            os.replace(produced, destination.with_suffix(extension))
            except Exception as exc:
                result["error"] = str(exc)
                result["exit_code"] = result["exit_code"] or 1
            result["elapsed_seconds"] = round(time.monotonic() - started, 3)
            return result

        pending, done, running = list(order), set(), {}
        failed = False
        with ThreadPoolExecutor(max_workers=args.jobs) as executor:
            while pending or running:
                if not failed:
                    for name in list(pending):
                        if len(running) >= args.jobs:
                            break
                        if set(dependencies[name]) <= done:
                            pending.remove(name)
                            print(f"START {name}", flush=True)
                            running[executor.submit(compile_one, name)] = name
                if not running:
                    break
                completed, _ = wait(running, return_when=FIRST_COMPLETED)
                for future in completed:
                    name = running.pop(future)
                    result = future.result()
                    report["results"].append(result)
                    if result["exit_code"] == 0:
                        done.add(name)
                    else:
                        failed = True
                    print(f"END {name}: exit {result['exit_code']} ({result['elapsed_seconds']}s)", flush=True)
                    write_json(report_path, report)
        try:
            unchanged()
        except RuntimeError as exc:
            failed = True
            report["freeze_error"] = str(exc)
        report["status"] = "failed" if failed or pending else "passed"
        report["unbuilt_modules"] = pending
        report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        write_json(report_path, report)
        print(f"{report['status'].upper()}: {len(done)}/{len(order)} modules; {report_path.relative_to(ROOT)}")
        return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"build_direct: {error}", file=sys.stderr)
        sys.exit(1)
