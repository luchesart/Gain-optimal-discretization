import C2.CADIsolationCells

/-! An eventually accepted rational dyadic mesh for every polynomial with
simple roots on the requested compact interval. -/
namespace C2.CADIsolation
open Polynomial Set Filter
open scoped Topology

def gridPoint (a b : ℚ) (n i : ℕ) : ℚ := a + (b-a)*(i:ℚ)/(2:ℚ)^n

def meshWidth (a b : ℚ) (n : ℕ) : ℚ := (b-a)/(2:ℚ)^n

noncomputable def certifiedMesh (p : ℚ[X]) (a b : ℚ) (n : ℕ) : Prop :=
  ∀ i ∈ Finset.range (2^n),
    certifiedCell p a b (gridPoint a b n i) (gridPoint a b n (i+1))

@[simp] theorem gridPoint_zero (a b : ℚ) (n : ℕ) : gridPoint a b n 0 = a := by
  simp [gridPoint]

@[simp] theorem gridPoint_last (a b : ℚ) (n : ℕ) : gridPoint a b n (2^n) = b := by
  have h : (2:ℚ)^n ≠ 0 := pow_ne_zero _ (by norm_num)
  simp only [gridPoint,Nat.cast_pow,Nat.cast_ofNat]
  field_simp
  <;> ring

theorem gridPoint_step_width (a b : ℚ) (n i : ℕ) :
    gridPoint a b n (i+1) - gridPoint a b n i = meshWidth a b n := by
  simp only [gridPoint,meshWidth,Nat.cast_add,Nat.cast_one]
  ring

theorem gridPoint_mono {a b : ℚ} (hab : a ≤ b) (n : ℕ) :
    Monotone (gridPoint a b n) := by
  intro i j hij
  dsimp [gridPoint]
  exact add_le_add_left (div_le_div_of_nonneg_right
    (mul_le_mul_of_nonneg_left (by exact_mod_cast hij) (sub_nonneg.mpr hab))
    (pow_nonneg (by norm_num) n)) a

theorem gridPoint_mem {a b : ℚ} (hab : a ≤ b) {n i : ℕ} (hi : i ≤ 2^n) :
    a ≤ gridPoint a b n i ∧ gridPoint a b n i ≤ b := by
  constructor
  · simpa using gridPoint_mono hab n (Nat.zero_le i)
  · simpa using gridPoint_mono hab n hi

theorem grid_cell_bounds {a b : ℚ} (hab : a ≤ b) {n i : ℕ} (hi : i < 2^n) :
    a ≤ gridPoint a b n i ∧
    gridPoint a b n i ≤ gridPoint a b n (i+1) ∧
    gridPoint a b n (i+1) ≤ b := by
  exact ⟨(gridPoint_mem hab hi.le).1,gridPoint_mono hab n (Nat.le_succ i),
    (gridPoint_mem hab (Nat.succ_le_iff.mpr hi)).2⟩

theorem meshWidth_cast (a b : ℚ) (n : ℕ) :
    (meshWidth a b n : ℝ) = ((b:ℝ)-(a:ℝ))*(1/2:ℝ)^n := by
  simp only [meshWidth,Rat.cast_div,Rat.cast_sub,Rat.cast_pow,Rat.cast_ofNat]
  rw [div_pow,one_pow]
  ring

theorem meshWidth_tendsto_zero (a b : ℚ) :
    Tendsto (fun n => (meshWidth a b n : ℝ)) atTop (𝓝 0) := by
  simp_rw [meshWidth_cast]
  simpa using (tendsto_pow_atTop_nhds_zero_of_lt_one
    (by norm_num : (0:ℝ) ≤ 1/2) (by norm_num : (1/2:ℝ) < 1)).const_mul ((b:ℝ)-(a:ℝ))

/-- Compactness supplies a strictly positive separation from simultaneous
vanishing. This is an existence proof used only to prove search termination. -/
theorem exists_positive_separation (p : ℚ[X]) (a b : ℚ)
    (hs : ∀ x ∈ Icc (a:ℝ) (b:ℝ), realEval p x ≠ 0 ∨ realEval p.derivative x ≠ 0) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ x ∈ Icc (a:ℝ) (b:ℝ),
      δ ≤ |realEval p x| + |realEval p.derivative x| := by
  apply isCompact_Icc.exists_forall_le'
    (((realEval_continuous p).abs.add (realEval_continuous p.derivative).abs).continuousOn)
  intro x hx
  rcases hs x hx with hp | hd
  · exact add_pos_of_pos_of_nonneg (abs_pos.mpr hp) (abs_nonneg _)
  · exact add_pos_of_nonneg_of_pos (abs_nonneg _) (abs_pos.mpr hd)

/-- Every sufficiently fine dyadic mesh passes the exact rational tests.
The input only requires simple real roots on this interval; it does not
assume an isolator output, a root count, or a sign-invariant partition. -/
theorem certifiedMesh_eventually (p : ℚ[X]) {a b : ℚ} (hab : a ≤ b)
    (hs : ∀ x ∈ Icc (a:ℝ) (b:ℝ), realEval p x ≠ 0 ∨ realEval p.derivative x ≠ 0) :
    ∃ N : ℕ, ∀ n ≥ N, certifiedMesh p a b n := by
  obtain ⟨δ,hδ,hsep⟩ := exists_positive_separation p a b hs
  have hlim : Tendsto (fun n => 2*(slopeBound p a b:ℝ)*(meshWidth a b n:ℝ))
      atTop (𝓝 0) := by
    simpa using (meshWidth_tendsto_zero a b).const_mul (2*(slopeBound p a b:ℝ))
  obtain ⟨N,hN⟩ := eventually_atTop.mp (hlim.eventually (gt_mem_nhds hδ))
  refine ⟨N,fun n hn i hi => ?_⟩
  have hb := grid_cell_bounds hab (Finset.mem_range.mp hi)
  let l := gridPoint a b n i
  let u := gridPoint a b n (i+1)
  have hm := midpoint_mem hb.2.1
  have hal : (a:ℝ) ≤ (l:ℝ) := by exact_mod_cast hb.1
  have hub : (u:ℝ) ≤ (b:ℝ) := by exact_mod_cast hb.2.2
  have hsep' := hsep (midpoint l u:ℝ) ⟨hal.trans hm.1,hm.2.trans hub⟩
  change certifiedCell p a b l u
  by_contra hfail
  have h₁ : |p.eval (midpoint l u)| ≤ slopeBound p a b * (u-l) := by
    apply le_of_not_gt
    intro h
    exact hfail (Or.inl h)
  have h₂ : |p.derivative.eval (midpoint l u)| ≤ slopeBound p a b * (u-l) := by
    apply le_of_not_gt
    intro h
    exact hfail (Or.inr h)
  have h₁' : |realEval p (midpoint l u:ℝ)| ≤
      (slopeBound p a b:ℝ)*((u-l:ℚ):ℝ) := by
    rw [realEval_rat]
    exact_mod_cast h₁
  have h₂' : |realEval p.derivative (midpoint l u:ℝ)| ≤
      (slopeBound p a b:ℝ)*((u-l:ℚ):ℝ) := by
    rw [realEval_rat]
    exact_mod_cast h₂
  have hw : u-l = meshWidth a b n := gridPoint_step_width a b n i
  rw [hw] at h₁' h₂'
  have hsmall := hN n hn
  linarith

/-- Existence of an accepted finite mesh, the hypothesis needed by an
executable least-index search with a decidable dense rational checker. -/
theorem exists_certifiedMesh (p : ℚ[X]) {a b : ℚ} (hab : a ≤ b)
    (hs : ∀ x ∈ Icc (a:ℝ) (b:ℝ), realEval p x ≠ 0 ∨ realEval p.derivative x ≠ 0) :
    ∃ n, certifiedMesh p a b n := by
  obtain ⟨N,hN⟩ := certifiedMesh_eventually p hab hs
  exact ⟨N,hN N le_rfl⟩

end C2.CADIsolation
