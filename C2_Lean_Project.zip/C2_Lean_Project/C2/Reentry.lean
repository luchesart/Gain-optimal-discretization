import C2.CubicSchur
import Mathlib.Analysis.SpecialFunctions.Sqrt

/-! # Two disconnected components of a genuine Schur-stable gain set -/

namespace C2

noncomputable def reentryLower : ℝ := (5 - Real.sqrt 5) / 10
noncomputable def reentryUpper : ℝ := (5 + Real.sqrt 5) / 10

theorem reentry_transformed_denominator (z : ℂ) :
    9*(z-1)^2+4*(z-1)*((z+1)/2)+36*((z+1)/2)^2 =
      20*(z^2+4/5) := by ring

theorem reentry_transformed_numerator (z : ℂ) :
    10*(z-1)^2+20*(z-1)*((z+1)/2)+80*((z+1)/2)^2 =
      20*(2*z^2+z+1) := by ring

theorem reentry_characteristic (z k : ℂ) :
    z*(20*(z^2+4/5))+k*(20*(2*z^2+z+1)) =
      20*(z^3+2*k*z^2+(4/5+k)*z+k) := by ring

theorem reentry_continuous_denominator_hurwitz {z : ℂ}
    (hz : 9*z^2+4*z+36=0) : z.re < 0 :=
  quadratic_hurwitz_of_positive (by norm_num) (by norm_num) (by norm_num) hz

theorem reentry_continuous_numerator_hurwitz {z : ℂ}
    (hz : 10*z^2+20*z+80=0) : z.re < 0 :=
  quadratic_hurwitz_of_positive (by norm_num) (by norm_num) (by norm_num) hz

theorem reentry_schur_iff {k : ℝ} (hk : 0 < k) :
    CubicSchur (2*k) (4/5+k) k ↔ k < 9/10 ∧ 0 < k^2-k+1/5 := by
  rw [cubicSchur_iff]
  constructor
  · rintro ⟨_, _, hm, hf⟩
    constructor <;> nlinarith
  · rintro ⟨hku, hf⟩
    refine ⟨?_, by linarith, by linarith, by nlinarith⟩
    rw [abs_of_pos hk]
    linarith

theorem reentry_quadratic_iff (k : ℝ) :
    0 < k^2-k+1/5 ↔ k < reentryLower ∨ reentryUpper < k := by
  have hs : 0 < Real.sqrt (5:ℝ) := Real.sqrt_pos.2 (by norm_num)
  have hsq : (Real.sqrt (5:ℝ))^2 = 5 := Real.sq_sqrt (by norm_num)
  have hab : reentryLower < reentryUpper := by
    dsimp [reentryLower,reentryUpper]
    linarith
  have hfac : k^2-k+1/5 = (k-reentryLower)*(k-reentryUpper) := by
    dsimp [reentryLower,reentryUpper]
    nlinarith [hsq]
  rw [hfac, mul_pos_iff]
  constructor
  · rintro (⟨_,hb⟩ | ⟨ha,_⟩)
    · right; linarith
    · left; linarith
  · rintro (ha | hb)
    · right; constructor <;> linarith
    · left; constructor <;> linarith

theorem reentry_exact_intervals {k : ℝ} (hk : 0 < k) :
    CubicSchur (2*k) (4/5+k) k ↔
      (k < reentryLower ∨ reentryUpper < k) ∧ k < 9/10 := by
  rw [reentry_schur_iff hk, reentry_quadratic_iff]
  exact and_comm

theorem reentry_stable_one_tenth : CubicSchur (1/5) (9/10) (1/10) := by
  rw [cubicSchur_iff]
  norm_num [abs_of_nonneg]

theorem reentry_unstable_one_half : ¬ CubicSchur 1 (13/10) (1/2) := by
  rw [cubicSchur_iff]
  norm_num [abs_of_nonneg]

theorem reentry_stable_four_fifths : CubicSchur (8/5) (8/5) (4/5) := by
  rw [cubicSchur_iff]
  norm_num [abs_of_nonneg]

end C2
