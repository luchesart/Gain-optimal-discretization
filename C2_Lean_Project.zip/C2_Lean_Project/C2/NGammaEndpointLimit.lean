import C2.NGammaAllocationRegularity
import C2.NGammaEndpoint
import Mathlib.Analysis.Calculus.DSlope

/-!
# The zero-frequency bridge to the endpoint resource problem

The normalized phase has a genuine joint continuous extension at zero frequency,
with value twice the endpoint resource.  Feasible positive-frequency points stay
uniformly away from the singular faces x_i=0 near zero frequency.
-/
noncomputable section
open scoped BigOperators Topology
namespace C2.NGamma

def phaseDenominator (r x w : ℝ) : ℝ := r*x^2+2*x+r*w^2

theorem phaseDenominator_pos {r x w : ℝ} (hr : 0 < r) (hx : 0 ≤ x) (hw : 0 < w) :
    0 < phaseDenominator r x w := by
  unfold phaseDenominator
  positivity

theorem allocationPhase_eq_arctan {r x w : ℝ} (hr : 0 < r) (hx : 0 ≤ x) (hw : 0 < w) :
    allocationPhase r x w = Real.arctan (2*w/phaseDenominator r x w) := by
  have ha : 0 ≤ (x+2/r)/w := by positivity
  have hb : 0 ≤ x/w := div_nonneg hx (le_of_lt hw)
  have hp : ((x+2/r)/w)*(-(x/w)) < 1 := by
    have h := mul_nonpos_of_nonneg_of_nonpos ha (neg_nonpos.2 hb)
    linarith
  unfold allocationPhase
  rw [sub_eq_add_neg,← Real.arctan_neg,Real.arctan_add hp]
  congr 1
  have hD := phaseDenominator_pos hr hx hw
  unfold phaseDenominator at *
  have hA : 0 < 1-((x+2/r)/w)*(-(x/w)) := by linarith
  field_simp
  <;> ring

/-- A single phase component bounded by the total phase already gives a
quantitative exclusion of the singular face x=0 as frequency tends to zero. -/
theorem feasible_component_lower_bound {r x w : ℝ} (hr : 0 < r)
    (hx : 0 ≤ x) (hw : 0 < w) (hw1 : w < 1)
    (hp : allocationPhase r x w ≤ 2*Real.arctan w) :
    1 ≤ x*(r*x+2)+(r+1)*w^2 := by
  rw [allocationPhase_eq_arctan hr hx hw,Real.two_mul_arctan (by linarith) hw1] at hp
  have hd : 0 < phaseDenominator r x w := phaseDenominator_pos hr hx hw
  have hdw : 0 < 1-w^2 := by nlinarith
  have harg : 2*w/phaseDenominator r x w ≤ 2*w/(1-w^2) :=
    Real.arctan_strictMono.le_iff_le.mp hp
  have hcross := (div_le_div_iff₀ hd hdw).mp harg
  unfold phaseDenominator at hcross
  nlinarith

theorem feasible_component_uniform_positive {r x w : ℝ} (hr : 0 < r)
    (hx : x ∈ Set.Icc 0 1) (hw : 0 < w) (hw1 : w < 1)
    (hsmall : (r+1)*w^2 ≤ 1/2)
    (hp : allocationPhase r x w ≤ 2*Real.arctan w) :
    1/(2*(r+2)) ≤ x := by
  have hb := feasible_component_lower_bound hr hx.1 hw hw1 hp
  have hsq : x^2 ≤ x := by nlinarith [hx.1,hx.2]
  apply (div_le_iff₀ (by positivity : 0 < 2*(r+2))).2
  nlinarith

/-- A continuous extension of the actual normalized phase `phase / w`.
`dslope` supplies the removable value arctan'(0)=1. -/
def normalizedPhase (r x w : ℝ) : ℝ :=
  dslope Real.arctan 0 (2*w/phaseDenominator r x w) *
    (2/phaseDenominator r x w)

theorem arctan_dslope_continuous : Continuous (dslope Real.arctan 0) := by
  apply continuous_iff_continuousAt.2
  intro x
  by_cases hx : x=0
  · subst x
    exact continuousAt_dslope_same.2 (Real.hasDerivAt_arctan 0).differentiableAt
  · exact (continuousAt_dslope_of_ne hx).2 Real.continuousAt_arctan

theorem normalizedPhase_eq {r x w : ℝ} (hr : 0 < r) (hx : 0 ≤ x) (hw : 0 < w) :
    normalizedPhase r x w = allocationPhase r x w / w := by
  have hd := phaseDenominator_pos hr hx hw
  have hz : 2*w/phaseDenominator r x w ≠ 0 := ne_of_gt (div_pos (by positivity) hd)
  unfold normalizedPhase
  rw [dslope_of_ne _ hz,allocationPhase_eq_arctan hr hx hw]
  simp only [slope_def_field,sub_zero,Real.arctan_zero]
  field_simp
  <;> ring

theorem normalizedPhase_zero {r x : ℝ} (hr : 0 < r) (hx : 0 < x) :
    normalizedPhase r x 0 = 2*endpointCost r x := by
  unfold normalizedPhase phaseDenominator endpointCost
  simp only [mul_zero,zero_pow (by norm_num : (2:ℕ) ≠ 0),add_zero,zero_div,dslope_same]
  rw [(Real.hasDerivAt_arctan 0).deriv]
  norm_num
  field_simp
  <;> ring

theorem normalizedPhase_joint_continuousAt {r : ℝ} {p : ℝ × ℝ}
    (hd : phaseDenominator r p.1 p.2 ≠ 0) :
    ContinuousAt (fun p : ℝ × ℝ => normalizedPhase r p.1 p.2) p := by
  have hD : ContinuousAt (fun p : ℝ × ℝ => phaseDenominator r p.1 p.2) p := by
    unfold phaseDenominator
    fun_prop
  have harg : ContinuousAt (fun p : ℝ × ℝ => 2*p.2/phaseDenominator r p.1 p.2) p :=
    (continuousAt_const.mul continuousAt_snd).div hD hd
  exact (arctan_dslope_continuous.continuousAt.comp harg).mul
    (continuousAt_const.div hD hd)

theorem normalizedPhase_endpoint_continuousAt {r x : ℝ} (hr : 0 < r) (hx : 0 < x) :
    ContinuousAt (fun p : ℝ × ℝ => normalizedPhase r p.1 p.2) (x,0) := by
  apply normalizedPhase_joint_continuousAt
  exact ne_of_gt (by dsimp [phaseDenominator]; positivity)

theorem allocationGain_endpoint {r x : ℝ} (hr : 0 < r) (hx : 0 < x) :
    allocationGain r x 0 = r+2/x := by
  have hx0 : x ≠ 0 := ne_of_gt hx
  have h : 0 ≤ r+2/x := by positivity
  unfold allocationGain
  have heq : ((r*x+2)^2+(r*0)^2)/(x^2+0^2) = (r+2/x)^2 := by
    field_simp
    <;> ring
  rw [heq,Real.sqrt_sq h]

theorem allocationGain_endpoint_continuousAt {r x : ℝ} (hx : 0 < x) :
    ContinuousAt (fun p : ℝ × ℝ => allocationGain r p.1 p.2) (x,0) := by
  unfold allocationGain
  apply Real.continuous_sqrt.continuousAt.comp
  have hd : x^2+(0:ℝ)^2 ≠ 0 := by positivity
  exact ContinuousAt.div (by fun_prop) (by fun_prop) hd

theorem allocationPhase_nonneg {r w x : ℝ} (hr : 0 < r) (hw : 0 < w) (hx : 0 ≤ x) :
    0 ≤ allocationPhase r x w := by
  rw [allocationPhase_eq_arctan hr hx hw]
  have h := Real.arctan_le_arctan (show 0 ≤ 2*w/phaseDenominator r x w by
    exact le_of_lt (div_pos (by positivity) (phaseDenominator_pos hr hx hw)))
  simpa using h

/-- Any cluster point of feasible positive-frequency allocations as w tends to
zero lies on the exact endpoint resource surface, with every coordinate positive.
This is a closed-graph statement for the actual phase equation, not an assumed
regularity or compactness property of the optimizer. -/
theorem feasible_endpoint_cluster {ι κ : Type*} [Fintype ι]
    {F : Filter κ} [Filter.NeBot F]
    (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    (w : κ → ℝ) (x : κ → ι → ℝ) (x₀ : ι → ℝ)
    (hwlim : Filter.Tendsto w F (𝓝 0))
    (hxlim : ∀ i, Filter.Tendsto (fun k => x k i) F (𝓝 (x₀ i)))
    (hw : ∀ k, 0 < w k) (hx : ∀ k i, x k i ∈ Set.Icc 0 1)
    (hphase : ∀ k, (∑ i, allocationPhase (r i) (x k i) (w k)) = 2*Real.arctan (w k)) :
    (∀ i, 0 < x₀ i ∧ x₀ i ≤ 1) ∧ (∑ i, endpointCost (r i) (x₀ i)) = 1 := by
  classical
  have hxmem : ∀ i, x₀ i ∈ Set.Icc 0 1 := by
    intro i
    exact ⟨ge_of_tendsto' (hxlim i) (fun k => (hx k i).1),
      le_of_tendsto' (hxlim i) (fun k => (hx k i).2)⟩
  have hcomponent : ∀ k i, allocationPhase (r i) (x k i) (w k) ≤ 2*Real.arctan (w k) := by
    intro k i
    rw [← hphase k]
    exact Finset.single_le_sum (fun j _ => allocationPhase_nonneg (hr j) (hw k) (hx k j).1)
      (Finset.mem_univ i)
  have hsmall : ∀ᶠ k in F, w k < 1 := hwlim (gt_mem_nhds (by norm_num : (0:ℝ) < 1))
  have hxpos : ∀ i, 0 < x₀ i := by
    intro i
    have hbound : ∀ᶠ k in F, 1 ≤ x k i*(r i*x k i+2)+(r i+1)*(w k)^2 := by
      filter_upwards [hsmall] with k hk
      exact feasible_component_lower_bound (hr i) (hx k i).1 (hw k) hk (hcomponent k i)
    have ht : Filter.Tendsto (fun k => x k i*(r i*x k i+2)+(r i+1)*(w k)^2) F
        (𝓝 (x₀ i*(r i*x₀ i+2))) := by
      have h : Filter.Tendsto (fun k => x k i*(r i*x k i+2)+(r i+1)*(w k)^2) F
          (𝓝 (x₀ i*(r i*x₀ i+2)+(r i+1)*(0:ℝ)^2)) :=
        ((hxlim i).mul ((tendsto_const_nhds.mul (hxlim i)).add_const 2)).add
          (tendsto_const_nhds.mul (hwlim.pow 2))
      simpa using h
    have hb : 1 ≤ x₀ i*(r i*x₀ i+2) := ge_of_tendsto ht hbound
    by_contra hn
    have heq : x₀ i=0 := le_antisymm (le_of_not_gt hn) (hxmem i).1
    norm_num [heq] at hb
  refine ⟨fun i => ⟨hxpos i,(hxmem i).2⟩,?_⟩
  have hnlim : ∀ i, Filter.Tendsto (fun k => normalizedPhase (r i) (x k i) (w k)) F
      (𝓝 (2*endpointCost (r i) (x₀ i))) := by
    intro i
    have h := (normalizedPhase_endpoint_continuousAt (hr i) (hxpos i)).tendsto.comp
      ((hxlim i).prodMk_nhds hwlim)
    simpa only [Function.comp_def,normalizedPhase_zero (hr i) (hxpos i)] using h
  have hsumlim := tendsto_finset_sum Finset.univ (fun i _ => hnlim i)
  have heq : (fun k => ∑ i, normalizedPhase (r i) (x k i) (w k)) =
      (fun k => 2*dslope Real.arctan 0 (w k)) := by
    funext k
    simp_rw [normalizedPhase_eq (hr _) (hx k _).1 (hw k)]
    rw [← Finset.sum_div,hphase k,dslope_of_ne _ (ne_of_gt (hw k))]
    simp only [slope_def_field,sub_zero,Real.arctan_zero]
    ring
  rw [heq] at hsumlim
  have ht : Filter.Tendsto (fun k => 2*dslope Real.arctan 0 (w k)) F (𝓝 2) := by
    have h : Filter.Tendsto (fun k => 2*dslope Real.arctan 0 (w k)) F
        (𝓝 (2*dslope Real.arctan 0 0)) :=
      tendsto_const_nhds.mul (arctan_dslope_continuous.continuousAt.tendsto.comp hwlim)
    simpa only [dslope_same,(Real.hasDerivAt_arctan 0).deriv,zero_pow (by norm_num : (2:ℕ)≠0),
      add_zero,div_one,mul_one,Function.comp_def] using h
  have hsum := tendsto_nhds_unique hsumlim ht
  rw [← Finset.mul_sum] at hsum
  linarith

end C2.NGamma
