import C2.NGammaAmplitude

noncomputable section
open Set Filter
open scoped BigOperators Topology
namespace C2.NGamma.Cayley

lemma amplitude_lt_endpoint {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) {t : ℝ} (ht : 0 ≤ t) :
    amplitude r x t < ∏ i, (r i+2/x i) := by
  have hm := amplitude_strictMonoOn hn hr (fun i => (hx i).le)
  have hle : amplitude r x (t+1) ≤ ∏ i, (r i+2/x i) := by
    apply ge_of_tendsto (amplitude_tendsto_atTop hr hx)
    filter_upwards [eventually_ge_atTop (t+1)] with s hs
    exact hm.monotoneOn (show 0 ≤ t+1 by linarith) (show 0 ≤ s by linarith) hs
  exact lt_of_lt_of_le (hm ht (show 0 ≤ t+1 by linarith) (by linarith)) hle

lemma base_gain_lt_endpoint {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) :
    (∏ i, r i) < ∏ i, (r i+2/x i) := by
  simpa only [amplitude_zero] using amplitude_lt_endpoint hn hr hx (le_refl (0:ℝ))

lemma base_gain_lt_amplitude {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) {t : ℝ} (ht : 0 < t) :
    (∏ i, r i) < amplitude r x t := by
  simpa only [amplitude_zero] using amplitude_strictMonoOn hn hr hx (le_refl (0:ℝ)) ht.le ht

end C2.NGamma.Cayley
