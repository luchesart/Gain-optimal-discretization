import C2.TwoGammaShared

/-! Named manuscript-level assertions about the supremum of all stable gains,
not only the initial interval. -/
noncomputable section
open scoped BigOperators
open Set
namespace C2.TwoGamma
open NGamma NGamma.PolynomialModel

def stableGains (r₁ r₂ γ₁ γ₂ : ℝ) : Set ℝ :=
  {b | 0 ≤ b ∧ SchurStable (characteristic r₁ r₂ γ₁ γ₂ b)}

def fullSquareGains (r₁ r₂ : ℝ) : Set ℝ :=
  {b | ∃ γ₁ ∈ Icc (0:ℝ) 1, ∃ γ₂ ∈ Icc (0:ℝ) 1, b ∈ stableGains r₁ r₂ γ₁ γ₂}

def halfSquareGains (r₁ r₂ : ℝ) : Set ℝ :=
  {b | ∃ γ₁ ∈ Icc (1/2:ℝ) 1, ∃ γ₂ ∈ Icc (1/2:ℝ) 1, b ∈ stableGains r₁ r₂ γ₁ γ₂}

theorem optimal_pair_isLUB {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    IsLUB (stableGains r₁ r₂ (optimalGamma r₁ r₂) (optimalGamma r₂ r₁)) (gain r₁ r₂) := by
  have he : stableGains r₁ r₂ (optimalGamma r₁ r₂) (optimalGamma r₂ r₁) = Ico 0 (gain r₁ r₂) := by
    ext b
    constructor
    · rintro ⟨hb,hs⟩
      exact ⟨hb,(optimal_pair_stable_iff h₁ h₂ hb).mp hs⟩
    · rintro ⟨hb,hB⟩
      exact ⟨hb,(optimal_pair_stable_iff h₁ h₂ hb).mpr hB⟩
  rw [he]
  exact isLUB_Ico (gain_pos h₁ h₂)

theorem full_square_isLUB {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    IsLUB (fullSquareGains r₁ r₂) (gain r₁ r₂) := by
  have hg₁ := optimalGamma_interior h₁ h₂
  have hg₂ := optimalGamma_interior h₂ h₁
  constructor
  · rintro b ⟨γ₁,hγ₁,γ₂,hγ₂,hb,hs⟩
    exact (full_square_gain_bound h₁ h₂ hγ₁ hγ₂ hb hs).le
  · intro c hc
    apply (optimal_pair_isLUB h₁ h₂).2
    intro b hb
    exact hc ⟨optimalGamma r₁ r₂,⟨by linarith,hg₁.2.le⟩,
      optimalGamma r₂ r₁,⟨by linarith,hg₂.2.le⟩,hb⟩

theorem half_square_isLUB {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    IsLUB (halfSquareGains r₁ r₂) (gain r₁ r₂) := by
  have hg₁ := optimalGamma_interior h₁ h₂
  have hg₂ := optimalGamma_interior h₂ h₁
  constructor
  · rintro b ⟨γ₁,hγ₁,γ₂,hγ₂,hb,hs⟩
    exact (half_square_gain_bound h₁ h₂ hγ₁ hγ₂ hb hs).le
  · intro c hc
    apply (optimal_pair_isLUB h₁ h₂).2
    intro b hb
    exact hc ⟨optimalGamma r₁ r₂,⟨hg₁.1.le,hg₁.2.le⟩,
      optimalGamma r₂ r₁,⟨hg₂.1.le,hg₂.2.le⟩,hb⟩

/-- The only full-square parameter pair whose entire stable-gain set has
supremum B is the explicitly displayed pair. -/
theorem full_square_optimal_pair_unique {r₁ r₂ γ₁ γ₂ : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂)
    (hg₁ : γ₁ ∈ Icc (0:ℝ) 1) (hg₂ : γ₂ ∈ Icc (0:ℝ) 1)
    (hSup : IsLUB (stableGains r₁ r₂ γ₁ γ₂) (gain r₁ r₂)) :
    γ₁ = optimalGamma r₁ r₂ ∧ γ₂ = optimalGamma r₂ r₁ := by
  let x := Parameterization.xOfGamma γ₁
  let y := Parameterization.xOfGamma γ₂
  have hx : x ∈ Icc (-1:ℝ) 1 := (Parameterization.full_cube_coordinate γ₁).mp hg₁
  have hy : y ∈ Icc (-1:ℝ) 1 := (Parameterization.full_cube_coordinate γ₂).mp hg₂
  have hclosed : IsClosed {b : ℝ | 0 ≤ A1 r₁ r₂ x y b ∧ 0 ≤ A2 r₁ r₂ x y b ∧ 0 ≤ H r₁ r₂ x y b} := by
    apply IsClosed.inter
    · apply isClosed_le (f := fun _ : ℝ => (0:ℝ)) (g := fun b : ℝ => A1 r₁ r₂ x y b) continuous_const
      unfold A1
      fun_prop
    · apply IsClosed.inter
      · apply isClosed_le (f := fun _ : ℝ => (0:ℝ)) (g := fun b : ℝ => A2 r₁ r₂ x y b) continuous_const
        unfold A2
        fun_prop
      · apply isClosed_le (f := fun _ : ℝ => (0:ℝ)) (g := fun b : ℝ => H r₁ r₂ x y b) continuous_const
        unfold H A0 A1 A2 A3
        fun_prop
  have hsubset : stableGains r₁ r₂ γ₁ γ₂ ⊆
      {b : ℝ | 0 ≤ A1 r₁ r₂ x y b ∧ 0 ≤ A2 r₁ r₂ x y b ∧ 0 ≤ H r₁ r₂ x y b} := by
    intro b hb
    have hs' : SchurStable (PolynomialModel.characteristic (poles r₁ r₂) ![x,y] 1 b) := by
      simpa only [characteristic_eq_generic,coordinates] using hb.2
    obtain ⟨hA1,hA2,_,hH⟩ := stable_necessary h₁ h₂ hx hy hb.1 hs'
    exact ⟨hA1.le,hA2.le,hH.le⟩
  obtain ⟨ha₁,ha₂,hH⟩ := closure_minimal hsubset hclosed (hSup.mem_closure hSup.nonempty)
  have hxp : 0 < x := lt_of_not_ge fun hn =>
    closed_high_gain_exclusion_left h₁ h₂ (le_refl _) hn ha₁ ha₂ hH
  have hyp : 0 < y := lt_of_not_ge fun hn =>
    closed_high_gain_exclusion_right h₁ h₂ (le_refl _) hn ha₁ ha₂ hH
  have hh₁ : γ₁ ∈ Icc (1/2:ℝ) 1 := (Parameterization.half_cube_coordinate γ₁).mpr ⟨hxp.le,hx.2⟩
  have hh₂ : γ₂ ∈ Icc (1/2:ℝ) 1 := (Parameterization.half_cube_coordinate γ₂).mpr ⟨hyp.le,hy.2⟩
  obtain ⟨C,hC,hset⟩ := connected_stable_gain_interval h₁ h₂ hh₁ hh₂
  change stableGains r₁ r₂ γ₁ γ₂ = Ico 0 C at hset
  have hCLUB : IsLUB (stableGains r₁ r₂ γ₁ γ₂) C := by rw [hset]; exact isLUB_Ico hC
  have hBC : gain r₁ r₂ = C := hSup.unique hCLUB
  have hmargin : initialGainMargin (poles r₁ r₂) (coordinates γ₁ γ₂) 1 = gain r₁ r₂ := by
    rw [hBC]
    apply initialGainMargin_eq_of_exact_interval hC
    intro b hb
    have hmem : b ∈ stableGains r₁ r₂ γ₁ γ₂ ↔ b ∈ Ico 0 C := by rw [hset]
    simpa [stableGains,hb,characteristic_eq_generic] using hmem
  have hcoords := ((explicit_initial_margin_optimum h₁ h₂).2.2.2 (coordinates γ₁ γ₂)
    (by
      intro i
      fin_cases i
      · exact hx
      · exact hy)).2.mp hmargin
  have ha := congrFun hcoords (0:Fin 2)
  have hb := congrFun hcoords (1:Fin 2)
  simp only [coordinates,optimalVector,Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.head_cons] at ha hb
  unfold Parameterization.xOfGamma at ha hb
  unfold optimalGamma
  constructor <;> linarith

end C2.TwoGamma
