import C2.NGammaRootCountEndpoints
noncomputable section
open scoped BigOperators ComplexConjugate Topology
open Set Complex Polynomial Filter
namespace C2.NGamma.PolynomialModel
variable {n : ℕ} {r x : Fin n → ℝ}

def negativeQ (x y : ℝ) : ℝ := ((1+x)*y-(1-x))/2

def negativeMagnitude (r x : Fin n → ℝ) (y : ℝ) : ℝ :=
  y * ∏ i, (r i+(y+1)/negativeQ (x i) y)

theorem negativeQ_pos {x y : ℝ} (hx : 0 < x) (hy : 1 ≤ y) : 0 < negativeQ x y := by
  unfold negativeQ
  have hh : 0 ≤ x*(y-1) := mul_nonneg hx.le (by linarith)
  nlinarith

theorem negativeMagnitude_one (hx : ∀ i, 0 < x i) :
    negativeMagnitude r x 1 = ∏ i, (r i+2/x i) := by
  norm_num [negativeMagnitude, negativeQ]

theorem continuousOn_negativeMagnitude (hx : ∀ i, 0 < x i) :
    ContinuousOn (negativeMagnitude r x) (Set.Ici 1) := by
  apply continuousOn_id.mul
  apply continuousOn_finset_prod
  intro i hi
  apply continuousOn_const.add
  apply (continuousOn_id.add continuousOn_const).div
  · unfold negativeQ
    fun_prop
  · intro y hy
    exact ne_of_gt (negativeQ_pos (hx i) hy)

theorem negativeMagnitude_lower (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i)
    {y : ℝ} (hy : 1 ≤ y) : y * ∏ i, r i ≤ negativeMagnitude r x y := by
  apply mul_le_mul_of_nonneg_left _ (by linarith)
  apply Finset.prod_le_prod
  · intro i hi
    exact (hr i).le
  · intro i hi
    have hh : 0 ≤ (y+1)/negativeQ (x i) y := by
      exact div_nonneg (by linarith) (negativeQ_pos (hx i) hy).le
    linarith

theorem characteristic_eval_neg_real {y : ℝ} (hx : ∀ i, 0 < x i) (hy : 1 ≤ y) (b : ℝ) :
    (characteristic r x 1 b).eval (-(y : ℂ)) =
      (-1 : ℂ)^n * (∏ i, (negativeQ (x i) y : ℂ)) * (b-negativeMagnitude r x y) := by
  have hq (i : Fin n) : (q (x i)).eval (-(y : ℂ)) = -(negativeQ (x i) y : ℂ) := by
    rw [q_eval]
    simp only [negativeQ, Complex.ofReal_div, Complex.ofReal_sub, Complex.ofReal_mul,
      Complex.ofReal_add, Complex.ofReal_one, Complex.ofReal_ofNat]
    ring
  have hf (i : Fin n) : (factor (r i) (x i)).eval (-(y : ℂ)) =
      -(negativeQ (x i) y : ℂ) * (r i+(y+1)/negativeQ (x i) y : ℝ) := by
    rw [factor_eval, hq]
    push_cast
    have hn : (negativeQ (x i) y : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt (negativeQ_pos (hx i) hy)
    field_simp
    <;> ring
  simp only [characteristic, eval_add, eval_mul, eval_pow, eval_X, pow_one, eval_C, eval_prod,
    hf, hq, Finset.prod_mul_distrib, Finset.prod_neg, Finset.card_univ, Fintype.card_fin, negativeMagnitude,
    Complex.ofReal_mul, Complex.ofReal_prod]
  norm_cast
  ring

theorem exists_negative_real_root_of_endpoint_le
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i)
    {b : ℝ} (hb : (∏ i, (r i+2/x i)) ≤ b) :
    ∃ y : ℝ, 1 ≤ y ∧ (characteristic r x 1 b).eval (-(y : ℂ)) = 0 := by
  let B0 : ℝ := ∏ i, r i
  have hB : 0 < B0 := Finset.prod_pos (fun i _ => hr i)
  let Y : ℝ := max 1 ((b+1)/B0)
  have hY : 1 ≤ Y := le_max_left _ _
  have hbY : b < negativeMagnitude r x Y := by
    have hh : (b+1)/B0 ≤ Y := le_max_right _ _
    have hh' : b+1 ≤ Y*B0 := (div_le_iff₀ hB).1 hh
    have hl := negativeMagnitude_lower hr hx hY
    dsimp [B0] at *
    linarith
  have hstart : negativeMagnitude r x 1 ≤ b := by simpa [negativeMagnitude_one hx] using hb
  have hc := (continuousOn_negativeMagnitude (r := r) hx).mono (show Set.Icc 1 Y ⊆ Set.Ici 1 from fun y hy => hy.1)
  obtain ⟨y, hy, he⟩ := intermediate_value_Icc hY hc ⟨hstart, hbY.le⟩
  refine ⟨y, hy.1, ?_⟩
  rw [characteristic_eval_neg_real hx hy.1, he]
  simp

theorem not_schur_of_endpoint_le
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i)
    {b : ℝ} (hb : (∏ i, (r i+2/x i)) ≤ b) :
    ¬ SchurStable (characteristic r x 1 b) := by
  intro hs
  obtain ⟨y, hy, he⟩ := exists_negative_real_root_of_endpoint_le hr hx hb
  have hh := hs (-(y : ℂ)) he
  simp only [norm_neg, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by linarith : 0 ≤ y)] at hh
  exact not_lt_of_ge hy hh

end C2.NGamma.PolynomialModel
