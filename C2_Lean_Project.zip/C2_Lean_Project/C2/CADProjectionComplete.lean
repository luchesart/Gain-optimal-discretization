import C2.CADProjectionBasis
import C2.CADProjectionCells
import C2.CADProductCells

/-! Projection correctness for arbitrary finite strict rational bivariate
systems. The factorization and Bezout data are proved to exist, and their
finite exact identities imply feasibility constancy on every regular cell. -/
noncomputable section
open Polynomial Set
namespace C2.CADProjection

def totalProjectionCut {ι : Type*} [Fintype ι] {n : ℕ}
    (w : FactorData ι n) (v : ProjectionData (Fin n)) : ℚ[X] :=
  projectionCut w.factors v * ∏ i, w.left i * w.right i

theorem totalProjectionCut_ne_zero {ι : Type*} [Fintype ι] {n : ℕ}
    {F : ι → Bivariate} {w : FactorData ι n} {v : ProjectionData (Fin n)}
    (hw : ValidFactorData F w) (hv : ValidProjectionData w.factors v) :
    totalProjectionCut w v ≠ 0 :=
  mul_ne_zero hv.cut_ne_zero (Finset.prod_ne_zero_iff.mpr
    (fun i _ => mul_ne_zero (hw.1 i).1 (hw.1 i).2))

/-- The full finite cut also excludes every scalar multiplier denominator
and numerator used in the exact cleared factorization identities. -/
theorem totalProjectionCut_regular {ι : Type*} [Fintype ι] {n : ℕ}
    {F : ι → Bivariate} {w : FactorData ι n} {v : ProjectionData (Fin n)}
    (hw : ValidFactorData F w) (hv : ValidProjectionData w.factors v)
    (k : ℝ) (hk : (totalProjectionCut w v).eval₂ (algebraMap ℚ ℝ) k ≠ 0) :
    RegularFamilyAt w.factors k ∧ ∀ i,
      (w.left i).eval₂ (algebraMap ℚ ℝ) k ≠ 0 ∧
      (w.right i).eval₂ (algebraMap ℚ ℝ) k ≠ 0 := by
  let e : ℚ[X] →+* ℝ := Polynomial.eval₂RingHom (algebraMap ℚ ℝ) k
  have hmap : e (totalProjectionCut w v) ≠ 0 := hk
  have hparts : e (projectionCut w.factors v) ≠ 0 ∧
      (∏ i, e (w.left i) * e (w.right i)) ≠ 0 := by
    simpa only [totalProjectionCut,map_mul,map_prod,mul_ne_zero_iff] using hmap
  refine ⟨hv.regular k hparts.1,fun i => ?_⟩
  exact mul_ne_zero_iff.mp (Finset.prod_ne_zero_iff.mp hparts.2 i (Finset.mem_univ i))

def unitValue {ι : Type*} {n : ℕ} (w : FactorData ι n) (i : ι) (k : ℝ) : ℝ :=
  (w.right i).eval₂ (algebraMap ℚ ℝ) k / (w.left i).eval₂ (algebraMap ℚ ℝ) k

/-- The original polynomial values equal the specialized finite factor data
at every gain at which the checked scalar denominator does not vanish. -/
theorem ValidFactorData.value_eq {ι : Type*} {n : ℕ}
    {F : ι → Bivariate} {w : FactorData ι n} (hw : ValidFactorData F w)
    (i : ι) (k x : ℝ) (hk : (w.left i).eval₂ (algebraMap ℚ ℝ) k ≠ 0) :
    value (F i) k x = unitValue w i k * x ^ w.zeroPower i *
      (x-1) ^ w.onePower i * ∏ j, value (w.factors j) k x ^ w.powers i j := by
  exact C2.CADFactor.specialize_cleared_identity
    (Polynomial.eval₂RingHom (algebraMap ℚ ℝ) k) (F i) w.factors
    (w.zeroPower i) (w.onePower i) (w.powers i) (hw.2.2 i) hk x

/-- Finite exact factor and projection identities prove actual feasibility
invariance of the original inequalities on each connected projection-free set. -/
theorem valid_data_feasibility_constant {ι : Type*} [Fintype ι] {n : ℕ}
    (F : ι → Bivariate) (w : FactorData ι n) (v : ProjectionData (Fin n))
    (hw : ValidFactorData F w) (hv : ValidProjectionData w.factors v)
    (I : Set ℝ) (hI : IsPreconnected I)
    (hcut : ∀ k ∈ I, (totalProjectionCut w v).eval₂ (algebraMap ℚ ℝ) k ≠ 0)
    {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) :
    (∃ x ∈ Icc (0:ℝ) 1, ∀ i, 0 < value (F i) a x) ↔
    (∃ x ∈ Icc (0:ℝ) 1, ∀ i, 0 < value (F i) b x) := by
  have hregular (k : ℝ) (hk : k ∈ I) := totalProjectionCut_regular hw hv k (hcut k hk)
  have hucont : ∀ i, ContinuousOn (unitValue w i) I := by
    intro i
    exact ((w.right i).continuous_eval₂ (algebraMap ℚ ℝ)).continuousOn.div
      ((w.left i).continuous_eval₂ (algebraMap ℚ ℝ)).continuousOn
      (fun k hk => (hregular k hk).2 i |>.1)
  have hunz : ∀ i k, k ∈ I → unitValue w i k ≠ 0 := by
    intro i k hk
    exact div_ne_zero ((hregular k hk).2 i).2 ((hregular k hk).2 i).1
  have hpattern := C2.CADDelineability.endpoint_products_constant
    (fun j z => value (w.factors j) z.1 z.2) (fun j => continuous_value (w.factors j))
    (unitValue w) w.powers w.zeroPower w.onePower hw.2.1 I hI
    (fun k hk => (hregular k hk).1.analytic) hucont hunz ha hb
  have heq (k : ℝ) (hk : k ∈ I) :
      (∃ x ∈ Icc (0:ℝ) 1, ∀ i, 0 < value (F i) k x) ↔
      k ∈ C2.CADDelineability.patternGains (fun i z =>
        unitValue w i z.1 * z.2 ^ w.zeroPower i * (z.2-1) ^ w.onePower i *
          ∏ j, value (w.factors j) z.1 z.2 ^ w.powers i j) := by
    constructor
    · rintro ⟨x,hx,hpos⟩
      refine ⟨x,hx,fun i => ?_⟩
      have hi := hpos i
      rw [hw.value_eq i k x ((hregular k hk).2 i).1] at hi
      exact hi
    · rintro ⟨x,hx,hpos⟩
      refine ⟨x,hx,fun i => ?_⟩
      rw [hw.value_eq i k x ((hregular k hk).2 i).1]
      exact hpos i
  exact (heq a ha).trans (hpattern.trans (heq b hb).symm)

/-- General mathematical projection theorem, with no supplied factorization,
root regularity or feasibility-invariance assumption. This includes constants,
repeated factors, common factors and every gain-only factor. -/
theorem exists_feasibility_projection {ι : Type*} [Fintype ι]
    (F : ι → Bivariate) (hF : ∀ i, F i ≠ 0) :
    ∃ D : ℚ[X], D ≠ 0 ∧
      ∀ I : Set ℝ, IsPreconnected I →
      (∀ k ∈ I, D.eval₂ (algebraMap ℚ ℝ) k ≠ 0) →
      ∀ {a b : ℝ}, a ∈ I → b ∈ I →
        ((∃ x ∈ Icc (0:ℝ) 1, ∀ i, 0 < value (F i) a x) ↔
         (∃ x ∈ Icc (0:ℝ) 1, ∀ i, 0 < value (F i) b x)) := by
  obtain ⟨n,w,v,hw,hv⟩ := exists_factor_projection_data F hF
  exact ⟨totalProjectionCut w v,totalProjectionCut_ne_zero hw hv,
    fun I hI hcut _ _ ha hb => valid_data_feasibility_constant F w v hw hv I hI hcut ha hb⟩

end C2.CADProjection
