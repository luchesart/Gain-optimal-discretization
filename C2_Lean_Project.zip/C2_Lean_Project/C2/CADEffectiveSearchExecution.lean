import C2.CADEffectiveSearch

/-! Exact finite execution witnesses for the exhaustive search implementation. -/
namespace C2.CADEffective
variable {α : Type*} [Encodable α]

theorem scanFrom_eq_of_first (accept : α → Bool) (n fuel j : ℕ) (a : α)
    (hn : n ≤ j) (hj : j < n + fuel)
    (hd : Encodable.decode (α := α) j = some a) (ha : accept a = true)
    (hfirst : ∀ k, n ≤ k → k < j → acceptedCode accept k = false) :
    scanFrom accept n fuel = some a := by
  induction fuel generalizing n with
  | zero => omega
  | succ fuel ih =>
      by_cases he : j = n
      · subst j
        simp only [scanFrom, hd, ha, Bool.true_eq, ↓reduceIte]
      · have hnlt : n < j := by omega
        have hnext : scanFrom accept (n+1) fuel = some a :=
          ih (n+1) (by omega) (by omega) (fun k hk hkj => hfirst k (by omega) hkj)
        have hb := hfirst n (le_refl n) hnlt
        cases hnDec : Encodable.decode (α := α) n with
        | none => simpa only [scanFrom, hnDec] using hnext
        | some b =>
            have hbb : accept b = false := by simpa only [acceptedCode, hnDec, Option.any_some] using hb
            simpa only [scanFrom, hnDec, hbb, Bool.false_eq_true, ↓reduceIte] using hnext

/-- The exact selected result is returned after a finite explicitly bounded
prefix scan. This identifies the total search with its ordinary finite loop. -/
theorem search_finite_execution_eq (accept : α → Bool) (h : ∃ a, accept a = true) :
    scanFrom accept 0 (searchIndex accept h + 1) = some (search accept h) := by
  apply scanFrom_eq_of_first accept 0 (searchIndex accept h + 1)
    (searchIndex accept h) (search accept h) (Nat.zero_le _) (by omega)
  · exact Option.eq_some_of_isSome _
  · exact search_accepted accept h
  · intro k _ hk
    exact searchIndex_minimal accept h hk

end C2.CADEffective
