import C2.FirstOrderSchur

noncomputable section
namespace C2.FirstOrder

def U₁ (r γ : ℝ) : ℝ := (1 + r * γ) / (1 - γ)
def U₂ (r γ : ℝ) : ℝ := r + 2 / (2 * γ - 1)

theorem stable_lower_half_iff {r γ a : ℝ} (hr : 0 ≤ r)
    (hγ : 0 ≤ γ) (hγh : γ < 1/2) :
    Stable r γ a ↔ max 0 (r - 2 / (1 - 2 * γ)) < a ∧ a < U₁ r γ := by
  have hd : 0 < 1 - γ := by linarith
  have hq : 0 < 1 - 2 * γ := by linarith
  rw [stable_iff_jury hr hγ]
  unfold Jury U₁
  rw [max_lt_iff, lt_div_iff₀ hd]
  have hl : r - 2 / (1 - 2 * γ) < a ↔ 0 < 2 + (2 * γ - 1) * (r - a) := by
    calc
      r - 2 / (1 - 2 * γ) < a ↔ r - a < 2 / (1 - 2 * γ) := by constructor <;> intro h <;> linarith only [h]
      _ ↔ (r - a) * (1 - 2 * γ) < 2 := lt_div_iff₀ hq
      _ ↔ 0 < 2 + (2 * γ - 1) * (r - a) := by constructor <;> intro h <;> nlinarith
  rw [hl]
  constructor
  · rintro ⟨ha,h₁,h₂⟩
    exact ⟨⟨ha,h₁⟩,by linarith⟩
  · rintro ⟨⟨ha,h₁⟩,h₂⟩
    exact ⟨ha,h₁,by linarith⟩

theorem stable_half_iff {r a : ℝ} (hr : 0 ≤ r) :
    Stable r (1/2) a ↔ 0 < a ∧ a < r + 2 := by
  rw [stable_iff_jury hr (by norm_num)]
  unfold Jury
  constructor
  · rintro ⟨ha,h₁,h₂⟩
    exact ⟨ha,by nlinarith⟩
  · rintro ⟨ha,h⟩
    exact ⟨ha,by norm_num,by nlinarith⟩

theorem stable_upper_half_iff {r γ a : ℝ} (hr : 0 ≤ r)
    (hγh : 1/2 < γ) (hγ1 : γ < 1) :
    Stable r γ a ↔ 0 < a ∧ a < min (U₁ r γ) (U₂ r γ) := by
  have hd : 0 < 1 - γ := by linarith
  have hq : 0 < 2 * γ - 1 := by linarith
  rw [stable_iff_jury hr (by linarith)]
  unfold Jury U₁ U₂
  rw [lt_min_iff, lt_div_iff₀ hd]
  have hu : a < r + 2 / (2 * γ - 1) ↔ 0 < 2 + (2 * γ - 1) * (r - a) := by
    calc
      a < r + 2 / (2 * γ - 1) ↔ a - r < 2 / (2 * γ - 1) := by constructor <;> intro h <;> linarith only [h]
      _ ↔ (a - r) * (2 * γ - 1) < 2 := lt_div_iff₀ hq
      _ ↔ 0 < 2 + (2 * γ - 1) * (r - a) := by constructor <;> intro h <;> nlinarith
  rw [hu]
  constructor <;> rintro ⟨ha, h₁, h₂⟩ <;> exact ⟨ha, by linarith, by linarith⟩

theorem stable_one_iff {r a : ℝ} (hr : 0 ≤ r) :
    Stable r 1 a ↔ 0 < a ∧ a < r + 2 := by
  rw [stable_iff_jury hr (by norm_num)]
  unfold Jury
  constructor
  · rintro ⟨ha,h₁,h₂⟩
    exact ⟨ha,by nlinarith⟩
  · rintro ⟨ha,h⟩
    exact ⟨ha,by nlinarith,by nlinarith⟩

theorem lower_half_interval_nonempty {r γ : ℝ} (hr : 0 ≤ r)
    (hγ : 0 ≤ γ) (hγh : γ < 1/2) :
    (∃ a : ℝ, Stable r γ a) ↔ r < (1 + 2 * (1 - 2 * γ)) / (1 - 2 * γ)^2 := by
  have hd : 0 < 1 - γ := by linarith
  have hq : 0 < 1 - 2 * γ := by linarith
  have hu : 0 < U₁ r γ := div_pos (by nlinarith [mul_nonneg hr hγ]) hd
  have hid : U₁ r γ - (r - 2 / (1 - 2 * γ)) =
      (1 + 2 * (1 - 2 * γ) - r * (1 - 2 * γ)^2) / ((1 - 2 * γ) * (1 - γ)) := by
    unfold U₁
    field_simp [ne_of_gt hd, ne_of_gt hq]
    <;> ring
  have hb : (∃ a : ℝ, Stable r γ a) ↔ max 0 (r - 2/(1-2*γ)) < U₁ r γ := by
    constructor
    · rintro ⟨a,ha⟩
      obtain ⟨hl,hh⟩ := (stable_lower_half_iff hr hγ hγh).mp ha
      exact hl.trans hh
    · intro h
      obtain ⟨a,hl,hh⟩ := exists_between h
      exact ⟨a,(stable_lower_half_iff hr hγ hγh).mpr ⟨hl,hh⟩⟩
  rw [hb, max_lt_iff, and_iff_right hu]
  rw [← sub_pos, hid, div_pos_iff_of_pos_right (mul_pos hq hd)]
  rw [lt_div_iff₀ (sq_pos_of_pos hq)]
  constructor <;> intro h <;> nlinarith

/-- The paper's complete piecewise one-sample threshold. -/
noncomputable def oneSampleThreshold (γ : ℝ) : ℝ :=
  if γ ≤ 3/4 then 1 / (1 - γ) else 2 / (2 * γ - 1)

theorem integrator_lower_branch {γ a : ℝ} (hγ : 0 ≤ γ) (hγq : γ ≤ 3/4) :
    Stable 0 γ a ↔ 0 < a ∧ a < 1 / (1 - γ) := by
  have hd : 0 < 1 - γ := by linarith
  rw [stable_iff_jury (by norm_num) hγ, lt_div_iff₀ hd]
  unfold Jury
  constructor
  · rintro ⟨ha,h₁,h₂⟩
    exact ⟨ha,by nlinarith⟩
  · rintro ⟨ha,h⟩
    have hc := mul_nonneg ha.le (show 0 ≤ 3 - 4 * γ by linarith)
    exact ⟨ha,by nlinarith,by nlinarith⟩

theorem integrator_upper_branch {γ a : ℝ} (hγq : 3/4 ≤ γ) (hγ1 : γ ≤ 1) :
    Stable 0 γ a ↔ 0 < a ∧ a < 2 / (2 * γ - 1) := by
  have hd : 0 < 2 * γ - 1 := by linarith
  rw [stable_iff_jury (by norm_num) (by linarith), lt_div_iff₀ hd]
  unfold Jury
  constructor
  · rintro ⟨ha,h₁,h₂⟩
    exact ⟨ha,by nlinarith⟩
  · rintro ⟨ha,h⟩
    have hc := mul_nonneg ha.le (show 0 ≤ 4 * γ - 3 by linarith)
    exact ⟨ha,by nlinarith,by nlinarith⟩

theorem integrator_piecewise_region {γ a : ℝ} (hγ : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    Stable 0 γ a ↔ 0 < a ∧ a < oneSampleThreshold γ := by
  unfold oneSampleThreshold
  split_ifs with h
  · exact integrator_lower_branch hγ h
  · exact integrator_upper_branch (by linarith) hγ1

theorem oneSampleThreshold_unique_max {γ : ℝ} (hγ : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    oneSampleThreshold γ ≤ 4 ∧ (oneSampleThreshold γ = 4 ↔ γ = 3/4) := by
  unfold oneSampleThreshold
  split_ifs with h
  · have hd : 0 < 1 - γ := by linarith
    constructor
    · rw [div_le_iff₀ hd]
      linarith
    · rw [div_eq_iff (ne_of_gt hd)]
      constructor <;> intro he <;> linarith
  · have hd : 0 < 2 * γ - 1 := by linarith
    constructor
    · rw [div_le_iff₀ hd]
      linarith
    · rw [div_eq_iff (ne_of_gt hd)]
      constructor <;> intro he <;> linarith

theorem oneSampleThreshold_pos {γ : ℝ} (hγ : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    0 < oneSampleThreshold γ := by
  unfold oneSampleThreshold
  split_ifs with h
  · exact div_pos (by norm_num) (by linarith)
  · exact div_pos (by norm_num) (by linarith)

theorem oneSampleThreshold_isLUB {γ : ℝ} (hγ : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    IsLUB {a : ℝ | Stable 0 γ a} (oneSampleThreshold γ) := by
  have he : {a : ℝ | Stable 0 γ a} = Set.Ioo 0 (oneSampleThreshold γ) := by
    ext a
    exact integrator_piecewise_region hγ hγ1
  rw [he]
  exact isLUB_Ioo (oneSampleThreshold_pos hγ hγ1)

theorem le_oneSampleThreshold_iff {γ a : ℝ} (hγ : 0 ≤ γ) (hγ1 : γ ≤ 1)
    (ha : 0 ≤ a) :
    a ≤ oneSampleThreshold γ ↔ a*(1-γ) ≤ 1 ∧ a*(2*γ-1) ≤ 2 := by
  unfold oneSampleThreshold
  split_ifs with h
  · rw [le_div_iff₀ (show 0 < 1-γ by linarith)]
    have hc := mul_nonneg ha (show 0 ≤ 3-4*γ by linarith)
    constructor
    · intro hb
      exact ⟨hb,by nlinarith⟩
    · exact And.left
  · rw [le_div_iff₀ (show 0 < 2*γ-1 by linarith)]
    have hc := mul_nonneg ha (show 0 ≤ 4*γ-3 by linarith)
    constructor
    · intro hb
      exact ⟨by nlinarith,hb⟩
    · exact And.right

end C2.FirstOrder

