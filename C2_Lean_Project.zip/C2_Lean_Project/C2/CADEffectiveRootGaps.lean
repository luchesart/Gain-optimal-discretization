import C2.CADEffectiveRootOutput

/-! Endpoint inclusion and root-free gaps of the sorted executable output. -/
namespace C2.CADEffective.Dense
open Polynomial Set C2.CADIsolation

theorem rootAtRank_mem_interval (p : Poly) {a b : ℚ} (hab : a ≤ b) {n r : ℕ}
    (hr : r ∈ rootRanks p a b n) {x : ℝ} (hx : rootAtRank p a b n r x) :
    x ∈ Icc (a:ℝ) (b:ℝ) := by
  have hs := (mem_rootRanks p a b n r).mp hr
  by_cases he : r % 2 = 0
  · simp only [rootAtRank,he,if_pos] at hx
    simp only [he,if_pos] at hs
    rw [hx.1]
    exact (selectedPoint_sound (denote p) hab hs).1
  · simp only [rootAtRank,he,if_neg] at hx
    simp only [he,if_neg] at hs
    have hb := grid_cell_bounds hab hs.1
    have hl : (a:ℝ) ≤ (gridPoint a b n (r/2):ℝ) := by exact_mod_cast hb.1
    have hu : (gridPoint a b n (r/2+1):ℝ) ≤ (b:ℝ) := by exact_mod_cast hb.2.2
    exact ⟨hl.trans hx.1.1.le,hx.1.2.le.trans hu⟩

theorem rootAtRank_is_root (p : Poly) (a b : ℚ) (n r : ℕ) {x : ℝ}
    (hx : rootAtRank p a b n r x) : realEval (denote p) x = 0 := by
  unfold rootAtRank at hx
  split_ifs at hx <;> exact hx.2

theorem first_rank_mem (p : Poly) (a b : ℚ) (n : ℕ) (ha : eval p a = 0) :
    0 ∈ rootRanks p a b n := by
  rw [mem_rootRanks]
  simp only [Nat.zero_mod,Nat.zero_div,if_pos,selectedPoint,gridPoint_zero,Nat.zero_le,true_and]
  rwa [← eval_denote]

theorem last_rank_mem (p : Poly) (a b : ℚ) (n : ℕ) (hb : eval p b = 0) :
    2*2^n ∈ rootRanks p a b n := by
  rw [mem_rootRanks]
  simpa [selectedPoint,← eval_denote] using hb

theorem first_rank_meaning (p : Poly) (a b : ℚ) (n : ℕ) {x : ℝ}
    (hx : rootAtRank p a b n 0 x) : x = (a:ℝ) := by
  simpa [rootAtRank] using hx.1

theorem last_rank_meaning (p : Poly) (a b : ℚ) (n : ℕ) {x : ℝ}
    (hx : rootAtRank p a b n (2*2^n) x) : x = (b:ℝ) := by
  have h : x = (b:ℝ) ∧ realEval (denote p) x = 0 := by simpa [rootAtRank] using hx
  exact h.1

/-- No root is hidden between consecutive returned ranks. -/
theorem no_root_between_consecutive_ranks (p : Poly) {a b : ℚ} (hab : a < b)
    {n r s : ℕ} (hm : certifiedMesh (denote p) a b n)
    (hr : r ∈ rootRanks p a b n) (hs : s ∈ rootRanks p a b n)
    (hcon : ∀ t ∈ rootRanks p a b n, r < t → t < s → False)
    {x y : ℝ} (hx : rootAtRank p a b n r x) (hy : rootAtRank p a b n s y) :
    ∀ z ∈ Ioo x y, realEval (denote p) z ≠ 0 := by
  intro z hz hpz
  have hxg := rootAtRank_mem_interval p hab.le hr hx
  have hyg := rootAtRank_mem_interval p hab.le hs hy
  have hzg : z ∈ Icc (a:ℝ) (b:ℝ) := ⟨hxg.1.trans hz.1.le,hz.2.le.trans hyg.2⟩
  obtain ⟨t,ht,hzt⟩ := rootRanks_complete p hab hm hzg hpz
  have hrt : r < t := by
    by_contra hn
    rcases lt_or_eq_of_le (not_lt.mp hn) with hlt | he
    · have hzx := root_rank_order p hab ht hr hlt hzt hx
      exact (not_lt_of_ge hzx.le) hz.1
    · subst t
      have he := (rootRanks_unique_root p hab hm hr).unique hzt hx
      exact (ne_of_lt hz.1) he.symm
  have hts : t < s := by
    by_contra hn
    rcases lt_or_eq_of_le (not_lt.mp hn) with hlt | he
    · have hyz := root_rank_order p hab hs ht hlt hy hzt
      exact (not_lt_of_ge hyz.le) hz.2
    · subst t
      have he := (rootRanks_unique_root p hab hm hs).unique hzt hy
      exact (ne_of_lt hz.2) he
  exact hcon t ht hrt hts

/-- An exact rational gap sample determines the polynomial sign throughout
that true gap between consecutive roots. -/
theorem gap_sample_sign (p : Poly) {a b : ℚ} (hab : a < b) {n r s : ℕ}
    (hm : certifiedMesh (denote p) a b n)
    (hr : r ∈ rootRanks p a b n) (hs : s ∈ rootRanks p a b n) (hrs : r < s)
    (hcon : ∀ t ∈ rootRanks p a b n, r < t → t < s → False)
    {x y z : ℝ} (hx : rootAtRank p a b n r x) (hy : rootAtRank p a b n s y)
    (hz : z ∈ Ioo x y) :
    0 < realEval (denote p) z ↔ 0 < eval p (betweenRanks a b n r s) := by
  have hsample := betweenRanks_correct p hab hr hs hrs hx hy
  rw [eval_denote,← realEval_rat_pos]
  exact realEval_pos_iff_of_no_roots (denote p) hz hsample
    (no_root_between_consecutive_ranks p hab hm hr hs hcon hx hy)

end C2.CADEffective.Dense
