import C2.CADDriverIsolation
import C2.CADEffectiveBivariate
import C2.CADAlgorithmInterpretation

/-! A concrete total CAD testing driver. It specializes the supplied dense
bivariate inequalities at each rational gain sample, handles identically zero
specializations, isolates the square-free parameter-root product with 0 and 1,
tests every computed rational parameter gap, and returns the greatest marked
right gain-root rank. The projection polynomial is an explicit dense input;
the projection producer and semantic constancy theorem are separate modules.
-/

namespace C2.CADDriver
open C2.CADEffective C2.CADAlgorithm

def consecutiveRanks (data : Isolation) : List (ℕ × ℕ) :=
  data.ranks.zip data.ranks.tail

def gapSamples (data : Isolation) (a b : ℚ) : List ℚ :=
  (consecutiveRanks data).map fun c => Dense.betweenRanks a b data.mesh c.1 c.2

def specializations (input : List Bivariate.Poly) (gain : ℚ) : List Dense.Poly :=
  input.map fun p => Bivariate.atGain p gain

/-- Zero specializations make the strict feasible set empty. Otherwise the
actual product is nonzero, and the proved total square-free isolator applies. -/
def parameterIsolation (input : List Bivariate.Poly) (gain : ℚ) : Option Isolation :=
  let ps := specializations input gain
  if hz : anyZero ps = true then none
  else
    have hp : Dense.denote (product ps) ≠ 0 :=
      product_nonzero ps ((anyZero_eq_false_iff ps).mp (Bool.eq_false_iff.mpr hz))
    some (isolate (product ps) hp 0 1 (by norm_num))

def parameterSamples (input : List Bivariate.Poly) (gain : ℚ) : List ℚ :=
  match parameterIsolation input gain with
  | none => []
  | some data => gapSamples data 0 1

def rationalTests (input : List Bivariate.Poly) : List (ℚ → ℚ → ℚ) :=
  input.map Bivariate.eval

def markGain (input : List Bivariate.Poly) (gain : ℚ) : Bool :=
  markAtGain (rationalTests input) (parameterSamples input gain) gain

def sampledGainCells (input : List Bivariate.Poly) (data : Isolation)
    (K : ℚ) : List (SampledCell ℕ) :=
  (consecutiveRanks data).map fun c =>
    let k := Dense.betweenRanks 0 K data.mesh c.1 c.2
    {left := c.1, right := c.2, gainSample := k,
      parameterSamples := parameterSamples input k}

structure Run where
  isolation : Isolation
  sampledCells : List (SampledCell ℕ)
  result : Option ℕ

/-- Every computation is dense rational arithmetic, a proved terminating
search, or structural list recursion. Natural rank comparisons replace any
general-purpose real-algebraic comparison oracle. -/
def runWithProjection (input : List Bivariate.Poly) (projection : Dense.Poly)
    (hp : Dense.denote projection ≠ 0) (K : ℚ) (hK : 0 ≤ K) : Run :=
  let iso := isolate projection hp 0 K hK
  let cells := sampledGainCells input iso K
  ⟨iso, cells, testAndSelect (rationalTests input) cells⟩

theorem parameterIsolation_none_iff (input : List Bivariate.Poly) (gain : ℚ) :
    parameterIsolation input gain = none ↔
      anyZero (specializations input gain) = true := by
  dsimp only [parameterIsolation]
  split <;> simp_all

theorem parameterIsolation_some (input : List Bivariate.Poly) (gain : ℚ)
    (hz : anyZero (specializations input gain) = false) :
    ∃ data, parameterIsolation input gain = some data := by
  unfold parameterIsolation
  simp only [hz, Bool.false_eq_true, dite_false]
  exact ⟨_, rfl⟩

theorem markGain_zero_specialization (input : List Bivariate.Poly) (gain : ℚ)
    (hz : anyZero (specializations input gain) = true) : markGain input gain = false := by
  have hn := (parameterIsolation_none_iff input gain).mpr hz
  simp [markGain, parameterSamples, hn, markAtGain]

theorem markGain_true_iff (input : List Bivariate.Poly) (gain : ℚ) :
    markGain input gain = true ↔
      ∃ parameter ∈ parameterSamples input gain,
        ∀ p ∈ input, 0 < Bivariate.eval p parameter gain := by
  rw [markGain, markAtGain_eq_true_iff]
  simp [rationalTests]

theorem run_none_iff (input : List Bivariate.Poly) (projection : Dense.Poly)
    (hp : Dense.denote projection ≠ 0) (K : ℚ) (hK : 0 ≤ K) :
    (runWithProjection input projection hp K hK).result = none ↔
      ∀ c ∈ (runWithProjection input projection hp K hK).sampledCells,
        ¬∃ parameter ∈ c.parameterSamples,
          ∀ p ∈ input, 0 < Bivariate.eval p parameter c.gainSample := by
  change testAndSelect (rationalTests input) _ = none ↔ _
  rw [testAndSelect_none_iff]
  simp [rationalTests, runWithProjection]

theorem run_some_test_spec (input : List Bivariate.Poly) (projection : Dense.Poly)
    (hp : Dense.denote projection ≠ 0) (K : ℚ) (hK : 0 ≤ K) {r : ℕ}
    (hout : (runWithProjection input projection hp K hK).result = some r) :
    (∃ c ∈ (runWithProjection input projection hp K hK).sampledCells,
      (∃ parameter ∈ c.parameterSamples,
        ∀ p ∈ input, 0 < Bivariate.eval p parameter c.gainSample) ∧ c.right = r) ∧
    ∀ c ∈ (runWithProjection input projection hp K hK).sampledCells,
      (∃ parameter ∈ c.parameterSamples,
        ∀ p ∈ input, 0 < Bivariate.eval p parameter c.gainSample) → c.right ≤ r := by
  have h := testAndSelect_some_spec hout
  simpa [rationalTests] using h

theorem selected_rank_mem (input : List Bivariate.Poly) (projection : Dense.Poly)
    (hp : Dense.denote projection ≠ 0) (K : ℚ) (hK : 0 ≤ K) {r : ℕ}
    (hout : (runWithProjection input projection hp K hK).result = some r) :
    r ∈ (runWithProjection input projection hp K hK).isolation.ranks := by
  obtain ⟨⟨c, hc, _, hcr⟩, _⟩ := run_some_test_spec input projection hp K hK hout
  obtain ⟨d, hd, rfl⟩ := List.mem_map.mp hc
  have hright := List.mem_of_mem_tail (List.of_mem_zip hd).2
  exact hcr ▸ hright

theorem selected_rank_unique_root (input : List Bivariate.Poly) (projection : Dense.Poly)
    (hp : Dense.denote projection ≠ 0) (K : ℚ) (hK : 0 < K) {r : ℕ}
    (hout : (runWithProjection input projection hp K hK.le).result = some r) :
    ∃! x, Dense.rootAtRank (runWithProjection input projection hp K hK.le).isolation.polynomial
      0 K (runWithProjection input projection hp K hK.le).isolation.mesh r x := by
  exact isolate_unique_root projection hp 0 K hK
    (selected_rank_mem input projection hp K hK.le hout)

end C2.CADDriver
