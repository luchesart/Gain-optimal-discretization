import Mathlib

/-!
# General coefficient and gain bounds

The bounds in this module concern the actual complex roots.  They supply
the quantitative polynomial step in the general rational gain argument.
They do not formalize CAD, root isolation, or a state-space realization.
-/

noncomputable section
open Polynomial Finset
namespace C2.GeneralCompletion

/-- Exact binomial bound for a polynomial whose roots lie in the closed disk.
The leading coefficient is retained, rather than assuming a monic model. -/
theorem coefficient_bound_of_closed_disk {p : Polynomial ℂ} (hp : p ≠ 0)
    (hroot : ∀ z : ℂ, p.eval z = 0 → ‖z‖ ≤ 1) (i : ℕ) :
    ‖p.coeff i‖ ≤ ‖p.leadingCoeff‖ * (p.natDegree.choose i : ℝ) := by
  let q := Polynomial.C p.leadingCoeff⁻¹ * p
  have hl : p.leadingCoeff ≠ 0 := leadingCoeff_ne_zero.mpr hp
  have hq : q.Monic := monic_C_mul_of_mul_leadingCoeff_eq_one (inv_mul_cancel₀ hl)
  have hd : q.natDegree = p.natDegree := by
    exact Polynomial.natDegree_C_mul (inv_ne_zero hl)
  have hr : ∀ z ∈ (q.map (RingHom.id ℂ)).roots, ‖z‖ ≤ (1 : ℝ) := by
    intro z hz
    have he : q.eval z = 0 := by
      simpa using (isRoot_of_mem_roots hz)
    have he' : p.eval z = 0 := by
      simpa [q, hl] using he
    exact hroot z he'
  have hb := Polynomial.coeff_le_of_roots_le i hq (IsAlgClosed.splits q) hr
  have hnorm : 0 < ‖p.leadingCoeff‖ := norm_pos_iff.mpr hl
  simp only [Polynomial.map_id, hd, one_pow, one_mul] at hb
  have hb' : ‖p.coeff i‖ / ‖p.leadingCoeff‖ ≤ (p.natDegree.choose i : ℝ) := by
    simpa [q, norm_mul, norm_inv, div_eq_mul_inv, mul_comm] using hb
  exact (div_le_iff₀ hnorm).mp hb' |>.trans_eq (mul_comm _ _)

/-- One uniform coefficient bound using the central binomial coefficient. -/
theorem coefficient_bound_middle_of_closed_disk {p : Polynomial ℂ} (hp : p ≠ 0)
    (hroot : ∀ z : ℂ, p.eval z = 0 → ‖z‖ ≤ 1) (i : ℕ) :
    ‖p.coeff i‖ ≤
      ‖p.leadingCoeff‖ * (p.natDegree.choose (p.natDegree / 2) : ℝ) := by
  apply (coefficient_bound_of_closed_disk hp hroot i).trans
  gcongr
  exact_mod_cast i.choose_le_middle p.natDegree

/-- A real polynomial version, with the actual complex-root interpretation. -/
theorem real_coefficient_bound {p : Polynomial ℝ} (hp : p ≠ 0)
    (hroot : ∀ z : ℂ, (p.map Complex.ofRealHom).eval z = 0 → ‖z‖ ≤ 1)
    (i : ℕ) :
    |p.coeff i| ≤ |p.leadingCoeff| * (p.natDegree.choose i : ℝ) := by
  have hp' : p.map Complex.ofRealHom ≠ 0 := by simpa using hp
  have h := coefficient_bound_of_closed_disk hp' hroot i
  simpa using h

/-- For a delayed affine family, every coefficient below the fixed leading
degree yields an explicit stabilizing-gain bound. -/
theorem affine_gain_bound {H N : Polynomial ℝ} {k μ H₀ E₀ : ℝ} {L i : ℕ}
    (hk : 0 ≤ k) (hμ : 0 < μ) (hN : μ ≤ |N.coeff i|)
    (hH : |H.coeff i| ≤ H₀) (hE : |H.leadingCoeff| ≤ E₀)
    (hdeg : H.natDegree = L) (hlo : N.natDegree < H.natDegree)
    (hroot : ∀ z : ℂ,
      ((H + Polynomial.C k * N).map Complex.ofRealHom).eval z = 0 → ‖z‖ ≤ 1) :
    k ≤ (H₀ + E₀ * (L.choose (L / 2) : ℝ)) / μ := by
  have hd : (H + Polynomial.C k * N).natDegree = H.natDegree :=
    natDegree_add_eq_left_of_natDegree_lt ((natDegree_C_mul_le k N).trans_lt hlo)
  have hlead : (H + Polynomial.C k * N).leadingCoeff = H.leadingCoeff :=
    leadingCoeff_add_of_degree_lt' (degree_lt_degree
      ((natDegree_C_mul_le k N).trans_lt hlo))
  have hHne : H ≠ 0 := by
    intro he
    simp [he] at hlo
  have hp : H + Polynomial.C k * N ≠ 0 := by
    intro he
    have h := congrArg Polynomial.leadingCoeff he
    rw [hlead, leadingCoeff_zero] at h
    exact (leadingCoeff_ne_zero.mpr hHne) h
  have hb := real_coefficient_bound hp hroot i
  rw [hd, hlead, hdeg] at hb
  have hb' : |(H + Polynomial.C k * N).coeff i| ≤
      E₀ * (L.choose (L/2) : ℝ) := by
    calc
      _ ≤ |H.leadingCoeff| * (L.choose i : ℝ) := hb
      _ ≤ E₀ * (L.choose (L/2) : ℝ) := by
        apply mul_le_mul hE
        · exact_mod_cast i.choose_le_middle L
        · positivity
        · exact (abs_nonneg _).trans hE
  have ht : k * |N.coeff i| ≤
      |(H + Polynomial.C k * N).coeff i| + |H.coeff i| := by
    have he : k * N.coeff i =
        (H + Polynomial.C k * N).coeff i - H.coeff i := by simp
    calc
      _ = |k * N.coeff i| := by rw [abs_mul, abs_of_nonneg hk]
      _ = _ := congrArg abs he
      _ ≤ _ := abs_sub _ _
  apply (le_div_iff₀ hμ).mpr
  have hm := mul_le_mul_of_nonneg_left hN hk
  linarith

/-- A nonzero lower-degree feedback numerator forces all nonnegative Schur
gains into a bounded interval. This is the large-gain exclusion used in the
first-margin proof, independently of any boundary enumeration. -/
theorem stable_gains_bounded {H N : Polynomial ℝ} (hN : N ≠ 0)
    (hlo : N.natDegree < H.natDegree) :
    ∃ K : ℝ, ∀ k : ℝ, 0 ≤ k →
      (∀ z : ℂ, ((H+Polynomial.C k*N).map Complex.ofRealHom).eval z = 0 → ‖z‖ < 1) →
      k ≤ K := by
  obtain ⟨i, hi⟩ : ∃ i : ℕ, N.coeff i ≠ 0 := by
    by_contra h
    push_neg at h
    apply hN
    ext i
    simpa using h i
  refine ⟨(|H.coeff i| + |H.leadingCoeff| *
    (H.natDegree.choose (H.natDegree/2) : ℝ))/|N.coeff i|, ?_⟩
  intro k hk hstable
  exact affine_gain_bound hk (abs_pos.mpr hi) le_rfl le_rfl le_rfl rfl hlo
    (fun z hz => le_of_lt (hstable z hz))

end C2.GeneralCompletion
