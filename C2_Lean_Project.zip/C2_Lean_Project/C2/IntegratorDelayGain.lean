import Mathlib.Tactic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
import Mathlib.Data.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Calculus.Deriv.MeanValue

noncomputable section
namespace C2.IntegratorDelay

def lowerFrequency (n : ℕ) : ℝ := Real.pi / (2 * (n : ℝ) + 1)
def upperFrequency (n : ℕ) : ℝ := Real.pi / (2 * (n : ℝ) - 1)
def boundaryGain (n : ℕ) (w : ℝ) : ℝ :=
  2 * Real.tan (w / 2) * Real.sin ((n : ℝ) * w)

theorem frequency_bounds {n : ℕ} (hn : 2 ≤ n) {w : ℝ}
    (hw : w ∈ Set.Icc (lowerFrequency n) (upperFrequency n)) :
    0 < w ∧ w ≤ Real.pi / 3 ∧
      0 < (n : ℝ) * w ∧ (n : ℝ) * w < Real.pi ∧
      (n : ℝ) * w ≤ Real.pi / 2 + w / 2 := by
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  have hlo : 0 < lowerFrequency n := by unfold lowerFrequency; positivity
  have hw0 : 0 < w := lt_of_lt_of_le hlo hw.1
  have hd : 0 < 2 * (n : ℝ) - 1 := by linarith
  have hmul : w * (2 * (n : ℝ) - 1) ≤ Real.pi :=
    (le_div_iff₀ hd).mp hw.2
  have hwpi : w ≤ Real.pi / 3 := by nlinarith
  refine ⟨hw0, hwpi, mul_pos (by linarith) hw0, ?_, ?_⟩
  · nlinarith [Real.pi_pos]
  · linarith

theorem boundaryGain_hasDerivAt (n : ℕ) {w : ℝ}
    (hc : Real.cos (w / 2) ≠ 0) :
    HasDerivAt (boundaryGain n)
      ((Real.sin ((n : ℝ) * w) +
        (n : ℝ) * Real.sin w * Real.cos ((n : ℝ) * w)) /
          Real.cos (w / 2) ^ 2) w := by
  have ht := (Real.hasDerivAt_tan hc).comp w ((hasDerivAt_id w).div_const 2)
  have hs := (Real.hasDerivAt_sin ((n : ℝ) * w)).comp w
    ((hasDerivAt_id w).const_mul (n : ℝ))
  have h := (ht.const_mul 2).mul hs
  convert h using 1
  simp only [Function.comp_apply, id_eq, one_div, mul_one, Real.tan_eq_sin_div_cos]
  have hdouble : Real.sin w = 2 * Real.sin (w / 2) * Real.cos (w / 2) := by
    convert Real.sin_two_mul (w / 2) using 1 <;> ring
  rw [hdouble]
  field_simp [hc]
  ring

/-- The numerator of the derivative has a useful lower bound past its midpoint. -/
theorem gain_derivative_numerator_lower {n : ℕ} (hn : 2 ≤ n) {w : ℝ}
    (hw : w ∈ Set.Icc (lowerFrequency n) (upperFrequency n))
    (hmid : Real.pi / 2 ≤ (n : ℝ) * w) :
    Real.cos (w / 2) * (1 - 2 * (n : ℝ) * Real.sin (w / 2) ^ 2) ≤
      Real.sin ((n : ℝ) * w) +
        (n : ℝ) * Real.sin w * Real.cos ((n : ℝ) * w) := by
  obtain ⟨hw0, hwpi, hnw0, hnwpi, hup⟩ := frequency_bounds hn hw
  let η := (n : ℝ) * w - Real.pi / 2
  have hη0 : 0 ≤ η := by dsimp [η]; linarith
  have hη : η ≤ w / 2 := by dsimp [η]; linarith
  have hc := Real.cos_le_cos_of_nonneg_of_le_pi hη0
    (show w / 2 ≤ Real.pi by linarith [Real.pi_pos]) hη
  have hs := Real.sin_le_sin_of_le_of_le_pi_div_two
    (le_trans (show -(Real.pi / 2) ≤ 0 by linarith [Real.pi_pos]) hη0)
    (show w / 2 ≤ Real.pi / 2 by linarith [Real.pi_pos]) hη
  have hsin : 0 ≤ Real.sin w :=
    Real.sin_nonneg_of_nonneg_of_le_pi hw0.le (by linarith [Real.pi_pos])
  have hn' : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  have hmul := mul_le_mul_of_nonneg_left hs (mul_nonneg hn' hsin)
  have hid1 : Real.sin ((n : ℝ) * w) = Real.cos η := by
    dsimp [η]
    rw [Real.cos_sub, Real.cos_pi_div_two, Real.sin_pi_div_two]
    ring
  have hid2 : Real.cos ((n : ℝ) * w) = -Real.sin η := by
    dsimp [η]
    rw [Real.sin_sub, Real.cos_pi_div_two, Real.sin_pi_div_two]
    ring
  have hdouble : Real.sin w = 2 * Real.sin (w / 2) * Real.cos (w / 2) := by
    convert Real.sin_two_mul (w / 2) using 1 <;> ring
  rw [hid1, hid2]
  rw [hdouble] at hmul ⊢
  nlinarith only [hmul, hc]

theorem gain_sine_bracket_pos {n : ℕ} (hn : 2 ≤ n) {w : ℝ}
    (hw : w ∈ Set.Icc (lowerFrequency n) (upperFrequency n))
    (hstrict : n = 2 → w < upperFrequency n) :
    0 < 1 - 2 * (n : ℝ) * Real.sin (w / 2) ^ 2 := by
  obtain ⟨hw0, hwpi, _, _, _⟩ := frequency_bounds hn hw
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  by_cases hn2 : n = 2
  · subst n
    have hwp : w < Real.pi / 3 := by
      have h := hstrict rfl
      norm_num [upperFrequency] at h
      exact h
    have hs := Real.sin_lt_sin_of_lt_of_le_pi_div_two
      (show -(Real.pi / 2) ≤ w / 2 by linarith [Real.pi_pos])
      (show Real.pi / 6 ≤ Real.pi / 2 by linarith [Real.pi_pos])
      (show w / 2 < Real.pi / 6 by linarith)
    rw [Real.sin_pi_div_six] at hs
    have hs0 : 0 ≤ Real.sin (w / 2) :=
      Real.sin_nonneg_of_nonneg_of_le_pi (by linarith) (by linarith [Real.pi_pos])
    norm_num
    nlinarith
  · have hn3 : (3 : ℝ) ≤ n := by exact_mod_cast (show 3 ≤ n by omega)
    have hd : 0 < 2 * (n : ℝ) - 1 := by linarith
    have hbound : w * (2 * (n : ℝ) - 1) ≤ Real.pi :=
      (le_div_iff₀ hd).mp hw.2
    have hsq : w ^ 2 * (2 * (n : ℝ) - 1) ^ 2 ≤ Real.pi ^ 2 := by
      nlinarith [sq_le_sq₀ (mul_pos hw0 hd).le Real.pi_pos.le |>.mpr hbound]
    have hpi : Real.pi ^ 2 < 10 := by
      nlinarith [Real.pi_pos, Real.pi_lt_d2]
    have hnpi := mul_lt_mul_of_pos_left hpi (show (0 : ℝ) < n by linarith)
    have hpoly : (n : ℝ) * Real.pi ^ 2 < 2 * (2 * (n : ℝ) - 1) ^ 2 := by
      nlinarith [sq_nonneg ((n : ℝ) - 3)]
    have hmul := mul_le_mul_of_nonneg_left hsq (Nat.cast_nonneg n : (0 : ℝ) ≤ n)
    have hneg : ((n : ℝ) * w ^ 2 - 2) * (2 * (n : ℝ) - 1) ^ 2 < 0 := by
      nlinarith
    have hsmall : (n : ℝ) * w ^ 2 < 2 := by
      by_contra! hb
      have hnon := mul_nonneg (show 0 ≤ (n : ℝ) * w ^ 2 - 2 by linarith)
        (sq_nonneg (2 * (n : ℝ) - 1))
      linarith
    have hs := mul_le_mul_of_nonneg_left (Real.sin_sq_le_sq (x := w / 2))
      (show 0 ≤ 2 * (n : ℝ) by positivity)
    nlinarith

theorem boundaryGain_deriv_pos {n : ℕ} (hn : 2 ≤ n) {w : ℝ}
    (hw : w ∈ Set.Icc (lowerFrequency n) (upperFrequency n))
    (hstrict : n = 2 → w < upperFrequency n) :
    0 < deriv (boundaryGain n) w := by
  obtain ⟨hw0, hwpi, hnw0, hnwpi, hup⟩ := frequency_bounds hn hw
  have hc : 0 < Real.cos (w / 2) := Real.cos_pos_of_mem_Ioo
    ⟨by linarith [Real.pi_pos], by linarith [Real.pi_pos]⟩
  rw [(boundaryGain_hasDerivAt n hc.ne').deriv]
  apply div_pos _ (sq_pos_of_pos hc)
  by_cases hmid : Real.pi / 2 ≤ (n : ℝ) * w
  · exact lt_of_lt_of_le (mul_pos hc (gain_sine_bracket_pos hn hw hstrict))
      (gain_derivative_numerator_lower hn hw hmid)
  · have hcos : 0 ≤ Real.cos ((n : ℝ) * w) :=
      Real.cos_nonneg_of_mem_Icc ⟨by linarith [Real.pi_pos], by linarith⟩
    have hsin : 0 ≤ Real.sin w :=
      Real.sin_nonneg_of_nonneg_of_le_pi hw0.le (by linarith [Real.pi_pos])
    exact add_pos_of_pos_of_nonneg (Real.sin_pos_of_pos_of_lt_pi hnw0 hnwpi)
      (mul_nonneg (mul_nonneg (Nat.cast_nonneg n) hsin) hcos)

/-- `lem:gainmonotone`: strict increase on the entire closed frequency interval. -/
theorem boundaryGain_strictMonoOn {n : ℕ} (hn : 2 ≤ n) :
    StrictMonoOn (boundaryGain n) (Set.Icc (lowerFrequency n) (upperFrequency n)) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc _ _) ?_ ?_
  · intro w hw
    obtain ⟨hw0, hwpi, _, _, _⟩ := frequency_bounds hn hw
    have hc : 0 < Real.cos (w / 2) := Real.cos_pos_of_mem_Ioo
      ⟨by linarith [Real.pi_pos], by linarith [Real.pi_pos]⟩
    exact (boundaryGain_hasDerivAt n hc.ne').continuousAt.continuousWithinAt
  · intro w hw
    rw [interior_Icc] at hw
    exact boundaryGain_deriv_pos hn ⟨hw.1.le, hw.2.le⟩ (fun _ => hw.2)

theorem boundaryGain_deriv_two_upper :
    deriv (boundaryGain 2) (upperFrequency 2) = 0 := by
  have hw : upperFrequency 2 = Real.pi / 3 := by norm_num [upperFrequency]
  rw [hw]
  have hc : Real.cos ((Real.pi / 3) / 2) ≠ 0 :=
    (Real.cos_pos_of_mem_Ioo ⟨by linarith [Real.pi_pos], by linarith [Real.pi_pos]⟩).ne'
  rw [(boundaryGain_hasDerivAt 2 hc).deriv]
  have hsin := Real.sin_two_mul (Real.pi / 3)
  have hcos := Real.cos_two_mul (Real.pi / 3)
  rw [Real.cos_pi_div_three] at hsin hcos
  norm_num at hsin hcos
  norm_num only [Nat.cast_ofNat]
  apply div_eq_zero_iff.mpr
  left
  rw [hsin, hcos, Real.sin_pi_div_three]
  ring

end C2.IntegratorDelay
