import C2.SecondOrder

/-! Exact rational bisection for the second-order optimizer. The executable
iteration uses only rational arithmetic and a rational sign comparison. -/

namespace C2.SecondOrder

def rationalCubic (u v t : ℚ) : ℚ := v*t^3 + 2*u*t^2 + (4-u)*t - 4

def rationalBisectStep (u v : ℚ) (I : ℚ × ℚ) : ℚ × ℚ :=
  let m := (I.1 + I.2)/2
  if rationalCubic u v m ≤ 0 then (m,I.2) else (I.1,m)

def rationalBisect (u v : ℚ) : ℕ → ℚ × ℚ
  | 0 => (0,1)
  | n+1 => rationalBisectStep u v (rationalBisect u v n)

@[simp] theorem rationalCubic_cast (u v t : ℚ) :
    (rationalCubic u v t : ℝ) = f (u:ℝ) (v:ℝ) (t:ℝ) := by
  unfold rationalCubic f
  push_cast
  rfl

theorem rationalBisectStep_nested {u v : ℚ} {I : ℚ × ℚ} (hI : I.1 ≤ I.2) :
    I.1 ≤ (rationalBisectStep u v I).1 ∧
    (rationalBisectStep u v I).1 ≤ (rationalBisectStep u v I).2 ∧
    (rationalBisectStep u v I).2 ≤ I.2 := by
  unfold rationalBisectStep
  dsimp only
  split_ifs <;> dsimp <;> refine ⟨?_,?_,?_⟩ <;> linarith

theorem rationalBisectStep_width (u v : ℚ) (I : ℚ × ℚ) :
    (rationalBisectStep u v I).2 - (rationalBisectStep u v I).1 =
      (I.2-I.1)/2 := by
  unfold rationalBisectStep
  dsimp only
  split_ifs <;> dsimp <;> ring

theorem rationalBisectStep_contains {u v : ℚ} {r : ℝ} {I : ℚ × ℚ}
    (hu : 0 < (u:ℝ)) (hv : 0 < (v:ℝ)) (hr : 0 < r)
    (hf : f (u:ℝ) (v:ℝ) r = 0) (hlo : 0 ≤ I.1)
    (hlr : (I.1:ℝ) ≤ r) (hrh : r ≤ (I.2:ℝ)) :
    ((rationalBisectStep u v I).1:ℝ) ≤ r ∧
      r ≤ ((rationalBisectStep u v I).2:ℝ) := by
  have hm : 0 < (((I.1+I.2)/2:ℚ):ℝ) := by
    push_cast
    have hl : (0:ℝ) ≤ (I.1:ℝ) := by exact_mod_cast hlo
    linarith
  unfold rationalBisectStep
  dsimp only
  split_ifs with h
  · dsimp
    refine ⟨?_,hrh⟩
    by_contra hn
    have hp := (root_lt_iff hu hv hr hf hm).mp (lt_of_not_ge hn)
    have hcast : f (u:ℝ) (v:ℝ) (((I.1+I.2)/2:ℚ):ℝ) ≤ 0 := by
      rw [← rationalCubic_cast]
      exact_mod_cast h
    linarith
  · dsimp
    refine ⟨hlr,?_⟩
    have hp : 0 < f (u:ℝ) (v:ℝ) (((I.1+I.2)/2:ℚ):ℝ) := by
      rw [← rationalCubic_cast]
      exact_mod_cast (lt_of_not_ge h)
    exact ((root_lt_iff hu hv hr hf hm).mpr hp).le

theorem rationalBisect_invariants {u v : ℚ} {r : ℝ}
    (hu : 0 < (u:ℝ)) (hv : 0 < (v:ℝ)) (hr : 0 < r) (hr1 : r < 1)
    (hf : f (u:ℝ) (v:ℝ) r = 0) (n : ℕ) :
    0 ≤ (rationalBisect u v n).1 ∧
    (rationalBisect u v n).1 ≤ (rationalBisect u v n).2 ∧
    (rationalBisect u v n).2 ≤ 1 ∧
    ((rationalBisect u v n).1:ℝ) ≤ r ∧ r ≤ ((rationalBisect u v n).2:ℝ) := by
  induction n with
  | zero =>
    norm_num [rationalBisect]
    exact ⟨hr.le,hr1.le⟩
  | succ n ih =>
    obtain ⟨hl,ho,hh,hlr,hrh⟩ := ih
    obtain ⟨hnl,hno,hnh⟩ := rationalBisectStep_nested (u:=u) (v:=v) ho
    obtain ⟨hnlr,hnrh⟩ := rationalBisectStep_contains hu hv hr hf hl hlr hrh
    exact ⟨hl.trans hnl,hno,hnh.trans hh,hnlr,hnrh⟩

theorem rationalBisect_nested {u v : ℚ} {r : ℝ}
    (hu : 0 < (u:ℝ)) (hv : 0 < (v:ℝ)) (hr : 0 < r) (hr1 : r < 1)
    (hf : f (u:ℝ) (v:ℝ) r = 0) (n : ℕ) :
    (rationalBisect u v n).1 ≤ (rationalBisect u v (n+1)).1 ∧
      (rationalBisect u v (n+1)).2 ≤ (rationalBisect u v n).2 := by
  have h := rationalBisectStep_nested (u:=u) (v:=v)
    (rationalBisect_invariants hu hv hr hr1 hf n).2.1
  exact ⟨h.1,h.2.2⟩

theorem rationalBisect_exact_width (u v : ℚ) (n : ℕ) :
    (rationalBisect u v n).2 - (rationalBisect u v n).1 = (1/2:ℚ)^n := by
  induction n with
  | zero => norm_num [rationalBisect]
  | succ n ih =>
    change (rationalBisectStep u v (rationalBisect u v n)).2 -
      (rationalBisectStep u v (rationalBisect u v n)).1 = _
    rw [rationalBisectStep_width,ih,pow_succ]
    ring

/-- Any iterate strictly inside (0,1) yields both optimizer enclosures. -/
theorem rationalBisect_optimizer_enclosures {u v : ℚ} {r : ℝ}
    (hu : 0 < (u:ℝ)) (hv : 0 < (v:ℝ)) (hr : 0 < r) (hr1 : r < 1)
    (hf : f (u:ℝ) (v:ℝ) r = 0) (n : ℕ)
    (hlo : 0 < (rationalBisect u v n).1) :
    gamma ((rationalBisect u v n).1:ℝ) ≤ gamma r ∧
    gamma r ≤ gamma ((rationalBisect u v n).2:ℝ) ∧
    optimum (u:ℝ) ((rationalBisect u v n).2:ℝ) ≤ optimum (u:ℝ) r ∧
    optimum (u:ℝ) r ≤ optimum (u:ℝ) ((rationalBisect u v n).1:ℝ) := by
  have h := rationalBisect_invariants hu hv hr hr1 hf n
  exact root_bracket_enclosures hu (by exact_mod_cast hlo) h.2.2.2.1 h.2.2.2.2

/-- Arbitrary requested accuracy is reached after finitely many rational steps. -/
theorem rationalBisect_termination (u v : ℚ) {ε : ℝ} (hε : 0 < ε) :
    ∃ N : ℕ, ∀ n ≥ N,
      ((rationalBisect u v n).2:ℝ) - ((rationalBisect u v n).1:ℝ) < ε := by
  have ht := tendsto_pow_atTop_nhds_zero_of_lt_one
    (by norm_num : (0:ℝ) ≤ 1/2) (by norm_num : (1/2:ℝ) < 1)
  obtain ⟨N,hN⟩ := Filter.eventually_atTop.mp (ht.eventually (gt_mem_nhds hε))
  refine ⟨N,fun n hn => ?_⟩
  have hw : ((rationalBisect u v n).2:ℝ) - ((rationalBisect u v n).1:ℝ) = (1/2:ℝ)^n := by
    have h := congrArg (fun q : ℚ => (q : ℝ)) (rationalBisect_exact_width u v n)
    push_cast at h
    exact h
  rw [hw]
  exact hN n hn

/-- After finitely many steps both rational endpoints are strictly inside
(0,1), with arbitrary accuracy and rigorous optimizer enclosures. -/
theorem rationalBisect_eventually_interior {u v : ℚ} {r ε : ℝ}
    (hu : 0 < (u:ℝ)) (hv : 0 < (v:ℝ)) (hr : 0 < r) (hr1 : r < 1)
    (hf : f (u:ℝ) (v:ℝ) r = 0) (hε : 0 < ε) :
    ∃ N : ℕ, ∀ n ≥ N,
      0 < (rationalBisect u v n).1 ∧ (rationalBisect u v n).2 < 1 ∧
      ((rationalBisect u v n).1:ℝ) ≤ r ∧ r ≤ ((rationalBisect u v n).2:ℝ) ∧
      ((rationalBisect u v n).2:ℝ) - ((rationalBisect u v n).1:ℝ) < ε := by
  have he : 0 < min ε (min r (1-r)) := lt_min hε (lt_min hr (by linarith))
  obtain ⟨N,hN⟩ := rationalBisect_termination u v he
  refine ⟨N,fun n hn => ?_⟩
  have hb := rationalBisect_invariants hu hv hr hr1 hf n
  have hw := hN n hn
  have heps := lt_of_lt_of_le hw (min_le_left _ _)
  have hwr := lt_of_lt_of_le hw ((min_le_right _ _).trans (min_le_left _ _))
  have hw1 := lt_of_lt_of_le hw ((min_le_right _ _).trans (min_le_right _ _))
  have hlo : (0:ℝ) < ((rationalBisect u v n).1:ℝ) := by linarith [hb.2.2.2.2]
  have hhi : ((rationalBisect u v n).2:ℝ) < 1 := by linarith [hb.2.2.2.1]
  exact ⟨by exact_mod_cast hlo,by exact_mod_cast hhi,hb.2.2.2.1,hb.2.2.2.2,heps⟩

/-- Manuscript corollary, with an actual rational algorithm and all its
termination, containment, and induced-optimizer guarantees. -/
theorem rational_isolation_complete {u v : ℚ} (hu : 0 < u) (hv : 0 < v)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ r : ℝ, 0 < r ∧ r < 1 ∧ f (u:ℝ) (v:ℝ) r = 0 ∧
      ∃ N : ℕ, ∀ n ≥ N,
        0 < (rationalBisect u v n).1 ∧ (rationalBisect u v n).2 < 1 ∧
        ((rationalBisect u v n).1:ℝ) ≤ r ∧ r ≤ ((rationalBisect u v n).2:ℝ) ∧
        ((rationalBisect u v n).2:ℝ) - ((rationalBisect u v n).1:ℝ) < ε ∧
        gamma ((rationalBisect u v n).1:ℝ) ≤ gamma r ∧
        gamma r ≤ gamma ((rationalBisect u v n).2:ℝ) ∧
        optimum (u:ℝ) ((rationalBisect u v n).2:ℝ) ≤ optimum (u:ℝ) r ∧
        optimum (u:ℝ) r ≤ optimum (u:ℝ) ((rationalBisect u v n).1:ℝ) := by
  have hu' : 0 < (u:ℝ) := by exact_mod_cast hu
  have hv' : 0 < (v:ℝ) := by exact_mod_cast hv
  obtain ⟨r,⟨hr,hr1,hf⟩,_⟩ := exists_unique_optimal_root hu' hv'
  obtain ⟨N,hN⟩ := rationalBisect_eventually_interior hu' hv' hr hr1 hf hε
  refine ⟨r,hr,hr1,hf,N,fun n hn => ?_⟩
  obtain ⟨hl,hh,hlr,hrh,hw⟩ := hN n hn
  obtain ⟨hgl,hgh,hbl,hbh⟩ := rationalBisect_optimizer_enclosures hu' hv' hr hr1 hf n hl
  exact ⟨hl,hh,hlr,hrh,hw,hgl,hgh,hbl,hbh⟩

end C2.SecondOrder
