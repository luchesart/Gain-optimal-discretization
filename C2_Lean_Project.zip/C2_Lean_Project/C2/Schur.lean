import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.Algebra.QuadraticDiscriminant
import Mathlib.Tactic

/-! # Root-based Schur stability of a real quadratic

`QuadraticSchur` quantifies over actual complex zeros and the complex norm.
It is not defined to mean the Jury inequalities. The equivalence below
supplies the bridge from algebraic parameter inequalities to pole locations.
-/

namespace C2

def QuadraticSchur (L b c : ℝ) : Prop :=
  ∀ z : ℂ, (L : ℂ) * z ^ 2 + (b : ℂ) * z + (c : ℂ) = 0 → ‖z‖ < 1

lemma quadratic_root_parts {L b c : ℝ} {z : ℂ}
    (hz : (L : ℂ) * z ^ 2 + (b : ℂ) * z + (c : ℂ) = 0) :
    L * (z.re ^ 2 - z.im ^ 2) + b * z.re + c = 0 ∧
      z.im * (2 * L * z.re + b) = 0 := by
  have hr := congrArg Complex.re hz
  have hi := congrArg Complex.im hz
  simp [pow_two, Complex.mul_re, Complex.mul_im] at hr hi
  constructor <;> nlinarith

theorem quadraticSchur_of_jury {L b c : ℝ} (hL : 0 < L)
    (hplus : 0 < L + b + c) (hminus : 0 < L - b + c)
    (hc : 0 < L - c) : QuadraticSchur L b c := by
  classical
  intro z hz
  obtain ⟨hr, hi⟩ := quadratic_root_parts hz
  have hnorm : ‖z‖ ^ 2 = z.re ^ 2 + z.im ^ 2 := by
    rw [Complex.sq_norm, Complex.normSq_apply]
    ring
  by_cases hy : z.im = 0
  · have hxlt : z.re < 1 := by
      by_contra! hx
      have hterm : 0 ≤ (z.re - 1) * (L * z.re - c) :=
        mul_nonneg (by linarith) (by nlinarith)
      have hpos : 0 < z.re * (L + b + c) := mul_pos (by linarith) hplus
      simp only [hy, zero_pow, sub_zero] at hr
      nlinarith
    have hxgt : -1 < z.re := by
      by_contra! hx
      have hterm : 0 ≤ (z.re + 1) * (L * z.re + c) :=
        mul_nonneg_of_nonpos_of_nonpos (by linarith) (by nlinarith)
      have hneg : z.re * (L - b + c) < 0 := mul_neg_of_neg_of_pos (by linarith) hminus
      simp only [hy, zero_pow, sub_zero] at hr
      nlinarith
    have hx2 : z.re ^ 2 < 1 := by nlinarith [mul_pos (by linarith : 0 < 1-z.re) (by linarith : 0 < 1+z.re)]
    rw [hy] at hnorm
    nlinarith [norm_nonneg z]
  · have hlin : 2 * L * z.re + b = 0 := (mul_eq_zero.mp hi).resolve_left hy
    have hprod : L * (z.re ^ 2 + z.im ^ 2) = c := by nlinarith
    have hsq : z.re ^ 2 + z.im ^ 2 < 1 := by nlinarith
    nlinarith [norm_nonneg z]

lemma quadratic_has_root {L b c : ℝ} (hL : L ≠ 0) :
    ∃ z : ℂ, (L : ℂ) * z ^ 2 + (b : ℂ) * z + (c : ℂ) = 0 := by
  obtain ⟨z, hz⟩ := exists_quadratic_eq_zero (a := (L : ℂ)) (b := (b : ℂ))
    (c := (c : ℂ)) (by exact_mod_cast hL)
    (IsAlgClosed.exists_eq_mul_self (discrim (L : ℂ) (b : ℂ) (c : ℂ)))
  exact ⟨z, by simpa [pow_two] using hz⟩

theorem jury_of_quadraticSchur {L b c : ℝ} (hL : 0 < L)
    (hs : QuadraticSchur L b c) :
    0 < L + b + c ∧ 0 < L - b + c ∧ 0 < L - c := by
  classical
  have hLr : L ≠ 0 := ne_of_gt hL
  have hLc : (L : ℂ) ≠ 0 := by exact_mod_cast hLr
  obtain ⟨z, hz⟩ := quadratic_has_root (b := b) (c := c) hLr
  let w : ℂ := -(b : ℂ) / (L : ℂ) - z
  have hw : (L : ℂ) * w ^ 2 + (b : ℂ) * w + (c : ℂ) = 0 := by
    dsimp [w]
    field_simp [hLc]
    linear_combination (L : ℂ) ^ 3 * hz
  have hprod : (L : ℂ) * z * w = (c : ℂ) := by
    dsimp [w]
    field_simp [hLc]
    linear_combination -(L : ℂ) * hz
  have hsum : (L : ℂ) * (z + w) = -(b : ℂ) := by
    dsimp [w]
    field_simp [hLc]
    ring
  have hzn := hs z hz
  have hwn := hs w hw
  have hmul : ‖z‖ * ‖w‖ < 1 := by
    calc
      ‖z‖ * ‖w‖ ≤ ‖z‖ * 1 := mul_le_mul_of_nonneg_left hwn.le (norm_nonneg z)
      _ < 1 := by simpa using hzn
  have hcabs : |c| < L := by
    calc
      |c| = ‖(L : ℂ) * z * w‖ := by rw [hprod]; simp
      _ = L * (‖z‖ * ‖w‖) := by simp [norm_mul, Complex.norm_real, abs_of_pos hL]; ring
      _ < L * 1 := mul_lt_mul_of_pos_left hmul hL
      _ = L := mul_one L
  have hc : 0 < L - c := by have := (le_abs_self c).trans_lt hcabs; linarith
  obtain ⟨hr, hi⟩ := quadratic_root_parts hz
  by_cases hy : z.im = 0
  · have hwy : w.im = 0 := by simp [w, hy]
    have hzx : -1 < z.re ∧ z.re < 1 := abs_lt.mp ((Complex.abs_re_le_norm z).trans_lt hzn)
    have hwx : -1 < w.re ∧ w.re < 1 := abs_lt.mp ((Complex.abs_re_le_norm w).trans_lt hwn)
    have hpr := congrArg Complex.re hprod
    have hsu := congrArg Complex.re hsum
    simp [Complex.mul_re, hy, hwy] at hpr hsu
    have hpos := mul_pos hL (mul_pos (by linarith : 0 < 1-z.re) (by linarith : 0 < 1-w.re))
    have hneg := mul_pos hL (mul_pos (by linarith : 0 < 1+z.re) (by linarith : 0 < 1+w.re))
    exact ⟨by nlinarith, by nlinarith, hc⟩
  · have hlin : 2 * L * z.re + b = 0 := (mul_eq_zero.mp hi).resolve_left hy
    have hpos := mul_pos hL (add_pos_of_nonneg_of_pos (sq_nonneg (z.re-1)) (sq_pos_of_ne_zero hy))
    have hneg := mul_pos hL (add_pos_of_nonneg_of_pos (sq_nonneg (z.re+1)) (sq_pos_of_ne_zero hy))
    exact ⟨by nlinarith, by nlinarith, hc⟩

theorem quadraticSchur_iff {L b c : ℝ} (hL : 0 < L) :
    QuadraticSchur L b c ↔ 0 < L + b + c ∧ 0 < L - b + c ∧ 0 < L - c :=
  ⟨jury_of_quadraticSchur hL, fun h => quadraticSchur_of_jury hL h.1 h.2.1 h.2.2⟩

theorem quadratic_hurwitz_of_positive {L b c : ℝ}
    (hL : 0 < L) (hb : 0 < b) (hc : 0 < c) {z : ℂ}
    (hz : (L:ℂ)*z^2+(b:ℂ)*z+(c:ℂ)=0) : z.re < 0 := by
  obtain ⟨hr,hi⟩ := quadratic_root_parts hz
  by_cases hy : z.im = 0
  · by_contra hx
    have hx0 : 0 ≤ z.re := le_of_not_gt hx
    have h1 := mul_nonneg hL.le (sq_nonneg z.re)
    have h2 := mul_nonneg hb.le hx0
    rw [hy] at hr
    nlinarith
  · have hlin := (mul_eq_zero.mp hi).resolve_left hy
    nlinarith

end C2
