import C2.CADEffectivePolynomial
import C2.CADEffectiveSearch
import C2.CADFactorSquarefree

/-! A genuinely executable square-free reducer. It enumerates five dense
rational polynomials and checks three identities. Mathematical gcds prove
existence of accepted data but are not called by the extracted algorithm. -/
namespace C2.CADEffective.Dense
open Polynomial

abbrev ReductionData := Poly × Poly × Poly × Poly × Poly

def reductionCheck (p : Poly) (w : ReductionData) : Bool :=
  eqb p (mul w.2.1 w.1) &&
    eqb (mul (derivative p) w.1) (mul p w.2.2.1) &&
      eqb (add (mul w.2.2.2.1 w.1) (mul w.2.2.2.2 (derivative w.1))) [1]

theorem reductionCheck_iff (p : Poly) (w : ReductionData) :
    reductionCheck p w = true ↔
      (denote p = denote w.2.1 * denote w.1 ∧
        (denote p).derivative * denote w.1 = denote p * denote w.2.2.1) ∧
      denote w.2.2.2.1 * denote w.1 +
        denote w.2.2.2.2 * (denote w.1).derivative = 1 := by
  simp [reductionCheck, Bool.and_eq_true, eqb_eq_true_iff]

theorem exists_reductionCheck (p : Poly) (hp : denote p ≠ 0) :
    ∃ w : ReductionData, reductionCheck p w = true := by
  obtain ⟨q,g,h,u,v,hp1,hp2,hp3⟩ := C2.CADFactor.exists_squarefree_reduction_witnesses (denote p) hp
  obtain ⟨q',hq'⟩ := exists_encoding q
  obtain ⟨g',hg'⟩ := exists_encoding g
  obtain ⟨h',hh'⟩ := exists_encoding h
  obtain ⟨u',hu'⟩ := exists_encoding u
  obtain ⟨v',hv'⟩ := exists_encoding v
  refine ⟨(q',g',h',u',v'), (reductionCheck_iff _ _).mpr ?_⟩
  simpa only [hq',hg',hh',hu',hv'] using And.intro (And.intro hp1 hp2) hp3

def produceReduction (p : Poly) (hp : denote p ≠ 0) : ReductionData :=
  C2.CADEffective.search (reductionCheck p) (exists_reductionCheck p hp)

theorem produceReduction_accepted (p : Poly) (hp : denote p ≠ 0) :
    reductionCheck p (produceReduction p hp) = true :=
  C2.CADEffective.search_accepted _ _

def reducedPoly (p : Poly) (hp : denote p ≠ 0) : Poly := (produceReduction p hp).1

theorem reductionCheck_sound (p : Poly) (hp : denote p ≠ 0) (w : ReductionData)
    (hw : reductionCheck p w = true) :
    (denote w.1).Separable ∧ denote w.1 ≠ 0 ∧
      ∀ {E : Type*} [Field E] [CharZero E] (f : ℚ →+* E) (x : E),
        (denote w.1).eval₂ f x = 0 ↔ (denote p).eval₂ f x = 0 := by
  obtain ⟨⟨hpg,hph⟩,huv⟩ := (reductionCheck_iff _ _).mp hw
  exact C2.CADFactor.squarefree_reduction_witnesses_sound hp hpg hph huv

theorem reducedPoly_correct (p : Poly) (hp : denote p ≠ 0) :
    (denote (reducedPoly p hp)).Separable ∧ denote (reducedPoly p hp) ≠ 0 ∧
      ∀ {E : Type*} [Field E] [CharZero E] (f : ℚ →+* E) (x : E),
        (denote (reducedPoly p hp)).eval₂ f x = 0 ↔ (denote p).eval₂ f x = 0 :=
  reductionCheck_sound p hp _ (produceReduction_accepted p hp)

theorem produceReduction_finite_execution (p : Poly) (hp : denote p ≠ 0) :
    ∃ fuel w, C2.CADEffective.scanFrom (reductionCheck p) 0 fuel = some w ∧
      reductionCheck p w = true := by
  obtain ⟨w,hw,hc⟩ := C2.CADEffective.search_has_finite_execution
    (reductionCheck p) (exists_reductionCheck p hp)
  exact ⟨_,w,hw,hc⟩

end C2.CADEffective.Dense
