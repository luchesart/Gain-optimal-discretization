import C2.NGammaOuter
import Mathlib.Analysis.SpecificLimits.Basic

/-! Genuine optimizing feasible allocations along frequencies tending to zero.
This supplies the sequence used by the endpoint compactness argument. -/
noncomputable section
open scoped BigOperators Topology
open Set Filter
namespace C2.NGamma.Global

theorem exists_optimizing_endpoint_sequence {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hS : endpointSum r ≤ 1) :
    ∃ ws : ℕ → ℝ, ∃ xs : ℕ → Fin n → ℝ,
      Tendsto ws atTop (𝓝 0) ∧
      (∀ k, 0 < ws k ∧ (∀ j, xs k j ∈ Icc (0:ℝ) 1) ∧
        (∑ j, allocationPhase (r j) (xs k j) (ws k)) = 2*Real.arctan (ws k) ∧
        Real.exp (frequencyValue r (ws k)) = ∏ j, allocationGain (r j) (xs k j) (ws k)) ∧
      ∀ w, 0 < w → feasible r w →
        ∀ᶠ k in atTop, Real.exp (frequencyValue r w) < ∏ j, allocationGain (r j) (xs k j) (ws k) := by
  obtain ⟨wp,hwp,hcross,hsmall,hlarge⟩ := feasible_frequency_interval hn r hr
  let ws : ℕ → ℝ := fun k => wp / ((k:ℝ)+1)
  have hwpos : ∀ k, 0 < ws k := fun k => div_pos hwp (by positivity)
  have hwle : ∀ k, ws k ≤ wp := by
    intro k
    dsimp [ws]
    apply (div_le_iff₀ (by positivity : 0 < (k:ℝ)+1)).2
    have hk : (0:ℝ) ≤ (k:ℝ) := Nat.cast_nonneg k
    nlinarith
  have hf : ∀ k, feasible r (ws k) := fun k => (hsmall hS (ws k) (hwpos k)).2 (hwle k)
  have hex : ∀ k, ∃ lam, frequencyAllocatedPhase r (ws k) lam = 2*Real.arctan (ws k) :=
    fun k => exists_balancing_multiplier r hr (hwpos k) (hf k)
  choose lam hlam using hex
  let xs : ℕ → Fin n → ℝ := fun k j => frequencyAllocation (r j) (ws k) (lam k)
  have hlim : Tendsto ws atTop (𝓝 0) := by
    have ht := (tendsto_one_div_add_atTop_nhds_zero_nat).const_mul wp
    simpa only [mul_zero,mul_one_div] using ht
  refine ⟨ws,xs,hlim,?_,?_⟩
  · intro k
    exact ⟨hwpos k,fun j => frequencyAllocation_mem _ _ _,hlam k,
      exp_frequencyValue_eq_product r hr (hwpos k) (hlam k)⟩
  · intro w hw hfw
    have he : ∀ᶠ k in atTop, ws k < w := hlim (Iio_mem_nhds hw)
    filter_upwards [he] with k hk
    rw [← exp_frequencyValue_eq_product r hr (hwpos k) (hlam k)]
    exact Real.exp_lt_exp.mpr
      (frequencyValue_strictAntiOn_feasible hn r hr ⟨hwpos k,hf k⟩ ⟨hw,hfw⟩ hk)

end C2.NGamma.Global
