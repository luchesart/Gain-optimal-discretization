#!/usr/bin/env python3
"""Rebuild the umbrella module and the same-source single-file version."""
from pathlib import Path
import re,sys,json
sys.path.insert(0,str(Path(__file__).resolve().parent))
from theorem_inventory import without_comments_and_strings
root=Path(__file__).resolve().parents[1]
files={f'C2.{p.stem}':p for p in (root/'C2').glob('*.lean')}
order=[]; active=set()
def visit(m):
 if m in order:return
 if m in active:raise RuntimeError('Cyclic imports')
 active.add(m)
 for imp in re.findall(r'^import\s+(\S+)\s*$',files[m].read_text(),re.M):
  if imp.startswith('C2.'):
   if imp not in files:raise RuntimeError(f'Missing module {imp}')
   visit(imp)
 active.remove(m);order.append(m)
for m in sorted(files):visit(m)
(root/'C2.lean').write_text(''.join('import '+m+'\n' for m in order))
chunks=['import Mathlib\n\n/-! C2 rational-delay optimization. Generated from the modular project.\nPinned: Lean 4.19.0; mathlib c44e0c8ee63ca166450922a373c7409c5d26b00b.\nRun tools/make_single_file.py after edits. Formal scope: PROOF_MAP_EN.csv.\nLocally compiled; no claim of a live.lean website session. -/\n']
for m in order:
 text=files[m].read_text()
 clean=without_comments_and_strings(text)
 stack=[]
 for line in clean.splitlines():
  if re.match(r'^\s*namespace\s+',line):stack.append('namespace')
  elif re.match(r'^\s*(?:noncomputable\s+)?section(?:\s|$)',line):stack.append('section')
  elif re.match(r'^\s*end(?:\s+\S+)?\s*$',line):stack.pop()
 assert all(s=='section' for s in stack)
 text=re.sub(r'^import\s+[^\n]+\n','',text,flags=re.M)
 chunks.append('\n/- ===== '+m+' ===== -/\n'+text+'\n'+'end\n'*len(stack))
(root/'live/C2_Live_Lean419.lean').write_text(''.join(chunks))
print(json.dumps({'module_order':order,'single_file_lines':sum(c.count('\n') for c in chunks)},indent=2))
