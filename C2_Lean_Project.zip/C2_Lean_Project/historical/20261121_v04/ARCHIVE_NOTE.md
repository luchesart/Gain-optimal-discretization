# Archived v0.4.0 metadata

These are byte-identical snapshots of the release metadata, inventory, generated
source and axiom audit before the v0.5.0 integration. Their dates and scope remain
historical; the active verdict is ../../VERIFICATION.json. References inside
these snapshots retain their original project-root meaning. Original dated
validation logs remain under ../../validation/20261109, and all original 208
proof modules remain byte-identical in the current C2 directory.
