# C2 Theorem 3 — completed, 9 November 2026

The former remaining-obligations record is archived at ../historical/20261109_v03/validation/cad_remaining_20261109.md. It is superseded by the completed native algorithm and its actual-output theorem C2.CADNative.native_gain_projection_correct. See cad_native_theorem_completion_20261109.json and cad_end_to_end_review_20261109.json. The global release checks are recorded in ../VERIFICATION.json.

The verified procedure uses finite rational factor/Bézout data search, squarefree reduction, dyadic isolation and rational samples. It proves termination and the actual algebraic global supremum. It does not verify the separate SymPy/resultant implementation or claim competitive running time.
