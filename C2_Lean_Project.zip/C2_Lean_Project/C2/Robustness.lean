import C2.FirstOrderSchur

/-! Exact closed rectangular robustness box for the one-sample integrator.
The conclusion uses actual complex-root Schur stability, via FirstOrder.Stable.
-/
namespace C2.Robustness

def BoxStable (a₀ δ ρ : ℝ) : Prop :=
  ∀ γ ∈ Set.Icc (3 / 4 - δ) (3 / 4 + δ),
    ∀ a ∈ Set.Icc (a₀ * (1 - ρ)) (a₀ * (1 + ρ)),
      C2.FirstOrder.Stable 0 γ a

theorem exact_rectangular_budget {a₀ δ ρ : ℝ}
    (ha₀ : 0 < a₀) (hδ : 0 ≤ δ) (hδu : δ ≤ 1 / 4)
    (hρ : 0 ≤ ρ) (hρu : ρ < 1) :
    BoxStable a₀ δ ρ ↔ a₀ < 4 / ((1 + ρ) * (1 + 4 * δ)) := by
  have hp : 0 < (1 + ρ) * (1 + 4 * δ) := mul_pos (by linarith) (by linarith)
  rw [lt_div_iff₀ hp]
  constructor
  · intro h
    have hs := h (3 / 4 - δ) ⟨le_rfl, by linarith⟩
      (a₀ * (1 + ρ)) ⟨by nlinarith only [mul_nonneg ha₀.le hρ], le_rfl⟩
    have hj := (C2.FirstOrder.stable_iff_jury (r := 0) (by norm_num)
      (γ := 3 / 4 - δ) (by linarith)).mp hs
    unfold C2.FirstOrder.Jury at hj
    nlinarith only [hj.2.2]
  · intro hb
    intro γ hγ a ha
    have hγ0 : 0 ≤ γ := by linarith [hγ.1]
    apply (C2.FirstOrder.stable_iff_jury (r := 0) (by norm_num) hγ0).mpr
    have ha0 : 0 < a := lt_of_lt_of_le (mul_pos ha₀ (by linarith)) ha.1
    have hcap : a * (1 + 4 * δ) < 4 := by
      have hm := mul_le_mul_of_nonneg_right ha.2 (by linarith : 0 ≤ 1 + 4 * δ)
      nlinarith only [hm, hb]
    unfold C2.FirstOrder.Jury
    refine ⟨ha0, ?_, ?_⟩
    · have hm := mul_le_mul_of_nonneg_left hγ.2 ha0.le
      nlinarith only [hm, hcap]
    · have hm := mul_le_mul_of_nonneg_left hγ.1 ha0.le
      nlinarith only [hm, hcap]

end C2.Robustness
