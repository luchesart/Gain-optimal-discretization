import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Tactic

/-!
# Identical positive factors: exact closed-form consequences

These results prove the algebraic and trigonometric specializations used in
`cor:ngamma-identical-global`.  Global maximality is not defined or assumed in
this module: it must be supplied by the arbitrary-order optimization theorem.
-/

noncomputable section
namespace C2.NGammaEqual

def endpointCoordinate (m r : ℝ) : ℝ := m / (1 + Real.sqrt (1 + m * r))
def endpointGamma (m r : ℝ) : ℝ := (1 + endpointCoordinate m r) / 2
def endpointGain (n : ℕ) (r : ℝ) : ℝ :=
  (r + 2 / (n : ℝ) * (1 + Real.sqrt (1 + (n : ℝ) * r))) ^ n

lemma endpointCoordinate_pos {m r : ℝ} (hm : 0 < m) :
    0 < endpointCoordinate m r := by
  unfold endpointCoordinate
  exact div_pos hm (by positivity)

lemma endpointCoordinate_resource {m r : ℝ} (hm : 0 ≤ m) (hr : 0 ≤ r) :
    endpointCoordinate m r * (2 + r * endpointCoordinate m r) = m := by
  have hs := Real.sq_sqrt (show 0 ≤ 1 + m * r by positivity)
  have hd : 1 + Real.sqrt (1 + m * r) ≠ 0 := by positivity
  have hidentity : 2 * (1 + Real.sqrt (1 + m * r)) + r * m =
      (1 + Real.sqrt (1 + m * r)) ^ 2 := by nlinarith
  unfold endpointCoordinate
  calc
    m / (1 + Real.sqrt (1 + m * r)) *
        (2 + r * (m / (1 + Real.sqrt (1 + m * r)))) =
      m * (2 * (1 + Real.sqrt (1 + m * r)) + r * m) /
        (1 + Real.sqrt (1 + m * r)) ^ 2 := by field_simp [hd] <;> ring_nf <;> simp
    _ = m := by rw [hidentity]; exact mul_div_cancel_right₀ m (pow_ne_zero _ hd)

lemma endpointCoordinate_le_one_iff {m r : ℝ} (hm : 1 ≤ m) (hr : 0 < r) :
    endpointCoordinate m r ≤ 1 ↔ m - 2 ≤ r := by
  have hp : 0 < m := by linarith
  have hx : 0 < endpointCoordinate m r := endpointCoordinate_pos hp
  have hq := endpointCoordinate_resource (le_of_lt hp) (le_of_lt hr)
  constructor
  · intro hu
    have hsq : endpointCoordinate m r ^ 2 ≤ 1 := by nlinarith
    have hh := mul_le_mul_of_nonneg_left hsq hr.le
    nlinarith [hh]
  · intro hbound
    by_contra hh
    have hg : 1 < endpointCoordinate m r := lt_of_not_ge hh
    have hprod : 2 + r < endpointCoordinate m r *
        (2 + r * endpointCoordinate m r) := by
      have hsq : 1 < endpointCoordinate m r ^ 2 := by nlinarith
      have hh := mul_lt_mul_of_pos_left hsq hr
      nlinarith [hh]
    linarith

lemma endpointCoordinate_eq_one_iff {m r : ℝ} (hm : 1 ≤ m) (hr : 0 < r) :
    endpointCoordinate m r = 1 ↔ r = m - 2 := by
  have hp : 0 < m := by linarith
  have hx := endpointCoordinate_pos (r := r) hp
  have hq := endpointCoordinate_resource hp.le hr.le
  constructor
  · intro h; rw [h] at hq; linarith
  · intro h
    have hu := (endpointCoordinate_le_one_iff hm hr).2 (by linarith)
    have hf : (endpointCoordinate m r - 1) *
        (r * (endpointCoordinate m r + 1) + 2) = 0 := by nlinarith [hq]
    have hpos : 0 < r * (endpointCoordinate m r + 1) + 2 := by positivity
    have hz := (mul_eq_zero.mp hf).resolve_right (ne_of_gt hpos)
    linarith

lemma endpointGamma_admissible_iff {m r : ℝ} (hm : 1 ≤ m) (hr : 0 < r) :
    (1 / 2 ≤ endpointGamma m r ∧ endpointGamma m r ≤ 1) ↔ m - 2 ≤ r := by
  have hx := endpointCoordinate_pos (r := r) (show 0 < m by linarith)
  unfold endpointGamma
  rw [← endpointCoordinate_le_one_iff hm hr]
  constructor
  · rintro ⟨_, h⟩; linarith
  · intro h; constructor <;> linarith

lemma endpointGain_factor_identity {n : ℕ} (hn : 0 < n) (r : ℝ) :
    r + 2 / endpointCoordinate (n : ℝ) r =
      r + 2 / (n : ℝ) * (1 + Real.sqrt (1 + (n : ℝ) * r)) := by
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast Nat.ne_of_gt hn
  have hd : 1 + Real.sqrt (1 + (n : ℝ) * r) ≠ 0 := by positivity
  unfold endpointCoordinate
  field_simp
  <;> ring

lemma equal_resource_sum {n : ℕ} (hn : 0 < n) {r : ℝ} (hr : 0 ≤ r) :
    (∑ _j : Fin n, 1 / (endpointCoordinate (n : ℝ) r *
      (2 + r * endpointCoordinate (n : ℝ) r))) = 1 := by
  rw [endpointCoordinate_resource (by positivity) hr]
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast Nat.ne_of_gt hn
  field_simp

lemma endpoint_boundary_agreement {n : ℕ} (hn : 3 ≤ n) :
    endpointGamma (n : ℝ) ((n : ℝ) - 2) = 1 ∧
    endpointGain n ((n : ℝ) - 2) = (n : ℝ) ^ n := by
  have hnR : 3 ≤ (n : ℝ) := by exact_mod_cast hn
  have hr : 0 < (n : ℝ) - 2 := by linarith
  have hx := (endpointCoordinate_eq_one_iff (by linarith : 1 ≤ (n : ℝ)) hr).2 rfl
  constructor
  · unfold endpointGamma; rw [hx]; norm_num
  · unfold endpointGain
    rw [← endpointGain_factor_identity (by omega : 0 < n), hx]
    congr 1
    ring

lemma sin_three_mul_factor (φ : ℝ) :
    Real.sin (3 * φ) = Real.sin φ * (4 * Real.cos φ ^ 2 - 1) := by
  rw [Real.sin_three_mul]
  have h := Real.sin_sq_add_cos_sq φ
  have hm := congrArg (fun y : ℝ => Real.sin φ * y) h
  dsimp at hm
  nlinarith [hm]

lemma sin_four_mul_factor (φ : ℝ) :
    Real.sin (4 * φ) = 4 * Real.sin φ * Real.cos φ * (2 * Real.cos φ ^ 2 - 1) := by
  have hfour : (4 : ℝ) * φ = 2 * (2 * φ) := by ring
  rw [hfour, Real.sin_two_mul, Real.sin_two_mul, Real.cos_two_mul]
  ring

/-- Direct reduction of the n=3 finite-frequency gain from its angle equation. -/
lemma order_three_gain {r φ : ℝ} (hs : Real.sin φ ≠ 0)
    (hangle : r + 1 = Real.sin (2 * φ) / Real.sin φ) :
    (Real.sin (3 * φ) / Real.sin φ) ^ 3 = (r * (r + 2)) ^ 3 := by
  have hc : r + 1 = 2 * Real.cos φ := by
    rw [Real.sin_two_mul] at hangle
    have hcancel : 2 * Real.sin φ * Real.cos φ / Real.sin φ = 2 * Real.cos φ := by
      field_simp
      ring
    rw [hcancel] at hangle
    exact hangle
  rw [sin_three_mul_factor]
  have hratio : Real.sin φ * (4 * Real.cos φ ^ 2 - 1) / Real.sin φ =
      r * (r + 2) := by
    rw [mul_div_cancel_left₀ _ hs]
    have hc2 := congrArg (fun y : ℝ => y ^ 2) hc
    dsimp at hc2
    nlinarith [hc2]
  rw [hratio]

/-- Direct reduction of the n=4 finite-frequency gain from its angle equation. -/
lemma order_four_gain {r φ : ℝ} (hs : Real.sin φ ≠ 0)
    (hangle : r + 1 = Real.sin (3 * φ) / Real.sin φ) :
    (Real.sin (4 * φ) / Real.sin φ) ^ 4 = r ^ 4 * (r + 2) ^ 2 := by
  rw [sin_three_mul_factor, mul_div_cancel_left₀ _ hs] at hangle
  have hc : 4 * Real.cos φ ^ 2 = r + 2 := by linarith
  rw [sin_four_mul_factor]
  have hratio : (4 * Real.sin φ * Real.cos φ * (2 * Real.cos φ ^ 2 - 1)) /
      Real.sin φ = 2 * r * Real.cos φ := by
    calc
      _ = 4 * Real.cos φ * (2 * Real.cos φ ^ 2 - 1) := by field_simp; ring
      _ = 2 * r * Real.cos φ := by nlinarith [congrArg (fun y : ℝ => Real.cos φ * y) hangle]
  rw [hratio]
  calc
    (2 * r * Real.cos φ) ^ 4 = r ^ 4 * (4 * Real.cos φ ^ 2) ^ 2 := by ring
    _ = r ^ 4 * (r + 2) ^ 2 := by rw [hc]

lemma order_three_example : ((1 / 10 : ℝ) * (1 / 10 + 2)) ^ 3 = 9261 / 1000000 := by
  norm_num

end C2.NGammaEqual
