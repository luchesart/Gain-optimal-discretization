import C2.Schur
import C2.PoleZeroEndpoints

namespace C2.PoleZero

/-- Actual complex-root stability for the full one-delay pole-zero model. -/
def Stable (r η γ a : ℝ) : Prop :=
  0 < a ∧ C2.QuadraticSchur (1 + r * γ)
    (-1 + r * (1 - γ) + a * (γ + η)) (a * (1 - γ - η))

theorem stable_iff_jury {r η γ a : ℝ} (hr : 0 ≤ r) (hγ : 0 ≤ γ) :
    Stable r η γ a ↔ Jury r η γ a := by
  have hL : 0 < 1 + r * γ := by nlinarith [mul_nonneg hr hγ]
  unfold Stable Jury
  rw [C2.quadraticSchur_iff hL]
  constructor
  · rintro ⟨ha, h₁, h₂, h₃⟩
    refine ⟨ha, ?_, ?_⟩ <;> nlinarith
  · rintro ⟨ha, h₁, h₂⟩
    refine ⟨ha, ?_, ?_, ?_⟩ <;> nlinarith

theorem stable_global_gain_bound {r η γ a : ℝ} (hr : 0 ≤ r)
    (hγ : 0 ≤ γ) (hv : 0 < v r η) (h : Stable r η γ a) :
    a < aInterior r η :=
  global_gain_bound hr hv ((stable_iff_jury hr hγ).1 h)

theorem interior_stable_iff {r η a : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η)
    (hv : 0 < v r η) (hint : η ≤ FirstOrder.γStar (r / v r η)) :
    Stable r η (γInterior r η) a ↔ 0 < a ∧ a < aInterior r η := by
  rw [stable_iff_jury hr (interior_parameter_bounds hr hη hv hint).1]
  exact interior_admissible_iff hr hv

theorem stable_projection {r η a : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η)
    (hv : 0 < v r η) (hint : η ≤ FirstOrder.γStar (r / v r η)) :
    (∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r η γ a) ↔
      0 < a ∧ a < aInterior r η := by
  constructor
  · rintro ⟨γ, hγ, _, h⟩
    exact ⟨h.1, stable_global_gain_bound hr hγ hv h⟩
  · intro h
    have hg := interior_parameter_bounds hr hη hv hint
    exact ⟨γInterior r η, hg.1, hg.2, (interior_stable_iff hr hη hv hint).2 h⟩

theorem stable_interior_gain_isLUB {r η : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η)
    (hv : 0 < v r η) (hint : η ≤ FirstOrder.γStar (r / v r η)) :
    IsLUB {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r η γ a}
      (aInterior r η) := by
  have heq : {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r η γ a} =
      {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r η γ a} := by
    ext a
    exact (stable_projection hr hη hv hint).trans
      (admissible_projection hr hη hv hint).symm
  rw [heq]
  exact interior_gain_isLUB hr hη hv hint

theorem stable_interior_maximizing_parameter_unique {r η γ : ℝ}
    (hr : 0 ≤ r) (hγ : 0 ≤ γ) (hv : 0 < v r η)
    (hS : IsLUB {a : ℝ | Stable r η γ a} (aInterior r η)) :
    γ = γInterior r η := by
  have heq : {a : ℝ | Stable r η γ a} = {a : ℝ | Jury r η γ a} := by
    ext a
    exact stable_iff_jury hr hγ
  rw [heq] at hS
  exact interior_maximizing_parameter_unique hr hv hS

theorem feasible_stable_eq_jury {r η : ℝ} (hr : 0 ≤ r) :
    {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r η γ a} =
      {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r η γ a} := by
  ext a
  constructor
  · rintro ⟨γ, hγ, hγ1, h⟩
    exact ⟨γ, hγ, hγ1, (stable_iff_jury hr hγ).1 h⟩
  · rintro ⟨γ, hγ, hγ1, h⟩
    exact ⟨γ, hγ, hγ1, (stable_iff_jury hr hγ).2 h⟩

theorem fe_stable_iff {r η a : ℝ} (hr : 0 ≤ r)
    (hv : 0 < v r η) (hleft : γInterior r η < 0) :
    Stable r η 0 a ↔ 0 < a ∧ a < aFE r η := by
  obtain ⟨hη, hr2, hF⟩ := fe_regime_consequences hr hv hleft
  rw [stable_iff_jury hr (le_refl 0)]
  exact fe_admissible_iff hr2 hη hF

theorem be_stable_iff {r η a : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η) :
    Stable r η 1 a ↔ 0 < a ∧ a < aBE r η := by
  rw [stable_iff_jury hr (by norm_num : (0 : ℝ) ≤ 1)]
  exact be_admissible_iff hr hη

theorem fe_stable_projection {r η a : ℝ} (hr : 0 ≤ r)
    (hv : 0 < v r η) (hleft : γInterior r η < 0) :
    (∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r η γ a) ↔
      0 < a ∧ a < aFE r η := by
  have heq := feasible_stable_eq_jury (η := η) hr
  have hmem : a ∈ {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r η γ a} ↔
      a ∈ {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r η γ a} := by rw [heq]
  exact hmem.trans (fe_admissible_projection hr hv hleft)

theorem be_stable_projection {r η a : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η)
    (hv : v r η < 0) :
    (∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r η γ a) ↔
      0 < a ∧ a < aBE r η := by
  have heq := feasible_stable_eq_jury (η := η) hr
  have hmem : a ∈ {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r η γ a} ↔
      a ∈ {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r η γ a} := by rw [heq]
  exact hmem.trans (be_admissible_projection hr hη hv)

theorem fe_stable_gain_isLUB {r η : ℝ} (hr : 0 ≤ r)
    (hv : 0 < v r η) (hleft : γInterior r η < 0) :
    IsLUB {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r η γ a}
      (aFE r η) := by
  rw [feasible_stable_eq_jury hr]
  exact fe_gain_isLUB hr hv hleft

theorem be_stable_gain_isLUB {r η : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η)
    (hv : v r η < 0) :
    IsLUB {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Stable r η γ a}
      (aBE r η) := by
  rw [feasible_stable_eq_jury hr]
  exact be_gain_isLUB hr hη hv

theorem fe_stable_maximizing_parameter_iff {r η γ : ℝ} (hr : 0 ≤ r)
    (hv : 0 < v r η) (hleft : γInterior r η < 0) (hγ : 0 ≤ γ) :
    IsLUB {a : ℝ | Stable r η γ a} (aFE r η) ↔ γ = 0 := by
  have heq : {a : ℝ | Stable r η γ a} = {a : ℝ | Jury r η γ a} := by
    ext a
    exact stable_iff_jury hr hγ
  rw [heq]
  constructor
  · exact fe_maximizing_parameter_unique hr hv hleft hγ
  · intro hg
    rw [hg]
    exact fe_parameter_isLUB hr hv hleft

theorem be_stable_maximizing_parameter_iff {r η γ : ℝ} (hr : 0 ≤ r)
    (hη : 0 ≤ η) (hv : v r η < 0) (hγ : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    IsLUB {a : ℝ | Stable r η γ a} (aBE r η) ↔ γ = 1 := by
  have heq : {a : ℝ | Stable r η γ a} = {a : ℝ | Jury r η γ a} := by
    ext a
    exact stable_iff_jury hr hγ
  rw [heq]
  constructor
  · exact be_maximizing_parameter_unique hη hv hγ1
  · intro hg
    rw [hg]
    exact be_parameter_isLUB hr hη

end C2.PoleZero
