import C2.CADEffectiveBivariate
import C2.CADEffectiveSearch
import C2.CADEffectiveLeading
import C2.CADProjectionBasis

/-! Finite executable data for the complete factorization/projection stage.
All stored coefficients are rational lists. The checker is finite Boolean
arithmetic; the proof of existence will establish total exhaustive production. -/
namespace C2.CADEffective.Bivariate
open Polynomial

structure Witness where
  n : ℕ
  factors : List Poly
  left : List Dense.Poly
  right : List Dense.Poly
  zeroPower : List ℕ
  onePower : List ℕ
  powers : List (List ℕ)
  simple : List Dense.Poly
  simpleU : List Poly
  simpleV : List Poly
  pair : List (List Dense.Poly)
  pairU : List (List Poly)
  pairV : List (List Poly)
  deriving Encodable

def nativeProd : List Poly → Poly
  | [] => one
  | p :: ps => mul p (nativeProd ps)

@[simp] theorem denote_nativeProd (ps : List Poly) :
    denote (nativeProd ps) = (ps.map denote).prod := by
  induction ps with
  | nil => simp [nativeProd]
  | cons p ps ih => simp [nativeProd, ih]

def gammaX : Poly := [[], [1]]
def gammaXSubOne : Poly := [[-1], [1]]

@[simp] theorem denote_gammaX : denote gammaX = X := by simp [gammaX]
@[simp] theorem denote_gammaXSubOne : denote gammaXSubOne = X - 1 := by
  simp [gammaXSubOne]; ring

def factorsProduct (w : Witness) (i : ℕ) : Poly :=
  nativeProd (List.ofFn (fun j : Fin w.n =>
    pow (w.factors.getD j []) ((w.powers.getD i []).getD j 0)))

noncomputable def inputFamily (F : List Poly) : Fin F.length → C2.CADProjection.Bivariate :=
  fun i => denote (F.getD i [])

noncomputable def toFactorData (F : List Poly) (w : Witness) :
    C2.CADProjection.FactorData (Fin F.length) w.n where
  factors := fun j => denote (w.factors.getD j [])
  left := fun i => Dense.denote (w.left.getD i [])
  right := fun i => Dense.denote (w.right.getD i [])
  zeroPower := fun i => w.zeroPower.getD i 0
  onePower := fun i => w.onePower.getD i 0
  powers := fun i j => (w.powers.getD i []).getD j 0

noncomputable def toProjectionData (w : Witness) : C2.CADProjection.ProjectionData (Fin w.n) where
  simple := fun i => Dense.denote (w.simple.getD i [])
  simpleU := fun i => denote (w.simpleU.getD i [])
  simpleV := fun i => denote (w.simpleV.getD i [])
  pair := fun i j => Dense.denote ((w.pair.getD i []).getD j [])
  pairU := fun i j => denote ((w.pairU.getD i []).getD j [])
  pairV := fun i j => denote ((w.pairV.getD i []).getD j [])

@[simp] theorem denote_factorsProduct (F : List Poly) (w : Witness) (i : Fin F.length) :
    denote (factorsProduct w i) =
      ∏ j : Fin w.n, ((toFactorData F w).factors j) ^ (toFactorData F w).powers i j := by
  simp [factorsProduct, denote_nativeProd, List.map_ofFn, List.prod_ofFn, toFactorData]

def factorIdentity (F : List Poly) (w : Witness) (i : ℕ) : Bool :=
  eqb (mul (constant (w.left.getD i [])) (F.getD i []))
    (mul (mul (mul (constant (w.right.getD i [])) (pow gammaX (w.zeroPower.getD i 0)))
      (pow gammaXSubOne (w.onePower.getD i 0))) (factorsProduct w i))

def witnessCheck (F : List Poly) (w : Witness) : Bool := decide (
  (∀ i : Fin F.length,
    Dense.eqb (w.left.getD i []) [] = false ∧
    Dense.eqb (w.right.getD i []) [] = false ∧ factorIdentity F w i = true) ∧
  (∀ j : Fin w.n, ∃ i : Fin F.length, (w.powers.getD i []).getD j 0 ≠ 0) ∧
  (∀ i : Fin w.n,
    Dense.eqb (leadingCoeff (w.factors.getD i [])) [] = false ∧
    Dense.eqb (gammaEval (w.factors.getD i []) 0) [] = false ∧
    Dense.eqb (gammaEval (w.factors.getD i []) 1) [] = false ∧
    Dense.eqb (w.simple.getD i []) [] = false ∧
    eqb (add (mul (w.simpleU.getD i []) (w.factors.getD i []))
      (mul (w.simpleV.getD i []) (derivative (w.factors.getD i []))))
        (constant (w.simple.getD i [])) = true) ∧
  (∀ i j : Fin w.n,
    Dense.eqb ((w.pair.getD i []).getD j []) [] = false ∧
      (i ≠ j → eqb (add
        (mul ((w.pairU.getD i []).getD j []) (w.factors.getD i []))
        (mul ((w.pairV.getD i []).getD j []) (w.factors.getD j [])))
        (constant ((w.pair.getD i []).getD j [])) = true)))

theorem dense_eqb_false_iff (p q : Dense.Poly) :
    Dense.eqb p q = false ↔ Dense.denote p ≠ Dense.denote q := by
  simpa only [Bool.not_eq_true] using not_congr (Dense.eqb_eq_true_iff p q)

theorem factorIdentity_iff (F : List Poly) (w : Witness) (i : Fin F.length) :
    factorIdentity F w i = true ↔
      C ((toFactorData F w).left i) * inputFamily F i =
        C ((toFactorData F w).right i) * X ^ (toFactorData F w).zeroPower i *
        (X-1) ^ (toFactorData F w).onePower i *
          ∏ j : Fin w.n, ((toFactorData F w).factors j) ^ (toFactorData F w).powers i j := by
  simp only [factorIdentity, eqb_eq_true_iff, denote_mul, denote_constant,
    denote_pow, denote_gammaX, denote_gammaXSubOne, denote_factorsProduct]
  rfl

/-- The executable finite checker is exactly the established mathematical
factor and projection specifications. -/
theorem witnessCheck_iff (F : List Poly) (w : Witness) :
    witnessCheck F w = true ↔
      C2.CADProjection.ValidFactorData (inputFamily F) (toFactorData F w) ∧
      C2.CADProjection.ValidProjectionData (toFactorData F w).factors (toProjectionData w) := by
  simp only [witnessCheck, decide_eq_true_eq, dense_eqb_false_iff,
    Dense.denote_nil, factorIdentity_iff, denote_leadingCoeff,
    gammaEval_zero, gammaEval_one, eqb_eq_true_iff, denote_add,
    denote_mul, denote_derivative, denote_constant]
  simp only [C2.CADProjection.ValidFactorData, C2.CADProjection.ValidProjectionData,
    toFactorData, toProjectionData]
  constructor
  · rintro ⟨hleft,hused,hsimple,hpair⟩
    exact ⟨⟨fun i => ⟨(hleft i).1, (hleft i).2.1⟩, hused,
      fun i => (hleft i).2.2⟩, hsimple, hpair⟩
  · rintro ⟨⟨hlr,hused,hid⟩,hsimple,hpair⟩
    exact ⟨fun i => ⟨(hlr i).1, (hlr i).2, hid i⟩,hused,hsimple,hpair⟩

end C2.CADEffective.Bivariate
