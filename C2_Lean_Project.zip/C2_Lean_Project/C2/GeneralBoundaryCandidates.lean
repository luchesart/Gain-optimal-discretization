import C2.GeneralBoundaryCandidatesChebyshev

/-! Finite exact unit-circle gain candidates, constructed by roots of the
Chebyshev cross-product polynomial and the two real endpoints. -/
noncomputable section
open scoped BigOperators
open Polynomial Set
namespace C2.GeneralBoundaryCandidates

def upperPoint (x : ℝ) : ℂ := (x:ℂ)+(Real.sqrt (1-x^2):ℂ)*Complex.I

def gainAt (H N : ℝ[X]) (z : ℂ) : ℝ :=
  -(evalC H z*star (evalC N z)).re/Complex.normSq (evalC N z)

def candidatePoints (H N : ℝ[X]) : Set ℂ :=
  {1,-1} ∪ upperPoint '' (Ioo (-1:ℝ) 1 ∩ {x | (Q H N).eval x = 0})

def candidateGains (H N : ℝ[X]) : Set ℝ :=
  {k | 0 < k ∧ ∃ z ∈ candidatePoints H N, evalC N z ≠ 0 ∧ k = gainAt H N z}

@[simp] theorem upperPoint_re (x : ℝ) : (upperPoint x).re = x := by simp [upperPoint]
@[simp] theorem upperPoint_im (x : ℝ) : (upperPoint x).im = Real.sqrt (1-x^2) := by simp [upperPoint]

theorem circle_equation {z : ℂ} (hz : ‖z‖ = 1) : z.re^2+z.im^2=1 := by
  have hh := Complex.normSq_eq_norm_sq z
  rw [hz] at hh
  simpa [Complex.normSq_apply,pow_two] using hh

theorem upperPoint_norm {x : ℝ} (hx : x ∈ Ioo (-1:ℝ) 1) : ‖upperPoint x‖ = 1 := by
  have hs : 0 ≤ 1-x^2 := by nlinarith [hx.1,hx.2]
  have hq := Real.sq_sqrt hs
  have hn := Complex.normSq_eq_norm_sq (upperPoint x)
  simp only [Complex.normSq_apply,upperPoint_re,upperPoint_im] at hn
  nlinarith [norm_nonneg (upperPoint x)]

theorem upperPoint_im_pos {x : ℝ} (hx : x ∈ Ioo (-1:ℝ) 1) : 0 < (upperPoint x).im := by
  rw [upperPoint_im]
  apply Real.sqrt_pos.mpr
  nlinarith [hx.1,hx.2]

theorem upper_circle_representation {z : ℂ} (hz : ‖z‖ = 1) (hi : 0 < z.im) :
    z.re ∈ Ioo (-1:ℝ) 1 ∧ z = upperPoint z.re := by
  have hq := circle_equation hz
  have hx : z.re ∈ Ioo (-1:ℝ) 1 := by
    constructor <;> nlinarith [sq_pos_of_pos hi]
  refine ⟨hx,?_⟩
  apply Complex.ext
  · simp
  · rw [upperPoint_im]
    apply Eq.symm
    exact (Real.sqrt_eq_iff_eq_sq (by nlinarith) hi.le).mpr (by nlinarith)

theorem real_circle_points {z : ℂ} (hz : ‖z‖ = 1) (hi : z.im = 0) : z = 1 ∨ z = -1 := by
  have hq := circle_equation hz
  rw [hi] at hq
  have hr : z.re = 1 ∨ z.re = -1 := by
    have hh : (z.re-1)*(z.re+1)=0 := by nlinarith
    rcases mul_eq_zero.mp hh with h|h
    · exact Or.inl (by linarith)
    · exact Or.inr (by linarith)
  rcases hr with h|h
  · left; apply Complex.ext <;> simp [h,hi]
  · right; apply Complex.ext <;> simp [h,hi]

theorem candidatePoints_finite {H N : ℝ[X]} (hQ : Q H N ≠ 0) : (candidatePoints H N).Finite := by
  have hroots : ({x : ℝ | (Q H N).eval x=0}:Set ℝ).Finite := by
    simpa only [Polynomial.IsRoot] using Polynomial.finite_setOf_isRoot hQ
  exact ((Set.finite_singleton (-1:ℂ)).insert 1).union ((hroots.inter_of_right _).image upperPoint)

theorem candidateGains_finite {H N : ℝ[X]} (hQ : Q H N ≠ 0) : (candidateGains H N).Finite := by
  apply ((candidatePoints_finite hQ).image (gainAt H N)).subset
  rintro k ⟨hk,z,hz,hn,hkz⟩
  exact ⟨z,hz,hkz.symm⟩

theorem candidatePoint_properties {H N : ℝ[X]} {z : ℂ} (hz : z ∈ candidatePoints H N) :
    ‖z‖=1 ∧ (evalC H z*star (evalC N z)).im=0 := by
  rcases hz with hz | ⟨x,⟨hx,hQ⟩,rfl⟩
  · rcases hz with rfl | hz
    · constructor
      · simp
      · rw [chebyshev_identity_on_circle H N (by simp : ‖(1:ℂ)‖=1)]
        simp
    · have he : z = -1 := Set.mem_singleton_iff.mp hz
      subst z
      constructor
      · simp
      · rw [chebyshev_identity_on_circle H N (by simp : ‖(-1:ℂ)‖=1)]
        simp
  · refine ⟨upperPoint_norm hx,?_⟩
    rw [chebyshev_identity_on_circle H N (upperPoint_norm hx),upperPoint_re,hQ,mul_zero]

theorem feedback_conj {H N : ℝ[X]} {k : ℝ} {z : ℂ}
    (hz : evalC H z+(k:ℂ)*evalC N z=0) :
    evalC H (star z)+(k:ℂ)*evalC N (star z)=0 := by
  rw [evalC_conj,evalC_conj]
  have hh := congrArg (star : ℂ → ℂ) hz
  simpa only [map_add,map_mul,Complex.star_def,Complex.conj_ofReal,map_zero] using hh

/-- At the real endpoints the cross-product quotient is the ordinary real
quotient used in the manuscript. -/
theorem gainAt_ofReal (H N : ℝ[X]) (x : ℝ) (hN : N.eval x ≠ 0) :
    gainAt H N (x:ℂ) = -(H.eval x)/(N.eval x) := by
  unfold gainAt
  rw [evalC_ofReal,evalC_ofReal]
  simp only [Complex.star_def,Complex.conj_ofReal,Complex.mul_re,
    Complex.ofReal_re,Complex.ofReal_im,mul_zero,sub_zero,Complex.normSq_ofReal]
  field_simp
  ring

/-- Exact iff for the finite Chebyshev/endpoints candidate construction. -/
theorem unitCircleRoot_iff_candidate {H N : ℝ[X]} {k : ℝ} (hk : 0 < k)
    (hcommon : ∀ z : ℂ, ‖z‖=1 → evalC N z=0 → evalC H z≠0) :
    C2.UnitCircleRoot (evalC H) (evalC N) k ↔ k ∈ candidateGains H N := by
  constructor
  · rintro ⟨z,hz,hroot⟩
    have hupper : ∃ w : ℂ, ‖w‖=1 ∧ 0 ≤ w.im ∧ evalC H w+(k:ℂ)*evalC N w=0 := by
      by_cases hi : 0 ≤ z.im
      · exact ⟨z,hz,hi,hroot⟩
      · exact ⟨star z,by simpa using hz,by simpa using (show 0 ≤ -z.im by linarith),feedback_conj hroot⟩
    obtain ⟨w,hw,hwi,hwr⟩ := hupper
    have hN : evalC N w ≠ 0 := by
      intro hn
      have hh : evalC H w=0 := by simpa [hn] using hwr
      exact hcommon w hw hn hh
    obtain ⟨hkg,hcross⟩ := (C2.feedback_zero_iff_cross_product (evalC H w) (evalC N w) k hN).mp hwr
    refine ⟨hk,w,?_,hN,hkg⟩
    by_cases hi : w.im=0
    · exact Or.inl (real_circle_points hw hi)
    · have hip : 0 < w.im := lt_of_le_of_ne hwi (Ne.symm hi)
      obtain ⟨hx,hwx⟩ := upper_circle_representation hw hip
      have hQ : (Q H N).eval w.re=0 := by
        rw [chebyshev_identity_on_circle H N hw] at hcross
        exact (mul_eq_zero.mp hcross).resolve_left (ne_of_gt hip)
      exact Or.inr ⟨w.re,⟨hx,hQ⟩,hwx.symm⟩
  · rintro ⟨hk,z,hz,hN,hkg⟩
    obtain ⟨hnorm,hcross⟩ := candidatePoint_properties hz
    exact ⟨z,hnorm,(C2.feedback_zero_iff_cross_product (evalC H z) (evalC N z) k hN).mpr ⟨hkg,hcross⟩⟩

end C2.GeneralBoundaryCandidates
