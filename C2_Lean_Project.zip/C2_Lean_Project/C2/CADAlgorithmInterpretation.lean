import C2.CADAlgorithm

/-! Exact interpretation of executable ordered endpoint data. This bridge
allows a computable representation of real algebraic cuts to use the generic
finite algorithm, while the geometric correctness theorem is stated in ℝ. -/

namespace C2.CADAlgorithm

def Cell.mapEndpoints {α β : Type*} (f : α → β) (c : Cell α) : Cell β where
  left := f c.left
  right := f c.right
  sample := c.sample
  marked := c.marked

def SampledCell.mapEndpoints {α β : Type*} (f : α → β)
    (c : SampledCell α) : SampledCell β where
  left := f c.left
  right := f c.right
  gainSample := c.gainSample
  parameterSamples := c.parameterSamples

theorem monotone_map_max {α β : Type*} [LinearOrder α] [LinearOrder β]
    {f : α → β} (hf : Monotone f) (a b : α) :
    f (max a b) = max (f a) (f b) := by
  by_cases h : a ≤ b
  · rw [max_eq_right h, max_eq_right (hf h)]
  · rw [max_eq_left (le_of_not_ge h), max_eq_left (hf (le_of_not_ge h))]

theorem maximum_map {α β : Type*} [LinearOrder α] [LinearOrder β]
    {f : α → β} (hf : Monotone f) (xs : List α) :
    maximum? (xs.map f) = (maximum? xs).map f := by
  induction xs with
  | nil => rfl
  | cons a rest ih =>
    simp only [List.map_cons, maximum?, ih]
    cases h : maximum? rest with
    | none => rfl
    | some b => simp [monotone_map_max hf]

theorem markedEndpoints_map {α β : Type*} (f : α → β) (cells : List (Cell α)) :
    markedEndpoints (cells.map (Cell.mapEndpoints f)) = (markedEndpoints cells).map f := by
  induction cells with
  | nil => rfl
  | cons c rest ih =>
    cases hm : c.marked <;>
      simp [markedEndpoints, Cell.mapEndpoints, hm, markedEndpoints] at ih ⊢ <;>
      exact ih

theorem output_map {α β : Type*} [LinearOrder α] [LinearOrder β]
    {f : α → β} (hf : Monotone f) (cells : List (Cell α)) :
    output (cells.map (Cell.mapEndpoints f)) = (output cells).map f := by
  rw [output, markedEndpoints_map, maximum_map hf]
  rfl

theorem testAndSelect_map {α β : Type*} [LinearOrder α] [LinearOrder β]
    {f : α → β} (hf : Monotone f)
    (tests : List (ℚ → ℚ → ℚ)) (cells : List (SampledCell α)) :
    testAndSelect tests (cells.map (SampledCell.mapEndpoints f)) =
      (testAndSelect tests cells).map f := by
  have hlist : (cells.map (SampledCell.mapEndpoints f)).map (fun c => c.test tests) =
      (cells.map fun c => c.test tests).map (Cell.mapEndpoints f) := by
    simp only [List.map_map]
    rfl
  simp only [testAndSelect]
  rw [hlist, output_map hf]

theorem interpreted_output_isLUB {α : Type*} [LinearOrder α]
    {f : α → ℝ} (hf : Monotone f) {cells : List (Cell α)} {a : α}
    (hvalid : ValidCells (cells.map (Cell.mapEndpoints f)))
    (hout : output cells = some a) :
    IsLUB (representedGains (cells.map (Cell.mapEndpoints f))) (f a) := by
  apply output_isLUB hvalid
  rw [output_map hf, hout]
  rfl

theorem interpreted_output_algebraic {α : Type*} [LinearOrder α]
    {f : α → ℝ} {cells : List (Cell α)} {a : α}
    (halg : ∀ c ∈ cells, IsAlgebraic ℚ (f c.right))
    (hout : output cells = some a) : IsAlgebraic ℚ (f a) := by
  obtain ⟨⟨c, hc, _, hca⟩, _⟩ := output_some_spec hout
  exact hca ▸ halg c hc

end C2.CADAlgorithm
