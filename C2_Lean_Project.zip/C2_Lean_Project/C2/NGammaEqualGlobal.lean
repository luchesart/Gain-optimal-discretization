import C2.NGammaEqualEndpoint
import C2.NGammaEqualFrequency
import C2.NGammaGlobalOptimum

/-! Both global equal-factor frequency/endpoint optimization regimes, with
the explicit finite-angle value identified with the actual optimum. The
independent Schur interval theorem supplies the dynamical interpretation. -/
noncomputable section
open scoped BigOperators
open Set C2.NGamma C2.NGamma.Global
namespace C2.NGammaEqual

lemma exp_sum_allocationLogGain {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) {w : ℝ} (hw : 0 < w) :
    Real.exp (∑ j, allocationLogGain (r j) (x j) w) =
      ∏ j, allocationGain (r j) (x j) w := by
  rw [Real.exp_sum]
  apply Finset.prod_congr rfl
  intro j hj
  rw [← log_allocationGain (hr j) hw, Real.exp_log (allocationGain_pos (hr j) hw (x j))]

/-- Every finite-frequency competitor is strictly inferior to the explicit
identical endpoint design, throughout its valid regime. -/
theorem identical_endpoint_dominates_finite {n : ℕ} (hn : 0 < n) {r w : ℝ}
    (hr : 0 < r) (hregime : (n:ℝ)-2 ≤ r) (hw : 0 < w)
    (x : Fin n → ℝ) (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    (hp : (∑ j, allocationPhase r (x j) w) = 2*Real.arctan w) :
    (∏ j, allocationGain r (x j) w) < endpointGain n r := by
  have hS : endpointSum (fun _ : Fin n => r) ≤ 1 := by
    have hsum : endpointSum (fun _ : Fin n => r) = (n:ℝ)/(r+2) := by
      simp [endpointSum,div_eq_mul_inv]
    rw [hsum]
    exact (div_le_one (by positivity : 0 < r+2)).2 (by linarith)
  exact lt_of_le_of_lt (gain_product_le_exp_frequencyValue
    (fun _ : Fin n => r) x (fun _ => hr) hw hx hp)
    (positive_frequency_below_endpoint_bound hn (fun _ : Fin n => r) (fun _ => hr) hS _
      (fun y hy hc => (identical_endpoint_optimal hn hr hregime y hy hc).1)
      hw ⟨x,hx,hp⟩)

/-- The explicit finite-angle gain is the actual unique global
frequency-domain optimum, rather than an unrelated unit-circle witness. -/
theorem identical_finite_global_gain {n : ℕ} (hn : 3 ≤ n) {r : ℝ}
    (hr : 0 < r) (hrn : r < (n:ℝ)-2) :
    ∃ w : ℝ, ∃ φ : ℝ, 0 < w ∧ φ ∈ Ioo 0 (Real.pi/(n:ℝ)) ∧
      r+1 = Real.sin (((n:ℝ)-1)*φ)/Real.sin φ ∧
      (∑ _ : Fin n, allocationPhase r 1 w) = 2*Real.arctan w ∧
      (∏ _ : Fin n, allocationGain r 1 w) = (Real.sin ((n:ℝ)*φ)/Real.sin φ)^n ∧
      ∀ v : ℝ, 0 < v → ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) →
        (∑ j, allocationPhase r (x j) v) = 2*Real.arctan v →
        (∏ j, allocationGain r (x j) v) ≤ (Real.sin ((n:ℝ)*φ)/Real.sin φ)^n ∧
        ((∏ j, allocationGain r (x j) v) = (Real.sin ((n:ℝ)*φ)/Real.sin φ)^n ↔
          v=w ∧ x=fun _ => 1) := by
  have hn0 : 0 < n := by omega
  have hS : 1 < endpointSum (fun _ : Fin n => r) := by
    have hsum : endpointSum (fun _ : Fin n => r) = (n:ℝ)/(r+2) := by
      simp [endpointSum,div_eq_mul_inv]
    rw [hsum]
    exact (one_lt_div (by positivity : 0 < r+2)).2 (by linarith)
  obtain ⟨w,hw,hp,hmax⟩ := positive_endpoint_unique_global_maximum hn0
    (fun _ : Fin n => r) (fun _ => hr) hS
  let φ := allocationPhase r 1 w
  have hangle := angle_from_all_one_phase hn0 hr hw hp
  have hgain : (∏ _ : Fin n, allocationGain r 1 w) = (Real.sin ((n:ℝ)*φ)/Real.sin φ)^n := by
    rw [all_one_gain_angle hn0 hr hw hp]
    simp [φ,div_pow]
  refine ⟨w,φ,hw,hangle.1,hangle.2,hp,hgain,?_⟩
  intro v hv x hx hphase
  have hh := hmax v hv x hx hphase
  have hvexp := exp_sum_allocationLogGain (fun _ : Fin n => r) x (fun _ => hr) hv
  have hwexp := exp_sum_allocationLogGain (fun _ : Fin n => r) (fun _ => 1) (fun _ => hr) hw
  rw [← hgain,← hvexp,← hwexp]
  exact ⟨Real.exp_le_exp.mpr hh.1, by rw [Real.exp_injective.eq_iff]; exact hh.2⟩

end C2.NGammaEqual
