import C2.IntegratorDelayCayley
import C2.IntegratorDelayLift
import C2.NGammaRootCount
import C2.NGammaPhaseIndex
import C2.NGammaCharacteristicLift

noncomputable section
open Polynomial Filter
open scoped Topology ComplexConjugate
namespace C2.IntegratorDelay
open NGamma.PolynomialModel NGamma.RootCountBridge NGamma.ArgumentMatch
open NGamma.Cayley

def characteristicAngle (n : ℕ) (x a tb : ℝ) (k : ℤ) (t : ℝ) : ℝ :=
  qPhase x t + translatedAngle (amplitude x) (totalPhase n x) a tb k t

theorem totalPhase_continuous (n : ℕ) (x : ℝ) : Continuous (totalPhase n x) := by
  unfold totalPhase
  exact ((continuous_const.mul Real.continuous_arctan).add continuous_const).sub
    (Real.continuous_arctan.comp (continuous_const.mul continuous_id))

theorem integratorAngle_continuousOn (n : ℕ) (x : ℝ) {a tb : ℝ} {k : ℤ}
    (ha : 0 < a) (htb : 0 < tb) (hBeq : amplitude x tb = a)
    (hlo : -Real.pi < totalPhase n x tb - 2 * Real.pi * k)
    (hhi : totalPhase n x tb - 2 * Real.pi * k < Real.pi) :
    ContinuousOn (characteristicAngle n x a tb k) (Set.Ici 0) := by
  apply ContinuousOn.add (qPhase_continuous x).continuousOn
  exact zero_translatedAngle_continuousOn (amplitude_continuous x)
    (totalPhase_continuous n x) (fun t ht => amplitude_nonneg x ht)
    (fun t ht => amplitude_pos x ht) (amplitude_strictMonoOn x) ha htb hBeq hlo hhi

theorem integratorAngle_polar (n : ℕ) (x a tb : ℝ) (k : ℤ)
    (htb : 0 ≤ tb) {t : ℝ} (ht : 0 ≤ t) :
    (poly n x a).eval (point t) = (‖(poly n x a).eval (point t)‖ : ℂ) *
      Complex.exp ((characteristicAngle n x a tb k t : ℂ) * Complex.I) := by
  have hqnorm : ‖(q x).eval (point t)‖ = qAmplitude x t := by
    rw [q_polar, norm_mul, Complex.norm_real, Real.norm_eq_abs,
      abs_of_pos (qAmplitude_pos x t), Complex.norm_exp_ofReal_mul_I, mul_one]
  have hq : (q x).eval (point t) = (‖(q x).eval (point t)‖ : ℂ) *
      Complex.exp ((qPhase x t : ℂ) * Complex.I) := by rw [hqnorm]; exact q_polar x t
  have hp := zero_translatedAngle_polar (B := amplitude x) (ψ := totalPhase n x)
    (b := a) (k := k) (fun t ht => amplitude_pos x ht) htb ht
  have hp' : transfer n x (point t) + a = (‖transfer n x (point t) + a‖ : ℂ) *
      Complex.exp ((translatedAngle (amplitude x) (totalPhase n x) a tb k t : ℂ) * Complex.I) := by
    simpa only [polarCurve, ← transfer_polar n x t ht] using hp
  rw [poly_eval_point]
  exact NGamma.Cayley.polar_mul hq hp'

theorem integrator_point_ne_zero (n : ℕ) (x : ℝ) {a tb : ℝ} {k : ℤ}
    (ha : 0 < a) (htb : 0 < tb) (hBeq : amplitude x tb = a)
    (hlo : -Real.pi < totalPhase n x tb - 2 * Real.pi * k)
    (hhi : totalPhase n x tb - 2 * Real.pi * k < Real.pi)
    {t : ℝ} (ht : 0 ≤ t) : (poly n x a).eval (point t) ≠ 0 := by
  rw [poly_eval_point]
  apply mul_ne_zero (q_eval_point_ne_zero x t)
  have h := zero_translated_curve_ne_zero (B := amplitude x) (ψ := totalPhase n x)
    (fun t ht => amplitude_nonneg x ht) (fun t ht => amplitude_pos x ht)
    (amplitude_strictMonoOn x) ha htb hBeq hlo hhi ht
  simpa only [polarCurve, ← transfer_polar n x t ht] using h

theorem integratorAngle_zero (n : ℕ) (x : ℝ) {a tb : ℝ} (k : ℤ)
    (ha : 0 < a) (htb : 0 ≤ tb) : characteristicAngle n x a tb k 0 = 0 := by
  unfold characteristicAngle
  rw [zero_translatedAngle_zero (amplitude_zero x) ha htb]
  simp [qPhase]

theorem poly_endpoint_ne_zero (n : ℕ) {x a : ℝ} (ha : 0 < a)
    (hbound : a * |x| < 2) : (poly n x a).eval (-1) ≠ 0 := by
  intro he
  rw [poly_eval_neg_one] at he
  have he' : (a : ℂ) * x = -2 * (-1 : ℂ) ^ n := by linear_combination -he
  have hh := congrArg norm he'
  simp only [norm_mul, norm_pow, norm_neg, norm_one, one_pow, Complex.norm_real,
    Real.norm_eq_abs, abs_of_pos ha, mul_one] at hh
  norm_num at hh
  linarith

theorem transfer_correction_arg_limit (n : ℕ) {x a : ℝ} (ha : 0 < a)
    (hbound : a * |x| < 2) :
    Tendsto (fun t => Complex.arg (1 + (a : ℂ) / transfer n x (point t))) atTop (𝓝 0) := by
  let c : ℝ := a * x / (2 * (-1) ^ n)
  have hcabs : |c| < 1 := by
    have he : |c| = a * |x| / 2 := by
      simp [c, abs_div, abs_mul, abs_pow, abs_of_pos ha]
    rw [he]
    linarith
  have hcpos : 0 < (1 + (c : ℂ)).re := by
    simp only [Complex.add_re, Complex.one_re, Complex.ofReal_re]
    have := (abs_lt.mp hcabs).1
    linarith
  have hcarg : Complex.arg (1 + (c : ℂ)) = 0 :=
    Complex.arg_eq_zero_iff.2 ⟨hcpos.le, by simp⟩
  have h := (Complex.continuousAt_arg (Or.inl hcpos)).tendsto.comp
    ((reciprocal_transfer_tendsto_atTop n x a).const_add 1)
  simpa only [hcarg] using h

theorem integratorAngle_tendsto (n : ℕ) {x a tb : ℝ} (k : ℤ)
    (ha : 0 < a) (hbound : a * |x| < 2) :
    Tendsto (characteristicAngle n x a tb k) atTop
      (𝓝 (((n : ℝ) + 1) * Real.pi - 2 * Real.pi * k)) := by
  have hat := Real.tendsto_arctan_atTop.mono_right nhdsWithin_le_nhds
  have hmain : Tendsto (fun t => (2 * (n : ℝ) + 1) * Real.arctan t + Real.pi / 2)
      atTop (𝓝 (((n : ℝ) + 1) * Real.pi)) := by
    convert (hat.const_mul (2 * (n : ℝ) + 1)).add_const (Real.pi / 2) using 1 <;> ring
  have hlim := ((hmain.add (transfer_correction_arg_limit n ha hbound)).sub_const
    (2 * Real.pi * k))
  simp only [add_zero] at hlim
  apply hlim.congr'
  filter_upwards [eventually_gt_atTop tb, eventually_ge_atTop (0 : ℝ)] with t ht ht0
  simp only [characteristicAngle, translatedAngle, not_le.mpr ht, if_false]
  rw [polarCurve, ← transfer_polar n x t ht0]
  unfold qPhase totalPhase
  ring

/-- Exact exterior-root count, with multiplicity, for the integrator case `r=0`. -/
theorem integrator_root_count {n : ℕ} (hn : 1 ≤ n) {x a tb : ℝ}
    (ha : 0 < a) (htb : 0 < tb) (hBeq : amplitude x tb = a) (hbound : a * |x| < 2)
    (hodd : ∀ k : ℤ, totalPhase n x tb ≠ (2 * (k : ℝ) + 1) * Real.pi) :
    (countOutside (poly n x a) : ℤ) = 2 * phaseIndex (totalPhase n x tb) := by
  let k := phaseIndex (totalPhase n x tb)
  have hk := phaseIndex_bounds hodd
  have hlo : -Real.pi < totalPhase n x tb - 2 * Real.pi * k := by dsimp [k]; nlinarith [hk.1]
  have hhi : totalPhase n x tb - 2 * Real.pi * k < Real.pi := by dsimp [k]; nlinarith [hk.2]
  have hroots := no_unit_roots_of_cayley_nonzero (poly_eval_conj n x a)
    (fun t ht => integrator_point_ne_zero n x ha htb hBeq hlo hhi ht)
    (poly_endpoint_ne_zero n ha hbound)
  apply exterior_count_of_cayley_argument (poly_ne_zero hn x a) (poly_eval_conj n x a)
    hroots (integratorAngle_continuousOn n x ha htb hBeq hlo hhi)
    (fun t ht => integratorAngle_polar n x a tb k htb.le ht)
    (integratorAngle_tendsto n k ha hbound) k
  rw [integratorAngle_zero n x k ha htb.le, sub_zero, poly_natDegree hn]
  push_cast
  ring

theorem integrator_schur_iff_phase {n : ℕ} (hn : 2 ≤ n) {x a tb : ℝ}
    (hx : x ≤ 1) (ha : 0 < a) (htb : 0 < tb)
    (hBeq : amplitude x tb = a) (hbound : a * |x| < 2) :
    SchurStable (poly n x a) ↔ totalPhase n x tb < Real.pi := by
  have hpos := totalPhase_pos hn hx htb.le
  by_cases hodd : ∀ k : ℤ, totalPhase n x tb ≠ (2 * (k : ℝ) + 1) * Real.pi
  · let k := phaseIndex (totalPhase n x tb)
    have hk := phaseIndex_bounds hodd
    have hlo : -Real.pi < totalPhase n x tb - 2 * Real.pi * k := by dsimp [k]; nlinarith [hk.1]
    have hhi : totalPhase n x tb - 2 * Real.pi * k < Real.pi := by dsimp [k]; nlinarith [hk.2]
    have hroots := no_unit_roots_of_cayley_nonzero (poly_eval_conj n x a)
      (fun t ht => integrator_point_ne_zero n x ha htb hBeq hlo hhi ht)
      (poly_endpoint_ne_zero n ha hbound)
    rw [schur_iff_countOutside_zero (poly_ne_zero (by omega) x a) hroots]
    have hc := integrator_root_count (by omega : 1 ≤ n) ha htb hBeq hbound hodd
    have he : countOutside (poly n x a) = 0 ↔ phaseIndex (totalPhase n x tb) = 0 := by omega
    rw [he, phaseIndex_eq_zero_iff hpos.le]
  · push_neg at hodd
    obtain ⟨k, hk⟩ := hodd
    have hroot : (poly n x a).eval (point tb) = 0 := by
      rw [poly_eval_point, transfer_polar n x tb htb.le, hBeq, hk,
        NGamma.Cayley.exp_odd_pi k]
      ring
    have hns : ¬ SchurStable (poly n x a) := by
      intro hs
      have h := hs (point tb) hroot
      rw [point_norm] at h
      exact lt_irrefl 1 h
    have hnt : ¬ totalPhase n x tb < Real.pi := by
      intro h
      exact NGamma.Cayley.nonodd_of_phase_lt_pi hpos.le h k hk
    exact iff_of_false hns hnt

end C2.IntegratorDelay
