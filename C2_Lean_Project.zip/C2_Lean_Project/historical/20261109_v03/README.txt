C2 rational-delay optimization — Lean proof project, version 0.3.0
Formalization update: 9 November 2026

The 45-result development map now contains 44 COMPLETE and 1 PARTIAL
result. The remaining partial result is thm:exact-gain-projection:
generic CAD projection/lifting and effective algebraic root isolation are
not yet formally verified. Whole-article completion is not claimed.

This release closes 24 further numbered results: actual-root stability
regions and boundaries, integer-delay integrator results, the two-parameter
optimum, MIACE recurrences and optimization, exact sensitivity norms,
robustness, pole-radius optimization and rational bisection. All 13 earlier
arbitrary-order results remain complete. See PROOF_MAP_EN.csv for exact scope.

Pinned environment: Lean 4.19.0; mathlib
c44e0c8ee63ca166450922a373c7409c5d26b00b.
156 proof modules; 1355 explicit public theorem/lemma declarations;
1644 explicit public declarations audited. All 95 input proof modules
are preserved byte-for-byte. The additional 61 modules contain 452 new
public theorems/lemmas. Only propext, Classical.choice and Quot.sound occur
in the transitive axiom audit. No sorryAx or custom axioms are accepted.
The audit uses the unchanged official Lean.CollectAxioms.collect with one
shared visited set across all public roots. Its axiom union satisfies the
same allowed-axiom condition as all individual checks; exact per-root lists
are not produced. Evidence: work/SharedAxiomAudit.log and work/axiom_audit.json.
AxiomAudit.lean remains an optional per-root reporting input.

Build and check on a normal pinned installation:
  lake exe cache get
  python tools/make_single_file.py
  python tools/theorem_inventory.py
  lake build
  lake env lean -j1 live/C2_Live_Lean419.lean
  python tools/run_axiom_audit.py

After restoring the cache, tools/build_direct.py provides direct topological
compilation with one Lean job and pinned-dependency checks. Run --help for
its options. It avoids rebuilding the cached mathlib dependency graph.
This release used individual direct Lean compilations, the complete umbrella
import, the generated standalone file and the all-public-declaration audit.
VERIFICATION.json records the actual checks; a fresh lake build is not claimed.

C2.lean imports every module. live/C2_Live_Lean419.lean is generated from
the same sources and was checked independently as one file. This is a local
Lean check; no online live.lean website session is claimed. The distribution
omits dependency repositories, compiled objects and caches; Lake restores
dependencies from the pinned manifest.

MANUSCRIPT_FORMALIZATION_NOTES.md distinguishes written and formal proof
routes. COMPLETE means the numbered hypotheses and conclusions are covered,
not that every line of the printed proof is reproduced. In the general
realization theorem, minimal explicitly means dimension deg(D_gamma).
Equivalence with the separate Kalman controllability/observability definition
is not claimed. CAD's exact remaining obligations are listed in
validation/cad_remaining_20261109.md.

The full-cube result concerns the initial interval adjacent to zero; it does
not assert optimization of disconnected components. Positive-cascade
optimization is for one aligned sample. Fractional delays and arbitrary
new plant classes are outside the current numbered statements. Numerical
outputs and the earlier IJC checkpoint are retained as historical material.
No journal submission or external message was performed.
