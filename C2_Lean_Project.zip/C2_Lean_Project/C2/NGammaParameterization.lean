import C2.NGammaPolynomial

/-! Exact affine change between the manuscript's discretization weights gamma
and the proof's coordinates x=2*gamma-1. -/
noncomputable section
open Polynomial
namespace C2.NGamma.Parameterization

def xOfGamma (γ : ℝ) : ℝ := 2*γ-1
def gammaOfX (x : ℝ) : ℝ := (1+x)/2

theorem gammaOfX_xOfGamma (γ : ℝ) : gammaOfX (xOfGamma γ) = γ := by
  unfold gammaOfX xOfGamma
  ring

theorem xOfGamma_gammaOfX (x : ℝ) : xOfGamma (gammaOfX x) = x := by
  unfold gammaOfX xOfGamma
  ring

theorem half_cube_coordinate (γ : ℝ) :
    γ ∈ Set.Icc (1/2:ℝ) 1 ↔ xOfGamma γ ∈ Set.Icc (0:ℝ) 1 := by
  simp only [Set.mem_Icc, xOfGamma]
  constructor <;> rintro ⟨h1,h2⟩ <;> constructor <;> linarith

theorem full_cube_coordinate (γ : ℝ) :
    γ ∈ Set.Icc (0:ℝ) 1 ↔ xOfGamma γ ∈ Set.Icc (-1:ℝ) 1 := by
  simp only [Set.mem_Icc, xOfGamma]
  constructor <;> rintro ⟨h1,h2⟩ <;> constructor <;> linarith

theorem gammaOfX_injective : Function.Injective gammaOfX := by
  intro x y he
  have := congrArg xOfGamma he
  simpa only [xOfGamma_gammaOfX] using this

theorem xOfGamma_injective : Function.Injective xOfGamma := by
  intro x y he
  have := congrArg gammaOfX he
  simpa only [gammaOfX_xOfGamma] using this

theorem numerator_factor (γ : ℝ) :
    PolynomialModel.q (xOfGamma γ) = C (γ:ℂ)*X+C (1-(γ:ℂ)) := by
  apply Polynomial.funext
  intro z
  simp only [PolynomialModel.q_eval, eval_add, eval_mul, eval_C, eval_X]
  unfold xOfGamma
  push_cast
  ring

theorem vector_gamma_equality {ι : Type*} (x y : ι → ℝ) :
    (fun i => gammaOfX (x i)) = (fun i => gammaOfX (y i)) ↔ x=y := by
  constructor
  · intro he
    funext i
    apply gammaOfX_injective
    exact congrFun he i
  · intro he; rw [he]

end C2.NGamma.Parameterization
