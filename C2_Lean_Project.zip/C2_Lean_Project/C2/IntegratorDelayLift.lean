import C2.NGammaPiecewiseLift

/-! A translated polar curve whose amplitude is zero at the initial endpoint.
This is the integrator version of the strictly-positive cascade argument lift. -/
noncomputable section
open Set
open scoped Topology
namespace C2.IntegratorDelay
open NGamma.ArgumentMatch

theorem polarCurve_norm_nonneg {B ψ : ℝ → ℝ} {t : ℝ} (hB : 0 ≤ B t) :
    ‖polarCurve B ψ t‖ = B t := by
  simp [polarCurve, norm_mul, Complex.norm_exp_ofReal_mul_I, abs_of_nonneg hB]

theorem zero_left_branch_re_pos {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    (hBp : ∀ t ∈ Ici (0 : ℝ), 0 ≤ B t) (hBm : StrictMonoOn B (Ici 0))
    (hb : 0 < b) (htb : 0 ≤ tb) (hBeq : B tb = b)
    (hlo : -Real.pi < ψ tb - 2 * Real.pi * k)
    (hhi : ψ tb - 2 * Real.pi * k < Real.pi)
    {t : ℝ} (ht : 0 ≤ t) (htt : t ≤ tb) :
    0 < (polarCurve B ψ t + b).re := by
  rcases lt_or_eq_of_le htt with hlt | heq
  · apply add_re_pos_of_norm_lt
    rw [polarCurve_norm_nonneg (hBp t ht), ← hBeq]
    exact hBm ht htb hlt
  · subst t
    have hp := one_add_exp_re_pos hlo hhi
    rw [exp_sub_turns] at hp
    have he : polarCurve B ψ tb + b =
        (b : ℂ) * (1 + Complex.exp ((ψ tb : ℂ) * Complex.I)) := by
      simp only [polarCurve, hBeq]
      ring
    rw [he]
    simpa using mul_pos hb hp

theorem zero_right_branch_re_pos {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    (hBp : ∀ t ∈ Ioi (0 : ℝ), 0 < B t) (hBm : StrictMonoOn B (Ici 0))
    (hb : 0 < b) (htb : 0 < tb) (hBeq : B tb = b)
    (hlo : -Real.pi < ψ tb - 2 * Real.pi * k)
    (hhi : ψ tb - 2 * Real.pi * k < Real.pi)
    {t : ℝ} (htt : tb ≤ t) :
    0 < (1 + (b : ℂ) / polarCurve B ψ t).re := by
  have ht : 0 < t := lt_of_lt_of_le htb htt
  rcases lt_or_eq_of_le htt with hlt | heq
  · apply one_add_re_pos_of_norm_lt
    rw [norm_div, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hb,
      polarCurve_norm (hBp t ht)]
    apply (div_lt_one (hBp t ht)).2
    rw [← hBeq]
    exact hBm htb.le ht.le hlt
  · subst t
    have hbn : (b : ℂ) ≠ 0 := by exact_mod_cast hb.ne'
    have he : (b : ℂ) / polarCurve B ψ tb = Complex.exp (-((ψ tb) : ℂ) * Complex.I) := by
      rw [polarCurve, hBeq, neg_mul, Complex.exp_neg]
      field_simp
    rw [he, neg_mul, Complex.exp_neg, ← exp_sub_turns (ψ tb) k,
      ← Complex.exp_neg, ← neg_mul]
    convert one_add_exp_re_pos (u := -(ψ tb - 2 * Real.pi * k))
      (by linarith) (by linarith) using 1 <;> simp only [Complex.ofReal_neg]

theorem zero_translatedAngle_continuousOn {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    (hB : Continuous B) (hψ : Continuous ψ)
    (hB0 : ∀ t ∈ Ici (0 : ℝ), 0 ≤ B t) (hBp : ∀ t ∈ Ioi (0 : ℝ), 0 < B t)
    (hBm : StrictMonoOn B (Ici 0)) (hb : 0 < b) (htb : 0 < tb) (hBeq : B tb = b)
    (hlo : -Real.pi < ψ tb - 2 * Real.pi * k)
    (hhi : ψ tb - 2 * Real.pi * k < Real.pi) :
    ContinuousOn (translatedAngle B ψ b tb k) (Ici 0) := by
  have hW := polarCurve_continuous hB hψ
  have hleft : ContinuousOn (fun t => Complex.arg (polarCurve B ψ t + b))
      (Ici 0 ∩ Iic tb) := by
    intro t ht
    exact ContinuousAt.comp_continuousWithinAt (f := fun u => polarCurve B ψ u + (b : ℂ))
      (Complex.continuousAt_arg (Or.inl
        (zero_left_branch_re_pos hB0 hBm hb htb.le hBeq hlo hhi ht.1 ht.2)))
      (hW.add continuous_const).continuousAt.continuousWithinAt
  have hright : ContinuousOn
      (fun t => ψ t + Complex.arg (1 + (b : ℂ) / polarCurve B ψ t) - 2 * Real.pi * k)
      (Ici 0 ∩ Ici tb) := by
    intro t ht
    apply ContinuousWithinAt.sub _ continuousWithinAt_const
    apply hψ.continuousAt.continuousWithinAt.add
    have hc : ContinuousWithinAt (fun u => 1 + (b : ℂ) / polarCurve B ψ u)
        (Ici 0 ∩ Ici tb) t :=
      continuousWithinAt_const.add
        (continuousWithinAt_const.div hW.continuousAt.continuousWithinAt
          (polarCurve_ne_zero (hBp t (lt_of_lt_of_le htb ht.2))))
    exact ContinuousAt.comp_continuousWithinAt
      (f := fun u => 1 + (b : ℂ) / polarCurve B ψ u)
      (Complex.continuousAt_arg (Or.inl
        (zero_right_branch_re_pos hBp hBm hb htb hBeq hlo hhi ht.2))) hc
  have hmatch : ∀ t ∈ Ici (0 : ℝ) ∩ frontier (Iic tb),
      Complex.arg (polarCurve B ψ t + b) =
        ψ t + Complex.arg (1 + (b : ℂ) / polarCurve B ψ t) - 2 * Real.pi * k := by
    intro t ht
    have he : t = tb := by simpa using ht.2
    subst t
    simp only [polarCurve, hBeq]
    exact amplitude_crossing_branch_match hb (ψ tb) k hlo hhi
  simpa only [closure_Iic, compl_Iic, closure_Ioi, Set.piecewise, mem_Iic] using
    (ContinuousOn.piecewise (t := Iic tb) hmatch
      (by simpa only [closure_Iic] using hleft)
      (by simpa only [compl_Iic, closure_Ioi] using hright))

theorem zero_translated_curve_ne_zero {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    (hB0 : ∀ t ∈ Ici (0 : ℝ), 0 ≤ B t) (hBp : ∀ t ∈ Ioi (0 : ℝ), 0 < B t)
    (hBm : StrictMonoOn B (Ici 0)) (hb : 0 < b) (htb : 0 < tb) (hBeq : B tb = b)
    (hlo : -Real.pi < ψ tb - 2 * Real.pi * k)
    (hhi : ψ tb - 2 * Real.pi * k < Real.pi)
    {t : ℝ} (ht : 0 ≤ t) : polarCurve B ψ t + b ≠ 0 := by
  by_cases htt : t ≤ tb
  · intro hz
    have hp := zero_left_branch_re_pos hB0 hBm hb htb.le hBeq hlo hhi ht htt
    rw [hz] at hp
    exact lt_irrefl 0 hp
  · have htpos : 0 < t := lt_trans htb (lt_of_not_ge htt)
    have hW := polarCurve_ne_zero (ψ := ψ) (hBp t htpos)
    have hp := zero_right_branch_re_pos hBp hBm hb htb hBeq hlo hhi (le_of_not_ge htt)
    intro hz
    have he : 1 + (b : ℂ) / polarCurve B ψ t = 0 := by
      field_simp
      linear_combination hz
    rw [he] at hp
    exact lt_irrefl 0 hp

theorem zero_translatedAngle_polar {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    (hBp : ∀ t ∈ Ioi (0 : ℝ), 0 < B t) (htb : 0 ≤ tb)
    {t : ℝ} (ht : 0 ≤ t) :
    polarCurve B ψ t + b = (‖polarCurve B ψ t + b‖ : ℂ) *
      Complex.exp ((translatedAngle B ψ b tb k t : ℂ) * Complex.I) := by
  by_cases htt : t ≤ tb
  · simp only [translatedAngle, htt, if_pos]
    exact (Complex.norm_mul_exp_arg_mul_I _).symm
  · exact translatedAngle_polar (hBp t (lt_of_le_of_lt htb (lt_of_not_ge htt)))

theorem zero_translatedAngle_zero {B ψ : ℝ → ℝ} {b tb : ℝ} {k : ℤ}
    (hB0 : B 0 = 0) (hb : 0 < b) (htb : 0 ≤ tb) :
    translatedAngle B ψ b tb k 0 = 0 := by
  simp only [translatedAngle, htb, if_pos, polarCurve, hB0, Complex.ofReal_zero,
    zero_mul, zero_add]
  exact Complex.arg_ofReal_of_nonneg hb.le

end C2.IntegratorDelay
