import C2.CADEffectivePolynomial

/-! Executable bivariate rational arithmetic. Outer lists index gamma powers;
inner rational lists index gain powers. Equality is checked coefficientwise. -/
namespace C2.CADEffective.Bivariate
open Polynomial

abbrev Poly := List Dense.Poly

noncomputable def denote (p : Poly) : Polynomial (Polynomial ℚ) :=
  p.foldr (fun a b => C (Dense.denote a) + X*b) 0

@[simp] theorem denote_nil : denote [] = 0 := rfl
@[simp] theorem denote_cons (a : Dense.Poly) (p : Poly) :
    denote (a :: p) = C (Dense.denote a) + X * denote p := rfl

@[simp] theorem coeff_denote (p : Poly) (n : ℕ) :
    (denote p).coeff n = Dense.denote (p.getD n []) := by
  induction p generalizing n with
  | nil => simp [List.getD_nil]
  | cons a p ih =>
      cases n with
      | zero => simp
      | succ n => simp [coeff_X_mul, ih]

def add : Poly → Poly → Poly
  | [], q => q
  | p, [] => p
  | a :: p, b :: q => Dense.add a b :: add p q

def neg (p : Poly) : Poly := p.map Dense.neg

def scale (a : Dense.Poly) (p : Poly) : Poly := p.map (Dense.mul a)

def mul : Poly → Poly → Poly
  | [], _ => []
  | a :: p, q => add (scale a q) ([] :: mul p q)

def constant (a : Dense.Poly) : Poly := [a]

def one : Poly := [[1]]

def pow (p : Poly) : ℕ → Poly
  | 0 => one
  | n+1 => mul (pow p n) p

def derivative : Poly → Poly
  | [] => []
  | _ :: p => add p ([] :: derivative p)

def atGain (p : Poly) (k : ℚ) : Dense.Poly := p.map (fun a => Dense.eval a k)

def eval (p : Poly) (gamma k : ℚ) : ℚ := Dense.eval (atGain p k) gamma

def eqb (p q : Poly) : Bool :=
  (List.range (max p.length q.length)).all
    (fun n => Dense.eqb (p.getD n []) (q.getD n []))

@[simp] theorem denote_add (p q : Poly) : denote (add p q) = denote p + denote q := by
  induction p generalizing q with
  | nil => simp [add]
  | cons a p ih =>
      cases q with
      | nil => simp [add]
      | cons b q => simp [add, ih, C_add]; ring

@[simp] theorem denote_neg (p : Poly) : denote (neg p) = -denote p := by
  induction p with
  | nil => simp [neg]
  | cons a p ih =>
      simp only [neg, List.map_cons, denote_cons, Dense.denote_neg, C_neg]
      rw [show denote (List.map Dense.neg p) = -denote p from ih]
      ring

@[simp] theorem denote_scale (a : Dense.Poly) (p : Poly) :
    denote (scale a p) = C (Dense.denote a) * denote p := by
  induction p with
  | nil => simp [scale]
  | cons b p ih =>
      simp only [scale, List.map_cons, denote_cons, Dense.denote_mul, C_mul]
      rw [show denote (List.map (Dense.mul a) p) = C (Dense.denote a) * denote p from ih]
      ring

@[simp] theorem denote_mul (p q : Poly) : denote (mul p q) = denote p * denote q := by
  induction p with
  | nil => simp [mul]
  | cons a p ih => simp [mul, ih]; ring

@[simp] theorem denote_constant (p : Dense.Poly) : denote (constant p) = C (Dense.denote p) := by
  simp [constant]

@[simp] theorem denote_one : denote one = 1 := by simp [one]

@[simp] theorem denote_pow (p : Poly) (n : ℕ) : denote (pow p n) = denote p ^ n := by
  induction n with
  | zero => simp [pow]
  | succ n ih => simp [pow, ih, pow_succ]

@[simp] theorem denote_derivative (p : Poly) : denote (derivative p) = (denote p).derivative := by
  induction p with
  | nil => simp [derivative]
  | cons a p ih => simp [derivative, ih, Polynomial.derivative_mul, add_comm]

@[simp] theorem denote_atGain (p : Poly) (k : ℚ) :
    Dense.denote (atGain p k) = (denote p).map (Polynomial.evalRingHom k) := by
  induction p with
  | nil => simp [atGain]
  | cons a p ih =>
      change Dense.denote (Dense.eval a k :: atGain p k) =
        (C (Dense.denote a) + X * denote p).map (Polynomial.evalRingHom k)
      rw [Dense.denote_cons, ih]
      simp [Dense.eval_denote]

@[simp] theorem eval_denote (p : Poly) (gamma k : ℚ) :
    eval p gamma k = ((denote p).map (Polynomial.evalRingHom k)).eval gamma := by
  simp only [eval, Dense.eval_denote, denote_atGain]

@[simp] theorem eqb_eq_true_iff (p q : Poly) : eqb p q = true ↔ denote p = denote q := by
  simp only [eqb, List.all_eq_true, List.mem_range, Dense.eqb_eq_true_iff]
  constructor
  · intro h
    apply Polynomial.ext
    intro n
    by_cases hn : n < max p.length q.length
    · simpa only [coeff_denote] using h n hn
    · simp only [coeff_denote]
      rw [List.getD_eq_default _ _ (by omega), List.getD_eq_default _ _ (by omega)]
  · intro h n hn
    simpa only [coeff_denote] using congrArg (fun P : Polynomial (Polynomial ℚ) => P.coeff n) h

/-- Existence of a finite dense encoding; no encoding oracle is used at runtime. -/
theorem exists_encoding (p : Polynomial (Polynomial ℚ)) : ∃ v : Poly, denote v = p := by
  choose f hf using (fun i : Fin (p.natDegree + 1) => Dense.exists_encoding (p.coeff i))
  refine ⟨List.ofFn f, ?_⟩
  apply Polynomial.ext
  intro n
  simp only [coeff_denote]
  by_cases hn : n < p.natDegree + 1
  · rw [List.getD_eq_getElem _ _ (by simpa using hn)]
    rw [List.getElem_ofFn]
    exact hf _
  · rw [List.getD_eq_default _ _ (by simp; omega), Dense.denote_nil]
    exact (coeff_eq_zero_of_natDegree_lt (by omega)).symm

end C2.CADEffective.Bivariate
