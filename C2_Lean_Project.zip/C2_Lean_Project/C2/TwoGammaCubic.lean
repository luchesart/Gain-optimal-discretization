import C2.TwoGammaBasic
import C2.TwoGammaCoefficients
import C2.SecondOrder

/-! Cubic necessary inequalities for the complete parameter square. -/
noncomputable section
open scoped BigOperators
open Polynomial Set
namespace C2.TwoGamma
open NGamma NGamma.PolynomialModel

theorem polynomial_coefficients (r₁ r₂ x y b : ℝ) (z : ℂ) :
    (PolynomialModel.characteristic (poles r₁ r₂) ![x,y] 1 b).eval z =
      (leading r₁ r₂ x y:ℂ)*z^3+(middleB r₁ r₂ x y b:ℂ)*z^2+
      (middleC r₁ r₂ x y b:ℂ)*z+(constantCoeff x y b:ℂ) := by
  simp [PolynomialModel.characteristic,poles,Fin.prod_univ_two,
    factor_eval,q_eval,leading,middleB,middleC,constantCoeff,A0,A3]
  push_cast
  ring

theorem leading_pos {r₁ r₂ x y : ℝ} (hr₁ : 0 < r₁) (hr₂ : 0 < r₂)
    (hx : -1 ≤ x) (hy : -1 ≤ y) : 0 < leading r₁ r₂ x y := by
  unfold leading
  have hx' : 0 ≤ 1+x := by linarith
  have hy' : 0 ≤ 1+y := by linarith
  positivity

theorem stable_iff_cubic {r₁ r₂ x y b : ℝ} (hl : 0 < leading r₁ r₂ x y) :
    SchurStable (PolynomialModel.characteristic (poles r₁ r₂) ![x,y] 1 b) ↔
      C2.CubicSchur (middleB r₁ r₂ x y b/leading r₁ r₂ x y)
        (middleC r₁ r₂ x y b/leading r₁ r₂ x y)
        (constantCoeff x y b/leading r₁ r₂ x y) := by
  have hlc : (leading r₁ r₂ x y : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hl
  have he (z : ℂ) :
      (PolynomialModel.characteristic (poles r₁ r₂) ![x,y] 1 b).eval z =
      (leading r₁ r₂ x y:ℂ)*(z^3+(middleB r₁ r₂ x y b/leading r₁ r₂ x y:ℝ)*z^2+
        (middleC r₁ r₂ x y b/leading r₁ r₂ x y:ℝ)*z+(constantCoeff x y b/leading r₁ r₂ x y:ℝ)) := by
    rw [polynomial_coefficients]
    push_cast
    field_simp [hlc]
    ring
  constructor
  · intro hs z hz
    apply hs z
    rw [he,hz,mul_zero]
  · intro hs z hz
    apply hs z
    rw [he] at hz
    exact (mul_eq_zero.mp hz).resolve_left hlc

/-- Actual Schur stability implies the strict cubic Hurwitz inequalities. -/
theorem stable_necessary {r₁ r₂ x y b : ℝ} (hr₁ : 0 < r₁) (hr₂ : 0 < r₂)
    (hx : x ∈ Icc (-1:ℝ) 1) (hy : y ∈ Icc (-1:ℝ) 1) (hb : 0 ≤ b)
    (hs : SchurStable (PolynomialModel.characteristic (poles r₁ r₂) ![x,y] 1 b)) :
    0 < A1 r₁ r₂ x y b ∧ 0 < A2 r₁ r₂ x y b ∧ 0 < A3 r₁ r₂ x y b ∧ 0 < H r₁ r₂ x y b := by
  have hl := leading_pos hr₁ hr₂ hx.1 hy.1
  have hd : 0 ≤ constantCoeff x y b := by unfold constantCoeff; exact div_nonneg (mul_nonneg (mul_nonneg hb (by linarith [hx.2])) (by linarith [hy.2])) (by norm_num)
  have h0 : 0 < A0 r₁ r₂ b := by unfold A0; positivity
  have hj := (SecondOrder.scaled_cubicSchur_iff _ _ _ _ hl).mp ((stable_iff_cubic hl).mp hs)
  rw [abs_of_nonneg hd] at hj
  obtain ⟨hp,hm,hdet,hsum⟩ := coefficient_identities r₁ r₂ x y b
  have h3 : 0 < A3 r₁ r₂ x y b := by linarith [hj.2.2.1]
  have hH : 0 < H r₁ r₂ x y b := by linarith [hj.2.2.2]
  have hprod : 0 < (leading r₁ r₂ x y-constantCoeff x y b)*
      (leading r₁ r₂ x y+2*constantCoeff x y b-middleC r₁ r₂ x y b) := by
    nlinarith [mul_nonneg hd h3.le,hj.2.2.2]
  have hc : middleC r₁ r₂ x y b < leading r₁ r₂ x y+2*constantCoeff x y b := by
    by_contra hn
    have hh := mul_nonpos_of_nonneg_of_nonpos (by linarith [hj.1] : 0 ≤ leading r₁ r₂ x y-constantCoeff x y b)
      (by linarith [le_of_not_gt hn] : leading r₁ r₂ x y+2*constantCoeff x y b-middleC r₁ r₂ x y b ≤ 0)
    linarith
  have hsumpos : 0 < A1 r₁ r₂ x y b+A2 r₁ r₂ x y b := by linarith [hj.1]
  have hp12 : 0 < A1 r₁ r₂ x y b*A2 r₁ r₂ x y b := by
    have hh := mul_pos h0 h3
    unfold H at hH
    linarith
  have h1 : 0 < A1 r₁ r₂ x y b := by
    by_contra hn
    have h2 : 0 < A2 r₁ r₂ x y b := by linarith [le_of_not_gt hn]
    have hh := mul_nonpos_of_nonpos_of_nonneg (le_of_not_gt hn) h2.le
    linarith
  have h2 : 0 < A2 r₁ r₂ x y b := (mul_pos_iff_of_pos_left h1).mp hp12
  exact ⟨h1,h2,h3,hH⟩

end C2.TwoGamma
