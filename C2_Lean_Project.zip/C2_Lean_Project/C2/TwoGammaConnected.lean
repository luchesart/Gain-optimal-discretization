import C2.TwoGammaBasic
import C2.NGammaGainInterval

noncomputable section
open scoped BigOperators
open Polynomial Set
namespace C2.TwoGamma
open NGamma NGamma.PolynomialModel NGamma.Parameterization

/-- Complete numbered lemma `lem:two-gamma-connected`, in the paper's gamma
coordinates and with its actual complex characteristic polynomial. -/
theorem connected_stable_gain_interval {r₁ r₂ γ₁ γ₂ : ℝ}
    (hr₁ : 0 < r₁) (hr₂ : 0 < r₂)
    (hγ₁ : γ₁ ∈ Icc (1/2:ℝ) 1) (hγ₂ : γ₂ ∈ Icc (1/2:ℝ) 1) :
    ∃ B : ℝ, 0 < B ∧
      {b : ℝ | 0 ≤ b ∧ SchurStable (characteristic r₁ r₂ γ₁ γ₂ b)} = Ico 0 B := by
  have hr := poles_pos hr₁ hr₂
  have hx := coordinates_in_half_cube hγ₁ hγ₂
  have hinterval : ∃ B : ℝ, 0 < B ∧ ∀ b : ℝ, 0 ≤ b →
      (SchurStable (PolynomialModel.characteristic (poles r₁ r₂) (coordinates γ₁ γ₂) 1 b) ↔ b < B) := by
    rcases Cayley.single_sample_exact_gain_interval (by norm_num : 0 < (2:ℕ))
      hr (fun i => (hx i).1) (fun i => (hx i).2) with he | hi
    · obtain ⟨hxp,hS,hs,hroot⟩ := he
      exact ⟨_,Finset.prod_pos (fun i _ => by have := hr i; have := hxp i; positivity),hs⟩
    · obtain ⟨s,⟨hs,hphase,hstable,hroot,hnorm⟩,_⟩ := hi
      exact ⟨_,Cayley.amplitude_pos hr _ s,hstable⟩
  obtain ⟨B,hB,hstable⟩ := hinterval
  refine ⟨B,hB,?_⟩
  ext b
  simp only [Set.mem_setOf_eq,mem_Ico]
  constructor
  · rintro ⟨hb,hs⟩
    rw [characteristic_eq_generic] at hs
    exact ⟨hb,(hstable b hb).mp hs⟩
  · rintro ⟨hb,hbB⟩
    refine ⟨hb,?_⟩
    rw [characteristic_eq_generic]
    exact (hstable b hb).mpr hbB

end C2.TwoGamma
