import C2.NGammaGlobal
import C2.NGammaPhase

noncomputable section
open scoped BigOperators Topology
open Set Filter

namespace C2.NGamma.Global

def sumRatio {n : ℕ} (r x : Fin n → ℝ) (t : ℝ) : ℝ :=
  ∑ j, Phase.ratio (x j + 2/r j) (x j) t

def endpointSum {n : ℕ} (r : Fin n → ℝ) : ℝ :=
  ∑ j, 1/(r j+2)

def feasible {n : ℕ} (r : Fin n → ℝ) (w : ℝ) : Prop :=
  ∃ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) ∧
    ∑ j, phase (r j) (x j) w = 2*Real.arctan w

theorem ratio_continuousOn {a x : ℝ} : ContinuousOn (Phase.ratio a x) (Ioi 0) := by
  intro t ht
  have hn : Continuous (Phase.contribution a x) := by
    unfold Phase.contribution
    exact (Real.continuous_arctan.comp (continuous_const.mul continuous_id)).sub
      (Real.continuous_arctan.comp (continuous_const.mul continuous_id))
  have hd : ContinuousAt (fun u : ℝ => Real.arctan (1/u)) t :=
    Real.continuous_arctan.continuousAt.comp
      (continuousAt_const.div continuousAt_id (ne_of_gt ht))
  have hp := Phase.arctan_pos (one_div_pos.mpr ht)
  exact (hn.continuousAt.div hd hp.ne').continuousWithinAt

theorem sumRatio_continuousOn {n : ℕ} (r x : Fin n → ℝ) :
    ContinuousOn (sumRatio r x) (Ioi 0) := by
  exact continuousOn_finset_sum _ (fun j _ => ratio_continuousOn)

theorem sumRatio_strictMonoOn {n : ℕ} (hn : 0 < n) (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hx : ∀ j, x j ∈ Icc (0:ℝ) 1) :
    StrictMonoOn (sumRatio r x) (Ioi 0) := by
  intro s hs t ht hst
  apply Finset.sum_lt_sum
  · intro j _
    exact (Phase.ratio_strictMonoOn (hx j).1 (hx j).2
      (by have := div_pos (by norm_num : (0:ℝ)<2) (hr j); linarith) hs ht hst).le
  · refine ⟨⟨0,hn⟩,Finset.mem_univ _,?_⟩
    exact Phase.ratio_strictMonoOn (hx ⟨0,hn⟩).1 (hx ⟨0,hn⟩).2
      (by have := div_pos (by norm_num : (0:ℝ)<2) (hr ⟨0,hn⟩); linarith) hs ht hst

theorem sumRatio_tendsto_zero {n : ℕ} (r x : Fin n → ℝ) :
    Tendsto (sumRatio r x) (𝓝[>] 0) (𝓝 0) := by
  simpa [sumRatio] using tendsto_finset_sum Finset.univ
    (fun j _ => Phase.ratio_tendsto_zero (x j+2/r j) (x j))

theorem sumRatio_zero_atTop {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) :
    Tendsto (sumRatio r (fun _ => 0)) atTop atTop := by
  have h := Phase.ratio_tendsto_atTop_of_zero
    (a := 0+2/r ⟨0,hn⟩) (by have := hr ⟨0,hn⟩; positivity)
  refine tendsto_atTop_mono' atTop ?_ h
  filter_upwards [eventually_gt_atTop (0:ℝ)] with t ht
  unfold sumRatio
  apply Finset.single_le_sum (f := fun j : Fin n => Phase.ratio (0+2/r j) 0 t)
    (s := Finset.univ) (fun j _ => ?_) (Finset.mem_univ ⟨0,hn⟩)
  exact (div_pos (Phase.contribution_pos
    (by have := div_pos (by norm_num : (0:ℝ)<2) (hr j); linarith) ht)
    (Phase.arctan_pos (one_div_pos.mpr ht))).le

theorem sumRatio_one_atTop {n : ℕ} (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    Tendsto (sumRatio r (fun _ => 1)) atTop (𝓝 (2*endpointSum r)) := by
  have hi (j : Fin n) : 1/(1:ℝ)-1/(1+2/r j) = 2*(1/(r j+2)) := by
    have hj : r j ≠ 0 := (hr j).ne'
    have hj2 : r j + 2 ≠ 0 := by have := hr j; positivity
    field_simp
    <;> ring
  have h := tendsto_finset_sum Finset.univ (fun j _ =>
    Phase.ratio_tendsto_atTop_of_pos (a := 1+2/r j) (x := 1) (by norm_num)
      (by have := div_pos (by norm_num : (0:ℝ)<2) (hr j); linarith))
  simpa only [sumRatio,hi,endpointSum,Finset.mul_sum] using h

theorem sumRatio_eq_phase_sum {n : ℕ} (r x : Fin n → ℝ) (t : ℝ) :
    sumRatio r x t = (∑ j, phase (r j) (x j) (1/t)) / Real.arctan (1/t) := by
  unfold sumRatio Phase.ratio Phase.contribution phase
  rw [Finset.sum_div]
  simp only [div_eq_mul_inv,inv_inv,one_mul]

theorem feasible_iff_ratios {n : ℕ} (r : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {w : ℝ} (hw : 0 < w) :
    feasible r w ↔ sumRatio r (fun _ => 1) (1/w) ≤ 2 ∧
      2 ≤ sumRatio r (fun _ => 0) (1/w) := by
  have hp := Phase.arctan_pos hw
  rw [sumRatio_eq_phase_sum,sumRatio_eq_phase_sum]
  simp only [one_div_one_div]
  rw [div_le_iff₀ hp,le_div_iff₀ hp]
  exact phase_feasible_iff r hr hw

theorem sumRatio_one_lt_zero {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) {t : ℝ} (ht : 0 < t) :
    sumRatio r (fun _ => 1) t < sumRatio r (fun _ => 0) t := by
  rw [sumRatio_eq_phase_sum,sumRatio_eq_phase_sum]
  apply (div_lt_div_iff_of_pos_right (Phase.arctan_pos (one_div_pos.mpr ht))).2
  apply Finset.sum_lt_sum
  · intro j _
    exact (phase_strictAntiOn (hr j) (one_div_pos.mpr ht)
      (by norm_num) (by norm_num) (by norm_num : (0:ℝ)<1)).le
  · exact ⟨⟨0,hn⟩,Finset.mem_univ _,phase_strictAntiOn (hr ⟨0,hn⟩)
      (one_div_pos.mpr ht) (by norm_num) (by norm_num) (by norm_num : (0:ℝ)<1)⟩

theorem all_zero_crossing {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) :
    ∃! t, 0 < t ∧ sumRatio r (fun _ => 0) t = 2 :=
  unique_positive_crossing_atTop (sumRatio_continuousOn _ _)
    (sumRatio_strictMonoOn hn r _ hr (by intro j; norm_num))
    (sumRatio_tendsto_zero _ _) (sumRatio_zero_atTop hn r hr)

theorem all_one_crossing {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hS : 1 < endpointSum r) :
    ∃! t, 0 < t ∧ sumRatio r (fun _ => 1) t = 2 :=
  unique_positive_crossing_finite (sumRatio_continuousOn _ _)
    (sumRatio_strictMonoOn hn r _ hr (by intro j; norm_num))
    (sumRatio_tendsto_zero _ _) (sumRatio_one_atTop r hr) (by linarith)

theorem all_one_below_two {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hS : endpointSum r ≤ 1) {t : ℝ} (ht : 0 < t) :
    sumRatio r (fun _ => 1) t < 2 := by
  have h := strictly_below_finite_limit
    (sumRatio_strictMonoOn hn r _ hr (by intro j; norm_num))
    (sumRatio_one_atTop r hr) ht
  linarith

/-- Full feasible-frequency interval, in the original reciprocal half-angle
variable w. The endpoints are unique through the all-zero/all-one crossing
theorems, and the feasible vectors at them are identified below. -/
theorem feasible_frequency_interval {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) :
    ∃ wp : ℝ, 0 < wp ∧ sumRatio r (fun _ => 0) (1/wp) = 2 ∧
      (endpointSum r ≤ 1 → ∀ w, 0 < w → (feasible r w ↔ w ≤ wp)) ∧
      (1 < endpointSum r → ∃ wm : ℝ, 0 < wm ∧ wm < wp ∧
        sumRatio r (fun _ => 1) (1/wm) = 2 ∧
        ∀ w, 0 < w → (feasible r w ↔ wm ≤ w ∧ w ≤ wp)) := by
  obtain ⟨tp,htp,_⟩ := all_zero_crossing hn r hr
  have hmp := sumRatio_strictMonoOn hn r (fun _ => 0) hr (by intro j; norm_num)
  refine ⟨1/tp,one_div_pos.mpr htp.1,by simpa using htp.2,?_,?_⟩
  · intro hS w hw
    rw [feasible_iff_ratios r hr hw]
    have hlo := (all_one_below_two hn r hr hS (one_div_pos.mpr hw)).le
    rw [and_iff_right hlo]
    rw [(crossing_order_iff hmp htp.1 (one_div_pos.mpr hw) htp.2).2]
    rw [le_div_iff₀ hw,le_div_iff₀ htp.1]
    constructor <;> intro h <;> nlinarith
  · intro hS
    obtain ⟨tm,htm,_⟩ := all_one_crossing hn r hr hS
    have hmm := sumRatio_strictMonoOn hn r (fun _ => 1) hr (by intro j; norm_num)
    have hpm : tp < tm := by
      apply (hmp.lt_iff_lt htp.1 htm.1).mp
      rw [htp.2,← htm.2]
      exact sumRatio_one_lt_zero hn r hr htm.1
    refine ⟨1/tm,one_div_pos.mpr htm.1,
      one_div_lt_one_div_of_lt htp.1 hpm,by simpa using htm.2,?_⟩
    intro w hw
    rw [feasible_iff_ratios r hr hw]
    rw [(crossing_order_iff hmm htm.1 (one_div_pos.mpr hw) htm.2).1,
      (crossing_order_iff hmp htp.1 (one_div_pos.mpr hw) htp.2).2]
    rw [div_le_iff₀ hw,div_le_iff₀ htm.1,le_div_iff₀ hw,le_div_iff₀ htp.1]
    constructor <;> rintro ⟨ha,hb⟩ <;> constructor <;> nlinarith

theorem ratio_eq_two_iff_phase_eq {n : ℕ} (r x : Fin n → ℝ)
    {w : ℝ} (hw : 0 < w) :
    sumRatio r x (1/w) = 2 ↔
      (∑ j, phase (r j) (x j) w) = 2*Real.arctan w := by
  rw [sumRatio_eq_phase_sum]
  simp only [one_div_one_div]
  exact div_eq_iff (Phase.arctan_pos hw).ne'

theorem upper_endpoint_equation {n : ℕ} (r : Fin n → ℝ)
    {w : ℝ} (hw : 0 < w) :
    sumRatio r (fun _ => 0) (1/w) = 2 ↔
      (∑ j, Real.arctan (2/(r j*w))) = 2*Real.arctan w := by
  simpa [phase,div_div] using ratio_eq_two_iff_phase_eq r (fun _ => 0) hw

theorem lower_endpoint_equation {n : ℕ} (r : Fin n → ℝ)
    {w : ℝ} (hw : 0 < w) :
    sumRatio r (fun _ => 1) (1/w) = 2 ↔
      (∑ j, (Real.arctan ((1+2/r j)/w) - Real.arctan (1/w))) =
        2*Real.arctan w := by
  exact ratio_eq_two_iff_phase_eq r (fun _ => 1) hw

theorem upper_frequency_existsUnique {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) :
    ∃! w, 0 < w ∧ (∑ j, Real.arctan (2/(r j*w))) = 2*Real.arctan w := by
  obtain ⟨t,ht,hunique⟩ := all_zero_crossing hn r hr
  refine ⟨1/t,⟨one_div_pos.mpr ht.1,?_⟩,?_⟩
  · apply (upper_endpoint_equation r (one_div_pos.mpr ht.1)).mp
    simpa using ht.2
  · intro w hw
    have hi := hunique (1/w) ⟨one_div_pos.mpr hw.1,(upper_endpoint_equation r hw.1).mpr hw.2⟩
    calc w = 1/(1/w) := by simp
      _ = 1/t := by rw [hi]

theorem lower_frequency_existsUnique {n : ℕ} (hn : 0 < n) (r : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hS : 1 < endpointSum r) :
    ∃! w, 0 < w ∧
      (∑ j, (Real.arctan ((1+2/r j)/w) - Real.arctan (1/w))) = 2*Real.arctan w := by
  obtain ⟨t,ht,hunique⟩ := all_one_crossing hn r hr hS
  refine ⟨1/t,⟨one_div_pos.mpr ht.1,?_⟩,?_⟩
  · apply (lower_endpoint_equation r (one_div_pos.mpr ht.1)).mp
    simpa using ht.2
  · intro w hw
    have hi := hunique (1/w) ⟨one_div_pos.mpr hw.1,(lower_endpoint_equation r hw.1).mpr hw.2⟩
    calc w = 1/(1/w) := by simp
      _ = 1/t := by rw [hi]

theorem upper_frequency_vector_unique {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) {w : ℝ} (hw : 0 < w)
    (hwp : (∑ j, Real.arctan (2/(r j*w))) = 2*Real.arctan w)
    (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    (hphase : (∑ j, phase (r j) (x j) w) = 2*Real.arctan w) :
    ∀ j, x j = 0 := by
  have hz := (ratio_eq_two_iff_phase_eq r (fun _ => 0) hw).mp
    ((upper_endpoint_equation r hw).mpr hwp)
  exact phase_upper_endpoint_unique r x hr hw hx (hphase.trans hz.symm)

theorem lower_frequency_vector_unique {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) {w : ℝ} (hw : 0 < w)
    (hwm : (∑ j, (Real.arctan ((1+2/r j)/w) - Real.arctan (1/w))) =
      2*Real.arctan w)
    (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    (hphase : (∑ j, phase (r j) (x j) w) = 2*Real.arctan w) :
    ∀ j, x j = 1 := by
  exact phase_lower_endpoint_unique r x hr hw hx (hphase.trans hwm.symm)

end C2.NGamma.Global
