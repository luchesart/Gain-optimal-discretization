import Mathlib

/-! Effective rational coefficient enclosures for a general real polynomial.
These estimates support a dyadic root-isolation procedure; no root oracle occurs
in the definitions. -/
namespace C2.CADIsolation
open Polynomial Set

/-- Evaluation through the canonical rational-to-real embedding. -/
noncomputable def realEval (p : ℚ[X]) (x : ℝ) : ℝ := p.eval₂ (algebraMap ℚ ℝ) x

/-- A computable coefficient one-norm bound at radius `R`. -/
def coeffBound (p : ℚ[X]) (R : ℚ) : ℚ :=
  ∑ i ∈ p.support, |p.coeff i| * R^i

@[simp] theorem realEval_rat (p : ℚ[X]) (x : ℚ) :
    realEval p (x:ℝ) = ((p.eval x : ℚ) : ℝ) := by
  exact Polynomial.eval₂_at_apply (algebraMap ℚ ℝ) x

theorem realEval_continuous (p : ℚ[X]) : Continuous (realEval p) :=
  p.continuous_eval₂ _

theorem coeffBound_nonneg (p : ℚ[X]) {R : ℚ} (hR : 0 ≤ R) :
    0 ≤ coeffBound p R := by
  exact Finset.sum_nonneg (fun i hi => mul_nonneg (abs_nonneg _) (pow_nonneg hR _))

theorem abs_realEval_le_coeffBound (p : ℚ[X]) {R : ℚ} (hR : 0 ≤ R)
    {x : ℝ} (hx : |x| ≤ (R:ℝ)) :
    |realEval p x| ≤ (coeffBound p R : ℝ) := by
  rw [realEval, Polynomial.eval₂_eq_sum, Polynomial.sum_def]
  calc
    |∑ i ∈ p.support, (algebraMap ℚ ℝ) (p.coeff i) * x^i| ≤
        ∑ i ∈ p.support, |(algebraMap ℚ ℝ) (p.coeff i) * x^i| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i ∈ p.support, |(p.coeff i : ℝ)| * (R:ℝ)^i := by
      apply Finset.sum_le_sum
      intro i hi
      change |(p.coeff i:ℝ) * x^i| ≤ |(p.coeff i:ℝ)| * (R:ℝ)^i
      rw [abs_mul, abs_pow]
      exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (abs_nonneg _) hx _) (abs_nonneg _)
    _ = (coeffBound p R : ℝ) := by
      simp only [coeffBound, Rat.cast_sum, Rat.cast_mul, Rat.cast_abs, Rat.cast_pow]

theorem realEval_hasDerivAt (p : ℚ[X]) (x : ℝ) :
    HasDerivAt (realEval p) (realEval p.derivative x) x := by
  have hfun : realEval p = fun z => (p.map (algebraMap ℚ ℝ)).eval z := by
    funext z
    exact Polynomial.eval₂_eq_eval_map _
  rw [hfun]
  simpa only [realEval, Polynomial.eval₂_eq_eval_map, Polynomial.derivative_map] using
    (p.map (algebraMap ℚ ℝ)).hasDerivAt x

/-- Radius enclosing a rational interval, with a spare unit. -/
def intervalRadius (a b : ℚ) : ℚ := max |a| |b| + 1

theorem intervalRadius_pos (a b : ℚ) : 0 < intervalRadius a b := by
  have h := le_max_left |a| |b|
  have ha := abs_nonneg a
  dsimp [intervalRadius]
  linarith

theorem abs_le_intervalRadius {a b : ℚ} {x : ℝ}
    (hx : x ∈ Icc (a:ℝ) (b:ℝ)) : |x| ≤ (intervalRadius a b : ℝ) := by
  rw [abs_le]
  have ha : |(a:ℝ)| ≤ (intervalRadius a b : ℝ) := by
    exact_mod_cast (show |a| ≤ intervalRadius a b by dsimp [intervalRadius]; linarith [le_max_left |a| |b|])
  have hb : |(b:ℝ)| ≤ (intervalRadius a b : ℝ) := by
    exact_mod_cast (show |b| ≤ intervalRadius a b by dsimp [intervalRadius]; linarith [le_max_right |a| |b|])
  exact ⟨(neg_le_of_abs_le ha).trans hx.1, hx.2.trans (le_of_abs_le hb)⟩

/-- Explicit Lipschitz bound on any rational closed interval. -/
theorem realEval_sub_le (p : ℚ[X]) (a b : ℚ) {x y : ℝ}
    (hx : x ∈ Icc (a:ℝ) (b:ℝ)) (hy : y ∈ Icc (a:ℝ) (b:ℝ)) :
    |realEval p y - realEval p x| ≤
      (coeffBound p.derivative (intervalRadius a b) : ℝ) * |y-x| := by
  have hb : ∀ z ∈ Icc (a:ℝ) (b:ℝ), ‖realEval p.derivative z‖ ≤
      (coeffBound p.derivative (intervalRadius a b) : ℝ) := by
    intro z hz
    rw [Real.norm_eq_abs]
    exact abs_realEval_le_coeffBound p.derivative (intervalRadius_pos a b).le
      (abs_le_intervalRadius hz)
  have h := Convex.norm_image_sub_le_of_norm_hasDerivWithin_le
    (fun z (_ : z ∈ Icc (a:ℝ) (b:ℝ)) => (realEval_hasDerivAt p z).hasDerivWithinAt)
    hb (convex_Icc (a:ℝ) (b:ℝ)) hx hy
  simpa only [Real.norm_eq_abs] using h

end C2.CADIsolation
