import C2.IntegratorDelayOutward
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.Deriv
import Mathlib.Analysis.Complex.RealDeriv
import Mathlib.Analysis.InnerProductSpace.Calculus

/-! Actual local root branches at the unit circle.  The inverse function theorem
constructs the branch; differentiability is a conclusion, not an assumption. -/
noncomputable section
open Filter ComplexConjugate
open scoped Topology
namespace C2.IntegratorDelay

def gainOfPole (n : ℕ) (γ : ℝ) (z : ℂ) : ℂ :=
  -(z ^ n * (z - 1)) / feedback γ z

theorem gainOfPole_eq_of_root {n : ℕ} {γ a : ℝ} {z : ℂ}
    (hq : feedback γ z ≠ 0) (hp : characteristic n γ a z = 0) :
    gainOfPole n γ z = (a : ℂ) := by
  unfold gainOfPole
  apply (div_eq_iff hq).2
  change z ^ n * (z - 1) + (a : ℂ) * feedback γ z = 0 at hp
  linear_combination -hp

theorem gainOfPole_hasStrictDerivAt {n : ℕ} {γ a : ℝ} {z : ℂ}
    (hq : feedback γ z ≠ 0) (hp : characteristic n γ a z = 0) :
    HasStrictDerivAt (gainOfPole n γ)
      (-characteristicDerivative n γ a z / feedback γ z) z := by
  have hnum := ((hasStrictDerivAt_pow n z).mul
    ((hasStrictDerivAt_id z).sub_const 1)).neg
  have hden := ((((hasStrictDerivAt_id z).const_mul (γ : ℂ)).add_const 1).sub_const
    (γ : ℂ))
  have h := hnum.div hden hq
  have he : z ^ n * (z - 1) = -(a : ℂ) * feedback γ z := by
    change z ^ n * (z - 1) + (a : ℂ) * feedback γ z = 0 at hp
    linear_combination hp
  convert h using 1
  simp only [id_eq, mul_one, one_mul, gainOfPole, characteristicDerivative]
  simp only [feedback] at he ⊢
  rw [he]
  have hq' : (γ : ℂ) * z + 1 - γ ≠ 0 := hq
  field_simp [hq'] <;> ring

/-- The branch is defined on a real neighbourhood of the actual positive gain.
Its poles satisfy the actual characteristic equation, and the radial velocity
is positive at the crossing. -/
theorem exists_outward_root_branch {n : ℕ} {γ a : ℝ} {z : ℂ}
    (hn : 1 ≤ n) (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1)
    (ha : 0 < a) (hc : a * (1 - γ) < 1)
    (hz : ‖z‖ = 1) (hp : characteristic n γ a z = 0) :
    ∃ (f : ℝ → ℂ) (w : ℂ), f a = z ∧ HasDerivAt f w a ∧
      (∀ᶠ t in 𝓝 a, characteristic n γ t (f t) = 0) ∧
      0 < ((a : ℂ) * w / z).re ∧
      0 < deriv (fun t => ‖f t‖ ^ 2) a := by
  obtain ⟨hD, hv⟩ := unit_root_transversality hn hγ0 hγ1 ha hc hz hp
  have hq := (unit_root_feedback_ne_zero ha hz hp).2
  have hz0 : z ≠ 0 := by intro h; simpa [h] using hz
  let v : ℂ := -characteristicDerivative n γ a z / feedback γ z
  have hv0 : v ≠ 0 := div_ne_zero (neg_ne_zero.mpr hD) hq
  have hs : HasStrictDerivAt (gainOfPole n γ) v z := gainOfPole_hasStrictDerivAt hq hp
  have hvalue := gainOfPole_eq_of_root hq hp
  let g := hs.localInverse (gainOfPole n γ) v z hv0
  let f : ℝ → ℂ := fun t => g (t : ℂ)
  have hF := hs.hasStrictFDerivAt_equiv hv0
  have hga : g (a : ℂ) = z := by
    simpa only [g, hvalue] using hF.localInverse_apply_image
  have hder : HasDerivAt g v⁻¹ (a : ℂ) := by
    simpa only [g, hvalue] using (hs.to_localInverse hv0).hasDerivAt
  have hf : HasDerivAt f v⁻¹ a := hder.comp_ofReal
  have hfa : f a = z := hga
  have hrcomplex : ∀ᶠ y in 𝓝 (a : ℂ), gainOfPole n γ (g y) = y := by
    simpa only [g, hvalue] using hF.eventually_right_inverse
  have hrreal : ∀ᶠ t in 𝓝 a, gainOfPole n γ (f t) = (t : ℂ) :=
    Complex.continuous_ofReal.continuousAt.tendsto.eventually hrcomplex
  have hfeedback : ContinuousAt (fun t => feedback γ (f t)) a :=
    ((continuousAt_const.mul hf.continuousAt).add continuousAt_const).sub continuousAt_const
  have hqnear : ∀ᶠ t in 𝓝 a, feedback γ (f t) ≠ 0 :=
    hfeedback.eventually_ne (by simpa only [hfa] using hq)
  have hroot : ∀ᶠ t in 𝓝 a, characteristic n γ t (f t) = 0 := by
    filter_upwards [hrreal, hqnear] with t ht hqt
    have he := (div_eq_iff hqt).mp ht
    change -(f t ^ n * (f t - 1)) = (t : ℂ) * feedback γ (f t) at he
    change f t ^ n * (f t - 1) + (t : ℂ) * feedback γ (f t) = 0
    linear_combination -he
  have hvel : 0 < ((a : ℂ) * v⁻¹ / z).re := by
    have hid : (a : ℂ) * v⁻¹ / z = -(a : ℂ) * feedback γ z /
        (z * characteristicDerivative n γ a z) := by
      dsimp [v]
      field_simp [hD, hq, hz0] <;> ring_nf <;> simp
    rw [hid]
    exact hv
  have hnorm : Complex.normSq z = 1 := by
    rw [Complex.normSq_eq_norm_sq, hz]
    norm_num
  have hvel_eq : ((a : ℂ) * v⁻¹ / z).re = a * (v⁻¹ * conj z).re := by
    simp only [Complex.div_re, hnorm, div_one, Complex.mul_re,
      Complex.ofReal_re, Complex.ofReal_im, Complex.mul_im, Complex.conj_re,
      Complex.conj_im, zero_mul, sub_zero, add_zero]
    ring
  have hinner : 0 < (v⁻¹ * conj z).re := by
    rw [hvel_eq] at hvel
    exact (mul_pos_iff_of_pos_left ha).mp hvel
  have hsq := hf.norm_sq
  rw [hfa, Complex.inner] at hsq
  have hsqpos : 0 < deriv (fun t => ‖f t‖ ^ 2) a := by
    rw [hsq.deriv]
    exact mul_pos (by norm_num) hinner
  exact ⟨f, v⁻¹, hfa, hf, hroot, hvel, hsqpos⟩

end C2.IntegratorDelay
