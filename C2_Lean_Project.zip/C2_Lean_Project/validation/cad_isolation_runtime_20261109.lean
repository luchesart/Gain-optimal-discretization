import C2.CADEffectiveRootOutput
open Polynomial Set
open C2.CADEffective.Dense C2.CADIsolation

private theorem sqrtTwo_simple :
    ∀ x ∈ Icc (0:ℝ) (2:ℝ), realEval (denote [-2,0,1]) x ≠ 0 ∨
      realEval (denote [-2,0,1]).derivative x ≠ 0 := by
  intro x hx
  by_cases hp : realEval (denote [-2,0,1]) x = 0
  · right
    intro hd
    norm_num [realEval,denote_cons,Polynomial.derivative_add,Polynomial.derivative_mul] at hp hd
    nlinarith
  · exact Or.inl hp

def sqrtTwo_depth : ℕ := meshIndex [-2,0,1] (a:=0) (b:=2) (by norm_num) (by simpa using sqrtTwo_simple)
#eval sqrtTwo_depth
#eval rootRanks [-2,0,1] 0 2 sqrtTwo_depth
#eval isolatingIntervals [-2,0,1] 0 2 sqrtTwo_depth
#eval meshCheck [-2,0,1] 0 2 sqrtTwo_depth
