import C2.CommonDegree
import C2.GeneralCompletionBounds

/-!
# Explicit uniform gain bound for the common-parameter rational family

The symbolic coefficient envelopes are polynomials in gamma; evaluating
them recovers the original transformed polynomial. No numerical root test
or sampled parameter bound is assumed.
-/

noncomputable section
open Polynomial Finset
namespace C2.GeneralCompletion

def coefficientAbsSum (p : Polynomial ℝ) : ℝ :=
  ∑ i ∈ Finset.range (p.natDegree + 1), |p.coeff i|

theorem abs_eval_le_coefficientAbsSum (p : Polynomial ℝ) {x : ℝ}
    (hx : |x| ≤ 1) : |p.eval x| ≤ coefficientAbsSum p := by
  rw [eval_eq_sum_range]
  calc
    _ ≤ ∑ i ∈ Finset.range (p.natDegree+1), |p.coeff i*x^i| := abs_sum_le_sum_abs _ _
    _ ≤ ∑ i ∈ Finset.range (p.natDegree+1), |p.coeff i| := by
      apply Finset.sum_le_sum
      intro i hi
      rw [abs_mul, abs_pow]
      exact mul_le_of_le_one_right (abs_nonneg _) (pow_le_one₀ (abs_nonneg _) hx)
    _ = _ := rfl

/-- Some coefficient is large whenever a polynomial is large at a point of
the closed unit interval. The declared degree may exceed the actual degree. -/
theorem exists_coefficient_lower_bound {p : Polynomial ℝ} {d : ℕ}
    (hd : p.natDegree ≤ d) {z μ : ℝ} (hz : |z| ≤ 1) (hμ : 0 < μ)
    (heval : (d+1 : ℝ)*μ ≤ |p.eval z|) :
    ∃ i ≤ d, μ ≤ |p.coeff i| := by
  by_contra h
  push_neg at h
  have he : |p.eval z| ≤ ∑ i ∈ Finset.range (d+1), |p.coeff i| := by
    rw [eval_eq_sum_range' (Nat.lt_succ_of_le hd)]
    apply (abs_sum_le_sum_abs _ _).trans
    apply Finset.sum_le_sum
    intro i hi
    rw [abs_mul, abs_pow]
    exact mul_le_of_le_one_right (abs_nonneg _) (pow_le_one₀ (abs_nonneg _) hz)
  have hs : (∑ i ∈ Finset.range (d+1), |p.coeff i|) <
      ∑ _i ∈ Finset.range (d+1), μ := by
    apply Finset.sum_lt_sum
    · intro i hi
      exact (h i (Nat.le_of_lt_succ (Finset.mem_range.mp hi))).le
    · exact ⟨0, by simp, h 0 (Nat.zero_le d)⟩
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul, Nat.cast_add,
    Nat.cast_one] at hs
  linarith

def samplePoint (T s γ : ℝ) : ℝ :=
  (1 + T*(1-γ)*s)/(1-T*γ*s)

theorem samplePoint_bounds {T s γ : ℝ} (hT : 0 < T)
    (hs : -1 ≤ T*s ∧ T*s ≤ 0) (hγ : γ ∈ Set.Icc (0 : ℝ) 1) :
    0 ≤ samplePoint T s γ ∧ samplePoint T s γ ≤ 1 := by
  have hgs : T*γ*s ≤ 0 := by nlinarith [mul_nonpos_of_nonneg_of_nonpos hγ.1 hs.2]
  have hden : 0 < 1-T*γ*s := by linarith
  have hnum : 0 ≤ 1+T*(1-γ)*s := by nlinarith
  constructor
  · exact div_nonneg hnum hden.le
  · apply (div_le_one hden).mpr
    nlinarith

theorem samplePoint_transform {B : Polynomial ℝ} {d : ℕ} (hB : B.natDegree ≤ d)
    {T s γ : ℝ} (hT : 0 < T) (hs : T*s ≤ 0)
    (hγ : 0 ≤ γ) :
    (C2.commonDegreeTransform B d (C2.thetaScale T γ) C2.thetaNumerator).eval
        (samplePoint T s γ) = (T/(1-T*γ*s))^d * B.eval s := by
  have hgs : T*γ*s ≤ 0 := by nlinarith [mul_nonpos_of_nonneg_of_nonpos hγ hs]
  have hden : 0 < 1-T*γ*s := by linarith
  have hscale : (C2.thetaScale T γ).eval (samplePoint T s γ) = T/(1-T*γ*s) := by
    simp only [C2.thetaScale, Polynomial.eval_mul, Polynomial.eval_add,
      Polynomial.eval_C, Polynomial.eval_X, samplePoint]
    field_simp [hden.ne']
    <;> ring
  have hnonzero : (C2.thetaScale T γ).eval (samplePoint T s γ) ≠ 0 := by
    rw [hscale]
    exact div_ne_zero hT.ne' hden.ne'
  rw [C2.commonDegreeTransform_eval_div B d _ _ _ hB hnonzero, hscale]
  congr 2
  simp only [C2.thetaNumerator, Polynomial.eval_sub, Polynomial.eval_X,
    Polynomial.eval_one, samplePoint]
  field_simp [hT.ne', hden.ne']
  <;> ring

/-- Explicit lower bound for a numerator coefficient, uniformly on the
whole admissible gamma interval. -/
theorem transformed_numerator_coefficient_lower_bound
    {B : Polynomial ℝ} {d : ℕ} (hB : B.natDegree ≤ d)
    {T s γ : ℝ} (hT : 0 < T) (hs : -1 ≤ T*s ∧ T*s ≤ 0)
    (hBs : B.eval s ≠ 0) (hγ : γ ∈ Set.Icc (0 : ℝ) 1) :
    ∃ i ≤ d, T^d*|B.eval s| / ((d+1 : ℝ)*(1+T*|s|)^d) ≤
      |(C2.commonDegreeTransform B d (C2.thetaScale T γ) C2.thetaNumerator).coeff i| := by
  let μ := T^d*|B.eval s| / ((d+1 : ℝ)*(1+T*|s|)^d)
  have hsp : s ≤ 0 := by nlinarith
  have hden1 : 0 < 1+T*|s| := by positivity
  have hμ : 0 < μ := by dsimp [μ]; positivity
  have hgs : T*γ*s ≤ 0 := by nlinarith [mul_nonpos_of_nonneg_of_nonpos hγ.1 hs.2]
  have hden : 0 < 1-T*γ*s := by linarith
  have hdenle : 1-T*γ*s ≤ 1+T*|s| := by
    rw [abs_of_nonpos hsp]
    have h := mul_nonpos_of_nonneg_of_nonpos (sub_nonneg.mpr hγ.2) hs.2
    nlinarith
  have hfrac : T/(1+T*|s|) ≤ T/(1-T*γ*s) :=
    div_le_div_of_nonneg_left hT.le hden hdenle
  have hlower : T^d*|B.eval s| /(1+T*|s|)^d ≤
      |(C2.commonDegreeTransform B d (C2.thetaScale T γ) C2.thetaNumerator).eval
        (samplePoint T s γ)| := by
    rw [samplePoint_transform hB hT hs.2 hγ.1, abs_mul, abs_pow,
      abs_of_pos (div_pos hT hden)]
    have hp := pow_le_pow_left₀ (div_nonneg hT.le hden1.le) hfrac d
    have hm := mul_le_mul_of_nonneg_right hp (abs_nonneg (B.eval s))
    simpa [div_pow, div_mul_eq_mul_div] using hm
  apply exists_coefficient_lower_bound
    (C2.commonDegreeTransform_natDegree_le B d _ _
      (C2.thetaScale_natDegree_le T γ) C2.thetaNumerator_natDegree_le)
    (abs_le.mpr ⟨by linarith [(samplePoint_bounds hT hs hγ).1],
      (samplePoint_bounds hT hs hγ).2⟩) hμ
  have hdpos : 0 < (d+1 : ℝ) := by positivity
  have hμeq : (d+1 : ℝ)*μ = T^d*|B.eval s| /(1+T*|s|)^d := by
    dsimp [μ]
    field_simp [hdpos.ne', hden1.ne']
    ring
  rw [hμeq]
  exact hlower

def symbolicTransform (p : Polynomial ℝ) (d : ℕ) (T : ℝ) :
    Polynomial (Polynomial ℝ) :=
  C2.commonDegreeTransform (p.map Polynomial.C) d
    (C2.thetaScale (Polynomial.C T) Polynomial.X) C2.thetaNumerator

theorem symbolicTransform_evaluate (p : Polynomial ℝ) (d : ℕ) (T γ : ℝ) :
    (symbolicTransform p d T).map (Polynomial.evalRingHom γ) =
      C2.commonDegreeTransform p d (C2.thetaScale T γ) C2.thetaNumerator := by
  simp [symbolicTransform, C2.commonDegreeTransform, C2.thetaScale, C2.thetaNumerator,
    Polynomial.map_sum]

def symbolicDelayedDenominator (A : Polynomial ℝ) (d m : ℕ) (T : ℝ) :
    Polynomial (Polynomial ℝ) :=
  Polynomial.X^m * symbolicTransform A d T

theorem symbolicDelayedDenominator_evaluate (A : Polynomial ℝ) (d m : ℕ) (T γ : ℝ) :
    (symbolicDelayedDenominator A d m T).map (Polynomial.evalRingHom γ) =
      Polynomial.X^m * C2.commonDegreeTransform A d (C2.thetaScale T γ) C2.thetaNumerator := by
  simp [symbolicDelayedDenominator, symbolicTransform_evaluate]

def denominatorCoefficientEnvelope (A : Polynomial ℝ) (d m : ℕ) (T : ℝ) : ℝ :=
  (Finset.range (d+1)).sup' ⟨0, by simp⟩
    (fun i => coefficientAbsSum ((symbolicDelayedDenominator A d m T).coeff i))

def leadingCoefficientEnvelope (A : Polynomial ℝ) (d : ℕ) (T : ℝ) : ℝ :=
  coefficientAbsSum ((symbolicTransform A d T).coeff d)

/-- Full explicit uniform real gain bound, with the paper's actual coefficient
one-norm envelopes. Rational input is a specialization of this stronger result.
The node `s` can be any nonzero-evaluation point with `-1 ≤ T*s ≤ 0`. -/
theorem uniform_gain_bound
    (A B : Polynomial ℝ) (d m : ℕ) (T s γ k : ℝ)
    (hB : B.natDegree ≤ d) (hm : 0 < m) (hT : 0 < T)
    (hs : -1 ≤ T*s ∧ T*s ≤ 0) (hBs : B.eval s ≠ 0)
    (hγ : γ ∈ Set.Icc (0 : ℝ) 1) (hk : 0 ≤ k)
    (hdegree : (C2.commonDegreeTransform A d (C2.thetaScale T γ)
      C2.thetaNumerator).coeff d ≠ 0)
    (hstable : ∀ z : ℂ,
      ((Polynomial.X^m * C2.commonDegreeTransform A d (C2.thetaScale T γ)
          C2.thetaNumerator + Polynomial.C k *
        C2.commonDegreeTransform B d (C2.thetaScale T γ) C2.thetaNumerator).map
          Complex.ofRealHom).eval z = 0 → ‖z‖ < 1) :
    k ≤ (denominatorCoefficientEnvelope A d m T +
      leadingCoefficientEnvelope A d T * ((d+m).choose ((d+m)/2) : ℝ)) /
      (T^d*|B.eval s| /((d+1 : ℝ)*(1+T*|s|)^d)) := by
  let D := C2.commonDegreeTransform A d (C2.thetaScale T γ) C2.thetaNumerator
  let N := C2.commonDegreeTransform B d (C2.thetaScale T γ) C2.thetaNumerator
  let H := Polynomial.X^m * D
  have hDle : D.natDegree ≤ d :=
    C2.commonDegreeTransform_natDegree_le A d _ _
      (C2.thetaScale_natDegree_le T γ) C2.thetaNumerator_natDegree_le
  have hDd : D.natDegree = d := natDegree_eq_of_le_of_coeff_ne_zero hDle hdegree
  have hDne : D ≠ 0 := by
    intro he
    apply hdegree
    change D.coeff d = 0
    rw [he, coeff_zero]
  have hHd : H.natDegree = d+m := by
    dsimp [H]
    rw [natDegree_X_pow_mul m hDne, hDd]
  have hNle : N.natDegree ≤ d :=
    C2.commonDegreeTransform_natDegree_le B d _ _
      (C2.thetaScale_natDegree_le T γ) C2.thetaNumerator_natDegree_le
  have hlow : N.natDegree < H.natDegree := by rw [hHd]; omega
  have hμ : 0 < T^d*|B.eval s| /((d+1 : ℝ)*(1+T*|s|)^d) := by positivity
  obtain ⟨i, hi, hcoef⟩ := transformed_numerator_coefficient_lower_bound hB hT hs hBs hγ
  have hγabs : |γ| ≤ 1 := abs_le.mpr ⟨by linarith [hγ.1], hγ.2⟩
  have hHcoef : |H.coeff i| ≤ denominatorCoefficientEnvelope A d m T := by
    have he := congrArg (fun p : Polynomial ℝ => p.coeff i)
      (symbolicDelayedDenominator_evaluate A d m T γ)
    have he' : ((symbolicDelayedDenominator A d m T).coeff i).eval γ = H.coeff i := by
      simpa using he
    rw [← he']
    apply (abs_eval_le_coefficientAbsSum _ hγabs).trans
    exact Finset.le_sup'
      (fun j => coefficientAbsSum ((symbolicDelayedDenominator A d m T).coeff j))
      (Finset.mem_range.mpr (Nat.lt_succ_of_le hi))
  have hlead : H.leadingCoeff = D.coeff d := by
    calc
      H.leadingCoeff = D.leadingCoeff := by simp [H]
      _ = D.coeff d := by rw [Polynomial.leadingCoeff, hDd]
  have hEcoef : |H.leadingCoeff| ≤ leadingCoefficientEnvelope A d T := by
    have he := congrArg (fun p : Polynomial ℝ => p.coeff d)
      (symbolicTransform_evaluate A d T γ)
    have he' : ((symbolicTransform A d T).coeff d).eval γ = D.coeff d := by
      simpa using he
    rw [hlead, ← he']
    exact abs_eval_le_coefficientAbsSum _ hγabs
  exact affine_gain_bound hk hμ hcoef hHcoef hEcoef hHd hlow
    (fun z hz => le_of_lt (hstable z hz))

/-- A nonzero degree-at-most-d polynomial has a nonvanishing value among any
d+1 distinct proposed nodes. -/
theorem exists_nonzero_node {K : Type*} [Field K] {d : ℕ}
    (B : Polynomial K) (hB : B ≠ 0) (hd : B.natDegree ≤ d)
    (s : Fin (d+1) → K) (hs : Function.Injective s) :
    ∃ j, B.eval (s j) ≠ 0 := by
  by_contra h
  push_neg at h
  apply hB
  exact Polynomial.eq_zero_of_natDegree_lt_card_of_eval_eq_zero B hs h
    (by simpa using Nat.lt_succ_of_le hd)

/-- The paper's particular d+1 negative nodes always include a nonzero
numerator value, and each node lies in the interval required above. -/
theorem exists_paper_node {B : Polynomial ℝ} {d : ℕ} {T : ℝ}
    (hB : B ≠ 0) (hd : B.natDegree ≤ d) (hT : 0 < T) :
    ∃ j : ℕ, 1 ≤ j ∧ j ≤ d+1 ∧ B.eval (-1/((j : ℝ)*T)) ≠ 0 ∧
      -1 ≤ T*(-1/((j : ℝ)*T)) ∧ T*(-1/((j : ℝ)*T)) ≤ 0 := by
  let s : Fin (d+1) → ℝ := fun i => -1/(((i.val : ℝ)+1)*T)
  have hs : Function.Injective s := by
    intro i j hij
    have hi : 0 < ((i.val : ℝ)+1)*T := by positivity
    have hj : 0 < ((j.val : ℝ)+1)*T := by positivity
    have he := (div_eq_div_iff hi.ne' hj.ne').mp hij
    have he' : (i.val : ℝ) = (j.val : ℝ) := by nlinarith
    apply Fin.ext
    exact_mod_cast he'
  obtain ⟨i, hi⟩ := exists_nonzero_node B hB hd s hs
  refine ⟨i.val+1, by omega, by have := i.isLt; omega, ?_, ?_, ?_⟩
  · simpa [s] using hi
  all_goals
    have hj : 0 < ((i.val+1 : ℕ) : ℝ) := by positivity
    have he : T*(-1/((((i.val+1 : ℕ) : ℝ))*T)) =
        -1/(((i.val+1 : ℕ) : ℝ)) := by field_simp [hT.ne', hj.ne']; ring
    rw [he]
  · apply (le_div_iff₀ hj).mpr
    have hn : (1 : ℝ) ≤ ((i.val+1 : ℕ) : ℝ) := by
      exact_mod_cast Nat.succ_le_succ (Nat.zero_le i.val)
    linarith
  · exact div_nonpos_of_nonpos_of_nonneg (by norm_num) hj.le

/-- The integer ceiling prescription is a strict search bound. -/
theorem strict_search_bound {k K₀ : ℝ} (h : k ≤ K₀) : k < (⌈K₀⌉ : ℝ)+1 := by
  have hc : K₀ ≤ (⌈K₀⌉ : ℝ) := Int.le_ceil K₀
  linarith

end C2.GeneralCompletion
