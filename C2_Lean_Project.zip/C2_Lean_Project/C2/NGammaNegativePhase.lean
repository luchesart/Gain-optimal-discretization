import C2.NGammaFrequency
import C2.NGammaReflection

/-! The actual first phase crossing for admissible vectors with negative
coordinates.  This includes the zero-gain boundary x=-2/r. -/
noncomputable section
open scoped BigOperators Topology
open Set Filter
namespace C2.NGamma.Phase

lemma negative_contribution_strictMono {a x : ℝ} (ha : 0 ≤ a) (hx : x < 0) :
    StrictMono (contribution a x) := by
  intro s t hst
  have hA := Real.arctan_strictMono.monotone (mul_le_mul_of_nonneg_left hst.le ha)
  have hX := Real.arctan_strictMono (mul_lt_mul_of_neg_left hst hx)
  unfold contribution
  linarith

lemma negative_ratio_strictMonoOn {a x : ℝ} (ha : 0 ≤ a) (hx : x < 0) :
    StrictMonoOn (ratio a x) (Ioi 0) := by
  intro s hs t ht hst
  have hax : x < a := lt_of_lt_of_le hx ha
  have hDs := arctan_pos (one_div_pos.mpr hs)
  have hDt := arctan_pos (one_div_pos.mpr ht)
  have hDlt : Real.arctan (1/t) < Real.arctan (1/s) :=
    Real.arctan_strictMono (one_div_lt_one_div_of_lt hs hst)
  have hNt := contribution_pos hax ht
  unfold ratio
  exact lt_of_lt_of_le ((div_lt_div_iff_of_pos_right hDs).2
    (negative_contribution_strictMono ha hx hst))
    (div_le_div_of_nonneg_left hNt.le hDt hDlt.le)

lemma negative_ratio_tendsto_atTop {a x : ℝ} (ha : 0 ≤ a) (hx : x < 0) :
    Tendsto (ratio a x) atTop atTop := by
  have ht := ratio_tendsto_atTop_of_zero (a := -x) (by linarith)
  apply tendsto_atTop_mono' atTop _ ht
  filter_upwards [eventually_gt_atTop (0:ℝ)] with t ht
  have hA : 0 ≤ Real.arctan (a*t) := by
    simpa only [Real.arctan_zero] using
      Real.arctan_strictMono.monotone (mul_nonneg ha ht.le)
  unfold ratio contribution
  apply (div_le_div_iff_of_pos_right (arctan_pos (one_div_pos.mpr ht))).2
  simp only [zero_mul,Real.arctan_zero,sub_zero,neg_mul,Real.arctan_neg]
  linarith

end C2.NGamma.Phase
namespace C2.NGamma.Global

lemma mixed_sumRatio_strictMonoOn {n : ℕ} (hn : 0 < n) (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hlo : ∀ j, -(2/r j) ≤ x j) (hhi : ∀ j, x j ≤ 1) :
    StrictMonoOn (sumRatio r x) (Ioi 0) := by
  have hi : ∀ j, StrictMonoOn (Phase.ratio (x j+2/r j) (x j)) (Ioi 0) := by
    intro j
    by_cases hx : x j < 0
    · exact Phase.negative_ratio_strictMonoOn (by have := hlo j; linarith) hx
    · exact Phase.ratio_strictMonoOn (le_of_not_gt hx) (hhi j)
        (by have := div_pos (by norm_num : (0:ℝ)<2) (hr j); linarith)
  intro s hs t ht hst
  apply Finset.sum_lt_sum
  · intro j _
    exact (hi j hs ht hst).le
  · exact ⟨⟨0,hn⟩,Finset.mem_univ _,hi _ hs ht hst⟩

lemma negative_sumRatio_tendsto_atTop {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hlo : ∀ j, -(2/r j) ≤ x j)
    (hneg : ∃ j, x j < 0) : Tendsto (sumRatio r x) atTop atTop := by
  obtain ⟨i,hi⟩ := hneg
  have ht := Phase.negative_ratio_tendsto_atTop
    (a := x i+2/r i) (by have := hlo i; linarith) hi
  apply tendsto_atTop_mono' atTop _ ht
  filter_upwards [eventually_gt_atTop (0:ℝ)] with t ht
  unfold sumRatio
  apply Finset.single_le_sum (s := Finset.univ) _ (Finset.mem_univ i)
  intro j hj
  exact (div_pos (Phase.contribution_pos
    (by have := div_pos (by norm_num : (0:ℝ)<2) (hr j); linarith) ht)
    (Phase.arctan_pos (one_div_pos.mpr ht))).le

/-- Existence and uniqueness of the actual first normalized phase crossing,
including negative coordinates whose zero-gain factor is still admissible. -/
theorem negative_first_phase_crossing {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hlo : ∀ j, -(2/r j) ≤ x j) (hhi : ∀ j, x j ≤ 1)
    (hneg : ∃ j, x j < 0) : ∃! t, 0 < t ∧ sumRatio r x t = 2 := by
  have hn : 0 < n := by obtain ⟨j,_⟩ := hneg; exact Nat.zero_lt_of_lt j.isLt
  exact unique_positive_crossing_atTop (sumRatio_continuousOn r x)
    (mixed_sumRatio_strictMonoOn hn r x hr hlo hhi) (sumRatio_tendsto_zero r x)
    (negative_sumRatio_tendsto_atTop r x hr hlo hneg)

lemma reflected_sumRatio_strict {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hlo : ∀ j, -(2/r j) ≤ x j)
    (hneg : ∃ j, x j < 0) {t : ℝ} (ht : 0 < t) :
    sumRatio r (fun j => |x j|) t < sumRatio r x t := by
  simp only [sumRatio,Phase.ratio,← Finset.sum_div]
  exact (div_lt_div_iff_of_pos_right (Phase.arctan_pos (one_div_pos.mpr ht))).2
    (reflected_phase_sum_strict r x hr hlo hneg ht)

lemma reflected_crossing_later {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) (hlo : ∀ j, -(2/r j) ≤ x j)
    (habs : ∀ j, |x j| ≤ 1) (hneg : ∃ j, x j < 0)
    {t u : ℝ} (ht : 0 < t) (hu : 0 < u)
    (hcross : sumRatio r x t = 2) (href : sumRatio r (fun j => |x j|) u = 2) : t < u := by
  have hn : 0 < n := by obtain ⟨j,_⟩ := hneg; exact Nat.zero_lt_of_lt j.isLt
  have hlt := reflected_sumRatio_strict r x hr hlo hneg ht
  rw [hcross] at hlt
  by_contra h
  have hle := (sumRatio_strictMonoOn hn r (fun j => |x j|) hr
    (fun j => ⟨abs_nonneg _,habs j⟩)).monotoneOn hu ht (le_of_not_gt h)
  rw [href] at hle
  linarith

end C2.NGamma.Global
