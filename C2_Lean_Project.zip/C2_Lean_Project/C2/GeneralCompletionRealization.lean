import C2.CommonDegree
import C2.NGammaRealizationDynamics

/-!
# Degree-minimal rational realizations and retained internal modes

The realization premise is an equality of rational transfer functions,
written as a polynomial cross-product, together with state dimension deg D.
The latter is the degree-minimal convention: the lower-bound theorem below
proves that no realization of a coprime quotient can have fewer states.
The characteristic polynomial and decay equivalence are conclusions.
-/
noncomputable section
open Polynomial Matrix
namespace C2.GeneralCompletion
open C2.NGamma.Realization

/-- Every common divisor introduced by the integer delay divides X^m.
Thus even multiplicities of cancelled modes are confined to zero. -/
theorem common_divisor_dvd_delay_power {K : Type*} [Field K]
    {D N Q : Polynomial K} (m : ℕ) (hDN : IsCoprime D N)
    (hQH : Q ∣ Polynomial.X^m * D) (hQN : Q ∣ N) :
    Q ∣ (Polynomial.X : Polynomial K)^m := by
  have hDQ : IsCoprime D Q := hDN.of_isCoprime_of_dvd_right hQN
  exact hDQ.symm.dvd_of_dvd_mul_right hQH

/-- A state-space system realizes the rational quotient N/D. This condition
contains no closed-loop characteristic or stability assumption. -/
def RationalRealization (S : Delay.StateSpace ℝ) (D N : Polynomial ℝ) : Prop :=
  causalNumerator S.A S.B S.C S.D * D = N * S.A.charpoly

/-- The polynomial cross-product indeed gives the ordinary state-space
transfer quotient wherever both sides are defined. -/
theorem realization_transfer_quotient (S : Delay.StateSpace ℝ)
    {D N : Polynomial ℝ} (hreal : RationalRealization S D N) (z : ℝ)
    (hP : S.A.charpoly.eval z ≠ 0) (hD : D.eval z ≠ 0) :
    Delay.transfer S z = N.eval z / D.eval z := by
  have hM : (z • (1 : Matrix S.State S.State ℝ)-S.A).det ≠ 0 := by
    simpa only [charpoly_eval] using hP
  have hq := causalNumerator_quotient S.A S.B S.C S.D z hM
  change Delay.transfer S z = _ at hq
  rw [hq]
  apply (div_eq_div_iff hP hD).mpr
  simpa only [Polynomial.eval_mul] using congrArg (Polynomial.eval z) hreal

theorem denominator_dvd_realization_charpoly (S : Delay.StateSpace ℝ)
    {D N : Polynomial ℝ} (hDN : IsCoprime D N) (hreal : RationalRealization S D N) :
    D ∣ S.A.charpoly := by
  apply hDN.dvd_of_dvd_mul_left
  change D ∣ N * S.A.charpoly
  rw [← hreal]
  exact dvd_mul_left D _

/-- Every realization of a coprime quotient has at least deg D states. -/
theorem realization_dimension_lower_bound (S : Delay.StateSpace ℝ)
    {D N : Polynomial ℝ} (hDN : IsCoprime D N) (hreal : RationalRealization S D N) :
    D.natDegree ≤ Fintype.card S.State := by
  have h := Polynomial.natDegree_le_of_dvd
    (denominator_dvd_realization_charpoly S hDN hreal) (Matrix.charpoly_monic S.A).ne_zero
  simpa using h

/-- Degree minimality and coprimeness recover both uncancelled state-space
polynomials, with the same scalar normalization. -/
theorem minimal_realization_polynomials (S : Delay.StateSpace ℝ)
    {D N : Polynomial ℝ} (hD : D ≠ 0) (hDN : IsCoprime D N)
    (hreal : RationalRealization S D N)
    (hdim : Fintype.card S.State = D.natDegree) :
    D = Polynomial.C D.leadingCoeff * S.A.charpoly ∧
      N = Polynomial.C D.leadingCoeff * causalNumerator S.A S.B S.C S.D := by
  have hl : D.leadingCoeff ≠ 0 := leadingCoeff_ne_zero.mpr hD
  have hdiv := denominator_dvd_realization_charpoly S hDN hreal
  have hden : D = Polynomial.C D.leadingCoeff * S.A.charpoly := by
    apply Polynomial.eq_of_dvd_of_natDegree_le_of_leadingCoeff
    · exact dvd_mul_of_dvd_right hdiv _
    · rw [Polynomial.natDegree_C_mul hl, Matrix.charpoly_natDegree_eq_dim, hdim]
    · rw [Polynomial.leadingCoeff_mul, Polynomial.leadingCoeff_C,
        (Matrix.charpoly_monic S.A).leadingCoeff, mul_one]
  refine ⟨hden, ?_⟩
  apply mul_right_cancel₀ (Matrix.charpoly_monic S.A).ne_zero
  change N * S.A.charpoly =
    (Polynomial.C D.leadingCoeff * causalNumerator S.A S.B S.C S.D) * S.A.charpoly
  calc
    _ = causalNumerator S.A S.B S.C S.D * D := hreal.symm
    _ = causalNumerator S.A S.B S.C S.D * (Polynomial.C D.leadingCoeff * S.A.charpoly) :=
      congrArg (fun p => causalNumerator S.A S.B S.C S.D * p) hden
    _ = _ := by ring

/-- The concrete delayed feedback matrix retains the full, uncancelled
characteristic polynomial stated in the manuscript. -/
theorem minimal_delayed_characteristic (S : Delay.StateSpace ℝ)
    {D N : Polynomial ℝ} (hD : D ≠ 0) (hDN : IsCoprime D N)
    (hreal : RationalRealization S D N)
    (hdim : Fintype.card S.State = D.natDegree)
    {m : ℕ} (hm : 0 < m) (k : ℝ) :
    Polynomial.C D.leadingCoeff * (Delay.closedLoop (Delay.delay S m) k).charpoly =
      Polynomial.X^m * D + Polynomial.C k * N := by
  obtain ⟨hden, hnum⟩ := minimal_realization_polynomials S hD hDN hreal hdim
  calc
    _ = Polynomial.X^m * (Polynomial.C D.leadingCoeff * S.A.charpoly) +
        Polynomial.C k * (Polynomial.C D.leadingCoeff * causalNumerator S.A S.B S.C S.D) := by
      rw [delayed_charpoly S hm k]
      ring
    _ = _ := by rw [← hden, ← hnum]

/-- Actual augmented-state dimension, including all m shift-register states. -/
theorem minimal_delayed_dimension (S : Delay.StateSpace ℝ)
    {D : Polynomial ℝ} (hdim : Fintype.card S.State = D.natDegree) (m : ℕ) :
    Fintype.card (Delay.delay S m).State = D.natDegree + m := by
  rw [Delay.delay_card, hdim]

/-- No internal instability can be hidden by transfer cancellations: the
actual trajectory decay test is equivalent to the full polynomial-root test. -/
theorem minimal_delayed_asymptotic_stability_iff (S : Delay.StateSpace ℝ)
    {D N : Polynomial ℝ} (hD : D ≠ 0) (hDN : IsCoprime D N)
    (hreal : RationalRealization S D N)
    (hdim : Fintype.card S.State = D.natDegree)
    {m : ℕ} (hm : 0 < m) (k : ℝ) :
    AsymptoticallyStable (Delay.closedLoop (Delay.delay S m) k) ↔
      ∀ z : ℂ, ((Polynomial.X^m*D+Polynomial.C k*N).map
        Complex.ofRealHom).eval z = 0 → ‖z‖ < 1 := by
  rw [asymptoticallyStable_iff_schur]
  have hl : (D.leadingCoeff : ℂ) ≠ 0 := by
    exact_mod_cast leadingCoeff_ne_zero.mpr hD
  have hp := congrArg (Polynomial.map Complex.ofRealHom)
    (minimal_delayed_characteristic S hD hDN hreal hdim hm k)
  simp only [Polynomial.map_mul, Polynomial.map_C] at hp
  have he (z : ℂ) :
      ((Polynomial.X^m*D+Polynomial.C k*N).map Complex.ofRealHom).eval z = 0 ↔
        (C2.NGamma.complexify (Delay.closedLoop (Delay.delay S m) k)).charpoly.eval z = 0 := by
    rw [← hp, Polynomial.eval_mul, Polynomial.eval_C, mul_eq_zero]
    simp only [Complex.ofRealHom_eq_coe, hl, false_or]
    rw [← Matrix.charpoly_map _ Complex.ofRealHom]
    rfl
  constructor
  · intro h z hz
    exact h z ((he z).mp hz)
  · intro h z hz
    exact h z ((he z).mpr hz)

end C2.GeneralCompletion
