import C2.NGammaRootClosedness
import C2.NGammaMultiplicity
import Mathlib.Analysis.SpecificLimits.Basic

/-! Closed-disk stability at a limiting gain and the absence of unit roots
other than -1 at the positive endpoint. No continuity of an enumerated list
of polynomial roots is assumed. -/
noncomputable section
open scoped BigOperators Topology
open Polynomial Filter
namespace C2.NGamma.PolynomialModel
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Stable characteristic polynomials below B cannot acquire an exterior root
at B. The fixed nonzero leading coefficient is essential to this argument. -/
theorem roots_closed_disk_of_stable_below {r x : ι → ℝ} {d : ℕ} {B : ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, -1 ≤ x i) (hd : 1 ≤ d) (hB : 0 < B)
    (hstable : ∀ b : ℝ, 0 ≤ b → b < B → SchurStable (characteristic r x d b))
    {z : ℂ} (hz : (characteristic r x d B).eval z = 0) : ‖z‖ ≤ 1 := by
  by_contra! hout
  let lead : ℂ := ∏ i, ((1+r i*(1+x i)/2 : ℝ) : ℂ)
  let L : ℝ := ‖lead‖ * (‖z‖-1)^(Fintype.card ι+d)
  have hlead : lead ≠ 0 := by
    apply Finset.prod_ne_zero_iff.mpr
    intro i _
    exact_mod_cast ne_of_gt (cube_factor_leading_pos (hr i) (hx i))
  have hL : 0 < L := mul_pos (norm_pos_iff.mpr hlead) (pow_pos (by linarith) _)
  let seq : ℕ → ℝ := fun n => B - 1 / ((n : ℝ)+1)
  have hseq : Tendsto seq atTop (𝓝 B) := by
    simpa [seq] using (tendsto_const_nhds.sub tendsto_one_div_add_atTop_nhds_zero_nat)
  have hpos : ∀ᶠ n in atTop, 0 < seq n :=
    hseq.eventually (isOpen_Ioi.mem_nhds hB)
  have hbound : ∀ᶠ n in atTop, L ≤ ‖(characteristic r x d (seq n)).eval z‖ := by
    filter_upwards [hpos] with n hn
    have hlt : seq n < B := by
      dsimp [seq]
      have hden : 0 < (n : ℝ)+1 := by positivity
      linarith [one_div_pos.mpr hden]
    have hs := schur_eval_norm_lower_bound (hstable (seq n) hn.le hlt) hout
    obtain ⟨hdeg,hlc⟩ := cube_characteristic_degree_leading hr hx hd (seq n)
    simpa only [hdeg,hlc,L,lead] using hs
  have hc : Continuous (fun b : ℝ => ‖(characteristic r x d b).eval z‖) := by
    simp only [characteristic, eval_add, eval_mul, eval_pow, eval_X, eval_C, eval_prod]
    fun_prop
  have hlim := hc.continuousAt.tendsto.comp hseq
  rw [hz, norm_zero] at hlim
  have hh := ge_of_tendsto hlim hbound
  linarith

/-- The exact complementary norm identity on the unit circle. -/
theorem endpoint_factor_norm_gap {r x : ℝ} (hx : x ≠ 0) {z : ℂ} (hz : ‖z‖ = 1) :
    (r+2/x)^2 * ‖(q x).eval z‖^2 - ‖(factor r x).eval z‖^2 =
      (1+r*x)/x^2 * ‖z+1‖^2 := by
  have hid : (r+2/x)^2 * ‖(q x).eval z‖^2 - ‖(factor r x).eval z‖^2 =
      (1+r*x)/x^2 * ‖z+1‖^2 + (r+2/x)*(‖z‖^2-1) := by
    simp only [Complex.sq_norm, Complex.normSq_apply, factor_eval, q_eval]
    simp [Complex.add_re, Complex.add_im, Complex.sub_re, Complex.sub_im,
      Complex.mul_re, Complex.mul_im, Complex.div_re, Complex.div_im,
      Complex.normSq_apply]
    field_simp
    ring
  rw [hid, hz]
  ring

/-- Every finite unit-circle point has gain strictly below the endpoint. -/
theorem factor_norm_lt_endpoint_mul_q {r x : ℝ} (hr : 0 < r) (hx : 0 < x)
    {z : ℂ} (hz : ‖z‖ = 1) (hz1 : z ≠ -1) :
    ‖(factor r x).eval z‖ < (r+2/x)*‖(q x).eval z‖ := by
  have hg := endpoint_factor_norm_gap (r := r) (ne_of_gt hx) hz
  have hcoeff : 0 < (1+r*x)/x^2 := by positivity
  have hn : 0 < ‖z+1‖ := norm_pos_iff.mpr (by simpa [add_eq_zero_iff_eq_neg] using hz1)
  have hp : 0 < (1+r*x)/x^2*‖z+1‖^2 := mul_pos hcoeff (sq_pos_of_pos hn)
  have hb : 0 < r+2/x := by positivity
  nlinarith [norm_nonneg ((factor r x).eval z),
    mul_nonneg hb.le (norm_nonneg ((q x).eval z))]

/-- At the endpoint gain, -1 is the only possible unit-circle root. -/
theorem endpoint_unit_root_eq_neg_one [Nonempty ι] {r x : ι → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) (d : ℕ) {z : ℂ}
    (hz : ‖z‖ = 1)
    (hroot : (characteristic r x d (∏ i, (r i+2/x i))).eval z = 0) : z = -1 := by
  by_contra hz1
  have hf (i : ι) : 0 < ‖(factor (r i) (x i)).eval z‖ := by
    apply norm_pos_iff.mpr
    intro he
    have hs := factor_schur (hr i) (hx i).le z he
    linarith
  have hprod : (∏ i, ‖(factor (r i) (x i)).eval z‖) <
      (∏ i, (r i+2/x i)) * ∏ i, ‖(q (x i)).eval z‖ := by
    rw [← Finset.prod_mul_distrib]
    exact Finset.prod_lt_prod_of_nonempty (fun i _ => hf i)
      (fun i _ => factor_norm_lt_endpoint_mul_q (hr i) (hx i) hz hz1) Finset.univ_nonempty
  have hb : 0 < ∏ i, (r i+2/x i) :=
    Finset.prod_pos (fun i _ => add_pos (hr i) (div_pos (by norm_num) (hx i)))
  have he : z^d * ∏ i, (factor (r i) (x i)).eval z =
      -((∏ i, (r i+2/x i) : ℝ) * ∏ i, (q (x i)).eval z) := by
    apply eq_neg_of_add_eq_zero_left
    simpa only [characteristic, eval_add, eval_mul, eval_pow, eval_X, eval_C, eval_prod] using hroot
  have hh := congrArg norm he
  simp only [norm_mul, norm_pow, norm_prod, norm_neg, Complex.norm_real,
    Real.norm_eq_abs, abs_of_pos hb, hz, one_pow, one_mul] at hh
  have hbi (i : ι) : 0 < r i+2/x i := add_pos (hr i) (div_pos (by norm_num) (hx i))
  simp only [abs_of_pos (hbi _)] at hh
  linarith

/-- Conditional closure step: once the exact open stable interval is proved,
all endpoint roots other than -1 remain strictly inside the disk. -/
theorem endpoint_other_roots_inside_of_stable_below [Nonempty ι] {r x : ι → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i)
    (hstable : ∀ b : ℝ, 0 ≤ b → b < ∏ i, (r i+2/x i) →
      SchurStable (characteristic r x 1 b))
    {z : ℂ} (hz : (characteristic r x 1 (∏ i, (r i+2/x i))).eval z = 0)
    (hz1 : z ≠ -1) : ‖z‖ < 1 := by
  have hB : 0 < ∏ i, (r i+2/x i) :=
    Finset.prod_pos (fun i _ => add_pos (hr i) (div_pos (by norm_num) (hx i)))
  have hle := roots_closed_disk_of_stable_below hr (fun i => by linarith [hx i])
    (by norm_num : 1 ≤ (1:ℕ)) hB hstable hz
  exact lt_of_le_of_ne hle (fun he => hz1 (endpoint_unit_root_eq_neg_one hr hx 1 he hz))

end C2.NGamma.PolynomialModel
