import Mathlib.Tactic
import Mathlib.Data.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Analysis.Calculus.DSlope
import Mathlib.Analysis.SpecificLimits.Basic

noncomputable section
open Filter Topology
namespace C2.IntegratorDelay

/-- The fine-sampling physical-threshold formula in `cor:global`.
The connection to the optimizing stability margin is a separate theorem. -/
def physicalThreshold (n : ℕ) : ℝ :=
  2 * (n : ℝ) * Real.sin (Real.pi / (4 * (n : ℝ) - 2))

def physicalAngleValue (x : ℝ) : ℝ :=
  (Real.pi / (2 * x) + 1) * Real.sin x

theorem sine_tangent_remainder_bound {x : ℝ} (hx : 0 ≤ x) :
    Real.sin x - x * Real.cos x ≤ x ^ 3 / 3 := by
  let f : ℝ → ℝ := fun t => t ^ 3 / 3 - Real.sin t + t * Real.cos t
  have hf (t : ℝ) : HasDerivAt f (t ^ 2 - t * Real.sin t) t := by
    convert ((((hasDerivAt_id t).pow 3).div_const 3).sub (Real.hasDerivAt_sin t)).add
      ((hasDerivAt_id t).mul (Real.hasDerivAt_cos t)) using 1 <;> simp [f] <;> ring
  have hm : MonotoneOn f (Set.Ici 0) := by
    apply monotoneOn_of_deriv_nonneg (convex_Ici 0) ?_ ?_ ?_
    · exact (by fun_prop : Continuous f).continuousOn
    · intro t ht
      exact (hf t).differentiableAt.differentiableWithinAt
    · intro t ht
      rw [(hf t).deriv]
      have ht0 : 0 ≤ t := (interior_subset ht)
      nlinarith [mul_le_mul_of_nonneg_left (Real.sin_le ht0) ht0]
  have h := hm (show (0 : ℝ) ∈ Set.Ici 0 by simp) hx hx
  simp [f] at h
  linarith

theorem physicalAngleValue_hasDerivAt {x : ℝ} (hx : x ≠ 0) :
    HasDerivAt physicalAngleValue
      (Real.cos x - Real.pi / (2 * x ^ 2) * (Real.sin x - x * Real.cos x)) x := by
  have h := (((hasDerivAt_const x Real.pi).div
    ((hasDerivAt_id x).const_mul 2) (by simpa using hx)).add_const 1).mul
      (Real.hasDerivAt_sin x)
  convert h using 1
  simp only [id_eq, mul_one, zero_mul, zero_sub]
  field_simp [hx] <;> ring

theorem physicalAngleValue_deriv_pos {x : ℝ}
    (hx : x ∈ Set.Ioc 0 (Real.pi / 6)) :
    0 < deriv physicalAngleValue x := by
  rw [(physicalAngleValue_hasDerivAt hx.1.ne').deriv]
  have hrem := sine_tangent_remainder_bound hx.1.le
  have hcoef : 0 ≤ Real.pi / (2 * x ^ 2) := by positivity
  have hbound := mul_le_mul_of_nonneg_left hrem hcoef
  have hsimp : Real.pi / (2 * x ^ 2) * (x ^ 3 / 3) = Real.pi * x / 6 := by
    field_simp [hx.1.ne'] <;> ring
  rw [hsimp] at hbound
  have hcos := Real.cos_le_cos_of_nonneg_of_le_pi hx.1.le
    (show Real.pi / 3 ≤ Real.pi by linarith [Real.pi_pos])
    (show x ≤ Real.pi / 3 by linarith [Real.pi_pos, hx.2])
  rw [Real.cos_pi_div_three] at hcos
  have hmul := mul_le_mul_of_nonneg_left hx.2 Real.pi_pos.le
  have hpi : Real.pi ^ 2 < 10 := by nlinarith [Real.pi_pos, Real.pi_lt_d2]
  nlinarith

theorem physicalAngleValue_strictMonoOn :
    StrictMonoOn physicalAngleValue (Set.Ioc 0 (Real.pi / 6)) := by
  apply strictMonoOn_of_deriv_pos (convex_Ioc _ _) ?_ ?_
  · intro x hx
    exact (physicalAngleValue_hasDerivAt hx.1.ne').continuousAt.continuousWithinAt
  · intro x hx
    exact physicalAngleValue_deriv_pos (interior_subset hx)

theorem physicalThreshold_eq_angle {n : ℕ} (hn : 2 ≤ n) :
    physicalThreshold n = physicalAngleValue (Real.pi / (4 * (n : ℝ) - 2)) := by
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  have hd : 4 * (n : ℝ) - 2 ≠ 0 := by linarith
  unfold physicalThreshold physicalAngleValue
  field_simp [hd, Real.pi_ne_zero]
  ring

theorem sampling_angle_mem {n : ℕ} (hn : 2 ≤ n) :
    Real.pi / (4 * (n : ℝ) - 2) ∈ Set.Ioc 0 (Real.pi / 6) := by
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  have hd : 0 < 4 * (n : ℝ) - 2 := by linarith
  refine ⟨div_pos Real.pi_pos hd, ?_⟩
  apply (div_le_div_iff₀ hd (by norm_num : (0 : ℝ) < 6)).2
  nlinarith [Real.pi_pos]

theorem physicalThreshold_strictAntiOn :
    StrictAntiOn physicalThreshold (Set.Ici 2) := by
  intro m hm n hn hmn
  have hm' : (2 : ℝ) ≤ m := by exact_mod_cast hm
  have hmn' : (m : ℝ) < n := by exact_mod_cast hmn
  rw [physicalThreshold_eq_angle hm, physicalThreshold_eq_angle hn]
  apply physicalAngleValue_strictMonoOn (sampling_angle_mem hn) (sampling_angle_mem hm)
  apply (div_lt_div_iff₀ (by linarith) (by linarith)).2
  nlinarith [Real.pi_pos]

@[simp] theorem physicalThreshold_two : physicalThreshold 2 = 2 := by
  norm_num [physicalThreshold, Real.sin_pi_div_six]

theorem physicalThreshold_le_two {n : ℕ} (hn : 2 ≤ n) : physicalThreshold n ≤ 2 := by
  simpa using physicalThreshold_strictAntiOn.antitoneOn (by simp : (2 : ℕ) ∈ Set.Ici 2) hn hn

theorem physicalThreshold_tendsto :
    Tendsto physicalThreshold atTop (𝓝 (Real.pi / 2)) := by
  have hcast : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hden : Tendsto (fun n : ℕ => 4 * (n : ℝ) - 2) atTop atTop := by
    simpa [sub_eq_add_neg] using tendsto_atTop_add_const_right atTop (-2 : ℝ)
      (hcast.const_mul_atTop (by norm_num : (0 : ℝ) < 4))
  have hang : Tendsto (fun n : ℕ => Real.pi / (4 * (n : ℝ) - 2)) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop hden
  have hs : ContinuousAt (dslope Real.sin 0) 0 :=
    continuousAt_dslope_same.2 (Real.hasDerivAt_sin 0).differentiableAt
  have hconst : Tendsto (fun _ : ℕ => Real.pi / 2) atTop (𝓝 (Real.pi / 2)) :=
    tendsto_const_nhds
  have hlim := (hconst.add hang).mul (hs.tendsto.comp hang)
  have hlim' : Tendsto
      (fun n : ℕ => (Real.pi / 2 + Real.pi / (4 * (n : ℝ) - 2)) *
        dslope Real.sin 0 (Real.pi / (4 * (n : ℝ) - 2))) atTop (𝓝 (Real.pi / 2)) := by
    simpa [dslope_same, (Real.hasDerivAt_sin 0).deriv] using hlim
  apply hlim'.congr'
  filter_upwards [eventually_ge_atTop (2 : ℕ)] with n hn
  have hx := (sampling_angle_mem hn).1
  rw [dslope_of_ne _ hx.ne']
  simp only [slope_def_field, Real.sin_zero, sub_zero]
  unfold physicalThreshold
  have hn' : (2 : ℝ) ≤ n := by exact_mod_cast hn
  have hd : 4 * (n : ℝ) - 2 ≠ 0 := by linarith
  field_simp [hd, Real.pi_ne_zero]
  ring

end C2.IntegratorDelay
