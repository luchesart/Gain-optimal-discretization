import C2.CADEffectivePolynomial
import C2.CADIsolationOutput

/-! Executable dyadic-mesh search. All acceptance decisions use finite rational
coefficient lists. Compactness supplies only the erased termination proof. -/
namespace C2.CADEffective.Dense
open Polynomial Set

def slopeBound (p : Poly) (a b : ℚ) : ℚ :=
  1 + coeffBound (derivative p) (C2.CADIsolation.intervalRadius a b) +
    coeffBound (derivative (derivative p)) (C2.CADIsolation.intervalRadius a b)

theorem slopeBound_eq (p : Poly) (a b : ℚ) :
    slopeBound p a b = C2.CADIsolation.slopeBound (denote p) a b := by
  simp only [slopeBound, C2.CADIsolation.slopeBound, C2.CADIsolation.coeffBound,
    coeffBound_eq_support_sum, denote_derivative]

def cellCheck (p : Poly) (a b l u : ℚ) : Bool :=
  decide (slopeBound p a b * (u-l) < |eval p (C2.CADIsolation.midpoint l u)| ∨
    slopeBound p a b * (u-l) < |eval (derivative p) (C2.CADIsolation.midpoint l u)|)

theorem cellCheck_iff (p : Poly) (a b l u : ℚ) :
    cellCheck p a b l u = true ↔ C2.CADIsolation.certifiedCell (denote p) a b l u := by
  simp only [cellCheck, decide_eq_true_eq, C2.CADIsolation.certifiedCell,
    C2.CADIsolation.zeroFreeTest, C2.CADIsolation.monotoneTest,
    slopeBound_eq, eval_denote, denote_derivative]

def meshCheck (p : Poly) (a b : ℚ) (n : ℕ) : Bool :=
  (List.range (2^n)).all (fun i => cellCheck p a b
    (C2.CADIsolation.gridPoint a b n i) (C2.CADIsolation.gridPoint a b n (i+1)))

theorem meshCheck_iff (p : Poly) (a b : ℚ) (n : ℕ) :
    meshCheck p a b n = true ↔ C2.CADIsolation.certifiedMesh (denote p) a b n := by
  simp only [meshCheck, List.all_eq_true, List.mem_range, cellCheck_iff,
    C2.CADIsolation.certifiedMesh, Finset.mem_range]

theorem exists_meshCheck (p : Poly) {a b : ℚ} (hab : a ≤ b)
    (hs : ∀ x ∈ Icc (a:ℝ) (b:ℝ),
      C2.CADIsolation.realEval (denote p) x ≠ 0 ∨
        C2.CADIsolation.realEval (denote p).derivative x ≠ 0) :
    ∃ n, meshCheck p a b n = true := by
  obtain ⟨n, hn⟩ := C2.CADIsolation.exists_certifiedMesh (denote p) hab hs
  exact ⟨n, (meshCheck_iff p a b n).mpr hn⟩

/-- Genuine terminating natural-number search: only the Boolean rational mesh
checker is evaluated. The real nondegeneracy assumption occurs in a proof. -/
def meshIndex (p : Poly) {a b : ℚ} (hab : a ≤ b)
    (hs : ∀ x ∈ Icc (a:ℝ) (b:ℝ),
      C2.CADIsolation.realEval (denote p) x ≠ 0 ∨
        C2.CADIsolation.realEval (denote p).derivative x ≠ 0) : ℕ :=
  Nat.find (exists_meshCheck p hab hs)

theorem meshIndex_accepted (p : Poly) {a b : ℚ} (hab : a ≤ b)
    (hs : ∀ x ∈ Icc (a:ℝ) (b:ℝ),
      C2.CADIsolation.realEval (denote p) x ≠ 0 ∨
        C2.CADIsolation.realEval (denote p).derivative x ≠ 0) :
    meshCheck p a b (meshIndex p hab hs) = true :=
  Nat.find_spec (exists_meshCheck p hab hs)

theorem meshIndex_certified (p : Poly) {a b : ℚ} (hab : a ≤ b)
    (hs : ∀ x ∈ Icc (a:ℝ) (b:ℝ),
      C2.CADIsolation.realEval (denote p) x ≠ 0 ∨
        C2.CADIsolation.realEval (denote p).derivative x ≠ 0) :
    C2.CADIsolation.certifiedMesh (denote p) a b (meshIndex p hab hs) :=
  (meshCheck_iff p a b _).mp (meshIndex_accepted p hab hs)

theorem meshIndex_le_any_accepted (p : Poly) {a b : ℚ} (hab : a ≤ b)
    (hs : ∀ x ∈ Icc (a:ℝ) (b:ℝ),
      C2.CADIsolation.realEval (denote p) x ≠ 0 ∨
        C2.CADIsolation.realEval (denote p).derivative x ≠ 0)
    {n : ℕ} (hn : meshCheck p a b n = true) : meshIndex p hab hs ≤ n :=
  Nat.find_min' (exists_meshCheck p hab hs) hn

def meshIntervals (a b : ℚ) (n : ℕ) : List (ℚ × ℚ) :=
  (List.range (2^n)).map (fun i =>
    (C2.CADIsolation.gridPoint a b n i, C2.CADIsolation.gridPoint a b n (i+1)))

@[simp] theorem meshIntervals_length (a b : ℚ) (n : ℕ) :
    (meshIntervals a b n).length = 2^n := by simp [meshIntervals]

theorem every_meshInterval_checked (p : Poly) (a b : ℚ) (n : ℕ)
    (hn : meshCheck p a b n = true) {l u : ℚ}
    (hlu : (l,u) ∈ meshIntervals a b n) : cellCheck p a b l u = true := by
  obtain ⟨i, hi, hp⟩ := List.mem_map.mp hlu
  cases hp
  exact (List.all_eq_true.mp hn) i hi

/-- All exact rational grid roots, including endpoints. -/
def pointIndices (p : Poly) (a b : ℚ) (n : ℕ) : List ℕ :=
  (List.range (2^n+1)).filter (fun i =>
    decide (eval p (C2.CADIsolation.gridPoint a b n i) = 0))

/-- All open cells whose endpoint values have opposite signs. -/
def rootIntervalIndices (p : Poly) (a b : ℚ) (n : ℕ) : List ℕ :=
  (List.range (2^n)).filter (fun i => decide
    (eval p (C2.CADIsolation.gridPoint a b n i) *
      eval p (C2.CADIsolation.gridPoint a b n (i+1)) < 0))

theorem mem_pointIndices (p : Poly) (a b : ℚ) (n i : ℕ) :
    i ∈ pointIndices p a b n ↔ C2.CADIsolation.selectedPoint (denote p) a b n i := by
  simp only [pointIndices, List.mem_filter, List.mem_range, decide_eq_true_eq,
    eval_denote, C2.CADIsolation.selectedPoint, Nat.lt_succ_iff]

theorem mem_rootIntervalIndices (p : Poly) (a b : ℚ) (n i : ℕ) :
    i ∈ rootIntervalIndices p a b n ↔
      C2.CADIsolation.selectedInterval (denote p) a b n i := by
  simp only [rootIntervalIndices, List.mem_filter, List.mem_range, decide_eq_true_eq,
    eval_denote, C2.CADIsolation.selectedInterval]

def isolatedPoints (p : Poly) (a b : ℚ) (n : ℕ) : List ℚ :=
  (pointIndices p a b n).map (C2.CADIsolation.gridPoint a b n)

def isolatingIntervals (p : Poly) (a b : ℚ) (n : ℕ) : List (ℚ × ℚ) :=
  (rootIntervalIndices p a b n).map (fun i =>
    (C2.CADIsolation.gridPoint a b n i, C2.CADIsolation.gridPoint a b n (i+1)))

end C2.CADEffective.Dense
