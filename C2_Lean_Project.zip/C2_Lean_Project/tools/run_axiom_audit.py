#!/usr/bin/env python3
"""Run the complete shared-state official Lean axiom-union audit.

AxiomAudit.lean and check_axiom_audit.py retain optional exact per-root reports.
The default checks the equivalent allowed-axiom property for all public roots
without repeating common dependency traversals.
"""
import sys
from run_shared_axiom_audit import main

if __name__ == '__main__':
    sys.exit(main())
