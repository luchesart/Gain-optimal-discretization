import C2.NGammaRealizationAligned
import C2.NGammaRealizationDecay
import Mathlib.Analysis.Normed.Algebra.Spectrum
import Mathlib.Analysis.Matrix
import Mathlib.Analysis.SpecificLimits.Normed

/-! Standard finite-dimensional dynamics bridge: spectral Schur stability is
 equivalent to decay of every state trajectory. -/
noncomputable section
open Filter Topology Matrix
open scoped NNReal ENNReal
namespace C2.NGamma.Realization

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Every state trajectory of the homogeneous recurrence tends to zero. -/
def AsymptoticallyStable (A : Matrix ι ι ℝ) : Prop :=
  ∀ x : ι → ℝ, Tendsto (fun n : ℕ => (A^n) *ᵥ x) atTop (𝓝 0)

lemma complex_powers_tendsto_zero (A : Matrix ι ι ℂ)
    (h : ∀ z : ℂ, A.charpoly.eval z = 0 → ‖z‖ < 1) :
    Tendsto (fun n : ℕ => A^n) atTop (𝓝 0) := by
  cases isEmpty_or_nonempty ι with
  | inl hi =>
    letI := hi
    have he : ∀ n : ℕ, A^n = 0 := fun _ => Subsingleton.elim _ _
    simp_rw [he]
    exact tendsto_const_nhds
  | inr hi =>
    letI := hi
    letI : NormedRing (Matrix ι ι ℂ) := Matrix.linftyOpNormedRing
    letI : NormedAlgebra ℂ (Matrix ι ι ℂ) := Matrix.linftyOpNormedAlgebra
    have hs : spectralRadius ℂ A < 1 := by
      apply spectrum.spectralRadius_lt_of_forall_lt A
      intro z hz
      have hr : A.charpoly.eval z = 0 := by
        rw [charpoly_eval]
        have hu : ¬ IsUnit (z • (1 : Matrix ι ι ℂ)-A) := by
          simpa only [spectrum.mem_iff, Algebra.algebraMap_eq_smul_one] using hz
        simpa only [Matrix.isUnit_iff_isUnit_det, isUnit_iff_ne_zero, not_not] using hu
      exact_mod_cast h z hr
    exact powers_tendsto_zero_of_spectralRadius_lt_one A hs

lemma complexify_pow (A : Matrix ι ι ℝ) (n : ℕ) :
    C2.NGamma.complexify (A^n) = (C2.NGamma.complexify A)^n := by
  exact map_pow Complex.ofRealHom.mapMatrix A n

lemma complex_pow_mulVec (A : Matrix ι ι ℂ) (v : ι → ℂ) (mu : ℂ)
    (hv : A *ᵥ v = mu • v) (n : ℕ) : (A^n) *ᵥ v = mu^n • v := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ', ← Matrix.mulVec_mulVec, ih, Matrix.mulVec_smul, hv,
      smul_smul, pow_succ]

lemma complex_schur_of_powers_tendsto_zero (A : Matrix ι ι ℂ)
    (h : Tendsto (fun n : ℕ => A^n) atTop (𝓝 0)) :
    ∀ z : ℂ, A.charpoly.eval z = 0 → ‖z‖ < 1 := by
  intro z hz
  rw [charpoly_eval] at hz
  obtain ⟨v,hv,he⟩ := Matrix.exists_mulVec_eq_zero_iff.mpr hz
  have hev : A *ᵥ v = z • v := by
    rw [Matrix.sub_mulVec, Matrix.smul_mulVec_assoc, Matrix.one_mulVec] at he
    exact (sub_eq_zero.mp he).symm
  obtain ⟨i,hi⟩ : ∃ i, v i ≠ 0 := by
    by_contra hh
    push_neg at hh
    exact hv (funext hh)
  have hc : Tendsto (fun n : ℕ => ((A^n) *ᵥ v) i) atTop (𝓝 0) := by
    have hs := tendsto_finset_sum Finset.univ (fun j _ =>
      ((tendsto_pi_nhds.mp (tendsto_pi_nhds.mp h i) j).mul_const (v j)))
    simpa only [Matrix.mulVec, dotProduct, Matrix.zero_apply, zero_mul, Finset.sum_const_zero] using hs
  have hp : Tendsto (fun n : ℕ => z^n) atTop (𝓝 0) := by
    have hh := hc.div_const (v i)
    simp only [complex_pow_mulVec A v z hev, Pi.smul_apply, smul_eq_mul,
      mul_div_cancel_right₀ _ hi, zero_div] at hh
    exact hh
  exact tendsto_pow_atTop_nhds_zero_iff_norm_lt_one.mp hp

/-- Spectral Schur stability is sufficient for decay of every real state. -/
theorem asymptoticallyStable_of_schur (A : Matrix ι ι ℝ)
    (h : C2.NGamma.MatrixSchurStable A) : AsymptoticallyStable A := by
  have hp := complex_powers_tendsto_zero (C2.NGamma.complexify A) h
  have hr (i j : ι) : Tendsto (fun n : ℕ => (A^n) i j) atTop (𝓝 0) := by
    have ht := Complex.continuous_re.continuousAt.tendsto.comp
      (tendsto_pi_nhds.mp (tendsto_pi_nhds.mp hp i) j)
    simp_rw [← complexify_pow] at ht
    simpa only [C2.NGamma.complexify, Matrix.map_apply, Function.comp_def,
      Complex.ofReal_re, Matrix.zero_apply, Complex.zero_re] using ht
  intro x
  apply tendsto_pi_nhds.mpr
  intro i
  have hs := tendsto_finset_sum Finset.univ (fun j _ => (hr i j).mul_const (x j))
  simpa only [Matrix.mulVec, dotProduct, zero_mul, Finset.sum_const_zero, Pi.zero_apply] using hs

/-- Decay of every real initial state forces every complex eigenvalue inside
 the unit circle. The proof does not assume diagonalizability. -/
theorem schur_of_asymptoticallyStable (A : Matrix ι ι ℝ)
    (h : AsymptoticallyStable A) : C2.NGamma.MatrixSchurStable A := by
  apply complex_schur_of_powers_tendsto_zero
  apply tendsto_pi_nhds.mpr
  intro i
  apply tendsto_pi_nhds.mpr
  intro j
  have hr : Tendsto (fun n : ℕ => (A^n) i j) atTop (𝓝 0) := by
    simpa only [Matrix.mulVec_single_one] using
      (tendsto_pi_nhds.mp (h (Pi.single j 1)) i)
  have hc := Complex.continuous_ofReal.continuousAt.tendsto.comp hr
  change Tendsto (fun n : ℕ => ((C2.NGamma.complexify A)^n) i j) atTop (𝓝 0)
  simp_rw [← complexify_pow]
  simpa only [C2.NGamma.complexify, Matrix.map_apply, Function.comp_def,
    Complex.ofReal_zero, Matrix.zero_apply] using hc

/-- The standard spectral/dynamical equivalence for arbitrary real matrices. -/
theorem asymptoticallyStable_iff_schur (A : Matrix ι ι ℝ) :
    AsymptoticallyStable A ↔ C2.NGamma.MatrixSchurStable A :=
  ⟨schur_of_asymptoticallyStable A, asymptoticallyStable_of_schur A⟩

/-- Final internal-stability clause of the realization and aligned-delay
 theorem, stated literally as decay of every augmented-state trajectory. -/
theorem aligned_asymptotic_stability_iff {ι : Type} [Fintype ι] [DecidableEq ι]
    (T : ℝ) (Γ A : Matrix ι ι ℝ) (B C : ι → ℝ) (D k : ℝ)
    {d : ℕ} (hd : 0 < d) (hE : (E T Γ A).det ≠ 0) :
    AsymptoticallyStable
        (Delay.closedLoop (Delay.delay (causalStateSpace T Γ A B C D) d) k) ↔
      ∀ z : ℂ, ((Polynomial.X^d * denominator T Γ A +
        Polynomial.C k * numerator T Γ A B C D).map Complex.ofRealHom).eval z = 0 → ‖z‖ < 1 := by
  rw [asymptoticallyStable_iff_schur, aligned_schur_iff T Γ A B C D k hd hE]

end C2.NGamma.Realization
