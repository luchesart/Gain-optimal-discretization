import C2.NGammaRealizationDynamics

/-! The diagonal-Lyapunov proposition uses precisely the matrices E and Ad of
 the general realization theorem. -/
noncomputable section
namespace C2.NGamma
open Matrix
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

lemma diagonal_one_sub (γ : ι → ℝ) :
    diagonal (fun i => 1-γ i) = 1-diagonal γ := by
  ext i j
  by_cases hij : i = j
  · subst j
    simp
  · simp [Matrix.diagonal_apply_ne _ hij, Matrix.one_apply_ne hij, hij]

lemma stepF_eq_realizationF (T : ℝ) (γ : ι → ℝ) (A : Matrix ι ι ℝ) :
    stepF T γ A = Realization.F T (diagonal γ) A := by
  rw [stepF, diagonal_one_sub]
  rfl

lemma stepMatrix_eq_realizationAd (T : ℝ) (γ : ι → ℝ) (A : Matrix ι ι ℝ) :
    stepMatrix T γ A = Realization.Ad T (diagonal γ) A := by
  rw [stepMatrix, stepF_eq_realizationF]
  rfl

/-- Literal matrix realization form of the manuscript proposition, including
 decay of every state trajectory. -/
theorem realization_diagonal_stability {p γ : ι → ℝ} {A : Matrix ι ι ℝ} {T : ℝ}
    (hp : (diagonal p).PosDef) (hγ : ∀ i, 1/2 ≤ γ i) (hT : 0 < T)
    (hL : (-(A.transpose * diagonal p + diagonal p * A)).PosDef) :
    (Realization.E T (diagonal γ) A).det ≠ 0 ∧
      MatrixSchurStable (Realization.Ad T (diagonal γ) A) ∧
      Realization.AsymptoticallyStable (Realization.Ad T (diagonal γ) A) := by
  obtain ⟨hE,hS⟩ := diagonal_stability_of_lyapunov hp hγ hT hL
  rw [stepMatrix_eq_realizationAd] at hS
  exact ⟨hE,hS,Realization.asymptoticallyStable_of_schur _ hS⟩

end C2.NGamma
