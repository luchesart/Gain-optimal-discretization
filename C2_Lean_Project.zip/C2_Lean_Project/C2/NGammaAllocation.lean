import Mathlib.Tactic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Analysis.Complex.Basic

/-!
# Fixed-frequency allocation calculus

Definitions below are the phase, logarithmic magnitude, and marginal slope of
the actual one-factor frequency response.  They are not abstract surrogates.
-/
noncomputable section
open scoped BigOperators
namespace C2.NGamma

def allocationPhase (r x w : ℝ) : ℝ :=
  Real.arctan ((x+2/r)/w) - Real.arctan (x/w)

def allocationLogGain (r x w : ℝ) : ℝ :=
  (Real.log ((r*x+2)^2+(r*w)^2) - Real.log (x^2+w^2))/2

def allocationMarginal (r x w : ℝ) : ℝ :=
  (r*(x^2-w^2)+2*x)/(2*w*(r*x+1))

def phaseDerivative (r x w : ℝ) : ℝ :=
  -4*w*(r*x+1)/(((r*x+2)^2+r^2*w^2)*(x^2+w^2))

theorem allocationPhase_hasDerivAt {r w : ℝ} (hr : 0 < r) (hw : 0 < w) (x : ℝ) :
    HasDerivAt (fun x => allocationPhase r x w) (phaseDerivative r x w) x := by
  have h := ((((hasDerivAt_id x).add_const (2/r)).div_const w).arctan).sub
    (((hasDerivAt_id x).div_const w).arctan)
  unfold allocationPhase phaseDerivative
  convert h using 1
  have hD : 0 < x^2+w^2 := by positivity
  have hN : 0 < (r*x+2)^2+r^2*w^2 := by positivity
  have hA : 0 < 1+((x+2/r)/w)^2 := by positivity
  have hB : 0 < 1+(x/w)^2 := by positivity
  field_simp
  <;> ring

theorem phaseDerivative_neg {r w x : ℝ} (hr : 0 < r) (hw : 0 < w) (hx : 0 ≤ x) :
    phaseDerivative r x w < 0 := by
  unfold phaseDerivative
  apply div_neg_of_neg_of_pos
  · have h : 0 < r*x+1 := by positivity
    nlinarith
  · positivity

theorem allocationPhase_continuous {r w : ℝ} : Continuous (fun x => allocationPhase r x w) := by
  unfold allocationPhase
  continuity

theorem allocationPhase_strictAntiOn {r w : ℝ} (hr : 0 < r) (hw : 0 < w) :
    StrictAntiOn (fun x => allocationPhase r x w) (Set.Ici 0) := by
  apply strictAntiOn_of_deriv_neg (convex_Ici _) allocationPhase_continuous.continuousOn
  intro x hx
  rw [(allocationPhase_hasDerivAt hr hw x).deriv]
  exact phaseDerivative_neg hr hw (le_of_lt (by simpa using hx))

theorem allocationMarginal_difference {r w x y : ℝ} (hw : w ≠ 0)
    (hx : r*x+1 ≠ 0) (hy : r*y+1 ≠ 0) :
    allocationMarginal r y w-allocationMarginal r x w =
      (y-x)*(r^2*x*y+r*(x+y)+2+r^2*w^2)/(2*w*(r*x+1)*(r*y+1)) := by
  unfold allocationMarginal
  field_simp
  <;> ring

theorem allocationMarginal_strictMonoOn {r w : ℝ} (hr : 0 < r) (hw : 0 < w) :
    StrictMonoOn (fun x => allocationMarginal r x w) (Set.Ici 0) := by
  intro x hx y hy hxy
  have hx0 : 0 ≤ x := hx
  have hy0 : 0 ≤ y := hy
  have hxp : 0 < r*x+1 := by positivity
  have hyp : 0 < r*y+1 := by positivity
  have hd := allocationMarginal_difference (ne_of_gt hw) (ne_of_gt hxp) (ne_of_gt hyp)
  have hn : 0 < r^2*x*y+r*(x+y)+2+r^2*w^2 := by positivity
  have hs : 0 < allocationMarginal r y w-allocationMarginal r x w := by
    rw [hd]
    apply div_pos
    · exact mul_pos (sub_pos.mpr hxy) hn
    · positivity
  linarith

theorem allocationLogGain_hasDerivAt {r w : ℝ} (hr : 0 < r) (hw : 0 < w) (x : ℝ) :
    HasDerivAt (fun x => allocationLogGain r x w)
      ((2*(r*x+2)*r/((r*x+2)^2+(r*w)^2)-2*x/(x^2+w^2))/2) x := by
  have hN : 0 < (r*x+2)^2+(r*w)^2 := by positivity
  have hD : 0 < x^2+w^2 := by positivity
  have hn := ((((hasDerivAt_id x).const_mul r).add_const 2).pow 2).add_const ((r*w)^2)
  have hd := ((hasDerivAt_id x).pow 2).add_const (w^2)
  have h := ((hn.log (ne_of_gt hN)).sub (hd.log (ne_of_gt hD))).div_const 2
  unfold allocationLogGain
  convert h using 1 <;> simp only [id_eq, Nat.cast_ofNat, Nat.reduceSub, pow_one, mul_one] <;> ring

theorem allocation_marginal_identity {r w x : ℝ} (hr : 0 < r) (hw : 0 < w)
    (hx : 0 ≤ x) :
    (2*(r*x+2)*r/((r*x+2)^2+(r*w)^2)-2*x/(x^2+w^2))/2 =
      allocationMarginal r x w * phaseDerivative r x w := by
  have hN : 0 < (r*x+2)^2+r^2*w^2 := by positivity
  have hD : 0 < x^2+w^2 := by positivity
  have hP : 0 < r*x+1 := by positivity
  unfold allocationMarginal phaseDerivative
  field_simp
  <;> ring

/-- The marginal utility rises with x while the phase falls with x.  This is
    the strict decrease of slope in phase coordinates. -/
theorem allocation_strict_concavity_slope {r w x y : ℝ} (hr : 0 < r) (hw : 0 < w)
    (hx : 0 ≤ x) (hy : 0 ≤ y) (hphase : allocationPhase r x w < allocationPhase r y w) :
    allocationMarginal r x w > allocationMarginal r y w := by
  have hxy : y < x := by
    by_contra hn
    have hle : x ≤ y := le_of_not_gt hn
    rcases hle.eq_or_lt with h | h
    · subst y; exact (lt_irrefl _ hphase)
    · have hs := allocationPhase_strictAntiOn hr hw hx hy h
      linarith
  exact allocationMarginal_strictMonoOn hr hw hy hx hxy


/-- The unconstrained inverse-marginal formula in the manuscript. -/
def frequencyFree (r w l : ℝ) : ℝ :=
  l*w+(Real.sqrt (1+(1+l^2)*r^2*w^2)-1)/r

def frequencyAllocation (r w l : ℝ) : ℝ := min 1 (max 0 (frequencyFree r w l))

theorem frequencyFree_den_pos {r w l : ℝ} (hr : 0 < r) (hw : 0 < w) :
    0 < r*frequencyFree r w l+1 := by
  have hs := Real.sq_sqrt (show 0 ≤ 1+(1+l^2)*r^2*w^2 by positivity)
  have hn := Real.sqrt_nonneg (1+(1+l^2)*r^2*w^2)
  have hpos : 0 < r^2*w^2 := by positivity
  have hid : r*frequencyFree r w l+1 = l*r*w+Real.sqrt (1+(1+l^2)*r^2*w^2) := by
    unfold frequencyFree
    field_simp
    <;> ring
  rw [hid]
  nlinarith [sq_nonneg (l*r*w+Real.sqrt (1+(1+l^2)*r^2*w^2))]

theorem frequencyFree_marginal {r w l : ℝ} (hr : 0 < r) (hw : 0 < w) :
    allocationMarginal r (frequencyFree r w l) w = l := by
  have hs := Real.sq_sqrt (show 0 ≤ 1+(1+l^2)*r^2*w^2 by positivity)
  have hn := ne_of_gt (frequencyFree_den_pos (l := l) hr hw)
  unfold allocationMarginal
  apply (div_eq_iff (mul_ne_zero (mul_ne_zero (by norm_num) (ne_of_gt hw)) hn)).2
  unfold frequencyFree
  field_simp
  nlinarith

theorem allocationMarginal_strict_mono_extended {r w x y : ℝ}
    (hr : 0 < r) (hw : 0 < w) (hx : 0 < r*x+1) (hy : 0 < r*y+1) (hxy : x < y) :
    allocationMarginal r x w < allocationMarginal r y w := by
  have hd := allocationMarginal_difference (ne_of_gt hw) (ne_of_gt hx) (ne_of_gt hy)
  have hn : 0 < r^2*x*y+r*(x+y)+2+r^2*w^2 := by
    have hp := mul_pos hx hy
    nlinarith [sq_nonneg (r*w)]
  have hs : 0 < allocationMarginal r y w-allocationMarginal r x w := by
    rw [hd]
    exact div_pos (mul_pos (sub_pos.mpr hxy) hn) (by positivity)
  linarith

theorem frequencyFree_le_iff {r w l x : ℝ} (hr : 0 < r) (hw : 0 < w) (hx : 0 ≤ x) :
    frequencyFree r w l ≤ x ↔ l ≤ allocationMarginal r x w := by
  have hp : 0 < r*x+1 := by positivity
  have hfp := frequencyFree_den_pos (l := l) hr hw
  have heq := frequencyFree_marginal (l := l) hr hw
  constructor
  · intro h
    rcases h.eq_or_lt with h | h
    · rw [h] at heq
      exact le_of_eq heq.symm
    · exact le_of_lt (by simpa [heq] using allocationMarginal_strict_mono_extended hr hw hfp hp h)
  · intro h
    by_contra hn
    have hh := allocationMarginal_strict_mono_extended hr hw hp hfp (lt_of_not_ge hn)
    rw [heq] at hh
    linarith

theorem le_frequencyFree_iff {r w l x : ℝ} (hr : 0 < r) (hw : 0 < w) (hx : 0 ≤ x) :
    x ≤ frequencyFree r w l ↔ allocationMarginal r x w ≤ l := by
  have hp : 0 < r*x+1 := by positivity
  have hfp := frequencyFree_den_pos (l := l) hr hw
  have heq := frequencyFree_marginal (l := l) hr hw
  constructor
  · intro h
    rcases h.eq_or_lt with h | h
    · rw [h]; exact le_of_eq heq
    · exact le_of_lt (by simpa [heq] using allocationMarginal_strict_mono_extended hr hw hp hfp h)
  · intro h
    by_contra hn
    have hh := allocationMarginal_strict_mono_extended hr hw hfp hp (lt_of_not_ge hn)
    rw [heq] at hh
    linarith

theorem frequencyAllocation_mem (r w l : ℝ) : frequencyAllocation r w l ∈ Set.Icc 0 1 := by
  unfold frequencyAllocation
  exact ⟨le_min (by norm_num) (le_max_left _ _), min_le_left _ _⟩

theorem frequencyAllocation_continuous (r w : ℝ) : Continuous (frequencyAllocation r w) := by
  unfold frequencyAllocation frequencyFree
  exact continuous_const.min (continuous_const.max (by fun_prop))

theorem frequencyAllocation_zero_of {r w l : ℝ} (hr : 0 < r) (hw : 0 < w)
    (h : l ≤ allocationMarginal r 0 w) : frequencyAllocation r w l = 0 := by
  unfold frequencyAllocation
  rw [max_eq_left ((frequencyFree_le_iff hr hw (by norm_num)).2 h)]
  norm_num

theorem frequencyAllocation_one_of {r w l : ℝ} (hr : 0 < r) (hw : 0 < w)
    (h : allocationMarginal r 1 w ≤ l) : frequencyAllocation r w l = 1 := by
  have hh := (le_frequencyFree_iff hr hw (by norm_num)).2 h
  unfold frequencyAllocation
  rw [min_eq_left (le_trans hh (le_max_right _ _))]

/-- Exact clipped multiplier inequalities, including active bounds. -/
theorem frequencyAllocation_kkt {r w l : ℝ} (hr : 0 < r) (hw : 0 < w) :
    (0 < frequencyAllocation r w l → allocationMarginal r (frequencyAllocation r w l) w ≤ l) ∧
    (frequencyAllocation r w l < 1 → l ≤ allocationMarginal r (frequencyAllocation r w l) w) := by
  have hm := frequencyAllocation_mem r w l
  constructor
  · intro hp
    apply (le_frequencyFree_iff hr hw hm.1).1
    unfold frequencyAllocation at hp ⊢
    have hf : 0 < frequencyFree r w l := by
      have hh := lt_of_lt_of_le hp (min_le_right 1 (max 0 (frequencyFree r w l)))
      simpa using hh
    rw [max_eq_right (le_of_lt hf)]
    exact min_le_right _ _
  · intro hp
    apply (frequencyFree_le_iff hr hw hm.1).1
    unfold frequencyAllocation at hp ⊢
    have hf : max 0 (frequencyFree r w l) < 1 := by
      simpa only [min_lt_iff, lt_irrefl, false_or] using hp
    rw [min_eq_right (le_of_lt hf)]
    exact le_max_right _ _


def allocationLagrangian (r w l x : ℝ) : ℝ :=
  allocationLogGain r x w-l*allocationPhase r x w

theorem allocationLogGain_continuous {r w : ℝ} (hr : 0 < r) (hw : 0 < w) :
    Continuous (fun x => allocationLogGain r x w) := by
  unfold allocationLogGain
  apply Continuous.div_const
  apply Continuous.sub
  · exact (by fun_prop : Continuous fun x : ℝ => (r*x+2)^2+(r*w)^2).log
      (fun x => ne_of_gt (by positivity : 0 < (r*x+2)^2+(r*w)^2))
  · exact (by fun_prop : Continuous fun x : ℝ => x^2+w^2).log
      (fun x => ne_of_gt (by positivity : 0 < x^2+w^2))

theorem allocationLagrangian_continuous {r w : ℝ} (hr : 0 < r) (hw : 0 < w) (l : ℝ) :
    Continuous (allocationLagrangian r w l) :=
  (allocationLogGain_continuous hr hw).sub (continuous_const.mul allocationPhase_continuous)

theorem allocationLagrangian_hasDerivAt {r w x : ℝ} (hr : 0 < r) (hw : 0 < w)
    (hx : 0 ≤ x) (l : ℝ) :
    HasDerivAt (allocationLagrangian r w l)
      ((allocationMarginal r x w-l)*phaseDerivative r x w) x := by
  have h := (allocationLogGain_hasDerivAt hr hw x).sub
    ((allocationPhase_hasDerivAt hr hw x).const_mul l)
  unfold allocationLagrangian
  convert h using 1
  rw [allocation_marginal_identity hr hw hx]
  ring

/-- The clipped formula is the unique maximizer of the scalar Lagrangian. -/
theorem frequencyAllocation_lagrangian_strict {r w l x : ℝ}
    (hr : 0 < r) (hw : 0 < w) (hx : x ∈ Set.Icc 0 1)
    (hne : x ≠ frequencyAllocation r w l) :
    allocationLagrangian r w l x <
      allocationLagrangian r w l (frequencyAllocation r w l) := by
  let s := frequencyAllocation r w l
  have hs := frequencyAllocation_mem r w l
  have hk := frequencyAllocation_kkt hr hw (l := l)
  rcases lt_or_gt_of_ne hne with hxs | hsx
  · have hspos : 0 < s := lt_of_le_of_lt hx.1 hxs
    have hmono : StrictMonoOn (allocationLagrangian r w l) (Set.Icc 0 s) := by
      apply strictMonoOn_of_deriv_pos (convex_Icc _ _)
        (allocationLagrangian_continuous hr hw l).continuousOn
      intro y hy
      have hy' : 0 < y ∧ y < s := by simpa using hy
      rw [(allocationLagrangian_hasDerivAt hr hw (le_of_lt hy'.1) l).deriv]
      have hm : allocationMarginal r y w < allocationMarginal r s w :=
        allocationMarginal_strictMonoOn hr hw (le_of_lt hy'.1) hs.1 hy'.2
      have hl := hk.1 hspos
      exact mul_pos_of_neg_of_neg (by linarith) (phaseDerivative_neg hr hw (le_of_lt hy'.1))
    exact hmono ⟨hx.1,le_of_lt hxs⟩ ⟨hs.1,le_rfl⟩ hxs
  · have hslt : s < 1 := lt_of_lt_of_le hsx hx.2
    have hanti : StrictAntiOn (allocationLagrangian r w l) (Set.Icc s 1) := by
      apply strictAntiOn_of_deriv_neg (convex_Icc _ _)
        (allocationLagrangian_continuous hr hw l).continuousOn
      intro y hy
      have hy' : s < y ∧ y < 1 := by simpa using hy
      have hy0 : 0 ≤ y := le_trans hs.1 (le_of_lt hy'.1)
      rw [(allocationLagrangian_hasDerivAt hr hw hy0 l).deriv]
      have hm : allocationMarginal r s w < allocationMarginal r y w :=
        allocationMarginal_strictMonoOn hr hw hs.1 hy0 hy'.1
      have hl := hk.2 hslt
      exact mul_neg_of_pos_of_neg (by linarith) (phaseDerivative_neg hr hw hy0)
    exact hanti ⟨le_rfl,hs.2⟩ ⟨le_of_lt hsx,hx.2⟩ hsx

theorem frequencyAllocation_lagrangian_max {r w l x : ℝ}
    (hr : 0 < r) (hw : 0 < w) (hx : x ∈ Set.Icc 0 1) :
    allocationLagrangian r w l x ≤
      allocationLagrangian r w l (frequencyAllocation r w l) := by
  by_cases h : x = frequencyAllocation r w l
  · rw [h]
  · exact le_of_lt (frequencyAllocation_lagrangian_strict hr hw hx h)

variable {ι : Type*} [Fintype ι]

def frequencyAllocatedPhase (r : ι → ℝ) (w l : ℝ) : ℝ :=
  ∑ i, allocationPhase (r i) (frequencyAllocation (r i) w l) w

theorem frequencyAllocatedPhase_continuous (r : ι → ℝ) (w : ℝ) :
    Continuous (frequencyAllocatedPhase r w) := by
  apply continuous_finset_sum
  intro i _
  exact allocationPhase_continuous.comp (frequencyAllocation_continuous (r i) w)

/-- The scalar multiplier exists whenever the actual phase constraint is feasible. -/
theorem exists_frequency_multiplier (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {w a : ℝ} (hw : 0 < w)
    (hlo : (∑ i, allocationPhase (r i) 1 w) ≤ a)
    (hhi : a ≤ ∑ i, allocationPhase (r i) 0 w) :
    ∃ l : ℝ, frequencyAllocatedPhase r w l = a := by
  classical
  let L := -(∑ i, |allocationMarginal (r i) 0 w|)-1
  let U := (∑ i, |allocationMarginal (r i) 1 w|)+1
  have hL : ∀ i, L ≤ allocationMarginal (r i) 0 w := by
    intro i
    have hs := Finset.single_le_sum (fun j (_ : j ∈ Finset.univ) => abs_nonneg (allocationMarginal (r j) 0 w)) (Finset.mem_univ i)
    have ha := neg_abs_le (allocationMarginal (r i) 0 w)
    dsimp [L]
    linarith
  have hU : ∀ i, allocationMarginal (r i) 1 w ≤ U := by
    intro i
    have hs := Finset.single_le_sum (fun j (_ : j ∈ Finset.univ) => abs_nonneg (allocationMarginal (r j) 1 w)) (Finset.mem_univ i)
    have ha := le_abs_self (allocationMarginal (r i) 1 w)
    dsimp [U]
    linarith
  have hLU : L ≤ U := by
    have h0 : 0 ≤ ∑ i, |allocationMarginal (r i) 0 w| := Finset.sum_nonneg (fun _ _ => abs_nonneg _)
    have h1 : 0 ≤ ∑ i, |allocationMarginal (r i) 1 w| := Finset.sum_nonneg (fun _ _ => abs_nonneg _)
    dsimp [L,U]
    linarith
  have hphaseL : frequencyAllocatedPhase r w L = ∑ i, allocationPhase (r i) 0 w := by
    apply Finset.sum_congr rfl
    intro i _
    rw [frequencyAllocation_zero_of (hr i) hw (hL i)]
  have hphaseU : frequencyAllocatedPhase r w U = ∑ i, allocationPhase (r i) 1 w := by
    apply Finset.sum_congr rfl
    intro i _
    rw [frequencyAllocation_one_of (hr i) hw (hU i)]
  obtain ⟨l,_,hl⟩ := intermediate_value_Icc' hLU
    (frequencyAllocatedPhase_continuous r w).continuousOn
      (show a ∈ Set.Icc (frequencyAllocatedPhase r w U) (frequencyAllocatedPhase r w L) from
        ⟨by simpa [hphaseU] using hlo, by simpa [hphaseL] using hhi⟩)
  exact ⟨l,hl⟩


/-- Optimality at an actually attained phase, not an assumed optimization oracle. -/
theorem frequencyAllocation_log_optimal (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {w l : ℝ} (hw : 0 < w) (x : ι → ℝ) (hx : ∀ i, x i ∈ Set.Icc 0 1)
    (hphase : (∑ i, allocationPhase (r i) (x i) w) = frequencyAllocatedPhase r w l) :
    (∑ i, allocationLogGain (r i) (x i) w) ≤
      ∑ i, allocationLogGain (r i) (frequencyAllocation (r i) w l) w := by
  have hs := Finset.sum_le_sum (s := Finset.univ) (fun i _ =>
    frequencyAllocation_lagrangian_max (hr i) hw (l := l) (hx i))
  simp only [allocationLagrangian, Finset.sum_sub_distrib, ← Finset.mul_sum] at hs
  unfold frequencyAllocatedPhase at hphase
  rw [hphase] at hs
  linarith

theorem frequencyAllocation_log_optimal_strict (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {w l : ℝ} (hw : 0 < w) (x : ι → ℝ) (hx : ∀ i, x i ∈ Set.Icc 0 1)
    (hphase : (∑ i, allocationPhase (r i) (x i) w) = frequencyAllocatedPhase r w l)
    (hne : x ≠ fun i => frequencyAllocation (r i) w l) :
    (∑ i, allocationLogGain (r i) (x i) w) <
      ∑ i, allocationLogGain (r i) (frequencyAllocation (r i) w l) w := by
  classical
  obtain ⟨i,hi⟩ : ∃ i, x i ≠ frequencyAllocation (r i) w l := by
    by_contra h
    apply hne
    funext i
    by_contra hi
    exact h ⟨i,hi⟩
  have hs : (∑ i, allocationLagrangian (r i) w l (x i)) <
      ∑ i, allocationLagrangian (r i) w l (frequencyAllocation (r i) w l) := by
    apply Finset.sum_lt_sum
    · intro j _
      exact frequencyAllocation_lagrangian_max (hr j) hw (hx j)
    · exact ⟨i,Finset.mem_univ i,frequencyAllocation_lagrangian_strict (hr i) hw (hx i) hi⟩
  simp only [allocationLagrangian, Finset.sum_sub_distrib, ← Finset.mul_sum] at hs
  unfold frequencyAllocatedPhase at hphase
  rw [hphase] at hs
  linarith

/-- A feasible actual phase vector gives the endpoint inequalities required by IVT. -/
theorem allocation_phase_bounds (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {w : ℝ} (hw : 0 < w) (x : ι → ℝ) (hx : ∀ i, x i ∈ Set.Icc 0 1) :
    (∑ i, allocationPhase (r i) 1 w) ≤ (∑ i, allocationPhase (r i) (x i) w) ∧
      (∑ i, allocationPhase (r i) (x i) w) ≤ (∑ i, allocationPhase (r i) 0 w) := by
  constructor
  · exact Finset.sum_le_sum fun i _ =>
      (allocationPhase_strictAntiOn (hr i) hw).antitoneOn (hx i).1 (by norm_num) (hx i).2
  · exact Finset.sum_le_sum fun i _ =>
      (allocationPhase_strictAntiOn (hr i) hw).antitoneOn (by norm_num) (hx i).1 (hx i).1

/-- Full scalar-allocation/uniqueness conclusion for every feasible fixed frequency. -/
theorem exists_unique_frequency_allocation (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {w a : ℝ} (hw : 0 < w)
    (hfeasible : ∃ x : ι → ℝ, (∀ i, x i ∈ Set.Icc 0 1) ∧
      (∑ i, allocationPhase (r i) (x i) w) = a) :
    ∃ l : ℝ, frequencyAllocatedPhase r w l = a ∧
      (∀ i, frequencyAllocation (r i) w l ∈ Set.Icc 0 1) ∧
      ∀ x : ι → ℝ, (∀ i, x i ∈ Set.Icc 0 1) →
        (∑ i, allocationPhase (r i) (x i) w) = a →
          ((∑ i, allocationLogGain (r i) (x i) w) ≤
            (∑ i, allocationLogGain (r i) (frequencyAllocation (r i) w l) w) ∧
          (x ≠ (fun i => frequencyAllocation (r i) w l) →
            (∑ i, allocationLogGain (r i) (x i) w) <
              (∑ i, allocationLogGain (r i) (frequencyAllocation (r i) w l) w))) := by
  obtain ⟨x,hx,hphase⟩ := hfeasible
  have hb := allocation_phase_bounds r hr hw x hx
  obtain ⟨l,hl⟩ := exists_frequency_multiplier r hr hw (hphase ▸ hb.1) (hphase ▸ hb.2)
  refine ⟨l,hl,fun i => frequencyAllocation_mem _ _ _,?_⟩
  intro y hy hphasey
  have heq : (∑ i, allocationPhase (r i) (y i) w) = frequencyAllocatedPhase r w l := hphasey.trans hl.symm
  exact ⟨frequencyAllocation_log_optimal r hr hw y hy heq,
    fun hne => frequencyAllocation_log_optimal_strict r hr hw y hy heq hne⟩


/-- Actual magnitude of the complex factor r+2/(x-iw), in real coordinates. -/
def allocationGain (r x w : ℝ) : ℝ :=
  Real.sqrt (((r*x+2)^2+(r*w)^2)/(x^2+w^2))

theorem allocationGain_pos {r w : ℝ} (hr : 0 < r) (hw : 0 < w) (x : ℝ) :
    0 < allocationGain r x w := by
  unfold allocationGain
  apply Real.sqrt_pos.2
  positivity

theorem log_allocationGain {r w : ℝ} (hr : 0 < r) (hw : 0 < w) (x : ℝ) :
    Real.log (allocationGain r x w) = allocationLogGain r x w := by
  have hN : 0 < (r*x+2)^2+(r*w)^2 := by positivity
  have hD : 0 < x^2+w^2 := by positivity
  unfold allocationGain allocationLogGain
  rw [Real.log_sqrt (by positivity), Real.log_div (ne_of_gt hN) (ne_of_gt hD)]

theorem allocationGain_eq_complexNorm {r w : ℝ} (hw : 0 < w) (x : ℝ) :
    allocationGain r x w = ‖(r : ℂ)+2/((x : ℂ)-(w : ℂ)*Complex.I)‖ := by
  have hz : (x : ℂ)-(w : ℂ)*Complex.I ≠ 0 := by
    intro h
    have hi := congrArg Complex.im h
    simp at hi
    linarith
  have heq : (r : ℂ)+2/((x : ℂ)-(w : ℂ)*Complex.I) =
      (((r*x+2 : ℝ) : ℂ)-((r*w : ℝ) : ℂ)*Complex.I)/((x : ℂ)-(w : ℂ)*Complex.I) := by
    push_cast
    field_simp
    <;> ring
  rw [heq,norm_div,Complex.norm_def,Complex.norm_def]
  have hN : Complex.normSq ((((r*x+2 : ℝ) : ℂ)-((r*w : ℝ) : ℂ)*Complex.I)) =
      (r*x+2)^2+(r*w)^2 := by
    simp [Complex.normSq_apply]
    ring
  have hD : Complex.normSq ((x : ℂ)-(w : ℂ)*Complex.I) = x^2+w^2 := by
    simp [Complex.normSq_apply]
    ring
  rw [hN,hD]
  unfold allocationGain
  exact Real.sqrt_div (by positivity) _

theorem frequencyAllocation_gain_optimal (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {w l : ℝ} (hw : 0 < w) (x : ι → ℝ) (hx : ∀ i, x i ∈ Set.Icc 0 1)
    (hphase : (∑ i, allocationPhase (r i) (x i) w) = frequencyAllocatedPhase r w l) :
    (∏ i, allocationGain (r i) (x i) w) ≤
      ∏ i, allocationGain (r i) (frequencyAllocation (r i) w l) w := by
  apply (Real.log_le_log_iff (Finset.prod_pos (fun i _ => allocationGain_pos (hr i) hw _))
    (Finset.prod_pos (fun i _ => allocationGain_pos (hr i) hw _))).mp
  rw [Real.log_prod _ _ (fun i _ => ne_of_gt (allocationGain_pos (hr i) hw _)),
    Real.log_prod _ _ (fun i _ => ne_of_gt (allocationGain_pos (hr i) hw _))]
  simp_rw [log_allocationGain (hr _) hw]
  exact frequencyAllocation_log_optimal r hr hw x hx hphase

theorem frequencyAllocation_gain_optimal_strict (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {w l : ℝ} (hw : 0 < w) (x : ι → ℝ) (hx : ∀ i, x i ∈ Set.Icc 0 1)
    (hphase : (∑ i, allocationPhase (r i) (x i) w) = frequencyAllocatedPhase r w l)
    (hne : x ≠ fun i => frequencyAllocation (r i) w l) :
    (∏ i, allocationGain (r i) (x i) w) <
      ∏ i, allocationGain (r i) (frequencyAllocation (r i) w l) w := by
  apply (Real.log_lt_log_iff (Finset.prod_pos (fun i _ => allocationGain_pos (hr i) hw _))
    (Finset.prod_pos (fun i _ => allocationGain_pos (hr i) hw _))).mp
  rw [Real.log_prod _ _ (fun i _ => ne_of_gt (allocationGain_pos (hr i) hw _)),
    Real.log_prod _ _ (fun i _ => ne_of_gt (allocationGain_pos (hr i) hw _))]
  simp_rw [log_allocationGain (hr _) hw]
  exact frequencyAllocation_log_optimal_strict r hr hw x hx hphase hne

/-- The complete fixed-frequency allocation result stated using the actual
complex magnitudes.  The manuscript specializes `a` to `2 * arctan w`.
The optimizer is unique even when a whole interval of multipliers works. -/
theorem exists_unique_frequency_gain_optimizer (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {w a : ℝ} (hw : 0 < w)
    (hfeasible : ∃ x : ι → ℝ, (∀ i, x i ∈ Set.Icc 0 1) ∧
      (∑ i, allocationPhase (r i) (x i) w) = a) :
    ∃ l : ℝ, frequencyAllocatedPhase r w l = a ∧
      (∀ i, frequencyAllocation (r i) w l ∈ Set.Icc 0 1) ∧
      ∀ x : ι → ℝ, (∀ i, x i ∈ Set.Icc 0 1) →
        (∑ i, allocationPhase (r i) (x i) w) = a →
          ((∏ i, ‖(r i : ℂ)+2/((x i : ℂ)-(w : ℂ)*Complex.I)‖) ≤
            (∏ i, ‖(r i : ℂ)+2/((frequencyAllocation (r i) w l : ℂ)-(w : ℂ)*Complex.I)‖) ∧
          (x ≠ (fun i => frequencyAllocation (r i) w l) →
            (∏ i, ‖(r i : ℂ)+2/((x i : ℂ)-(w : ℂ)*Complex.I)‖) <
              (∏ i, ‖(r i : ℂ)+2/((frequencyAllocation (r i) w l : ℂ)-(w : ℂ)*Complex.I)‖))) := by
  obtain ⟨l,hl,hmem,_⟩ := exists_unique_frequency_allocation r hr hw hfeasible
  refine ⟨l,hl,hmem,?_⟩
  intro x hx hphase
  have heq : (∑ i, allocationPhase (r i) (x i) w) = frequencyAllocatedPhase r w l :=
    hphase.trans hl.symm
  constructor
  · simpa only [allocationGain_eq_complexNorm hw] using
      frequencyAllocation_gain_optimal r hr hw x hx heq
  · intro hne
    simpa only [allocationGain_eq_complexNorm hw] using
      frequencyAllocation_gain_optimal_strict r hr hw x hx heq hne

end C2.NGamma
