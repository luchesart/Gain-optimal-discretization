import C2.NGammaSinglePhase

/-! Ordering of all frequencies relative to the first phase crossing, for every
positive integer delay. This excludes later reentry below the first phase level. -/

noncomputable section
open Set
open scoped Topology BigOperators
namespace C2.NGamma.Phase

def phaseThreshold (d : ℕ) (t : ℝ) : ℝ :=
  2*(d:ℝ)-((d:ℝ)-1)*Real.pi/Real.arctan (1/t)

lemma phaseThreshold_antitoneOn {d : ℕ} (hd : 1 ≤ d) :
    AntitoneOn (phaseThreshold d) (Ioi 0) := by
  have hc : 0 ≤ ((d:ℝ)-1)*Real.pi := by
    have hd' : (1:ℝ) ≤ d := by exact_mod_cast hd
    exact mul_nonneg (by linarith) Real.pi_pos.le
  intro u hu v hv huv
  have hu' : 0 < u := hu
  have hv' : 0 < v := hv
  have hDa : 0 < Real.arctan (1/v) := arctan_pos (one_div_pos.mpr hv')
  have hDb : Real.arctan (1/v) ≤ Real.arctan (1/u) :=
    Real.arctan_strictMono.monotone (one_div_le_one_div_of_le hu' huv)
  exact sub_le_sub_left (div_le_div_of_nonneg_left hc hDa hDb) _

lemma phase_gap_identity {n : ℕ} (a x : Fin n → ℝ) (d : ℕ) {t : ℝ} (ht : 0 < t) :
    totalPhase a x d t-Real.pi = Real.arctan (1/t)*(sumRatio a x t-phaseThreshold d t) := by
  have hD : Real.arctan (1/t) ≠ 0 := (arctan_pos (one_div_pos.mpr ht)).ne'
  have hi : Real.arctan (1/t) = Real.pi/2-Real.arctan t := by
    simpa only [one_div] using Real.arctan_inv_of_pos ht
  have hsum : sumRatio a x t = (∑ j, contribution (a j) (x j) t)/Real.arctan (1/t) := by
    simp only [sumRatio, ratio, Finset.sum_div]
  rw [hsum]
  unfold totalPhase phaseThreshold
  field_simp
  rw [hi]
  ring

lemma phase_below_iff {n : ℕ} (a x : Fin n → ℝ) (d : ℕ) {t : ℝ} (ht : 0 < t) :
    totalPhase a x d t < Real.pi ↔ sumRatio a x t < phaseThreshold d t := by
  have hi := phase_gap_identity a x d ht
  have hD := arctan_pos (one_div_pos.mpr ht)
  constructor
  · intro h
    by_contra! hh
    have hp := mul_nonneg hD.le (sub_nonneg.mpr hh)
    linarith
  · intro h
    have hp := mul_neg_of_pos_of_neg hD (sub_neg.mpr h)
    linarith

lemma phase_above_iff {n : ℕ} (a x : Fin n → ℝ) (d : ℕ) {t : ℝ} (ht : 0 < t) :
    Real.pi < totalPhase a x d t ↔ phaseThreshold d t < sumRatio a x t := by
  have hi := phase_gap_identity a x d ht
  have hD := arctan_pos (one_div_pos.mpr ht)
  constructor
  · intro h
    by_contra! hh
    have hp := mul_nonpos_of_nonneg_of_nonpos hD.le (sub_nonpos.mpr hh)
    linarith
  · intro h
    have hp := mul_pos hD (sub_pos.mpr h)
    linarith

lemma phase_before_after_crossing {n d : ℕ} (hn : 0 < n) (hd : 1 ≤ d)
    {a x : Fin n → ℝ} (hx : ∀ j, 0 ≤ x j) (hx1 : ∀ j, x j ≤ 1)
    (hax : ∀ j, x j < a j) {s t : ℝ} (hs : 0 < s) (ht : 0 < t)
    (he : totalPhase a x d s = Real.pi) :
    (totalPhase a x d t < Real.pi ↔ t < s) ∧
      (Real.pi < totalPhase a x d t ↔ s < t) := by
  have hm := sumRatio_strictMonoOn hn hx hx1 hax
  have ha := phaseThreshold_antitoneOn hd
  have hR : sumRatio a x s = phaseThreshold d s :=
    (phase_eq_pi_iff_sumRatio a x d hs).mp he
  rw [phase_below_iff a x d ht, phase_above_iff a x d ht]
  constructor
  · constructor
    · intro h
      by_contra! hst
      have hmono := hm.monotoneOn hs ht hst
      have hanti := ha hs ht hst
      linarith
    · intro hts
      have hmono := hm ht hs hts
      have hanti := ha ht hs hts.le
      linarith
  · constructor
    · intro h
      by_contra! hts
      have hmono := hm.monotoneOn ht hs hts
      have hanti := ha ht hs hts
      linarith
    · intro hst
      have hmono := hm hs ht hst
      have hanti := ha hs ht hst.le
      linarith

end C2.NGamma.Phase
