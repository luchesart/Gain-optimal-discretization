import C2.CADEffectiveWitness

/-! Finite rational-list witnesses exist for every nonzero input family.
The encodings in this proof are not runtime inputs: exhaustive search runs the
finite Boolean checker, and this theorem establishes that search terminates. -/
namespace C2.CADEffective.Bivariate

private theorem getD_ofFn_fin {α : Type*} {n : ℕ} (f : Fin n → α)
    (i : Fin n) (a : α) : (List.ofFn f).getD i a = f i := by
  rw [List.getD_eq_getElem _ _ (by simpa using i.isLt), List.getElem_ofFn]

/-- Every valid mathematical factor/projection package is represented by an
accepted finite raw witness. All polynomial coefficients are rational lists. -/
theorem exists_witness_of_valid_data (F : List Poly) {n : ℕ}
    (fd : C2.CADProjection.FactorData (Fin F.length) n)
    (pd : C2.CADProjection.ProjectionData (Fin n))
    (hfd : C2.CADProjection.ValidFactorData (inputFamily F) fd)
    (hpd : C2.CADProjection.ValidProjectionData fd.factors pd) :
    ∃ w : Witness, witnessCheck F w = true := by
  classical
  choose factors hfactors using (fun j => exists_encoding (fd.factors j))
  choose left hleft using (fun i => Dense.exists_encoding (fd.left i))
  choose right hright using (fun i => Dense.exists_encoding (fd.right i))
  choose simple hsimple using (fun j => Dense.exists_encoding (pd.simple j))
  choose simpleU hsimpleU using (fun j => exists_encoding (pd.simpleU j))
  choose simpleV hsimpleV using (fun j => exists_encoding (pd.simpleV j))
  choose pair hpair using (fun i j => Dense.exists_encoding (pd.pair i j))
  choose pairU hpairU using (fun i j => exists_encoding (pd.pairU i j))
  choose pairV hpairV using (fun i j => exists_encoding (pd.pairV i j))
  let w : Witness := {
    n := n
    factors := List.ofFn factors
    left := List.ofFn left
    right := List.ofFn right
    zeroPower := List.ofFn fd.zeroPower
    onePower := List.ofFn fd.onePower
    powers := List.ofFn (fun i => List.ofFn (fd.powers i))
    simple := List.ofFn simple
    simpleU := List.ofFn simpleU
    simpleV := List.ofFn simpleV
    pair := List.ofFn (fun i => List.ofFn (pair i))
    pairU := List.ofFn (fun i => List.ofFn (pairU i))
    pairV := List.ofFn (fun i => List.ofFn (pairV i)) }
  have hfd_eq : toFactorData F w = fd := by
    simp only [toFactorData, w, getD_ofFn_fin, hfactors, hleft, hright]
  have hpd_eq : toProjectionData w = pd := by
    simp only [toProjectionData, w, getD_ofFn_fin, hsimple, hsimpleU, hsimpleV,
      hpair, hpairU, hpairV]
  refine ⟨w, (witnessCheck_iff F w).mpr ?_⟩
  rw [hfd_eq, hpd_eq]
  exact ⟨hfd, hpd⟩

/-- The exact finite witness checker accepts some candidate for every family
whose input polynomials are nonzero. No projection or factor oracle is assumed. -/
theorem exists_witnessCheck (F : List Poly)
    (hF : ∀ i, inputFamily F i ≠ 0) : ∃ w : Witness, witnessCheck F w = true := by
  obtain ⟨n,fd,pd,hfd,hpd⟩ :=
    C2.CADProjection.exists_factor_projection_data (inputFamily F) hF
  exact exists_witness_of_valid_data F fd pd hfd hpd

end C2.CADEffective.Bivariate
