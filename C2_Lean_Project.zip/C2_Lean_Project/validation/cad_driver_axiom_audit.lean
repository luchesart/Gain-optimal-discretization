import C2.CADDriverParameter
#print axioms C2.CADDriver.rootValue_gap_cover
#print axioms C2.CADDriver.rootValue_gap_no_root
#print axioms C2.CADDriver.dense_feasible_iff_gap_samples
#print axioms C2.CADDriver.markGain_correct
#print axioms C2.CADDriver.markGain_rawFeasible
#print axioms C2.CADDriver.selected_rank_unique_root
