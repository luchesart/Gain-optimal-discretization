import C2.CADFactorSquarefree

/-! Finite common separable factor bases, with fixed endpoint factors removed.
This is a classical existence theorem used to justify a finite witness search;
`normalizedFactors` is not presented as an executable factorization routine. -/
noncomputable section
open Polynomial UniqueFactorizationMonoid
open scoped BigOperators
namespace C2.CADFactor

variable {F : Type*} [Field F] [DecidableEq F] [CharZero F]
variable {ι : Type*} [Fintype ι]

def factorBasis (f : ι → F[X]) : Finset F[X] :=
  insert X (insert (X - 1) (Finset.univ.biUnion fun i => (normalizedFactors (f i)).toFinset))

def interiorBasis (f : ι → F[X]) : Finset F[X] :=
  ((factorBasis f).erase X).erase (X - 1)

def factorExponent (f : ι → F[X]) (i : ι) (q : F[X]) : ℕ :=
  (normalizedFactors (f i)).count q

theorem normalized_factor_monic {p q : F[X]} (hq : q ∈ normalizedFactors p) : q.Monic := by
  have hn := normalize_normalized_factor q hq
  have hm := Polynomial.monic_normalize (irreducible_of_normalized_factor q hq).ne_zero
  rwa [hn] at hm

theorem factorBasis_irreducible (f : ι → F[X]) {q : F[X]} (hq : q ∈ factorBasis f) :
    Irreducible q := by
  simp only [factorBasis, Finset.mem_insert, Finset.mem_biUnion, Finset.mem_univ,
    true_and, Multiset.mem_toFinset] at hq
  rcases hq with rfl | rfl | ⟨i, hi⟩
  · exact irreducible_X
  · simpa using irreducible_X_sub_C (1 : F)
  · exact irreducible_of_normalized_factor q hi

theorem factorBasis_monic (f : ι → F[X]) {q : F[X]} (hq : q ∈ factorBasis f) :
    q.Monic := by
  simp only [factorBasis, Finset.mem_insert, Finset.mem_biUnion, Finset.mem_univ,
    true_and, Multiset.mem_toFinset] at hq
  rcases hq with rfl | rfl | ⟨i, hi⟩
  · exact monic_X
  · simpa using monic_X_sub_C (1 : F)
  · exact normalized_factor_monic hi

theorem monic_irreducibles_coprime {p q : F[X]} (hp : Irreducible p)
    (hq : Irreducible q) (hpm : p.Monic) (hqm : q.Monic) (hne : p ≠ q) :
    IsCoprime p q := by
  apply hp.coprime_iff_not_dvd.mpr
  intro hd
  exact hne (eq_of_monic_of_associated hpm hqm
    (associated_of_dvd_dvd hd (hp.dvd_symm hq hd)))

theorem factorBasis_pairwise_coprime (f : ι → F[X]) {p q : F[X]}
    (hp : p ∈ factorBasis f) (hq : q ∈ factorBasis f) (hne : p ≠ q) :
    IsCoprime p q :=
  monic_irreducibles_coprime (factorBasis_irreducible f hp)
    (factorBasis_irreducible f hq) (factorBasis_monic f hp) (factorBasis_monic f hq) hne

theorem mem_interiorBasis {f : ι → F[X]} {q : F[X]} (hq : q ∈ interiorBasis f) :
    q ∈ factorBasis f ∧ q ≠ X ∧ q ≠ X - 1 := by
  simpa only [interiorBasis, Finset.mem_erase, and_assoc, and_left_comm, and_comm] using hq

theorem interiorBasis_separable (f : ι → F[X]) {q : F[X]} (hq : q ∈ interiorBasis f) :
    q.Separable :=
  (factorBasis_irreducible f (mem_interiorBasis hq).1).separable

theorem interiorBasis_nonzero (f : ι → F[X]) {q : F[X]} (hq : q ∈ interiorBasis f) :
    q ≠ 0 :=
  (factorBasis_irreducible f (mem_interiorBasis hq).1).ne_zero

theorem interiorBasis_pairwise_coprime (f : ι → F[X]) {p q : F[X]}
    (hp : p ∈ interiorBasis f) (hq : q ∈ interiorBasis f) (hne : p ≠ q) :
    IsCoprime p q :=
  factorBasis_pairwise_coprime f (mem_interiorBasis hp).1 (mem_interiorBasis hq).1 hne

theorem interiorBasis_endpoint_ne_zero (f : ι → F[X]) {q : F[X]}
    (hq : q ∈ interiorBasis f) : q.eval 0 ≠ 0 ∧ q.eval 1 ≠ 0 := by
  have hq' := mem_interiorBasis hq
  have hi := factorBasis_irreducible f hq'.1
  have hm := factorBasis_monic f hq'.1
  constructor
  · intro h
    have hd : (X - C (0 : F)) ∣ q := dvd_iff_isRoot.mpr h
    have he := eq_of_monic_of_associated (monic_X_sub_C (0 : F)) hm
      (associated_of_dvd_dvd hd ((irreducible_X_sub_C (0 : F)).dvd_symm hi hd))
    apply hq'.2.1
    simpa using he.symm
  · intro h
    have hd : (X - C (1 : F)) ∣ q := dvd_iff_isRoot.mpr h
    have he := eq_of_monic_of_associated (monic_X_sub_C (1 : F)) hm
      (associated_of_dvd_dvd hd ((irreducible_X_sub_C (1 : F)).dvd_symm hi hd))
    apply hq'.2.2
    simpa using he.symm

theorem factor_support_subset (f : ι → F[X]) (i : ι) :
    (normalizedFactors (f i)).toFinset ⊆ factorBasis f := by
  intro q hq
  apply Finset.mem_insert_of_mem
  apply Finset.mem_insert_of_mem
  exact Finset.mem_biUnion.mpr ⟨i, Finset.mem_univ i, hq⟩

theorem factorization_full_basis (f : ι → F[X]) (i : ι) :
    f i = C (f i).leadingCoeff * ∏ q ∈ factorBasis f, q ^ factorExponent f i q := by
  dsimp only [factorExponent]
  rw [← Finset.prod_multiset_count_of_subset _ _ (factor_support_subset f i)]
  exact (Polynomial.leadingCoeff_mul_prod_normalizedFactors (f i)).symm

theorem X_sub_one_ne_X : (X - 1 : F[X]) ≠ X := by
  intro h
  have hh := congrArg (fun p : F[X] => p.eval 0) h
  norm_num at hh

theorem factorization_interior_basis (f : ι → F[X]) (i : ι) :
    f i = C (f i).leadingCoeff * X ^ factorExponent f i X *
      (X - 1) ^ factorExponent f i (X - 1) *
      ∏ q ∈ interiorBasis f, q ^ factorExponent f i q := by
  have hx : (X : F[X]) ∈ factorBasis f := by simp [factorBasis]
  have hx1 : (X - 1 : F[X]) ∈ (factorBasis f).erase X := by
    simp [factorBasis, X_sub_one_ne_X]
  have he1 := Finset.mul_prod_erase (factorBasis f) (fun q => q ^ factorExponent f i q) hx
  have he2 := Finset.mul_prod_erase ((factorBasis f).erase X)
    (fun q => q ^ factorExponent f i q) hx1
  calc
    f i = C (f i).leadingCoeff * ∏ q ∈ factorBasis f, q ^ factorExponent f i q :=
      factorization_full_basis f i
    _ = _ := by
      rw [← he1, ← he2]
      dsimp only [interiorBasis]
      ring

theorem interiorBasis_active (f : ι → F[X]) {q : F[X]} (hq : q ∈ interiorBasis f) :
    ∃ i, 0 < factorExponent f i q := by
  have hq' := mem_interiorBasis hq
  have hmem := hq'.1
  simp only [factorBasis, Finset.mem_insert, Finset.mem_biUnion, Finset.mem_univ,
    true_and, Multiset.mem_toFinset] at hmem
  rcases hmem with h | h | ⟨i, hi⟩
  · exact False.elim (hq'.2.1 h)
  · exact False.elim (hq'.2.2 h)
  · exact ⟨i, Multiset.count_pos.mpr hi⟩

/-- Complete finite basis specification. Zero input polynomials are explicitly
excluded only where nonzero unit coefficients are needed. -/
theorem exists_finite_interior_factor_basis (f : ι → F[X]) (hf : ∀ i, f i ≠ 0) :
    ∃ (S : Finset F[X]) (a b : ι → ℕ) (m : ι → F[X] → ℕ) (u : ι → F),
      (∀ i, u i ≠ 0) ∧
      (∀ q ∈ S, q.Monic ∧ q.Separable ∧ q.eval 0 ≠ 0 ∧ q.eval 1 ≠ 0) ∧
      (∀ p ∈ S, ∀ q ∈ S, p ≠ q → IsCoprime p q) ∧
      (∀ q ∈ S, ∃ i, 0 < m i q) ∧
      (∀ i, f i = C (u i) * X ^ a i * (X - 1) ^ b i * ∏ q ∈ S, q ^ m i q) := by
  refine ⟨interiorBasis f, (fun i => factorExponent f i X),
    (fun i => factorExponent f i (X - 1)), factorExponent f,
    (fun i => (f i).leadingCoeff), ?_, ?_, ?_, ?_, ?_⟩
  · intro i; exact leadingCoeff_ne_zero.mpr (hf i)
  · intro q hq
    exact ⟨factorBasis_monic f (mem_interiorBasis hq).1,
      interiorBasis_separable f hq, interiorBasis_endpoint_ne_zero f hq⟩
  · intro p hp q hq hne; exact interiorBasis_pairwise_coprime f hp hq hne
  · intro q hq; exact interiorBasis_active f hq
  · exact factorization_interior_basis f

end C2.CADFactor
