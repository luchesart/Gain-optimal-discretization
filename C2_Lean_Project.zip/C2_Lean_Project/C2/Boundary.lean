import Mathlib

/-! Exact complex-algebra part of the general unit-circle boundary theorem.
Root-count constancy and finite real-root isolation are distinct obligations. -/

namespace C2

theorem feedback_zero_iff_complex_gain (H N : ℂ) (k : ℝ) (hN : N ≠ 0) :
    H + (k : ℂ) * N = 0 ↔ (k : ℂ) = -H / N := by
  constructor
  · intro h
    apply (eq_div_iff hN).mpr
    linear_combination h
  · intro h
    have hm := (eq_div_iff hN).mp h
    linear_combination hm

theorem feedback_zero_iff_real_gain (H N : ℂ) (k : ℝ) (hN : N ≠ 0) :
    H + (k : ℂ) * N = 0 ↔
      k = (-H / N).re ∧ (-H / N).im = 0 := by
  rw [feedback_zero_iff_complex_gain H N k hN, Complex.ext_iff]
  simp only [Complex.ofReal_re, Complex.ofReal_im, eq_comm (a := (0 : ℝ))]

theorem negative_quotient_re (H N : ℂ) :
    (-H / N).re = -(H * star N).re / Complex.normSq N := by
  simp [Complex.div_re, Complex.mul_re, Complex.mul_im]
  ring

theorem negative_quotient_im (H N : ℂ) :
    (-H / N).im = -(H * star N).im / Complex.normSq N := by
  simp [Complex.div_im, Complex.mul_re, Complex.mul_im]
  ring

theorem feedback_zero_iff_cross_product (H N : ℂ) (k : ℝ) (hN : N ≠ 0) :
    H + (k : ℂ) * N = 0 ↔
      k = -(H * star N).re / Complex.normSq N ∧ (H * star N).im = 0 := by
  rw [feedback_zero_iff_real_gain H N k hN, negative_quotient_re,
    negative_quotient_im]
  have hn : Complex.normSq N ≠ 0 := (Complex.normSq_pos.mpr hN).ne'
  simp only [div_eq_zero_iff, hn, or_false, neg_eq_zero]

def UnitCircleRoot (H N : ℂ → ℂ) (k : ℝ) : Prop :=
  ∃ z : ℂ, ‖z‖ = 1 ∧ H z + (k : ℂ) * N z = 0

theorem unitCircleRoot_iff_boundary (H N : ℂ → ℂ) (k : ℝ)
    (hc : ∀ z : ℂ, ‖z‖ = 1 → N z = 0 → H z ≠ 0) :
    UnitCircleRoot H N k ↔
      ∃ z : ℂ, ‖z‖ = 1 ∧ N z ≠ 0 ∧
        k = -(H z * star (N z)).re / Complex.normSq (N z) ∧
        (H z * star (N z)).im = 0 := by
  constructor
  · rintro ⟨z, hz, he⟩
    have hn : N z ≠ 0 := by
      intro hn
      have hh : H z = 0 := by simpa [hn] using he
      exact hc z hz hn hh
    exact ⟨z, hz, hn, (feedback_zero_iff_cross_product (H z) (N z) k hn).mp he⟩
  · rintro ⟨z, hz, hn, hk, hi⟩
    exact ⟨z, hz, (feedback_zero_iff_cross_product (H z) (N z) k hn).mpr ⟨hk, hi⟩⟩

end C2
