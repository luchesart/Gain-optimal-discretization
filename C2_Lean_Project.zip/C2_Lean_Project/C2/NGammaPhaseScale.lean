import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Tactic

/-! Elementary arctangent scale inequalities used by the arbitrary-order
normalized phase lemma. No assumptions about root counts or stability occur. -/

noncomputable section

namespace C2.NGamma.PhaseScale

def elasticityReciprocal (s : ℝ) : ℝ := (1 + s ^ 2) / s * Real.arctan s

theorem arctan_pos {s : ℝ} (hs : 0 < s) : 0 < Real.arctan s := by
  simpa only [Real.arctan_zero] using Real.arctan_strictMono hs

theorem arctan_lt_self {s : ℝ} (hs : 0 < s) : Real.arctan s < s := by
  simpa only [Real.tan_arctan] using
    Real.lt_tan (arctan_pos hs) (Real.arctan_lt_pi_div_two s)

theorem elasticityReciprocal_hasDerivAt {s : ℝ} (hs : 0 < s) :
    HasDerivAt elasticityReciprocal
      ((s ^ 2 * Real.arctan s + (s - Real.arctan s)) / s ^ 2) s := by
  have hn : s ≠ 0 := ne_of_gt hs
  have h := (((hasDerivAt_id s).pow 2).const_add 1).div (hasDerivAt_id s) hn
  convert h.mul (Real.hasDerivAt_arctan s) using 1 <;>
    simp only [elasticityReciprocal, id_eq] <;> field_simp <;> ring

theorem elasticityReciprocal_deriv_pos {s : ℝ} (hs : 0 < s) :
    0 < deriv elasticityReciprocal s := by
  rw [(elasticityReciprocal_hasDerivAt hs).deriv]
  exact div_pos (add_pos_of_nonneg_of_pos
    (mul_nonneg (sq_nonneg s) (le_of_lt (arctan_pos hs)))
    (sub_pos.mpr (arctan_lt_self hs))) (sq_pos_of_pos hs)

theorem elasticityReciprocal_strictMonoOn :
    StrictMonoOn elasticityReciprocal (Set.Ioi 0) := by
  apply strictMonoOn_of_deriv_pos (convex_Ioi 0)
  · intro s hs
    exact (elasticityReciprocal_hasDerivAt hs).continuousAt.continuousWithinAt
  · intro s hs
    exact elasticityReciprocal_deriv_pos (by simpa using hs)

def scaleRatio (c u : ℝ) : ℝ := Real.arctan (c * u) / Real.arctan u

theorem scaleRatio_hasDerivAt {c u : ℝ} (hc : 0 < c) (hu : 0 < u) :
    HasDerivAt (scaleRatio c)
      (c * u * (elasticityReciprocal u - elasticityReciprocal (c * u)) /
        ((1 + u ^ 2) * (1 + (c * u) ^ 2) * (Real.arctan u) ^ 2)) u := by
  have hun : u ≠ 0 := ne_of_gt hu
  have hcn : c ≠ 0 := ne_of_gt hc
  have han : Real.arctan u ≠ 0 := ne_of_gt (arctan_pos hu)
  have hp : 1 + u ^ 2 ≠ 0 := by positivity
  have hq : 1 + (c * u) ^ 2 ≠ 0 := by positivity
  have h := (((hasDerivAt_id u).const_mul c).arctan).div
    (Real.hasDerivAt_arctan u) han
  convert h using 1
  simp only [elasticityReciprocal, id_eq]
  field_simp
  <;> ring

theorem scaleRatio_strictMonoOn {c : ℝ} (hc : 0 < c) (hc1 : c < 1) :
    StrictMonoOn (scaleRatio c) (Set.Ioi 0) := by
  apply strictMonoOn_of_deriv_pos (convex_Ioi 0)
  · intro u hu
    exact (scaleRatio_hasDerivAt hc hu).continuousAt.continuousWithinAt
  · intro u hu
    have hu0 : 0 < u := by simpa using hu
    rw [(scaleRatio_hasDerivAt hc hu0).deriv]
    have hcu : 0 < c * u := mul_pos hc hu0
    have hlt : c * u < u := by nlinarith
    have hH := elasticityReciprocal_strictMonoOn hcu hu0 hlt
    apply div_pos
    · exact mul_pos (mul_pos hc hu0) (sub_pos.mpr hH)
    · have hapos := arctan_pos hu0
      positivity

theorem scaleRatio_strictAntiOn {c : ℝ} (hc : 1 < c) :
    StrictAntiOn (scaleRatio c) (Set.Ioi 0) := by
  have hc0 : 0 < c := by linarith
  apply strictAntiOn_of_deriv_neg (convex_Ioi 0)
  · intro u hu
    exact (scaleRatio_hasDerivAt hc0 hu).continuousAt.continuousWithinAt
  · intro u hu
    have hu0 : 0 < u := by simpa using hu
    rw [(scaleRatio_hasDerivAt hc0 hu0).deriv]
    have hcu : 0 < c * u := mul_pos hc0 hu0
    have hlt : u < c * u := by nlinarith
    have hH := elasticityReciprocal_strictMonoOn hu0 hcu hlt
    apply div_neg_of_neg_of_pos
    · exact mul_neg_of_pos_of_neg (mul_pos hc0 hu0) (sub_neg.mpr hH)
    · have hapos := arctan_pos hu0
      positivity

end C2.NGamma.PhaseScale
