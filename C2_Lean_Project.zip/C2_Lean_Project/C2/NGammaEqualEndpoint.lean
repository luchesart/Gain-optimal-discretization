import C2.NGammaEqual
import C2.NGammaEndpoint

/-! Exact uniform endpoint optimizer, including uniqueness and the threshold.
This specializes the proved arbitrary-order endpoint optimization theorem. -/
noncomputable section
open scoped BigOperators
open C2.NGamma
namespace C2.NGammaEqual

lemma positive_quadratic_resource_unique {r x y : ℝ} (hr : 0 < r)
    (hx : 0 < x) (hy : 0 < y) (heq : x*(2+r*x)=y*(2+r*y)) : x=y := by
  have hf : (x-y)*(r*(x+y)+2)=0 := by nlinarith
  have hp : 0 < r*(x+y)+2 := by positivity
  have hh := (mul_eq_zero.mp hf).resolve_right (ne_of_gt hp)
  linarith

lemma uniform_endpoint_parameter {n : ℕ} (hn : 0 < n) {r c : ℝ} (hr : 0 < r)
    (hbudget : allocatedResource (fun _ : Fin n => r) c = 4) :
    endpointParameter r c = endpointCoordinate (n:ℝ) r := by
  have hx : 0 < endpointParameter r c := endpointParameter_pos r c
  have hy : 0 < endpointCoordinate (n:ℝ) r := endpointCoordinate_pos (by exact_mod_cast hn)
  have hs := endpointParameter_budget (fun _ : Fin n => r) (fun _ => hr) hbudget
  have hb : (n:ℝ)/(endpointParameter r c*(2+r*endpointParameter r c))=1 := by
    simpa [endpointCost,div_eq_mul_inv] using hs
  have hd : endpointParameter r c*(2+r*endpointParameter r c) ≠ 0 := by positivity
  have hh : endpointParameter r c*(2+r*endpointParameter r c) = (n:ℝ) := by
    have h := (div_eq_iff hd).mp hb
    linarith
  apply positive_quadratic_resource_unique hr hx hy
  rw [hh,endpointCoordinate_resource (by positivity) hr.le]

lemma uniform_endpoint_product {n : ℕ} (hn : 0 < n) {r c : ℝ} (hr : 0 < r)
    (hbudget : allocatedResource (fun _ : Fin n => r) c = 4) :
    (∏ _ : Fin n, endpointAllocation r c) = endpointGain n r := by
  rw [← endpointParameter_inverse r c,uniform_endpoint_parameter hn hr hbudget,
    endpointGain_factor_identity hn]
  simp [endpointGain]

/-- Exact endpoint optimizer for equal factors, in the original x-coordinates.
It includes both r>n-2 and the threshold r=n-2. -/
theorem identical_endpoint_optimal {n : ℕ} (hn : 0 < n) {r : ℝ}
    (hr : 0 < r) (hregime : (n:ℝ)-2 ≤ r)
    (x : Fin n → ℝ) (hx : ∀ i, 0 < x i ∧ x i ≤ 1)
    (hcost : (∑ i, endpointCost r (x i)) ≤ 1) :
    (∏ i, (r+2/x i)) ≤ endpointGain n r ∧
      (x ≠ (fun _ => endpointCoordinate (n:ℝ) r) →
        (∏ i, (r+2/x i)) < endpointGain n r) := by
  have hnR : 0 < (n:ℝ) := by exact_mod_cast hn
  have hns : 1 ≤ (n:ℝ) := by exact_mod_cast hn
  have hsum : (∑ _ : Fin n, 1/(r+2)) = (n:ℝ)/(r+2) := by simp [div_eq_mul_inv]
  by_cases hstrict : (n:ℝ)-2 < r
  · letI : Nonempty (Fin n) := ⟨⟨0,hn⟩⟩
    have hbase : (∑ _ : Fin n, 1/(r+2)) < 1 := by
      rw [hsum]
      exact (div_lt_one (by positivity : 0 < r+2)).2 (by linarith)
    obtain ⟨c,hc,hbudget,_,_,hopt⟩ := exists_endpoint_optimizer
      (fun _ : Fin n => r) (fun _ => hr) hbase
    have hh := hopt x hx hcost
    have hp := uniform_endpoint_parameter hn hr hbudget
    have hg := uniform_endpoint_product hn hr hbudget
    simpa only [hp,hg] using hh
  · have heq : r=(n:ℝ)-2 := by linarith
    have hbase : (∑ _ : Fin n, 1/(r+2)) = 1 := by
      rw [hsum]
      apply (div_eq_one_iff_eq (by positivity : r+2≠0)).2
      linarith
    have hxeq := endpoint_feasible_equality_unique (fun _ : Fin n => r) x
      (fun _ => hr) hx hbase hcost
    have hstar : endpointCoordinate (n:ℝ) r = 1 :=
      (endpointCoordinate_eq_one_iff hns hr).2 heq
    have hv : (∏ i, (r+2/x i)) = endpointGain n r := by
      rw [hxeq]
      have hf := endpointGain_factor_identity hn r
      rw [hstar] at hf
      simp only [div_one] at hf
      simp [endpointGain,← hf]
    exact ⟨hv.le, fun hne => (hne (by simpa [hstar] using hxeq)).elim⟩

end C2.NGammaEqual
