import C2.CADSignPatterns
import C2.ProjectionCompletionWitness

/-! Exact gain-cell invariance for factored strict polynomial systems,
including gain-dependent nonzero units and the fixed endpoint factors. -/
noncomputable section
open Set Filter
open scoped Topology BigOperators
namespace C2.CADDelineability

/-- A continuous nonvanishing real unit has constant sign on a connected set. -/
theorem unit_positive_iff {I : Set ℝ} (hI : IsPreconnected I)
    (u : ℝ → ℝ) (hu : ContinuousOn u I) (hnz : ∀ k ∈ I, u k ≠ 0)
    {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) : 0 < u a ↔ 0 < u b := by
  have transfer : ∀ {a b : ℝ}, a ∈ I → b ∈ I → 0 < u a → 0 < u b := by
    intro a b ha hb hpos
    by_contra h
    obtain ⟨x, hx, hz⟩ := hI.intermediate_value hb ha hu
      (show (0 : ℝ) ∈ Icc (u b) (u a) from ⟨le_of_not_gt h, hpos.le⟩)
    exact hnz x hx hz
  exact ⟨transfer ha hb, transfer hb ha⟩

/-- Replacing a gain-dependent nonzero unit by its value at any other gain
of the same connected cell preserves every product sign. -/
theorem unit_product_positive_iff {I : Set ℝ} (hI : IsPreconnected I)
    (u : ℝ → ℝ) (hu : ContinuousOn u I) (hnz : ∀ k ∈ I, u k ≠ 0)
    {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) (v : ℝ) :
    0 < u a * v ↔ 0 < u b * v := by
  have hp := unit_positive_iff hI u hu hnz ha hb
  have hn : u a < 0 ↔ u b < 0 := by
    have hpn := unit_positive_iff hI (fun k => -u k) hu.neg
      (fun k hk => neg_ne_zero.mpr (hnz k hk)) ha hb
    simpa using hpn
  simp only [mul_pos_iff, hp, hn]

/-- Gain-dependent units are handled by their proved sign constancy, not by
assuming they are constant rational numbers. -/
theorem variable_unit_products_constant {ι τ : Type*} [Fintype ι]
    (F : ι → ℝ × ℝ → ℝ) (hcont : ∀ i, Continuous (F i))
    (u : τ → ℝ → ℝ) (e : τ → ι → ℕ) (hused : ∀ i, ∃ j, e j i ≠ 0)
    (I : Set ℝ) (hI : IsPreconnected I) (hreg : ∀ k ∈ I, Regular F k)
    (hu : ∀ j, ContinuousOn (u j) I) (hunz : ∀ j k, k ∈ I → u j k ≠ 0)
    {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) :
    a ∈ patternGains (fun j p => u j p.1 * ∏ i, (F i p) ^ e j i) ↔
    b ∈ patternGains (fun j p => u j p.1 * ∏ i, (F i p) ^ e j i) := by
  have hchange : ∀ k ∈ I,
      k ∈ patternGains (fun j p => u j p.1 * ∏ i, (F i p) ^ e j i) ↔
      k ∈ patternGains (fun j p => u j a * ∏ i, (F i p) ^ e j i) := by
    intro k hk
    constructor
    · rintro ⟨x, hx, hpos⟩
      exact ⟨x, hx, fun j => (unit_product_positive_iff hI (u j) (hu j)
        (hunz j) hk ha _).mp (hpos j)⟩
    · rintro ⟨x, hx, hpos⟩
      exact ⟨x, hx, fun j => (unit_product_positive_iff hI (u j) (hu j)
        (hunz j) hk ha _).mpr (hpos j)⟩
  rw [hchange a ha, hchange b hb]
  exact products_constant_on_preconnected F hcont (fun j => u j a) e hused
    I hI hreg ha hb

/-- At a strictly interior parameter, fixed endpoint powers have known signs. -/
theorem endpoint_product_sign_iff (x c p : ℝ) (a b : ℕ)
    (hx0 : 0 < x) (hx1 : x < 1) :
    (0 < c * x ^ a * (x - 1) ^ b * p) ↔
    (0 < (c * (-1 : ℝ) ^ b) * p) := by
  have hpos : 0 < x ^ a * (1 - x) ^ b :=
    mul_pos (pow_pos hx0 _) (pow_pos (sub_pos.mpr hx1) _)
  have hidentity : c * x ^ a * (x - 1) ^ b * p =
      ((c * (-1 : ℝ) ^ b) * p) * (x ^ a * (1 - x) ^ b) := by
    have hx : x - 1 = (-1 : ℝ) * (1 - x) := by ring
    rw [hx, mul_pow]
    ring
  rw [hidentity]
  exact mul_pos_iff_of_pos_right hpos

/-- Removing fixed endpoint factors does not alter the gain projection:
feasible boundary parameters can first be moved to the interior by continuity. -/
theorem endpoint_products_gain_iff {ι τ : Type*} [Fintype ι] [Finite τ]
    (F : ι → ℝ × ℝ → ℝ) (hcont : ∀ i, Continuous (F i))
    (u : τ → ℝ → ℝ) (e : τ → ι → ℕ) (r s : τ → ℕ) (k : ℝ) :
    k ∈ patternGains (fun j p =>
      u j p.1 * p.2 ^ r j * (p.2 - 1) ^ s j * ∏ i, (F i p) ^ e j i) ↔
    k ∈ patternGains (fun j p =>
      (u j p.1 * (-1 : ℝ) ^ s j) * ∏ i, (F i p) ^ e j i) := by
  have hf : ∀ j, Continuous (fun x : ℝ =>
      u j k * x ^ r j * (x - 1) ^ s j * ∏ i, (F i (k, x)) ^ e j i) := by
    intro j
    exact ((continuous_const.mul (continuous_id.pow _)).mul
      ((continuous_id.sub continuous_const).pow _)).mul
        (continuous_finset_prod _ (fun i _ =>
          ((hcont i).comp (continuous_const.prodMk continuous_id)).pow _))
  have hg : ∀ j, Continuous (fun x : ℝ =>
      (u j k * (-1 : ℝ) ^ s j) * ∏ i, (F i (k, x)) ^ e j i) := by
    intro j
    exact continuous_const.mul (continuous_finset_prod _ (fun i _ =>
      ((hcont i).comp (continuous_const.prodMk continuous_id)).pow _))
  constructor
  · rintro ⟨x, hx, hpos⟩
    obtain ⟨q, hq0, hq1, hq⟩ := C2.GainProjection.exists_rational_interior_witness
      (fun x j => u j k * x ^ r j * (x - 1) ^ s j * ∏ i, (F i (k, x)) ^ e j i)
      hf hx hpos
    exact ⟨q, ⟨hq0.le, hq1.le⟩, fun j =>
      (endpoint_product_sign_iff q (u j k) _ (r j) (s j) hq0 hq1).mp (hq j)⟩
  · rintro ⟨x, hx, hpos⟩
    obtain ⟨q, hq0, hq1, hq⟩ := C2.GainProjection.exists_rational_interior_witness
      (fun x j => (u j k * (-1 : ℝ) ^ s j) * ∏ i, (F i (k, x)) ^ e j i)
      hg hx hpos
    exact ⟨q, ⟨hq0.le, hq1.le⟩, fun j =>
      (endpoint_product_sign_iff q (u j k) _ (r j) (s j) hq0 hq1).mpr (hq j)⟩

/-- Complete analytic cell-marking theorem for a factored polynomial system,
with gain-dependent units and arbitrary fixed endpoint multiplicities. -/
theorem endpoint_products_constant {ι τ : Type*} [Fintype ι] [Finite τ]
    (F : ι → ℝ × ℝ → ℝ) (hcont : ∀ i, Continuous (F i))
    (u : τ → ℝ → ℝ) (e : τ → ι → ℕ) (r s : τ → ℕ)
    (hused : ∀ i, ∃ j, e j i ≠ 0)
    (I : Set ℝ) (hI : IsPreconnected I) (hreg : ∀ k ∈ I, Regular F k)
    (hu : ∀ j, ContinuousOn (u j) I) (hunz : ∀ j k, k ∈ I → u j k ≠ 0)
    {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) :
    a ∈ patternGains (fun j p =>
      u j p.1 * p.2 ^ r j * (p.2 - 1) ^ s j * ∏ i, (F i p) ^ e j i) ↔
    b ∈ patternGains (fun j p =>
      u j p.1 * p.2 ^ r j * (p.2 - 1) ^ s j * ∏ i, (F i p) ^ e j i) := by
  rw [endpoint_products_gain_iff F hcont u e r s a,
    endpoint_products_gain_iff F hcont u e r s b]
  apply variable_unit_products_constant F hcont (fun j k => u j k * (-1 : ℝ) ^ s j)
    e hused I hI hreg
  · intro j
    exact (hu j).mul continuousOn_const
  · intro j k hk
    exact mul_ne_zero (hunz j k hk) (pow_ne_zero _ (by norm_num))
  · exact ha
  · exact hb

end C2.CADDelineability
