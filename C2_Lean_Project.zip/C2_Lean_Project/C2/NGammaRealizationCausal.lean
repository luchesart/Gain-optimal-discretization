import C2.NGammaRealizationPolynomial

/-! The uncancelled polynomials of the implicit and causal realizations agree
up to det E. Polynomial identities include the eigenvalues, where the
resolvent formulas themselves are undefined. -/
noncomputable section
namespace C2.NGamma.Realization
open Matrix Polynomial
variable {ι : Type*} [Fintype ι] [DecidableEq ι]
variable {𝕜 : Type*} [Field 𝕜]

lemma charmatrix_eval (A : Matrix ι ι 𝕜) (z : 𝕜) :
    A.charmatrix.map (Polynomial.eval z) = z • 1 - A := by
  ext i j
  by_cases hij : i = j
  · subst j
    simp [Matrix.charmatrix_apply_eq, Matrix.map_apply]
  · simp [Matrix.charmatrix_apply_ne _ _ _ hij, Matrix.map_apply, hij]

lemma charpoly_eval (A : Matrix ι ι 𝕜) (z : 𝕜) :
    A.charpoly.eval z = (z • 1 - A).det := by
  exact ((Polynomial.evalRingHom z).map_det A.charmatrix).trans
    (congrArg Matrix.det (charmatrix_eval A z))

def causalNumerator (A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D : 𝕜) : 𝕜[X] :=
  Polynomial.C D * A.charpoly +
    dotProduct (fun i => Polynomial.C (C i))
      (A.charmatrix.adjugate *ᵥ (fun i => Polynomial.C (B i)))

lemma causalNumerator_eval (A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D z : 𝕜) :
    (causalNumerator A B C D).eval z =
      D*(z • 1-A).det + dotProduct C ((z • 1-A).adjugate *ᵥ B) := by
  have ha := (Polynomial.evalRingHom z).map_adjugate A.charmatrix
  change (A.charmatrix.adjugate.map (Polynomial.eval z)) =
    (A.charmatrix.map (Polynomial.eval z)).adjugate at ha
  rw [charmatrix_eval] at ha
  unfold causalNumerator
  simp only [Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_C, charpoly_eval]
  congr 1
  simp only [dotProduct, Matrix.mulVec, Polynomial.eval_finset_sum, Polynomial.eval_mul,
    Polynomial.eval_C]
  apply Finset.sum_congr rfl
  intro i _
  congr 1
  apply Finset.sum_congr rfl
  intro j _
  exact congrArg (fun a => a * B j) (congrFun (congrFun ha i) j)

lemma causalNumerator_quotient (A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D z : 𝕜)
    (hH : (z • (1 : Matrix ι ι 𝕜)-A).det ≠ 0) :
    D + dotProduct C ((z • 1-A)⁻¹ *ᵥ B) =
      (causalNumerator A B C D).eval z / A.charpoly.eval z := by
  rw [causalNumerator_eval, charpoly_eval, Matrix.inv_def, Ring.inverse_eq_inv,
    Matrix.smul_mulVec_assoc, dotProduct_smul]
  simp only [smul_eq_mul]
  field_simp

variable [Infinite 𝕜]

/-- Equality as uncancelled polynomials, including singular transform points. -/
theorem denominator_eq_charpoly (T : 𝕜) (Γ A : Matrix ι ι 𝕜)
    (hE : (E T Γ A).det ≠ 0) :
    denominator T Γ A = Polynomial.C (E T Γ A).det * (Ad T Γ A).charpoly := by
  apply Polynomial.funext
  intro z
  rw [denominator_eval, Polynomial.eval_mul, Polynomial.eval_C, charpoly_eval,
    determinant_factor T z Γ A hE]

/-- The numerator retains the same common det E factor as the denominator;
this is a polynomial identity and performs no pole-zero cancellation. -/
theorem numerator_eq_causal (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D : 𝕜)
    (hE : (E T Γ A).det ≠ 0) :
    numerator T Γ A B C D = Polynomial.C (E T Γ A).det *
      causalNumerator (Ad T Γ A) (Bd T Γ A B) C (D+dotProduct C (B0 T Γ A B)) := by
  have hp : (Ad T Γ A).charpoly * (numerator T Γ A B C D -
      Polynomial.C (E T Γ A).det *
        causalNumerator (Ad T Γ A) (Bd T Γ A B) C (D+dotProduct C (B0 T Γ A B))) = 0 := by
    apply Polynomial.funext
    intro z
    simp only [Polynomial.eval_mul, Polynomial.eval_sub, Polynomial.eval_C, Polynomial.eval_zero]
    by_cases hH : (z • (1 : Matrix ι ι 𝕜) - Ad T Γ A).det = 0
    · rw [charpoly_eval, hH, zero_mul]
    · have hm : (M T Γ A z).det ≠ 0 := by
        rw [determinant_factor T z Γ A hE]
        exact mul_ne_zero hE hH
      have ht := causal_transfer T z Γ A B C D hE hH
      rw [causalNumerator_quotient _ _ _ _ _ hH, transfer_quotient _ _ _ _ _ _ _ hm,
        denominator_eval, determinant_factor T z Γ A hE, charpoly_eval] at ht
      have hn : (numerator T Γ A B C D).eval z = (E T Γ A).det *
          (causalNumerator (Ad T Γ A) (Bd T Γ A B) C (D+dotProduct C (B0 T Γ A B))).eval z := by
        field_simp [hH, hE] at ht
        apply mul_right_cancel₀ hH
        calc
          (numerator T Γ A B C D).eval z * (z • 1 - Ad T Γ A).det =
              (causalNumerator (Ad T Γ A) (Bd T Γ A B) C (D+dotProduct C (B0 T Γ A B))).eval z *
                ((E T Γ A).det * (z • 1 - Ad T Γ A).det) := ht.symm
          _ = _ := by ring
      rw [hn, sub_self, mul_zero]
  have hn := (mul_eq_zero.mp hp).resolve_left (Matrix.charpoly_monic _).ne_zero
  exact sub_eq_zero.mp hn

end C2.NGamma.Realization
