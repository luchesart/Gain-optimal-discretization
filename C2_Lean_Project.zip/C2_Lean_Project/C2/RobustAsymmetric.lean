import C2.Robustness

/-!
# Exact asymmetric robustness and optimal nominal center

The stability predicate is the existing complex-root Schur predicate.
The parameter box is closed and contained in [0,1]; its width may be any
number from 0 through 1. Gain uncertainty is constant, not switching.
-/

noncomputable section

namespace C2.Robustness

def IntervalStable (l u al au : ℝ) : Prop :=
  ∀ γ ∈ Set.Icc l u, ∀ a ∈ Set.Icc al au,
    C2.FirstOrder.Stable 0 γ a

/-- Two upper-gain endpoint inequalities characterize the entire rectangle. -/
theorem exact_interval_rectangle {l u al au : ℝ}
    (hl : 0 ≤ l) (hlu : l ≤ u) (hu : u ≤ 1)
    (hal : 0 < al) (ha : al ≤ au) :
    IntervalStable l u al au ↔ au * (1 - l) < 1 ∧ au * (u - 1 / 2) < 1 := by
  have hau : 0 < au := hal.trans_le ha
  constructor
  · intro h
    have hL := (C2.FirstOrder.stable_iff_jury (r := 0) (by norm_num) hl).mp
      (h l ⟨le_rfl, hlu⟩ au ⟨ha, le_rfl⟩)
    have hU := (C2.FirstOrder.stable_iff_jury (r := 0) (by norm_num)
      (hl.trans hlu)).mp (h u ⟨hlu, le_rfl⟩ au ⟨ha, le_rfl⟩)
    unfold C2.FirstOrder.Jury at hL hU
    constructor <;> nlinarith [hL.2.2, hU.2.1]
  · rintro ⟨hL, hU⟩ γ hγ a ha'
    have ha0 : 0 < a := hal.trans_le ha'.1
    apply (C2.FirstOrder.stable_iff_jury (r := 0) (by norm_num)
      (hl.trans hγ.1)).mpr
    have hsecond : a * (1 - γ) < 1 := by
      have h₁ := mul_le_mul_of_nonneg_right ha'.2
        (show 0 ≤ 1 - γ by linarith [hγ.2])
      have h₂ := mul_le_mul_of_nonneg_left
        (show 1 - γ ≤ 1 - l by linarith [hγ.1]) hau.le
      exact lt_of_le_of_lt (h₁.trans h₂) hL
    have hfirst : a * (γ - 1 / 2) < 1 := by
      by_cases hc : γ ≤ 1 / 2
      · have hm := mul_nonpos_of_nonneg_of_nonpos ha0.le
          (show γ - 1 / 2 ≤ 0 by linarith)
        linarith
      · have h₁ := mul_le_mul_of_nonneg_right ha'.2
          (show 0 ≤ γ - 1 / 2 by linarith)
        have h₂ := mul_le_mul_of_nonneg_left
          (show γ - 1 / 2 ≤ u - 1 / 2 by linarith [hγ.2]) hau.le
        exact lt_of_le_of_lt (h₁.trans h₂) hU
    unfold C2.FirstOrder.Jury
    exact ⟨ha0, by nlinarith, by nlinarith⟩

def AsymmetricBoxStable (c dm dp a₀ ρ : ℝ) : Prop :=
  IntervalStable (c - dm) (c + dp) (a₀ * (1 - ρ)) (a₀ * (1 + ρ))

def budgetDenominator (c dm dp : ℝ) : ℝ :=
  max (1 - c + dm) (c + dp - 1 / 2)

def nominalCap (c dm dp ρ : ℝ) : ℝ :=
  1 / ((1 + ρ) * budgetDenominator c dm dp)

def optimalCenter (dm dp : ℝ) : ℝ :=
  min (3 / 4 + (dm - dp) / 2) (1 - dp)

def optimalDenominator (dm dp : ℝ) : ℝ :=
  max ((1 + 2 * (dm + dp)) / 4) (dm + dp)

theorem budgetDenominator_pos {c dm dp : ℝ} (hm : 0 ≤ dm) (hp : 0 ≤ dp) :
    0 < budgetDenominator c dm dp := by
  have h₁ := le_max_left (1 - c + dm) (c + dp - 1 / 2)
  have h₂ := le_max_right (1 - c + dm) (c + dp - 1 / 2)
  unfold budgetDenominator
  linarith

theorem mul_max_lt_one_iff {A x y : ℝ} (hA : 0 ≤ A) :
    A * max x y < 1 ↔ A * x < 1 ∧ A * y < 1 := by
  rcases le_total x y with h | h
  · rw [max_eq_right h]
    exact ⟨fun hy => ⟨lt_of_le_of_lt (mul_le_mul_of_nonneg_left h hA) hy, hy⟩,
      fun hxy => hxy.2⟩
  · rw [max_eq_left h]
    exact ⟨fun hx => ⟨hx, lt_of_le_of_lt (mul_le_mul_of_nonneg_left h hA) hx⟩,
      fun hxy => hxy.1⟩

/-- Exact budget for any asymmetric box contained in the physical parameter interval. -/
theorem exact_asymmetric_budget {c dm dp a₀ ρ : ℝ}
    (hm : 0 ≤ dm) (hp : 0 ≤ dp) (hc : dm ≤ c) (hcu : c ≤ 1 - dp)
    (ha : 0 < a₀) (hρ : 0 ≤ ρ) (hρu : ρ < 1) :
    AsymmetricBoxStable c dm dp a₀ ρ ↔ a₀ < nominalCap c dm dp ρ := by
  have hgain : 0 < 1 + ρ := by linarith
  have hA : 0 < a₀ * (1 + ρ) := mul_pos ha hgain
  have hden := budgetDenominator_pos (c := c) hm hp
  have hrect := exact_interval_rectangle
    (l := c - dm) (u := c + dp) (al := a₀ * (1 - ρ)) (au := a₀ * (1 + ρ))
    (by linarith) (by linarith) (by linarith)
    (mul_pos ha (by linarith))
    (by nlinarith [mul_nonneg ha.le hρ])
  rw [AsymmetricBoxStable, hrect]
  unfold nominalCap
  rw [lt_div_iff₀ (mul_pos hgain hden)]
  rw [← mul_assoc]
  rw [show 1 - (c - dm) = 1 - c + dm by ring]
  exact (mul_max_lt_one_iff hA.le).symm

/-- At a prescribed nominal gain, the complete set of feasible centers is
the intersection of the physical closed interval with these strict bounds. -/
theorem exact_center_interval {c dm dp a₀ ρ : ℝ}
    (hm : 0 ≤ dm) (hp : 0 ≤ dp) (hc : dm ≤ c) (hcu : c ≤ 1 - dp)
    (ha : 0 < a₀) (hρ : 0 ≤ ρ) (hρu : ρ < 1) :
    AsymmetricBoxStable c dm dp a₀ ρ ↔
      1 + dm - 1 / (a₀ * (1 + ρ)) < c ∧
        c < 1 / 2 - dp + 1 / (a₀ * (1 + ρ)) := by
  have hA : 0 < a₀ * (1 + ρ) := mul_pos ha (by linarith)
  have hrect := exact_interval_rectangle
    (l := c - dm) (u := c + dp) (al := a₀ * (1 - ρ)) (au := a₀ * (1 + ρ))
    (by linarith) (by linarith) (by linarith)
    (mul_pos ha (by linarith)) (by nlinarith [mul_nonneg ha.le hρ])
  rw [AsymmetricBoxStable, hrect]
  have hleft : a₀ * (1 + ρ) * (1 - (c - dm)) < 1 ↔
      1 + dm - 1 / (a₀ * (1 + ρ)) < c := by
    rw [mul_comm (a₀ * (1 + ρ)), ← lt_div_iff₀ hA]
    constructor <;> intro h <;> linarith
  have hright : a₀ * (1 + ρ) * (c + dp - 1 / 2) < 1 ↔
      c < 1 / 2 - dp + 1 / (a₀ * (1 + ρ)) := by
    rw [mul_comm (a₀ * (1 + ρ)), ← lt_div_iff₀ hA]
    constructor <;> intro h <;> linarith
  exact and_congr hleft hright

theorem optimalCenter_admissible {dm dp : ℝ}
    (hw : dm + dp ≤ 1) :
    dm ≤ optimalCenter dm dp ∧ optimalCenter dm dp ≤ 1 - dp := by
  unfold optimalCenter
  exact ⟨le_min (by linarith) (by linarith), min_le_right _ _⟩

theorem optimalCenter_small {dm dp : ℝ} (hw : dm + dp ≤ 1 / 2) :
    optimalCenter dm dp = 3 / 4 + (dm - dp) / 2 := by
  exact min_eq_left (by linarith)

theorem optimalCenter_large {dm dp : ℝ} (hw : 1 / 2 ≤ dm + dp) :
    optimalCenter dm dp = 1 - dp := by
  exact min_eq_right (by linarith)

theorem optimal_interval_small {dm dp : ℝ} (hw : dm + dp ≤ 1 / 2) :
    optimalCenter dm dp - dm = 3 / 4 - (dm + dp) / 2 ∧
      optimalCenter dm dp + dp = 3 / 4 + (dm + dp) / 2 := by
  rw [optimalCenter_small hw]
  constructor <;> ring

theorem optimal_interval_large {dm dp : ℝ} (hw : 1 / 2 ≤ dm + dp) :
    optimalCenter dm dp - dm = 1 - (dm + dp) ∧
      optimalCenter dm dp + dp = 1 := by
  rw [optimalCenter_large hw]
  constructor <;> ring

theorem optimalDenominator_small {dm dp : ℝ} (hw : dm + dp ≤ 1 / 2) :
    optimalDenominator dm dp = (1 + 2 * (dm + dp)) / 4 := by
  exact max_eq_left (by linarith)

theorem optimalDenominator_large {dm dp : ℝ} (hw : 1 / 2 ≤ dm + dp) :
    optimalDenominator dm dp = dm + dp := by
  exact max_eq_right (by linarith)

theorem budgetDenominator_at_optimalCenter (dm dp : ℝ) :
    budgetDenominator (optimalCenter dm dp) dm dp = optimalDenominator dm dp := by
  by_cases hw : dm + dp ≤ 1 / 2
  · rw [optimalCenter_small hw, optimalDenominator_small hw]
    unfold budgetDenominator
    have h₁ : 1 - (3 / 4 + (dm - dp) / 2) + dm = (1 + 2 * (dm + dp)) / 4 := by ring
    have h₂ : (3 / 4 + (dm - dp) / 2) + dp - 1 / 2 = (1 + 2 * (dm + dp)) / 4 := by ring
    rw [h₁, h₂, max_self]
  · have hw' : 1 / 2 ≤ dm + dp := le_of_not_ge hw
    rw [optimalCenter_large hw', optimalDenominator_large hw']
    unfold budgetDenominator
    have h₁ : 1 - (1 - dp) + dm = dm + dp := by ring
    have h₂ : (1 - dp) + dp - 1 / 2 = (1 : ℝ) / 2 := by ring
    rw [h₁, h₂, max_eq_left hw']

theorem budgetDenominator_lower_bound {c dm dp : ℝ} (hcu : c ≤ 1 - dp) :
    optimalDenominator dm dp ≤ budgetDenominator c dm dp := by
  have h₁ := le_max_left (1 - c + dm) (c + dp - 1 / 2)
  have h₂ := le_max_right (1 - c + dm) (c + dp - 1 / 2)
  unfold optimalDenominator budgetDenominator
  apply max_le <;> linarith

/-- The minimax denominator has a unique minimizer, including widths 0, 1/2 and 1. -/
theorem budgetDenominator_eq_iff {c dm dp : ℝ} (hcu : c ≤ 1 - dp) :
    budgetDenominator c dm dp = optimalDenominator dm dp ↔ c = optimalCenter dm dp := by
  constructor
  · intro h
    have h₁ : 1 - c + dm ≤ optimalDenominator dm dp := by
      rw [← h]; exact le_max_left _ _
    have h₂ : c + dp - 1 / 2 ≤ optimalDenominator dm dp := by
      rw [← h]; exact le_max_right _ _
    by_cases hw : dm + dp ≤ 1 / 2
    · rw [optimalDenominator_small hw] at h₁ h₂
      rw [optimalCenter_small hw]
      linarith
    · have hw' : 1 / 2 ≤ dm + dp := le_of_not_ge hw
      rw [optimalDenominator_large hw'] at h₁
      rw [optimalCenter_large hw']
      linarith
  · rintro rfl
    exact budgetDenominator_at_optimalCenter dm dp

theorem nominalCap_pos {c dm dp ρ : ℝ}
    (hm : 0 ≤ dm) (hp : 0 ≤ dp) (hρ : 0 ≤ ρ) :
    0 < nominalCap c dm dp ρ :=
  div_pos zero_lt_one (mul_pos (by linarith) (budgetDenominator_pos hm hp))

/-- The cap is the actual supremum of positive nominal gains satisfying
complex-root stability for the full uncertainty box. -/
theorem nominal_cap_isLUB {c dm dp ρ : ℝ}
    (hm : 0 ≤ dm) (hp : 0 ≤ dp) (hc : dm ≤ c) (hcu : c ≤ 1 - dp)
    (hρ : 0 ≤ ρ) (hρu : ρ < 1) :
    IsLUB {a₀ : ℝ | 0 < a₀ ∧ AsymmetricBoxStable c dm dp a₀ ρ}
      (nominalCap c dm dp ρ) := by
  have hset : {a₀ : ℝ | 0 < a₀ ∧ AsymmetricBoxStable c dm dp a₀ ρ} =
      Set.Ioo 0 (nominalCap c dm dp ρ) := by
    ext a₀
    constructor
    · rintro ⟨ha, hs⟩
      exact ⟨ha, (exact_asymmetric_budget hm hp hc hcu ha hρ hρu).mp hs⟩
    · rintro ⟨ha, hb⟩
      exact ⟨ha, (exact_asymmetric_budget hm hp hc hcu ha hρ hρu).mpr hb⟩
  rw [hset]
  exact isLUB_Ioo (nominalCap_pos hm hp hρ)

/-- The unique center maximizing the admissible nominal-gain supremum. -/
theorem nominalCap_optimal_unique {c dm dp ρ : ℝ}
    (hm : 0 ≤ dm) (hp : 0 ≤ dp) (hcu : c ≤ 1 - dp) (hρ : 0 ≤ ρ) :
    nominalCap c dm dp ρ ≤ nominalCap (optimalCenter dm dp) dm dp ρ ∧
      (nominalCap c dm dp ρ = nominalCap (optimalCenter dm dp) dm dp ρ ↔
        c = optimalCenter dm dp) := by
  have hρp : 0 < 1 + ρ := by linarith
  have hd := budgetDenominator_pos (c := c) hm hp
  have ho := budgetDenominator_pos (c := optimalCenter dm dp) hm hp
  have hmin := budgetDenominator_lower_bound (dm := dm) hcu
  rw [← budgetDenominator_at_optimalCenter dm dp] at hmin
  constructor
  · unfold nominalCap
    apply (div_le_div_iff₀ (mul_pos hρp hd) (mul_pos hρp ho)).mpr
    simpa using mul_le_mul_of_nonneg_left hmin hρp.le
  · constructor
    · intro he
      unfold nominalCap at he
      have hc := (div_eq_div_iff (mul_pos hρp hd).ne' (mul_pos hρp ho).ne').mp he
      have hz : (1 + ρ) * (budgetDenominator c dm dp -
          budgetDenominator (optimalCenter dm dp) dm dp) = 0 := by nlinarith [hc]
      have heq := sub_eq_zero.mp ((mul_eq_zero.mp hz).resolve_left hρp.ne')
      rw [budgetDenominator_at_optimalCenter] at heq
      exact (budgetDenominator_eq_iff hcu).mp heq
    · rintro rfl
      rfl

theorem robust_maximizing_center_iff {c dm dp ρ : ℝ}
    (hm : 0 ≤ dm) (hp : 0 ≤ dp) (hc : dm ≤ c) (hcu : c ≤ 1 - dp)
    (hρ : 0 ≤ ρ) (hρu : ρ < 1) :
    IsLUB {a₀ : ℝ | 0 < a₀ ∧ AsymmetricBoxStable c dm dp a₀ ρ}
      (nominalCap (optimalCenter dm dp) dm dp ρ) ↔ c = optimalCenter dm dp := by
  constructor
  · intro hs
    exact (nominalCap_optimal_unique hm hp hcu hρ).2.mp
      ((nominal_cap_isLUB hm hp hc hcu hρ hρu).unique hs)
  · rintro rfl
    exact nominal_cap_isLUB hm hp hc hcu hρ hρu

theorem optimal_nominalCap_small {dm dp ρ : ℝ}
    (hm : 0 ≤ dm) (hp : 0 ≤ dp) (hρ : 0 ≤ ρ) (hw : dm + dp ≤ 1 / 2) :
    nominalCap (optimalCenter dm dp) dm dp ρ =
      4 / ((1 + ρ) * (1 + 2 * (dm + dp))) := by
  unfold nominalCap
  rw [budgetDenominator_at_optimalCenter, optimalDenominator_small hw]
  have h₁ : 1 + ρ ≠ 0 := by linarith
  have h₂ : 1 + 2 * (dm + dp) ≠ 0 := by linarith
  field_simp [h₁, h₂]

theorem optimal_nominalCap_large {dm dp ρ : ℝ} (hw : 1 / 2 ≤ dm + dp) :
    nominalCap (optimalCenter dm dp) dm dp ρ = 1 / ((1 + ρ) * (dm + dp)) := by
  unfold nominalCap
  rw [budgetDenominator_at_optimalCenter, optimalDenominator_large hw]

/-- Exact design feasibility: the computed optimal center realizes every
strictly subcritical gain, and no other admissible center improves the cap. -/
theorem exists_robust_center_iff {dm dp a₀ ρ : ℝ}
    (hm : 0 ≤ dm) (hp : 0 ≤ dp) (hw : dm + dp ≤ 1)
    (ha : 0 < a₀) (hρ : 0 ≤ ρ) (hρu : ρ < 1) :
    (∃ c, dm ≤ c ∧ c ≤ 1 - dp ∧ AsymmetricBoxStable c dm dp a₀ ρ) ↔
      a₀ < nominalCap (optimalCenter dm dp) dm dp ρ := by
  constructor
  · rintro ⟨c, hc, hcu, hs⟩
    exact lt_of_lt_of_le ((exact_asymmetric_budget hm hp hc hcu ha hρ hρu).mp hs)
      (nominalCap_optimal_unique hm hp hcu hρ).1
  · intro ha'
    obtain ⟨hc, hcu⟩ := optimalCenter_admissible hw
    exact ⟨optimalCenter dm dp, hc, hcu,
      (exact_asymmetric_budget hm hp hc hcu ha hρ hρu).mpr ha'⟩

theorem global_robust_gain_isLUB {dm dp ρ : ℝ}
    (hm : 0 ≤ dm) (hp : 0 ≤ dp) (hw : dm + dp ≤ 1)
    (hρ : 0 ≤ ρ) (hρu : ρ < 1) :
    IsLUB {a₀ : ℝ | 0 < a₀ ∧
      ∃ c, dm ≤ c ∧ c ≤ 1 - dp ∧ AsymmetricBoxStable c dm dp a₀ ρ}
      (nominalCap (optimalCenter dm dp) dm dp ρ) := by
  have hset : {a₀ : ℝ | 0 < a₀ ∧
      ∃ c, dm ≤ c ∧ c ≤ 1 - dp ∧ AsymmetricBoxStable c dm dp a₀ ρ} =
      Set.Ioo 0 (nominalCap (optimalCenter dm dp) dm dp ρ) := by
    ext a₀
    constructor
    · rintro ⟨ha, hs⟩
      exact ⟨ha, (exists_robust_center_iff hm hp hw ha hρ hρu).mp hs⟩
    · rintro ⟨ha, hb⟩
      exact ⟨ha, (exists_robust_center_iff hm hp hw ha hρ hρu).mpr hb⟩
  rw [hset]
  exact isLUB_Ioo (nominalCap_pos hm hp hρ)

end C2.Robustness
