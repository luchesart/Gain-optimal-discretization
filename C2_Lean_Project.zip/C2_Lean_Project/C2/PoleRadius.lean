import C2.Schur
import Mathlib

/-! Exact maximum complex-root norm for the fixed gamma=3/4 characteristic,
and uniqueness of its minimum over the full positive stable-gain interval. -/

noncomputable section
namespace C2.PoleRadius

def characteristic (a : ℝ) (z : ℂ) : ℂ :=
  z^2 + ((3*a/4-1:ℝ):ℂ)*z + ((a/4:ℝ):ℂ)

def discriminant (a : ℝ) : ℝ := (9/16)*(a-4)*(a-4/9)

def upperRoot (a : ℝ) : ℝ := (1-3*a/4+Real.sqrt (discriminant a))/2

def lowerRoot (a : ℝ) : ℝ := (1-3*a/4-Real.sqrt (discriminant a))/2

def rootNorms (a : ℝ) : Set ℝ := {r | ∃ z : ℂ, characteristic a z = 0 ∧ ‖z‖ = r}

def radius (a : ℝ) : ℝ := sSup (rootNorms a)

theorem discriminant_identity (a : ℝ) :
    discriminant a = (1-3*a/4)^2-a := by unfold discriminant; ring

theorem low_discriminant_nonneg {a : ℝ} (ha : a ≤ 4/9) : 0 ≤ discriminant a := by
  unfold discriminant
  have hp := mul_nonneg_of_nonpos_of_nonpos (show a-4 ≤ 0 by linarith)
    (show a-4/9 ≤ 0 by linarith)
  nlinarith

theorem low_roots_nonnegative {a : ℝ} (ha : 0 < a) (haq : a ≤ 4/9) :
    0 ≤ lowerRoot a ∧ lowerRoot a ≤ upperRoot a := by
  have hsq : (Real.sqrt (discriminant a))^2 = (1-3*a/4)^2-a :=
    (Real.sq_sqrt (low_discriminant_nonneg haq)).trans (discriminant_identity a)
  have hs := Real.sqrt_nonneg (discriminant a)
  unfold lowerRoot upperRoot
  constructor <;> nlinarith

theorem low_factorization {a : ℝ} (haq : a ≤ 4/9) (z : ℂ) :
    characteristic a z = (z-(upperRoot a:ℂ))*(z-(lowerRoot a:ℂ)) := by
  have hsq : (Real.sqrt (discriminant a))^2 = (1-3*a/4)^2-a :=
    (Real.sq_sqrt (low_discriminant_nonneg haq)).trans (discriminant_identity a)
  have hsum : upperRoot a + lowerRoot a = 1-3*a/4 := by unfold upperRoot lowerRoot; ring
  have hprod : upperRoot a * lowerRoot a = a/4 := by
    unfold upperRoot lowerRoot
    nlinarith
  have hsumc : (upperRoot a:ℂ)+(lowerRoot a:ℂ) = ((1-3*a/4:ℝ):ℂ) := by exact_mod_cast hsum
  have hprodc : (upperRoot a:ℂ)*(lowerRoot a:ℂ) = ((a/4:ℝ):ℂ) := by exact_mod_cast hprod
  unfold characteristic
  push_cast at hsumc hprodc ⊢
  linear_combination z*hsumc - hprodc

theorem low_radius_isGreatest {a : ℝ} (ha : 0 < a) (haq : a ≤ 4/9) :
    IsGreatest (rootNorms a) (upperRoot a) := by
  obtain ⟨hl,hlu⟩ := low_roots_nonnegative ha haq
  have hu := hl.trans hlu
  constructor
  · refine ⟨(upperRoot a:ℂ),?_,?_⟩
    · rw [low_factorization haq]
      simp
    · simp [Complex.norm_real,abs_of_nonneg hu]
  · rintro r ⟨z,hz,hr⟩
    rw [low_factorization haq] at hz
    rcases mul_eq_zero.mp hz with hz | hz
    · have he : z = (upperRoot a:ℂ) := sub_eq_zero.mp hz
      rw [he] at hr
      simpa [Complex.norm_real,abs_of_nonneg hu] using hr.symm.le
    · have he : z = (lowerRoot a:ℂ) := sub_eq_zero.mp hz
      rw [he] at hr
      have heq : r = lowerRoot a := by simpa [Complex.norm_real,abs_of_nonneg hl] using hr.symm
      rw [heq]
      exact hlu

theorem high_discriminant_nonpos {a : ℝ} (haq : 4/9 ≤ a) (ha4 : a ≤ 4) :
    discriminant a ≤ 0 := by
  unfold discriminant
  have hp := mul_nonpos_of_nonpos_of_nonneg (show a-4 ≤ 0 by linarith)
    (show 0 ≤ a-4/9 by linarith)
  nlinarith

theorem high_root_norm {a : ℝ} (haq : 4/9 ≤ a) (ha4 : a ≤ 4) {z : ℂ}
    (hz : characteristic a z = 0) : ‖z‖ = Real.sqrt a / 2 := by
  have ha : 0 ≤ a := by linarith
  have hs := Real.sq_sqrt ha
  have hsn := Real.sqrt_nonneg a
  have hd := high_discriminant_nonpos haq ha4
  rw [discriminant_identity] at hd
  have hz' : (1:ℂ)*z^2 + ((3*a/4-1:ℝ):ℂ)*z + ((a/4:ℝ):ℂ) = 0 := by
    simpa [characteristic] using hz
  obtain ⟨hre,him⟩ := C2.quadratic_root_parts hz'
  have hlin : 2*z.re+(3*a/4-1)=0 := by
    by_cases hi : z.im = 0
    · rw [hi] at hre
      have hsquare := sq_nonneg (2*z.re+(3*a/4-1))
      nlinarith
    · have h := (mul_eq_zero.mp him).resolve_left hi
      nlinarith
  have hn : ‖z‖^2 = z.re^2+z.im^2 := by
    rw [Complex.sq_norm,Complex.normSq_apply]
    ring
  have hlinmul := congrArg (fun t : ℝ => t*z.re) hlin
  dsimp at hlinmul
  have hnorm : ‖z‖^2 = a/4 := by nlinarith
  nlinarith [norm_nonneg z]

theorem high_radius_isGreatest {a : ℝ} (haq : 4/9 ≤ a) (ha4 : a ≤ 4) :
    IsGreatest (rootNorms a) (Real.sqrt a/2) := by
  obtain ⟨z,hz⟩ := C2.quadratic_has_root (L:=1) (b:=3*a/4-1) (c:=a/4) (by norm_num)
  have hz' : characteristic a z = 0 := by simpa [characteristic] using hz
  constructor
  · exact ⟨z,hz',high_root_norm haq ha4 hz'⟩
  · rintro r ⟨w,hw,hr⟩
    have hn := high_root_norm haq ha4 hw
    linarith

theorem low_radius_formula {a : ℝ} (ha : 0 < a) (haq : a ≤ 4/9) :
    radius a = (1-3*a/4+Real.sqrt ((9/16)*(a-4)*(a-4/9)))/2 := by
  exact (low_radius_isGreatest ha haq).csSup_eq

theorem high_radius_formula {a : ℝ} (haq : 4/9 ≤ a) (ha4 : a ≤ 4) :
    radius a = Real.sqrt a/2 := (high_radius_isGreatest haq ha4).csSup_eq

theorem radius_at_minimum : radius (4/9) = 1/3 := by
  rw [low_radius_formula (by norm_num) (by norm_num)]
  norm_num

/-- The actual maximum complex-root norm has a unique minimum, including
both real-root and complex-conjugate regimes. -/
theorem radius_unique_minimum {a : ℝ} (ha : 0 < a) (ha4 : a < 4) :
    1/3 ≤ radius a ∧ (radius a = 1/3 ↔ a = 4/9) := by
  by_cases haq : a ≤ 4/9
  · have hf : radius a = upperRoot a := (low_radius_isGreatest ha haq).csSup_eq
    rw [hf]
    have hs := Real.sqrt_nonneg (discriminant a)
    constructor
    · unfold upperRoot
      nlinarith
    · constructor
      · intro h
        unfold upperRoot at h
        nlinarith
      · intro h
        subst a
        norm_num [upperRoot,discriminant]
  · have haq' : 4/9 ≤ a := le_of_lt (lt_of_not_ge haq)
    rw [high_radius_formula haq' ha4.le]
    have hs := Real.sq_sqrt ha.le
    have hsn := Real.sqrt_nonneg a
    constructor
    · nlinarith
    · constructor
      · intro h
        nlinarith
      · intro h
        subst a
        norm_num

end C2.PoleRadius
