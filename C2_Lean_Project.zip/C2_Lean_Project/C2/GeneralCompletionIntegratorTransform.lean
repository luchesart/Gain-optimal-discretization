import C2.GeneralCompletionIntegrator
import C2.GeneralCompletionTransformDerivative
import C2.GeneralCompletionLocalRoot

/-! Exact specialization of the simple-root small-gain theorem to the common
theta substitution and an arbitrary integer delay. -/
noncomputable section
open Polynomial
namespace C2.GeneralCompletion

theorem delayed_integrator_small_positive_gains {D N : Polynomial ℝ} (m : ℕ)
    (hD0 : D.eval 1 = 0) (hDd : D.derivative.eval 1 ≠ 0)
    (hstable : ∀ z : ℂ, (D.map Complex.ofRealHom).eval z = 0 → z ≠ 1 → ‖z‖ < 1)
    (hdegree : N.natDegree ≤ D.natDegree)
    (hratio : 0 < N.eval 1/D.derivative.eval 1) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℝ, 0 < k → k < ε →
      ∀ z : ℂ, ((Polynomial.X^m*D+Polynomial.C k*N).map
        Complex.ofRealHom).eval z = 0 → ‖z‖ < 1 := by
  let H := Polynomial.X^m*D
  have hDne : D ≠ 0 := by intro he; simp [he] at hDd
  have hH0 : H.eval 1 = 0 := by simp [H,hD0]
  have hHder : H.derivative.eval 1 = D.derivative.eval 1 :=
    delayed_integrator_derivative_one D m hD0
  have hHd : H.derivative.eval 1 ≠ 0 := by rwa [hHder]
  have hHstable : ∀ z : ℂ, (H.map Complex.ofRealHom).eval z = 0 → z ≠ 1 → ‖z‖ < 1 := by
    intro z hz hz1
    by_cases hz0 : z = 0
    · simp [hz0]
    · apply hstable z _ hz1
      have he : z^m*(D.map Complex.ofRealHom).eval z = 0 := by simpa [H] using hz
      exact (mul_eq_zero.mp he).resolve_left (pow_ne_zero m hz0)
  have hdeg : N.natDegree ≤ H.natDegree := by
    dsimp [H]
    rw [natDegree_X_pow_mul m hDne]
    exact hdegree.trans (Nat.le_add_right _ _)
  have hratio' : 0 < N.eval 1/H.derivative.eval 1 := by rwa [hHder]
  exact real_simple_root_small_positive_gains hH0 hHd hHstable hdeg hratio'

/-- The simple-integrator clause under the manuscript's common-parameter
substitution. The residue is exactly T*B(0)/A'(0), including the pure delay. -/
theorem theta_integrator_small_positive_gains
    (A B : Polynomial ℝ) (d m : ℕ) (T γ : ℝ)
    (hd : 1 ≤ d) (hT : 0 < T) (hB : B.natDegree ≤ d)
    (hA0 : A.eval 0 = 0) (hAd : A.derivative.eval 0 ≠ 0)
    (hr : 0 < B.eval 0/A.derivative.eval 0)
    (htop : (C2.commonDegreeTransform A d (C2.thetaScale T γ)
      C2.thetaNumerator).coeff d ≠ 0)
    (hstable : ∀ z : ℂ,
      ((C2.commonDegreeTransform A d (C2.thetaScale T γ) C2.thetaNumerator).map
        Complex.ofRealHom).eval z = 0 → z ≠ 1 → ‖z‖ < 1) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℝ, 0 < k → k < ε →
      ∀ z : ℂ, ((Polynomial.X^m *
          C2.commonDegreeTransform A d (C2.thetaScale T γ) C2.thetaNumerator +
        Polynomial.C k * C2.commonDegreeTransform B d (C2.thetaScale T γ)
          C2.thetaNumerator).map Complex.ofRealHom).eval z = 0 → ‖z‖ < 1 := by
  let D := C2.commonDegreeTransform A d (C2.thetaScale T γ) C2.thetaNumerator
  let N := C2.commonDegreeTransform B d (C2.thetaScale T γ) C2.thetaNumerator
  have hD0 : D.eval 1 = 0 := by rw [theta_transform_eval_one,hA0,mul_zero]
  have hDd : D.derivative.eval 1 ≠ 0 := by
    rw [theta_transform_derivative_at_integrator A d T γ hd hA0]
    exact mul_ne_zero (pow_ne_zero _ hT.ne') hAd
  have hDdegree : D.natDegree = d :=
    natDegree_eq_of_le_of_coeff_ne_zero
      (C2.commonDegreeTransform_natDegree_le A d _ _
        (C2.thetaScale_natDegree_le T γ) C2.thetaNumerator_natDegree_le) htop
  have hNdegree : N.natDegree ≤ D.natDegree := by
    rw [hDdegree]
    exact C2.commonDegreeTransform_natDegree_le B d _ _
      (C2.thetaScale_natDegree_le T γ) C2.thetaNumerator_natDegree_le
  have hratio : 0 < N.eval 1/D.derivative.eval 1 := by
    rw [theta_integrator_residue A B d T γ hd hT.ne' hA0 hAd]
    exact mul_pos hT hr
  exact delayed_integrator_small_positive_gains m hD0 hDd hstable hNdegree hratio

/-- Complete simple-integrator clause: exact Schur stability of every mode,
the local real root and derivative, and a quantified quadratic remainder
with the manuscript's coefficient T*B(0)/A'(0). -/
theorem theta_integrator_small_gain_full
    (A B : Polynomial ℝ) (d m : ℕ) (T γ : ℝ)
    (hd : 1 ≤ d) (hT : 0 < T) (hB : B.natDegree ≤ d)
    (hA0 : A.eval 0 = 0) (hAd : A.derivative.eval 0 ≠ 0)
    (hr : 0 < B.eval 0/A.derivative.eval 0)
    (htop : (C2.commonDegreeTransform A d (C2.thetaScale T γ)
      C2.thetaNumerator).coeff d ≠ 0)
    (hstable : ∀ z : ℂ,
      ((C2.commonDegreeTransform A d (C2.thetaScale T γ) C2.thetaNumerator).map
        Complex.ofRealHom).eval z = 0 → z ≠ 1 → ‖z‖ < 1) :
    let D := C2.commonDegreeTransform A d (C2.thetaScale T γ) C2.thetaNumerator
    let N := C2.commonDegreeTransform B d (C2.thetaScale T γ) C2.thetaNumerator
    (∃ ε : ℝ, 0 < ε ∧ ∀ k : ℝ, 0 < k → k < ε →
      ∀ z : ℂ, ((Polynomial.X^m*D+Polynomial.C k*N).map
        Complex.ofRealHom).eval z = 0 → ‖z‖ < 1) ∧
    ∃ (z : ℝ → ℝ) (C δ : ℝ), z 0 = 1 ∧
      HasDerivAt z (-T*(B.eval 0/A.derivative.eval 0)) 0 ∧ 0 < C ∧ 0 < δ ∧
      ∀ k : ℝ, |k| < δ →
        (Polynomial.X^m*D).eval (z k)+k*N.eval (z k)=0 ∧
        |z k-(1-k*T*(B.eval 0/A.derivative.eval 0))| ≤ C*k^2 := by
  dsimp only
  constructor
  · exact theta_integrator_small_positive_gains A B d m T γ hd hT hB hA0 hAd hr htop hstable
  · let D := C2.commonDegreeTransform A d (C2.thetaScale T γ) C2.thetaNumerator
    let N := C2.commonDegreeTransform B d (C2.thetaScale T γ) C2.thetaNumerator
    let H := Polynomial.X^m*D
    have hD0 : D.eval 1 = 0 := by rw [theta_transform_eval_one,hA0,mul_zero]
    have hH0 : H.eval 1 = 0 := by simp [H,hD0]
    have hHder : H.derivative.eval 1 = T^(d-1)*A.derivative.eval 0 := by
      rw [delayed_integrator_derivative_one D m hD0,
        theta_transform_derivative_at_integrator A d T γ hd hA0]
    have hHd : H.derivative.eval 1 ≠ 0 := by
      rw [hHder]
      exact mul_ne_zero (pow_ne_zero _ hT.ne') hAd
    have hB0 : B.eval 0 ≠ 0 := by intro he; simp [he] at hr
    have hN1 : N.eval 1 ≠ 0 := by
      rw [theta_transform_eval_one]
      exact mul_ne_zero (pow_ne_zero _ hT.ne') hB0
    have hres : N.eval 1/H.derivative.eval 1 = T*(B.eval 0/A.derivative.eval 0) := by
      rw [delayed_integrator_derivative_one D m hD0]
      exact theta_integrator_residue A B d T γ hd hT.ne' hA0 hAd
    obtain ⟨z,C,δ,hz0,hzder,hC,hδ,hz⟩ :=
      exists_local_real_root_branch_quadratic H N hH0 hHd hN1
    have hder : -N.eval 1/H.derivative.eval 1 = -T*(B.eval 0/A.derivative.eval 0) := by
      rw [neg_div,hres]
      ring
    rw [hder] at hzder
    refine ⟨z,C,δ,hz0,hzder,hC,hδ,?_⟩
    intro k hk
    obtain ⟨hroot,herr⟩ := hz k hk
    refine ⟨hroot,?_⟩
    have he : 1-k*N.eval 1/H.derivative.eval 1 =
        1-k*T*(B.eval 0/A.derivative.eval 0) := by
      rw [mul_div_assoc,hres]
      ring
    rwa [he] at herr

end C2.GeneralCompletion
