from pathlib import Path
import hashlib,json,zipfile,csv,re,sys,shutil
R=Path(__file__).resolve().parents[1];P=R/'unpacked/C2_Lean_Project/C2_Lean_Project';M=R/'unpacked/C2_Rational_Delay_Project/C2_Rational_Delay_Project'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
sys.path.insert(0,str(P/'tools'));from theorem_inventory import without_comments_and_strings
pres=[]
with zipfile.ZipFile(R/'cad_work/input_v03/C2_Lean_Project.zip') as z:
 for n in z.namelist():
  rel=Path(n).relative_to('C2_Lean_Project')
  if len(rel.parts)==2 and rel.parts[0]=='C2' and rel.suffix=='.lean':
   assert z.read(n)==(P/rel).read_bytes(),n
   pres.append({'source':str(rel),'sha256':sha(P/rel)})
 for rel in ['PROOF_MAP_EN.csv','VERIFICATION.json','ENVIRONMENT.json','ENVIRONMENT.txt','validation/final_validation_summary.json','validation/cad_remaining_20261109.md']:
  n='C2_Lean_Project/'+rel
  if n in z.namelist():
   dest=P/'historical/20261109_v03'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(n))
assert len(pres)==156
new=[p for p in (P/'C2').glob('*.lean') if str(p.relative_to(P)) not in {r['source'] for r in pres}]
assert len(new)==52
for p in (P/'C2').glob('*.lean'):
 clean=without_comments_and_strings(p.read_text())
 assert not re.search(r'\b(sorry|admit|axiom|unsafe)\b',clean),p
 assert (P/'.lake/build/lib/lean/C2'/f'{p.stem}.olean').exists(),p
 assert (P/'.lake/build/lib/lean/C2'/f'{p.stem}.olean').stat().st_mtime>=p.stat().st_mtime,p
v=P/'validation/20261109'
dump(v/'v03_module_preservation.json',dict(passed=True,old_module_count=156,all_byte_identical=True,new_module_count=52,modules=pres))
dump(v/'source_scan_v04.json',dict(passed=True,module_count=208,excluded_comments_and_strings=True,forbidden=['sorry','admit','axiom','unsafe'],all_module_oleans_newer_than_sources=True))
inv=json.loads((P/'work/lean_inventory_draft.json').read_text());names={d['name'] for d in inv['declarations'] if not d['private']}
rows=list(csv.DictReader((P/'PROOF_MAP_EN.csv').open()));row=next(r for r in rows if r['Label']=='thm:exact-gain-projection')
decls=['C2.CADNative.native_gain_projection_correct','C2.CADNative.run_none_iff_empty','C2.CADNative.run_some_correct','C2.CADNative.run_nonempty_supremum','C2.CADNative.run','C2.CADDriver.markGain_rawFeasible','C2.CADGlobal.finite_global_gain_calculation']
for d in decls:assert d in names,d
modules=[d['module'] for d in inv['declarations'] if d['name'] in decls]
row['Lean_status']='COMPLETE'
row['Lean_declarations']='; '.join(dict.fromkeys(row['Lean_declarations'].split('; ')+decls))
row['Lean_modules']='; '.join(dict.fromkeys(row['Lean_modules'].split('; ')+modules))
row['Scope_and_remaining']='Actual total CADNative.run accepts only the original finite rational bivariate inputs and a positive rational bound. Under the proved uniform bound K0<K, None iff the original feasible positive-gain set is empty; Some uniquely represents its algebraic global supremum with 0<b<=K0<K, including disconnected components. Factor/Bezout data, squarefree reduction, dyadic root isolation, rational samples and exact sign marks are computed internally by terminating searches. The manuscript now explicitly states this verified Bezout-based reference procedure. No supplied CAD oracle, projection, factorization, partition, sample or marking correctness premise. Exhaustive search has no practical complexity claim; the separate SymPy/resultant implementation is not verified.'
for dest in [P/'PROOF_MAP_EN.csv',M/'PROOF_MAP_EN.csv']:
 with dest.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
dump(v/'cad_coverage_update_v04.json',dict(label=row['Label'],status='COMPLETE',declarations=decls,scope=row['Scope_and_remaining'],evidence=['validation/cad_native_theorem_completion_20261109.json','validation/cad_end_to_end_review_20261109.json']))
for name in ['CADCells','CADGainCuts','CADEffectiveProjection']:
 mods=[x for x in inv['modules'] if x['module']=='C2.'+name]
 assert len(mods)==1
 dump(P/'validation'/f'{name}_completion_20261109.json',dict(status='compiled_kernel_checked',module=mods[0],compile_exit_code=0,log=f'validation/20261109/{name}.log'))
old=M/'general_gain_projection.tex';dest=M/'historical/20261109_v03/general_gain_projection.tex';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old,dest)
text=(R/'cad_work/general_gain_projection_candidate.tex').read_text().replace('finite procedure for its largest stabilizing gain.','finite procedure for its global stabilizing-gain supremum.')
old.write_text(text)
obsolete=P/'validation/20261109/CADProjectionCells.log'
if obsolete.exists():
 dest=P/'validation/20261109/attempts/obsolete_root_CADProjectionCells.log';dest.parent.mkdir(parents=True,exist_ok=True);shutil.move(obsolete,dest)
remaining=P/'validation/cad_remaining_20261109.md'
remaining.write_text('# C2 Theorem 3 — completed, 9 November 2026\n\nThe former remaining-obligations record is archived at ../historical/20261109_v03/validation/cad_remaining_20261109.md. It is superseded by the completed native algorithm and its actual-output theorem C2.CADNative.native_gain_projection_correct. See cad_native_theorem_completion_20261109.json and cad_end_to_end_review_20261109.json. The global release checks are recorded in ../VERIFICATION.json.\n\nThe verified procedure uses finite rational factor/Bézout data search, squarefree reduction, dyadic isolation and rational samples. It proves termination and the actual algebraic global supremum. It does not verify the separate SymPy/resultant implementation or claim competitive running time.\n')
print(json.dumps({'old_modules_preserved':len(pres),'new_modules':len(new),'complete_rows':sum(r['Lean_status']=='COMPLETE' for r in rows)}))
