import Mathlib.Analysis.SpecialFunctions.Complex.Arg
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.Topology.Connected.TotallyDisconnected
import Mathlib.Tactic

/-! An elementary polynomial argument principle, built from its actual complex
roots. Each root strictly inside the unit circle contributes one turn; roots
outside contribute zero turns. Multiplicity is retained by the root list. -/
noncomputable section
open scoped BigOperators
open Set Complex Polynomial
namespace C2.NGamma.RootCountBridge

def circle (t : ℝ) : ℂ := Complex.exp ((t : ℂ) * Complex.I)

@[simp] theorem circle_ne_zero (t : ℝ) : circle t ≠ 0 := Complex.exp_ne_zero _
@[simp] theorem norm_circle (t : ℝ) : ‖circle t‖ = 1 := Complex.norm_exp_ofReal_mul_I t
@[simp] theorem circle_zero : circle 0 = 1 := by simp [circle]
@[simp] theorem circle_two_pi : circle (2 * Real.pi) = 1 := by
  simpa [circle] using Complex.exp_two_pi_mul_I

theorem continuous_circle : Continuous circle := by unfold circle; fun_prop

def innerFactor (a : ℂ) (t : ℝ) : ℂ := 1 - a / circle t
def outerFactor (a : ℂ) (t : ℝ) : ℂ := 1 - circle t / a

theorem innerFactor_re_pos {a : ℂ} (ha : ‖a‖ < 1) (t : ℝ) :
    0 < (innerFactor a t).re := by
  have h := Complex.re_le_norm (a / circle t)
  simp only [norm_div, norm_circle, div_one] at h
  simp only [innerFactor, sub_re, one_re]
  linarith

theorem outerFactor_re_pos {a : ℂ} (ha : 1 < ‖a‖) (t : ℝ) :
    0 < (outerFactor a t).re := by
  have h := Complex.re_le_norm (circle t / a)
  simp only [norm_div, norm_circle] at h
  have hn : 1 / ‖a‖ < 1 := (div_lt_one (by positivity)).2 ha
  simp only [outerFactor, sub_re, one_re]
  linarith

theorem factor_inner (a : ℂ) (t : ℝ) :
    circle t - a = circle t * innerFactor a t := by
  unfold innerFactor
  field_simp [circle_ne_zero]

theorem factor_outer {a : ℂ} (ha : a ≠ 0) (t : ℝ) :
    circle t - a = (-a) * outerFactor a t := by
  unfold outerFactor
  field_simp
  ring

def linearAngle (a : ℂ) (t : ℝ) : ℝ :=
  if ‖a‖ < 1 then t + Complex.arg (innerFactor a t)
  else Complex.arg (-a) + Complex.arg (outerFactor a t)

theorem continuous_linearAngle {a : ℂ} (ha : ‖a‖ ≠ 1) :
    Continuous (linearAngle a) := by
  change Continuous (fun t => linearAngle a t)
  by_cases hi : ‖a‖ < 1
  · simp only [linearAngle, if_pos hi]
    apply continuous_id.add
    apply continuous_iff_continuousAt.2
    intro t
    apply (Complex.continuousAt_arg (Or.inl (innerFactor_re_pos hi t))).comp
    unfold innerFactor
    exact (continuous_const.sub (continuous_const.div continuous_circle circle_ne_zero)).continuousAt
  · have ho : 1 < ‖a‖ := lt_of_le_of_ne (le_of_not_gt hi) (Ne.symm ha)
    simp only [linearAngle, if_neg hi]
    apply continuous_const.add
    apply continuous_iff_continuousAt.2
    intro t
    apply (Complex.continuousAt_arg (Or.inl (outerFactor_re_pos ho t))).comp
    unfold outerFactor
    exact (continuous_const.sub (continuous_circle.div_const a)).continuousAt

theorem polar_inner (a : ℂ) (t : ℝ) :
    circle t - a = (‖circle t - a‖ : ℂ) *
      Complex.exp (((t + Complex.arg (innerFactor a t) : ℝ) : ℂ) * Complex.I) := by
  have hn : ‖circle t - a‖ = ‖innerFactor a t‖ := by
    rw [factor_inner, norm_mul, norm_circle, one_mul]
  rw [hn, Complex.ofReal_add, add_mul, Complex.exp_add]
  change circle t - a = (‖innerFactor a t‖ : ℂ) *
    (circle t * Complex.exp ((Complex.arg (innerFactor a t) : ℂ) * Complex.I))
  calc
    circle t - a = circle t * innerFactor a t := factor_inner a t
    _ = circle t * ((‖innerFactor a t‖ : ℂ) *
        Complex.exp ((Complex.arg (innerFactor a t) : ℂ) * Complex.I)) := by
          rw [Complex.norm_mul_exp_arg_mul_I]
    _ = _ := by ring

theorem polar_outer {a : ℂ} (ha : a ≠ 0) (t : ℝ) :
    circle t - a = (‖circle t - a‖ : ℂ) *
      Complex.exp (((Complex.arg (-a) + Complex.arg (outerFactor a t) : ℝ) : ℂ) * Complex.I) := by
  have hn : ‖circle t - a‖ = ‖-a‖ * ‖outerFactor a t‖ := by
    rw [factor_outer ha, norm_mul]
  rw [hn, Complex.ofReal_mul, Complex.ofReal_add, add_mul, Complex.exp_add]
  calc
    circle t - a = (-a) * outerFactor a t := factor_outer ha t
    _ = ((‖-a‖ : ℂ) * Complex.exp ((Complex.arg (-a) : ℂ) * Complex.I)) *
        ((‖outerFactor a t‖ : ℂ) *
          Complex.exp ((Complex.arg (outerFactor a t) : ℂ) * Complex.I)) := by
          rw [Complex.norm_mul_exp_arg_mul_I, Complex.norm_mul_exp_arg_mul_I]
    _ = _ := by ring

theorem polar_linear {a : ℂ} (_ha : ‖a‖ ≠ 1) (t : ℝ) :
    circle t - a = (‖circle t - a‖ : ℂ) *
      Complex.exp ((linearAngle a t : ℂ) * Complex.I) := by
  by_cases hi : ‖a‖ < 1
  · simpa only [linearAngle, if_pos hi] using polar_inner a t
  · have ha0 : a ≠ 0 := by intro h; simp [h] at hi
    simpa only [linearAngle, if_neg hi] using polar_outer ha0 t

theorem linearAngle_increment (a : ℂ) :
    linearAngle a (2 * Real.pi) - linearAngle a 0 =
      if ‖a‖ < 1 then 2 * Real.pi else 0 := by
  by_cases hi : ‖a‖ < 1
  · simp [linearAngle, hi, innerFactor]
  · simp [linearAngle, hi, outerFactor]

def rootsAngle : List ℂ → ℝ → ℝ
  | [], _ => 0
  | a :: roots, t => linearAngle a t + rootsAngle roots t

def factors (roots : List ℂ) (t : ℝ) : ℂ :=
  (roots.map (fun a => circle t - a)).prod

def insideCount (roots : List ℂ) : ℕ :=
  (roots.filter (fun a => ‖a‖ < 1)).length

theorem continuous_rootsAngle (roots : List ℂ)
    (hroots : ∀ a ∈ roots, ‖a‖ ≠ 1) : Continuous (rootsAngle roots) := by
  induction roots with
  | nil => exact continuous_const
  | cons a roots ih =>
    exact (continuous_linearAngle (hroots a (by simp))).add
      (ih (fun z hz => hroots z (by simp [hz])))

theorem polar_roots (roots : List ℂ)
    (hroots : ∀ a ∈ roots, ‖a‖ ≠ 1) (t : ℝ) :
    factors roots t = (‖factors roots t‖ : ℂ) *
      Complex.exp ((rootsAngle roots t : ℂ) * Complex.I) := by
  induction roots with
  | nil => simp [rootsAngle, factors]
  | cons a roots ih =>
    have ha := polar_linear (hroots a (by simp)) t
    have hr := ih (fun z hz => hroots z (by simp [hz]))
    simp only [rootsAngle, factors, List.map_cons, List.prod_cons]
    change (circle t - a) * factors roots t = _
    rw [norm_mul, Complex.ofReal_mul, Complex.ofReal_add, add_mul, Complex.exp_add]
    calc
      (circle t - a) * factors roots t =
        ((‖circle t - a‖ : ℂ) * Complex.exp ((linearAngle a t : ℂ) * I)) *
        ((‖factors roots t‖ : ℂ) * Complex.exp ((rootsAngle roots t : ℂ) * I)) := by
          rw [← ha, ← hr]
      _ = _ := by unfold factors; ring

theorem rootsAngle_increment (roots : List ℂ) :
    rootsAngle roots (2 * Real.pi) - rootsAngle roots 0 =
      (insideCount roots : ℝ) * (2 * Real.pi) := by
  induction roots with
  | nil => simp [rootsAngle, insideCount]
  | cons a roots ih =>
    have ha := linearAngle_increment a
    by_cases hi : ‖a‖ < 1
    · simp [rootsAngle, insideCount, List.filter_cons, hi] at *
      linarith
    · simp [rootsAngle, insideCount, List.filter_cons, hi] at *
      linarith

def polynomialAngle (p : Polynomial ℂ) (t : ℝ) : ℝ :=
  Complex.arg p.leadingCoeff + rootsAngle p.roots.toList t

def countInside (p : Polynomial ℂ) : ℕ := insideCount p.roots.toList

theorem eval_eq_factors (p : Polynomial ℂ) (t : ℝ) :
    p.eval (circle t) = p.leadingCoeff * factors p.roots.toList t := by
  rw [Polynomial.eval_eq_prod_roots_sub_of_splits_id (IsAlgClosed.splits p)]
  congr 1
  have hm : (↑(p.roots.toList.map (fun a => circle t - a)) : Multiset ℂ) =
      p.roots.map (fun a => circle t - a) := by
        rw [← Multiset.map_coe, Multiset.coe_toList]
  exact (congrArg Multiset.prod hm).symm

theorem polynomial_polar (p : Polynomial ℂ)
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) (t : ℝ) :
    p.eval (circle t) = (‖p.eval (circle t)‖ : ℂ) *
      Complex.exp ((polynomialAngle p t : ℂ) * Complex.I) := by
  have hr := polar_roots p.roots.toList (fun a ha => hroots a (by simpa using ha)) t
  rw [eval_eq_factors, norm_mul, Complex.ofReal_mul]
  simp only [polynomialAngle, Complex.ofReal_add, add_mul, Complex.exp_add]
  calc
    p.leadingCoeff * factors p.roots.toList t =
      ((‖p.leadingCoeff‖ : ℂ) * Complex.exp ((Complex.arg p.leadingCoeff : ℂ) * I)) *
      ((‖factors p.roots.toList t‖ : ℂ) *
        Complex.exp ((rootsAngle p.roots.toList t : ℂ) * I)) := by
          rw [Complex.norm_mul_exp_arg_mul_I, ← hr]
    _ = _ := by ring

theorem continuous_polynomialAngle (p : Polynomial ℂ)
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) : Continuous (polynomialAngle p) := by
  exact continuous_const.add
    (continuous_rootsAngle p.roots.toList (fun a ha => hroots a (by simpa using ha)))

theorem polynomialAngle_increment (p : Polynomial ℂ) :
    polynomialAngle p (2 * Real.pi) - polynomialAngle p 0 =
      (countInside p : ℝ) * (2 * Real.pi) := by
  simp only [polynomialAngle, countInside]
  linarith [rootsAngle_increment p.roots.toList]

theorem argument_difference_constant {s : Set ℝ} (hs : IsPreconnected s)
    {α β : ℝ → ℝ} (hα : ContinuousOn α s) (hβ : ContinuousOn β s)
    (he : ∀ t ∈ s, Complex.exp ((α t : ℂ) * I) =
      Complex.exp ((β t : ℂ) * I)) {u v : ℝ} (hu : u ∈ s) (hv : v ∈ s) :
    α u - β u = α v - β v := by
  let f : ℝ → ℂ := fun t =>
    (((α t : ℂ) * I) - ((β t : ℂ) * I)) / (2 * Real.pi * I)
  have hc : ContinuousOn f s := by
    exact (((Complex.continuous_ofReal.comp_continuousOn hα).mul continuousOn_const).sub
      ((Complex.continuous_ofReal.comp_continuousOn hβ).mul continuousOn_const)).div_const _
  have hden : (2 * (Real.pi : ℂ) * I) ≠ 0 := by
    exact mul_ne_zero (mul_ne_zero (by norm_num) (by exact_mod_cast Real.pi_ne_zero)) I_ne_zero
  have hr : f '' s ⊆ Set.range ((↑) : ℤ → ℂ) := by
    rintro z ⟨t, ht, rfl⟩
    obtain ⟨k, hk⟩ := Complex.exp_eq_exp_iff_exists_int.mp (he t ht)
    refine ⟨k, ?_⟩
    dsimp [f]
    rw [hk]
    field_simp
  have hd : IsTotallyDisconnected (Set.range ((↑) : ℤ → ℂ)) :=
    Complex.isometry_intCast.isEmbedding.isTotallyDisconnected_range.mpr inferInstance
  have hf := hd (f '' s) hr (hs.image f hc)
  have huv : f u = f v := hf ⟨u, hu, rfl⟩ ⟨v, hv, rfl⟩
  have hmul := (div_left_inj' hden).mp huv
  have him := congrArg Complex.im hmul
  simpa using him

theorem eval_circle_ne_zero {p : Polynomial ℂ} (hp : p ≠ 0)
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) (t : ℝ) : p.eval (circle t) ≠ 0 := by
  intro hz
  have hm : circle t ∈ p.roots := (Polynomial.mem_roots hp).2 hz
  exact hroots (circle t) hm (norm_circle t)

/-- The ordinary argument principle for a complex polynomial, proved directly
from its factorization. This theorem counts actual roots with multiplicity. -/
theorem polynomial_argument_principle {p : Polynomial ℂ} (hp : p ≠ 0)
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) {α : ℝ → ℝ}
    (hα : ContinuousOn α (Set.Icc 0 (2 * Real.pi)))
    (hpolar : ∀ t ∈ Set.Icc 0 (2 * Real.pi), p.eval (circle t) =
      (‖p.eval (circle t)‖ : ℂ) * Complex.exp ((α t : ℂ) * I)) :
    α (2 * Real.pi) - α 0 = (countInside p : ℝ) * (2 * Real.pi) := by
  have he : ∀ t ∈ Set.Icc 0 (2 * Real.pi), Complex.exp ((α t : ℂ) * I) =
      Complex.exp ((polynomialAngle p t : ℂ) * I) := by
    intro t ht
    have hn : (‖p.eval (circle t)‖ : ℂ) ≠ 0 := by
      exact_mod_cast (norm_ne_zero_iff.mpr (eval_circle_ne_zero hp hroots t))
    apply mul_left_cancel₀ hn
    exact (hpolar t ht).symm.trans (polynomial_polar p hroots t)
  have h0 : 0 ∈ Set.Icc 0 (2 * Real.pi) := by constructor <;> nlinarith [Real.pi_pos]
  have h1 : 2 * Real.pi ∈ Set.Icc 0 (2 * Real.pi) := by constructor <;> nlinarith [Real.pi_pos]
  have hc := argument_difference_constant isPreconnected_Icc hα
    (continuous_polynomialAngle p hroots).continuousOn he h1 h0
  linarith [polynomialAngle_increment p]

end C2.NGamma.RootCountBridge
