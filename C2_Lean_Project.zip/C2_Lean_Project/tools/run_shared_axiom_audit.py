#!/usr/bin/env python3
"""Audit all public roots with the unchanged official Lean collector and a shared state.

The union certifies the same allowed-axiom property as individual reports, while
avoiding repeated traversals. Exact per-root dependency lists are not claimed.
No theorem source or inventory is modified. No artificial timeout is used.
"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import time
from build_direct import pinned_environment

ROOT = Path(__file__).resolve().parents[1]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def prepare():
    inventory_path = ROOT / 'work/lean_inventory_draft.json'
    inventory = json.loads(inventory_path.read_text())
    names = [d['name'] for d in inventory['declarations'] if not d['private']]
    if not names or len(names) != len(set(names)):
        raise ValueError('Expected nonempty, duplicate-free public inventory')
    roots_path = ROOT / 'work/SharedAxiomAudit.roots.txt'
    roots_path.write_text('\n'.join(names) + '\n')
    source_path = ROOT / 'work/SharedAxiomAudit.lean'
    source_path.write_text('''import C2
import Lean.Util.CollectAxioms
import Lean.Elab.Command

/- Audit code only. The original collector reads the checked kernel environment,
traversing definition/theorem/opaque types and bodies, constructor and recursor
types, and inductive types plus constructors. Sharing its visited set computes
the union of reachable axioms without rescanning common dependencies.
No replacement collector or proof-source declarations are introduced. -/
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0

run_cmd do
  let rootText ← IO.FS.readFile "work/SharedAxiomAudit.roots.txt"
  let roots := ((rootText.splitOn "\\n").filter (· != "")).toArray.map String.toName
  let env ← getEnv
  let checked := env.checked.get
  for root in roots do
    unless (checked.find? root).isSome do
      throwError "Missing public declaration in checked kernel environment: {root}"
  let stdout ← IO.getStdout
  stdout.putStrLn s!"C2_SHARED_AXIOM_AUDIT_START roots={roots.size}"
  stdout.flush
  let mut state : Lean.CollectAxioms.State := {}
  let mut completed := 0
  for root in roots do
    let (_, next) := ((Lean.CollectAxioms.collect root).run env).run state
    state := next
    completed := completed + 1
    if completed == 1 || completed % 100 == 0 || completed == roots.size then
      stdout.putStrLn s!"C2_SHARED_AXIOM_AUDIT_PROGRESS roots={completed}/{roots.size} axioms={state.axioms.size}"
      stdout.flush
  let axioms := state.axioms.qsort Name.lt
  let allowed : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let unexpected := axioms.filter (fun name => !allowed.contains name)
  let report := Json.mkObj [
    ("schema", toJson "c2.shared-axiom-union.v1"),
    ("collector", toJson "Lean.CollectAxioms.collect (unchanged official implementation)"),
    ("inventory_sha256", toJson "INVENTORY_HASH"),
    ("root_list_sha256", toJson "ROOT_LIST_HASH"),
    ("expected_count", toJson EXPECTED_COUNT),
    ("checked_root_count", toJson completed),
    ("all_roots_exist_in_checked_kernel_environment", toJson true),
    ("roots", toJson (roots.map Name.toString)),
    ("axiom_union", toJson (axioms.map Name.toString)),
    ("allowed_axioms", toJson (allowed.map Name.toString)),
    ("unexpected_axioms", toJson (unexpected.map Name.toString)),
    ("passed", toJson (unexpected.isEmpty && completed == EXPECTED_COUNT))]
  IO.FS.writeFile "work/SharedAxiomAudit.raw.json" (report.pretty ++ "\\n")
  unless unexpected.isEmpty do
    throwError "Unexpected transitive axioms: {unexpected}"
  unless completed == EXPECTED_COUNT do
    throwError "Public root count changed: {completed}"
  stdout.putStrLn "C2_SHARED_AXIOM_AUDIT_COMPLETE"
  stdout.flush
'''.replace('INVENTORY_HASH', sha(inventory_path)).replace('ROOT_LIST_HASH', sha(roots_path)).replace('EXPECTED_COUNT', str(len(names))))
    return inventory_path, roots_path, source_path

def main():
    inventory_path, roots_path, source_path = prepare()
    lean, env, environment = pinned_environment()
    raw_path = ROOT / 'work/SharedAxiomAudit.raw.json'
    raw_path.unlink(missing_ok=True)
    log_path = ROOT / 'work/SharedAxiomAudit.log'
    result_path = ROOT / 'work/axiom_audit.json'
    result_path.write_text(json.dumps({'passed': False, 'status': 'running', 'audit_method': 'shared_official_collector_union'}) + '\n')
    command = [lean, '-j1', str(source_path.relative_to(ROOT))]
    if shutil.which('stdbuf'):
        command = ['stdbuf', '-oL', *command]
    print('Checking all public roots with one official collector state...', flush=True)
    started = time.monotonic()
    with log_path.open('w') as output:
        process = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
    execution = {'command': command, 'lean_exit_code': process.returncode,
                 'elapsed_seconds': time.monotonic() - started, 'log': str(log_path.relative_to(ROOT)),
                 'source_sha256': sha(source_path), 'inventory_sha256': sha(inventory_path),
                 'root_list_sha256': sha(roots_path), 'environment': environment}
    (ROOT / 'work/SharedAxiomAudit.execution.json').write_text(json.dumps(execution, indent=2) + '\n')
    if process.returncode:
        result_path.write_text(json.dumps({'passed': False, 'execution': execution}, indent=2) + '\n')
        print(f'Lean audit failed: exit {process.returncode}; see {log_path}', file=sys.stderr)
        return process.returncode
    return subprocess.run([sys.executable, 'tools/check_shared_axiom_audit.py'], cwd=ROOT).returncode

if __name__ == '__main__':
    sys.exit(main())
