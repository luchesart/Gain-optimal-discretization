import C2.CADAlgorithmInterpretation

/-! Transfer the finite maximum computed on native ranks to its real
interpretation. Order preservation is needed only on ranks actually used by
this finite computation; no ordering oracle on arbitrary algebraic numbers is
part of the executable algorithm. -/

namespace C2.CADAlgorithm
open Set

theorem output_map_of_rights_monotone {α : Type*} [LinearOrder α]
    (cells : List (Cell α)) (value : α → ℝ)
    (hmono : ∀ c ∈ cells, ∀ d ∈ cells, c.right ≤ d.right →
      value c.right ≤ value d.right) :
    output (cells.map (Cell.mapEndpoints value)) = (output cells).map value := by
  cases hout : output cells with
  | none =>
    apply (output_none_iff _).mpr
    intro c hc
    obtain ⟨d, hd, rfl⟩ := List.mem_map.mp hc
    exact (output_none_iff cells).mp hout d hd
  | some r =>
    obtain ⟨⟨c, hc, hm, hcr⟩, hmax⟩ := output_some_spec hout
    apply output_some_iff.mpr
    constructor
    · exact ⟨c.mapEndpoints value, List.mem_map.mpr ⟨c, hc, rfl⟩, hm,
        congrArg value hcr⟩
    · intro d hd hdm
      obtain ⟨e, he, rfl⟩ := List.mem_map.mp hd
      change value e.right ≤ value r
      rw [← hcr]
      exact hmono e he c hc (hcr ▸ hmax e he hdm)

theorem native_output_none_iff_empty {α : Type*} [LinearOrder α]
    (cells : List (Cell α)) (value : α → ℝ) {S E : Set ℝ}
    (hS : IsOpen S) (hE : E.Finite)
    (hvalid : ValidCells (cells.map (Cell.mapEndpoints value)))
    (hcover : S \ E = representedGains (cells.map (Cell.mapEndpoints value))) :
    output cells = none ↔ S = ∅ := by
  have hnone : output (cells.map (Cell.mapEndpoints value)) = none ↔
      output cells = none := by
    simp only [output_none_iff, List.forall_mem_map, Cell.mapEndpoints]
  exact hnone.symm.trans
    (output_none_iff_empty_of_decomposition hS hE hvalid hcover)

theorem native_output_isLUB {α : Type*} [LinearOrder α]
    (cells : List (Cell α)) (value : α → ℝ) {S E : Set ℝ}
    (hS : IsOpen S) (hE : E.Finite)
    (hvalid : ValidCells (cells.map (Cell.mapEndpoints value)))
    (hcover : S \ E = representedGains (cells.map (Cell.mapEndpoints value)))
    (hmono : ∀ c ∈ cells, ∀ d ∈ cells, c.right ≤ d.right →
      value c.right ≤ value d.right) {r : α} (hout : output cells = some r) :
    IsLUB S (value r) := by
  apply output_isLUB_of_decomposition hS hE hvalid hcover
  rw [output_map_of_rights_monotone cells value hmono, hout]
  rfl

end C2.CADAlgorithm
