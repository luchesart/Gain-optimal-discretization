import Mathlib

/-! The square-free quotient used in one-parameter CAD preprocessing.
This file proves its mathematical specification. A finite coefficient-list
implementation is a separate executable refinement, not supplied by `noncomputable`.
-/
noncomputable section
open Polynomial
namespace C2.CADFactor

variable {F : Type*} [Field F] [DecidableEq F] [CharZero F]

def squarefreePart (p : F[X]) : F[X] :=
  p / EuclideanDomain.gcd p p.derivative

theorem gcd_derivative_ne_zero {p : F[X]} (hp : p ≠ 0) :
    EuclideanDomain.gcd p p.derivative ≠ 0 := by
  intro h
  have hd := EuclideanDomain.gcd_dvd_left p p.derivative
  rw [h, zero_dvd_iff] at hd
  exact hp hd

theorem gcd_mul_squarefreePart {p : F[X]} (hp : p ≠ 0) :
    EuclideanDomain.gcd p p.derivative * squarefreePart p = p := by
  exact EuclideanDomain.mul_div_cancel' (gcd_derivative_ne_zero hp)
    (EuclideanDomain.gcd_dvd_left p p.derivative)

theorem squarefreePart_ne_zero {p : F[X]} (hp : p ≠ 0) :
    squarefreePart p ≠ 0 := by
  intro h
  have he := gcd_mul_squarefreePart hp
  rw [h, mul_zero] at he
  exact hp he.symm

theorem squarefreePart_dvd (p : F[X]) : squarefreePart p ∣ p := by
  by_cases hp : p = 0
  · simp [hp]
  · exact ⟨EuclideanDomain.gcd p p.derivative, by
      rw [mul_comm, gcd_mul_squarefreePart hp]⟩

theorem dvd_derivative_mul_squarefreePart {p : F[X]} (hp : p ≠ 0) :
    p ∣ p.derivative * squarefreePart p := by
  obtain ⟨r, hr⟩ := EuclideanDomain.gcd_dvd_right p p.derivative
  refine ⟨r, ?_⟩
  calc
    p.derivative * squarefreePart p =
        (EuclideanDomain.gcd p p.derivative * r) * squarefreePart p :=
      congrArg (fun a => a * squarefreePart p) hr
    _ = (EuclideanDomain.gcd p p.derivative * squarefreePart p) * r := by ring
    _ = p * r := by rw [gcd_mul_squarefreePart hp]

theorem isRoot_squarefreePart_iff {p : F[X]} (hp : p ≠ 0) (x : F) :
    (squarefreePart p).IsRoot x ↔ p.IsRoot x := by
  constructor
  · intro hx
    obtain ⟨r, hr⟩ := squarefreePart_dvd p
    rw [Polynomial.IsRoot, hr, Polynomial.eval_mul, hx, zero_mul]
  · intro hx
    exact isRoot_of_isRoot_of_dvd_derivative_mul hp
      (dvd_derivative_mul_squarefreePart hp) hx

theorem squarefreePart_rootMultiplicity_le_one {p : F[X]} (hp : p ≠ 0) (x : F) :
    (squarefreePart p).rootMultiplicity x ≤ 1 := by
  by_cases hx : p.IsRoot x
  · have hg0 := gcd_derivative_ne_zero hp
    have hm : p.rootMultiplicity x =
        (EuclideanDomain.gcd p p.derivative).rootMultiplicity x +
          (squarefreePart p).rootMultiplicity x := by
      calc
        p.rootMultiplicity x =
            (EuclideanDomain.gcd p p.derivative * squarefreePart p).rootMultiplicity x :=
          congrArg (Polynomial.rootMultiplicity x) (gcd_mul_squarefreePart hp).symm
        _ = _ := rootMultiplicity_mul (by rw [gcd_mul_squarefreePart hp]; exact hp)
    have hg : p.rootMultiplicity x - 1 ≤
        (EuclideanDomain.gcd p p.derivative).rootMultiplicity x := by
      apply (le_rootMultiplicity_iff hg0).mpr
      apply EuclideanDomain.dvd_gcd
      · exact (pow_dvd_pow (X - C x) (Nat.sub_le _ _)).trans
          (pow_rootMultiplicity_dvd p x)
      · rw [← derivative_rootMultiplicity_of_root hx]
        exact pow_rootMultiplicity_dvd p.derivative x
    omega
  · have hq : ¬ (squarefreePart p).IsRoot x :=
      fun h => hx ((isRoot_squarefreePart_iff hp x).mp h)
    rw [rootMultiplicity_eq_zero hq]
    exact Nat.zero_le _

theorem squarefreePart_map {E : Type*} [Field E] [DecidableEq E] [CharZero E]
    (f : F →+* E) (p : F[X]) :
    (squarefreePart p).map f = squarefreePart (p.map f) := by
  simp only [squarefreePart, Polynomial.map_div, ← Polynomial.gcd_map,
    Polynomial.derivative_map]

theorem squarefreePart_separable {p : F[X]} (hp : p ≠ 0) :
    (squarefreePart p).Separable := by
  classical
  let E := AlgebraicClosure F
  let f : F →+* E := algebraMap F E
  have hp' : p.map f ≠ 0 := Polynomial.map_ne_zero hp
  have hq' : squarefreePart (p.map f) ≠ 0 := squarefreePart_ne_zero hp'
  have hs : (squarefreePart (p.map f)).Separable := by
    apply (nodup_roots_iff_of_splits hq' (IsAlgClosed.splits _)).mp
    rw [Multiset.nodup_iff_count_le_one]
    intro x
    rw [Polynomial.count_roots]
    exact squarefreePart_rootMultiplicity_le_one hp' x
  rw [← squarefreePart_map f p] at hs
  exact (Polynomial.separable_map f).mp hs

theorem squarefreePart_natDegree_le {p : F[X]} (hp : p ≠ 0) :
    (squarefreePart p).natDegree ≤ p.natDegree :=
  Polynomial.natDegree_le_of_dvd (squarefreePart_dvd p) hp

theorem squarefreePart_eval₂_zero_iff {E : Type*} [Field E] [DecidableEq E] [CharZero E]
    (f : F →+* E) {p : F[X]} (hp : p ≠ 0) (x : E) :
    (squarefreePart p).eval₂ f x = 0 ↔ p.eval₂ f x = 0 := by
  have h := isRoot_squarefreePart_iff (Polynomial.map_ne_zero (f:=f) hp) x
  rw [← squarefreePart_map f p] at h
  simpa only [Polynomial.IsRoot, Polynomial.eval_map] using h

/-- Root preservation is an algebraic witness property, independent of the
particular quotient used to obtain the witnesses. -/
theorem isRoot_iff_of_reduction_witnesses {p q : F[X]} (hp : p ≠ 0)
    (hqp : q ∣ p) (hpq : p ∣ p.derivative * q) (x : F) :
    q.IsRoot x ↔ p.IsRoot x := by
  constructor
  · intro hx
    obtain ⟨r, hr⟩ := hqp
    rw [Polynomial.IsRoot, hr, Polynomial.eval_mul, hx, zero_mul]
  · exact isRoot_of_isRoot_of_dvd_derivative_mul hp hpq

/-- The same checked identities preserve zeros after any field embedding. -/
theorem eval₂_zero_iff_of_reduction_witnesses
    {E : Type*} [Field E] [CharZero E] (f : F →+* E)
    {p q : F[X]} (hp : p ≠ 0) (hqp : q ∣ p) (hpq : p ∣ p.derivative * q) (x : E) :
    q.eval₂ f x = 0 ↔ p.eval₂ f x = 0 := by
  classical
  have hqpm := Polynomial.map_dvd f hqp
  have hpqm : p.map f ∣ (p.map f).derivative * q.map f := by
    simpa only [Polynomial.map_mul, Polynomial.derivative_map] using Polynomial.map_dvd f hpq
  simpa only [Polynomial.IsRoot, Polynomial.eval_map] using
    isRoot_iff_of_reduction_witnesses (Polynomial.map_ne_zero hp) hqpm hpqm x

/-- Every nonzero polynomial has finite square-free reduction data whose
correctness is checked solely by the displayed polynomial identities. -/
theorem exists_squarefree_reduction_witnesses (p : F[X]) (hp : p ≠ 0) :
    ∃ q g h u v : F[X],
      p = g*q ∧ p.derivative*q = p*h ∧ u*q + v*q.derivative = 1 := by
  let q := squarefreePart p
  obtain ⟨h, hh⟩ := dvd_derivative_mul_squarefreePart hp
  obtain ⟨u,v,huv⟩ := (Polynomial.separable_def _).mp (squarefreePart_separable hp)
  exact ⟨q, EuclideanDomain.gcd p p.derivative, h,u,v,
    (gcd_mul_squarefreePart hp).symm, hh, huv⟩

/-- Soundness of the coefficient-identity checks used by an executable
finite-data search. Neither roots nor separability are assumed. -/
theorem squarefree_reduction_witnesses_sound
    {p q g h u v : F[X]} (hp : p ≠ 0)
    (hpg : p = g*q) (hph : p.derivative*q = p*h)
    (huv : u*q + v*q.derivative = 1) :
    q.Separable ∧ q ≠ 0 ∧
      ∀ {E : Type*} [Field E] [CharZero E] (f : F →+* E) (x : E),
        q.eval₂ f x = 0 ↔ p.eval₂ f x = 0 := by
  have hq0 : q ≠ 0 := by
    intro hq
    apply hp
    rw [hpg,hq,mul_zero]
  have hqp : q ∣ p := ⟨g, by rw [hpg,mul_comm]⟩
  have hpq : p ∣ p.derivative*q := ⟨h,hph⟩
  exact ⟨(Polynomial.separable_def _).mpr ⟨u,v,huv⟩, hq0,
    fun f x => eval₂_zero_iff_of_reduction_witnesses f hp hqp hpq x⟩

end C2.CADFactor
