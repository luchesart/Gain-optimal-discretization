import C2.NGammaCayley

noncomputable section
open scoped BigOperators
namespace C2.NGamma.Cayley

/-- Integer selecting the continuous phase branch at a magnitude crossing. -/
def phaseIndex (θ : ℝ) : ℤ := ⌊(θ+Real.pi)/(2*Real.pi)⌋

theorem phaseIndex_bounds {θ : ℝ}
    (hodd : ∀ k : ℤ, θ ≠ (2*(k:ℝ)+1)*Real.pi) :
    -Real.pi < θ-2*(phaseIndex θ:ℝ)*Real.pi ∧
      θ-2*(phaseIndex θ:ℝ)*Real.pi < Real.pi := by
  have hp : 0 < 2*Real.pi := mul_pos (by norm_num) Real.pi_pos
  have hlo := (le_div_iff₀ hp).1 (Int.floor_le ((θ+Real.pi)/(2*Real.pi)))
  have hhi := (div_lt_iff₀ hp).1 (Int.lt_floor_add_one ((θ+Real.pi)/(2*Real.pi)))
  change (phaseIndex θ:ℝ)*(2*Real.pi) ≤ θ+Real.pi at hlo
  change θ+Real.pi < ((phaseIndex θ:ℝ)+1)*(2*Real.pi) at hhi
  constructor
  · have hne := hodd (phaseIndex θ-1)
    push_cast at hne
    by_contra h
    apply hne
    nlinarith
  · nlinarith

theorem phaseIndex_nonneg {θ : ℝ} (hθ : 0 ≤ θ) : 0 ≤ phaseIndex θ := by
  exact Int.floor_nonneg.2 (div_nonneg (by linarith [Real.pi_pos]) (by positivity))

theorem phaseIndex_eq_zero_iff {θ : ℝ} (hθ : 0 ≤ θ) :
    phaseIndex θ = 0 ↔ θ < Real.pi := by
  unfold phaseIndex
  rw [Int.floor_eq_iff]
  norm_num
  have hp : 0 < 2*Real.pi := by positivity
  constructor
  · intro h
    have hlt := (div_lt_iff₀ hp).1 h.2
    linarith
  · intro h
    constructor
    · apply div_nonneg <;> linarith [Real.pi_pos]
    · apply (div_lt_iff₀ hp).2
      linarith

theorem exp_phaseIndex_sub (θ : ℝ) :
    Complex.exp (((θ-2*(phaseIndex θ:ℝ)*Real.pi:ℝ):ℂ)*Complex.I) =
      Complex.exp ((θ:ℂ)*Complex.I) := by
  apply Complex.exp_eq_exp_iff_exists_int.2
  refine ⟨-phaseIndex θ, ?_⟩
  push_cast
  ring

end C2.NGamma.Cayley
