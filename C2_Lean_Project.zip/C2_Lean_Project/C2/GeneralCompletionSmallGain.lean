import Mathlib

/-!
# A quantitative small-gain theorem for a Schur-stable denominator

This proves the strictly stable branch of `prop:general-small-gain` without
an assumption of root continuity. The simple-integrator branch is not claimed.
-/

noncomputable section
open Polynomial Finset
namespace C2.GeneralCompletion

def coefficientNormSum (p : Polynomial ℂ) : ℝ :=
  ∑ i ∈ Finset.range (p.natDegree + 1), ‖p.coeff i‖

theorem coefficientNormSum_nonneg (p : Polynomial ℂ) : 0 ≤ coefficientNormSum p := by
  exact Finset.sum_nonneg (fun i _ => norm_nonneg _)

/-- Outside the open unit disk, polynomial growth is bounded by its
coefficient norm sum and any exponent above its degree. -/
theorem eval_norm_le_coefficientNormSum {p : Polynomial ℂ} {L : ℕ}
    (hd : p.natDegree ≤ L) {z : ℂ} (hz : 1 ≤ ‖z‖) :
    ‖p.eval z‖ ≤ coefficientNormSum p * ‖z‖ ^ L := by
  rw [eval_eq_sum_range]
  calc
    _ ≤ ∑ i ∈ Finset.range (p.natDegree + 1), ‖p.coeff i * z^i‖ := norm_sum_le _ _
    _ = ∑ i ∈ Finset.range (p.natDegree + 1), ‖p.coeff i‖ * ‖z‖^i := by simp
    _ ≤ ∑ i ∈ Finset.range (p.natDegree + 1), ‖p.coeff i‖ * ‖z‖^L := by
      apply Finset.sum_le_sum
      intro i hi
      gcongr
      · exact hz
      · exact (Nat.le_of_lt_succ (Finset.mem_range.mp hi)).trans hd
    _ = _ := by rw [← Finset.sum_mul]; rfl

/-- A positive radial gap is supplied by every factor of a Schur polynomial. -/
theorem multiset_radial_gap {s : Multiset ℂ}
    (hs : ∀ a ∈ s, ‖a‖ < 1) {z : ℂ} (hz : 1 ≤ ‖z‖) :
    0 < (s.map (fun a => 1 - ‖a‖)).prod ∧
    (s.map (fun a => 1 - ‖a‖)).prod * ‖z‖^s.card ≤
      ‖(s.map (fun a => z-a)).prod‖ := by
  induction s using Multiset.induction_on with
  | empty => simp
  | @cons a s ih =>
    have ha := hs a (Multiset.mem_cons_self _ _)
    obtain ⟨hpos, hbound⟩ := ih (fun b hb => hs b (Multiset.mem_cons_of_mem hb))
    have hfactor : (1 - ‖a‖) * ‖z‖ ≤ ‖z-a‖ := by
      have hnorm := norm_sub_norm_le z a
      have hprod : ‖a‖ ≤ ‖a‖ * ‖z‖ := by nlinarith [norm_nonneg a]
      nlinarith
    simp only [Multiset.map_cons, Multiset.prod_cons, Multiset.card_cons, norm_mul]
    constructor
    · exact mul_pos (sub_pos.mpr ha) hpos
    · calc
        (1 - ‖a‖) * (s.map (fun a => 1 - ‖a‖)).prod * ‖z‖^(s.card+1) =
            ((1 - ‖a‖)*‖z‖) * ((s.map (fun a => 1 - ‖a‖)).prod * ‖z‖^s.card) := by
              rw [pow_succ]; ring
        _ ≤ ‖z-a‖ * ‖(s.map (fun a => z-a)).prod‖ := by
          exact mul_le_mul hfactor hbound (by positivity) (norm_nonneg _)

/-- The explicit positive gap coefficient of a nonzero Schur polynomial. -/
def radialGap (p : Polynomial ℂ) : ℝ :=
  ‖p.leadingCoeff‖ * (p.roots.map (fun a => 1 - ‖a‖)).prod

theorem radialGap_pos {p : Polynomial ℂ} (hp : p ≠ 0)
    (hs : ∀ z : ℂ, p.eval z = 0 → ‖z‖ < 1) : 0 < radialGap p := by
  have hr : ∀ z ∈ p.roots, ‖z‖ < 1 := fun z hz => hs z (isRoot_of_mem_roots hz)
  have h := (multiset_radial_gap hr (z := (1 : ℂ)) (by simp)).1
  exact mul_pos (norm_pos_iff.mpr (leadingCoeff_ne_zero.mpr hp)) h

theorem radialGap_eval_lower_bound {p : Polynomial ℂ}
    (hs : ∀ z : ℂ, p.eval z = 0 → ‖z‖ < 1)
    {z : ℂ} (hz : 1 ≤ ‖z‖) :
    radialGap p * ‖z‖^p.natDegree ≤ ‖p.eval z‖ := by
  have hr : ∀ z ∈ p.roots, ‖z‖ < 1 := fun z hz => hs z (isRoot_of_mem_roots hz)
  have h := (multiset_radial_gap hr hz).2
  have hcard : p.roots.card = p.natDegree := by
    simpa using (natDegree_eq_card_roots (IsAlgClosed.splits p)).symm
  rw [hcard] at h
  rw [eval_eq_prod_roots_sub_of_splits_id (IsAlgClosed.splits p), norm_mul]
  simpa only [radialGap, mul_assoc] using
    mul_le_mul_of_nonneg_left h (norm_nonneg p.leadingCoeff)

/-- Explicit perturbation radius; every complex feedback coefficient within
this radius preserves strict stability. -/
theorem small_gain_schur {H N : Polynomial ℂ} (hH : H ≠ 0)
    (hstable : ∀ z : ℂ, H.eval z = 0 → ‖z‖ < 1)
    (hdegree : N.natDegree ≤ H.natDegree) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℂ, ‖k‖ < ε →
      ∀ z : ℂ, (H + Polynomial.C k * N).eval z = 0 → ‖z‖ < 1 := by
  let ε := radialGap H / (coefficientNormSum N + 1)
  have hg := radialGap_pos hH hstable
  have hc := coefficientNormSum_nonneg N
  have he : 0 < coefficientNormSum N + 1 := by linarith
  refine ⟨ε, div_pos hg he, ?_⟩
  intro k hk z hz
  by_contra hbad
  have hzn : 1 ≤ ‖z‖ := le_of_not_gt hbad
  have hpow : 0 < ‖z‖^H.natDegree := pow_pos (by linarith) _
  have hlo := radialGap_eval_lower_bound hstable hzn
  have hup := eval_norm_le_coefficientNormSum hdegree hzn
  have heq : H.eval z = -(k*N.eval z) := by
    simpa only [Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_C,
      add_eq_zero_iff_eq_neg] using hz
  rw [heq, norm_neg, norm_mul] at hlo
  have hmul := mul_le_mul_of_nonneg_left hup (norm_nonneg k)
  have hless : ‖k‖ * (coefficientNormSum N + 1) < radialGap H :=
    (lt_div_iff₀ he).mp hk
  have hstrict : ‖k‖ * coefficientNormSum N < radialGap H := by
    nlinarith [norm_nonneg k]
  have hfinal := mul_lt_mul_of_pos_right hstrict hpow
  nlinarith

/-- The strictly stable-denominator clause of the manuscript, for every
integer delay. The conclusion includes a quantitative two-sided gain
neighborhood, so in particular all sufficiently small positive gains. -/
theorem delayed_small_positive_gains {D N : Polynomial ℝ} (m : ℕ)
    (hD : D ≠ 0) (hdegree : N.natDegree ≤ D.natDegree)
    (hstable : ∀ z : ℂ, (D.map Complex.ofRealHom).eval z = 0 → ‖z‖ < 1) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℝ, |k| < ε →
      ∀ z : ℂ, ((Polynomial.X^m*D + Polynomial.C k*N).map
        Complex.ofRealHom).eval z = 0 → ‖z‖ < 1 := by
  let H : Polynomial ℂ := Polynomial.X^m * D.map Complex.ofRealHom
  have hDc : D.map Complex.ofRealHom ≠ 0 := by simpa using hD
  have hH : H ≠ 0 := mul_ne_zero (pow_ne_zero m Polynomial.X_ne_zero) hDc
  have hHs : ∀ z : ℂ, H.eval z = 0 → ‖z‖ < 1 := by
    intro z hz
    have hz' : z^m * (D.map Complex.ofRealHom).eval z = 0 := by
      simpa [H] using hz
    by_cases hz0 : z = 0
    · simp [hz0]
    · exact hstable z ((mul_eq_zero.mp hz').resolve_left (pow_ne_zero m hz0))
  have hdeg : (N.map Complex.ofRealHom).natDegree ≤ H.natDegree := by
    dsimp [H]
    rw [natDegree_X_pow_mul m hDc]
    simpa using hdegree.trans (Nat.le_add_right D.natDegree m)
  obtain ⟨ε, hε, hs⟩ := small_gain_schur hH hHs hdeg
  refine ⟨ε, hε, ?_⟩
  intro k hk z hz
  apply hs (k : ℂ) (by simpa using hk) z
  simpa [H] using hz

end C2.GeneralCompletion
