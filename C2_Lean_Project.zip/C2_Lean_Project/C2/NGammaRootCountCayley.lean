import C2.NGammaRootCountConsequences
import C2.NGammaCayley

/-! The half-circle argument principle in the manuscript's unbounded Cayley
parameter. Taking the endpoint limit avoids any branch choice at infinity. -/
noncomputable section
open scoped BigOperators ComplexConjugate Topology
open Set Complex Polynomial Filter
namespace C2.NGamma.RootCountBridge

theorem polynomial_argument_principle_cayley {p : Polynomial ℂ} (hp : p ≠ 0)
    (hconj : ∀ z : ℂ, p.eval (conj z) = conj (p.eval z))
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) {α : ℝ → ℝ} {L : ℝ}
    (hα : ContinuousOn α (Set.Ici 0))
    (hpolar : ∀ t ∈ Set.Ici 0, p.eval (Cayley.point t) =
      (‖p.eval (Cayley.point t)‖ : ℂ) * Complex.exp ((α t : ℂ) * I))
    (hlim : Tendsto α atTop (𝓝 L)) :
    L - α 0 = (countInside p : ℝ) * Real.pi := by
  let β : ℝ → ℝ := fun t => polynomialAngle p (2 * Real.arctan t)
  have hβ : Continuous β :=
    (continuous_polynomialAngle p hroots).comp (continuous_const.mul Real.continuous_arctan)
  have hpoint (t : ℝ) : Cayley.point t = circle (2 * Real.arctan t) := by
    simpa [circle] using Cayley.point_exp t
  have he : ∀ t ∈ Set.Ici 0, Complex.exp ((α t : ℂ) * I) =
      Complex.exp ((β t : ℂ) * I) := by
    intro t ht
    have hn : (‖p.eval (Cayley.point t)‖ : ℂ) ≠ 0 := by
      rw [hpoint]
      exact_mod_cast (norm_ne_zero_iff.mpr (eval_circle_ne_zero hp hroots (2 * Real.arctan t)))
    apply mul_left_cancel₀ hn
    rw [← hpolar t ht, hpoint]
    exact polynomial_polar p hroots _
  have hdiff : ∀ t ∈ Set.Ici 0, α t - β t = α 0 - β 0 := by
    intro t ht
    exact argument_difference_constant isPreconnected_Ici hα hβ.continuousOn he ht (by simp)
  have hθ : Tendsto (fun t : ℝ => 2 * Real.arctan t) atTop (𝓝 Real.pi) := by
    have he : (2 : ℝ) * (Real.pi / 2) = Real.pi := by ring
    simpa only [he] using
      (Real.tendsto_arctan_atTop.mono_right nhdsWithin_le_nhds).const_mul (2 : ℝ)
  have hbLim : Tendsto β atTop (𝓝 (polynomialAngle p Real.pi)) :=
    (continuous_polynomialAngle p hroots).continuousAt.tendsto.comp hθ
  have heq : (fun t => α t - β t) =ᶠ[atTop] (fun _ => α 0 - β 0) := by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
    exact hdiff t ht
  have hh : L - polynomialAngle p Real.pi = α 0 - β 0 :=
    tendsto_nhds_unique (hlim.sub hbLim) (tendsto_const_nhds.congr' heq.symm)
  have hb0 : β 0 = polynomialAngle p 0 := by simp [β]
  rw [hb0] at hh
  linarith [polynomialAngle_half_increment hp hconj hroots]

theorem exterior_count_of_cayley_argument {p : Polynomial ℂ} (hp : p ≠ 0)
    (hconj : ∀ z : ℂ, p.eval (conj z) = conj (p.eval z))
    (hroots : ∀ a ∈ p.roots, ‖a‖ ≠ 1) {α : ℝ → ℝ} {L : ℝ}
    (hα : ContinuousOn α (Set.Ici 0))
    (hpolar : ∀ t ∈ Set.Ici 0, p.eval (Cayley.point t) =
      (‖p.eval (Cayley.point t)‖ : ℂ) * Complex.exp ((α t : ℂ) * I))
    (hlim : Tendsto α atTop (𝓝 L))
    (m : ℤ) (hend : L - α 0 = ((p.natDegree : ℝ) - 2 * m) * Real.pi) :
    (countOutside p : ℤ) = 2 * m := by
  have hi := polynomial_argument_principle_cayley hp hconj hroots hα hpolar hlim
  have hn := count_partition p hroots
  have hnr : (countInside p : ℝ) + (countOutside p : ℝ) = p.natDegree := by exact_mod_cast hn
  have hi' : (countInside p : ℝ) = (p.natDegree : ℝ) - 2 * m := by
    apply mul_right_cancel₀ Real.pi_ne_zero
    exact hi.symm.trans hend
  have ho : (countOutside p : ℝ) = 2 * m := by linarith
  exact_mod_cast ho

end C2.NGamma.RootCountBridge
