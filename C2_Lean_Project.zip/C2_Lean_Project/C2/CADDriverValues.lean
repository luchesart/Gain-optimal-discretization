import C2.CADDriver
import C2.CADRootPairs

/-! Real interpretation of the executable finite root ranks. This semantic
interpretation is never called by the native rational CAD computation. -/
noncomputable section
namespace C2.CADDriver
open Set C2.CADEffective C2.CADIsolation

noncomputable def rootValue (p : Dense.Poly) (hp : Dense.denote p ≠ 0)
    (a b : ℚ) (hab : a < b) (r : ℕ) : ℝ :=
  if hr : r ∈ (isolate p hp a b hab.le).ranks then
    Classical.choose (isolate_unique_root p hp a b hab hr).exists
  else 0

section
variable (p : Dense.Poly) (hp : Dense.denote p ≠ 0) (a b : ℚ) (hab : a < b)

theorem rootValue_spec {r : ℕ} (hr : r ∈ (isolate p hp a b hab.le).ranks) :
    Dense.rootAtRank (isolate p hp a b hab.le).polynomial a b
      (isolate p hp a b hab.le).mesh r (rootValue p hp a b hab r) := by
  simp only [rootValue, dif_pos hr]
  exact Classical.choose_spec (isolate_unique_root p hp a b hab hr).exists

theorem rootValue_mem_Icc {r : ℕ} (hr : r ∈ (isolate p hp a b hab.le).ranks) :
    rootValue p hp a b hab r ∈ Icc (a : ℝ) (b : ℝ) :=
  Dense.rootAtRank_mem_interval _ hab.le hr (rootValue_spec p hp a b hab hr)

theorem rootValue_is_root {r : ℕ} (hr : r ∈ (isolate p hp a b hab.le).ranks) :
    realEval (Dense.denote (isolate p hp a b hab.le).polynomial)
      (rootValue p hp a b hab r) = 0 :=
  Dense.rootAtRank_is_root _ _ _ _ _ (rootValue_spec p hp a b hab hr)

theorem rootValue_algebraic {r : ℕ} (hr : r ∈ (isolate p hp a b hab.le).ranks) :
    IsAlgebraic ℚ (rootValue p hp a b hab r) :=
  realEval_zero_isAlgebraic (isolate_polynomial_nonzero p hp a b hab.le)
    (rootValue_is_root p hp a b hab hr)

theorem rootValue_strictMono {r s : ℕ}
    (hr : r ∈ (isolate p hp a b hab.le).ranks)
    (hs : s ∈ (isolate p hp a b hab.le).ranks) (hrs : r < s) :
    rootValue p hp a b hab r < rootValue p hp a b hab s :=
  Dense.root_rank_order _ hab hr hs hrs
    (rootValue_spec p hp a b hab hr) (rootValue_spec p hp a b hab hs)

theorem rootValues_sorted :
    (isolate p hp a b hab.le).ranks.Pairwise
      (fun r s => rootValue p hp a b hab r < rootValue p hp a b hab s) :=
  Dense.rootRanks_values_sorted _ hab _ _ (fun _ hr => rootValue_spec p hp a b hab hr)

theorem rootValue_complete {x : ℝ} (hx : x ∈ Icc (a : ℝ) (b : ℝ))
    (hroot : realEval (Dense.denote p) x = 0 ∨ x = (a : ℝ) ∨ x = (b : ℝ)) :
    ∃ r ∈ (isolate p hp a b hab.le).ranks, rootValue p hp a b hab r = x := by
  obtain ⟨r, hr, hspec⟩ := isolate_complete p hp a b hab hx hroot
  exact ⟨r, hr, (isolate_unique_root p hp a b hab hr).unique
    (rootValue_spec p hp a b hab hr) hspec⟩

theorem rootValue_gap_sample {r s : ℕ}
    (hpair : (r,s) ∈ consecutiveRanks (isolate p hp a b hab.le)) :
    (Dense.betweenRanks a b (isolate p hp a b hab.le).mesh r s : ℝ) ∈
      Ioo (rootValue p hp a b hab r) (rootValue p hp a b hab s) := by
  obtain ⟨hr, hs, hrs, _⟩ := Dense.rankPairs_properties
    (isolate_ranks_sorted p hp a b hab.le) hpair
  exact Dense.betweenRanks_correct _ hab hr hs hrs
    (rootValue_spec p hp a b hab hr) (rootValue_spec p hp a b hab hs)

theorem rootValue_gap_no_root {r s : ℕ}
    (hpair : (r,s) ∈ consecutiveRanks (isolate p hp a b hab.le)) :
    ∀ x ∈ Ioo (rootValue p hp a b hab r) (rootValue p hp a b hab s),
      realEval (Dense.denote p) x ≠ 0 := by
  obtain ⟨hr, hs, _, hcon⟩ := Dense.rankPairs_properties
    (isolate_ranks_sorted p hp a b hab.le) hpair
  have hn := Dense.no_root_between_consecutive_ranks _ hab
    (isolate_mesh_certified p hp a b hab.le) hr hs hcon
    (rootValue_spec p hp a b hab hr) (rootValue_spec p hp a b hab hs)
  intro x hx hz
  exact hn x hx ((isolate_root_iff p hp a b hab.le x).mpr (Or.inl hz))

theorem rootValue_gap_cover {x : ℝ} (hx : x ∈ Ioo (a : ℝ) (b : ℝ))
    (hn : realEval (Dense.denote p) x ≠ 0) :
    ∃ r s, (r,s) ∈ consecutiveRanks (isolate p hp a b hab.le) ∧
      x ∈ Ioo (rootValue p hp a b hab r) (rootValue p hp a b hab s) := by
  have habR : (a : ℝ) ≤ (b : ℝ) := by exact_mod_cast hab.le
  obtain ⟨r, hr, hrv⟩ := rootValue_complete p hp a b hab
    ⟨le_rfl, habR⟩ (Or.inr (Or.inl rfl))
  obtain ⟨s, hs, hsv⟩ := rootValue_complete p hp a b hab
    ⟨habR, le_rfl⟩ (Or.inr (Or.inr rfl))
  apply Dense.exists_rankPair_bracket _ _ x (rootValues_sorted p hp a b hab)
  · exact ⟨r, hr, hrv ▸ hx.1⟩
  · exact ⟨s, hs, hsv ▸ hx.2⟩
  · intro t ht hxt
    have hz := rootValue_is_root p hp a b hab ht
    rw [← hxt] at hz
    rcases (isolate_root_iff p hp a b hab.le x).mp hz with hz | ha | hb
    · exact hn hz
    · exact (ne_of_gt hx.1) ha
    · exact (ne_of_lt hx.2) hb

end
end C2.CADDriver
