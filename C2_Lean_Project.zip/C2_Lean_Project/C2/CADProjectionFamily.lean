import C2.CADProjectionRegularity

/-! A common projection for a finite simple coprime bivariate basis. -/
noncomputable section
open Polynomial
namespace C2.CADProjection

/-- Specializing the gain commutes with evaluation at the fixed parameter 0. -/
@[simp] theorem value_zero (p : Bivariate) (k : ℝ) :
    value p k 0 = (p.eval 0).eval₂ (algebraMap ℚ ℝ) k := by
  simp [value,specialize]

/-- Specializing the gain commutes with evaluation at the fixed parameter 1. -/
@[simp] theorem value_one (p : Bivariate) (k : ℝ) :
    value p k 1 = (p.eval 1).eval₂ (algebraMap ℚ ℝ) k := by
  simp only [value,specialize,Polynomial.eval_map]
  exact Polynomial.eval₂_at_one _

/-- Finite basis regularity needed for sign-invariant parameter cells. -/
def RegularFamilyAt {ι : Type*} (p : ι → Bivariate) (k : ℝ) : Prop :=
  (∀ i, RegularAt (p i) k ∧ value (p i) k 0 ≠ 0 ∧ value (p i) k 1 ≠ 0) ∧
  ∀ i j, i ≠ j → ∀ x : ℝ, value (p i) k x ≠ 0 ∨ value (p j) k x ≠ 0

/-- Finitely many generic simple coprime factors admit one actual nonzero
rational gain polynomial whose complement satisfies every root-regularity
condition. Endpoints are handled by the explicit evaluated factors. -/
theorem exists_family_projection {ι : Type*} [Fintype ι]
    (p : ι → Bivariate) (hp : ∀ i, p i ≠ 0)
    (hsep : ∀ i, ((p i).map (algebraMap ℚ[X] (RatFunc ℚ))).Separable)
    (hpair : ∀ i j, i ≠ j → IsCoprime
      ((p i).map (algebraMap ℚ[X] (RatFunc ℚ)))
      ((p j).map (algebraMap ℚ[X] (RatFunc ℚ))))
    (hzero : ∀ i, (p i).eval 0 ≠ 0) (hone : ∀ i, (p i).eval 1 ≠ 0) :
    ∃ d : ℚ[X], d ≠ 0 ∧
      Set.Finite {k : ℝ | d.eval₂ (algebraMap ℚ ℝ) k = 0} ∧
      (∀ k : ℝ, d.eval₂ (algebraMap ℚ ℝ) k = 0 → IsAlgebraic ℚ k) ∧
      ∀ k : ℝ, d.eval₂ (algebraMap ℚ ℝ) k ≠ 0 → RegularFamilyAt p k := by
  classical
  have hi : ∀ i, ∃ d : ℚ[X], d ≠ 0 ∧ ∀ k : ℝ,
      d.eval₂ (algebraMap ℚ ℝ) k ≠ 0 →
        RegularAt (p i) k ∧ value (p i) k 0 ≠ 0 ∧ value (p i) k 1 ≠ 0 := by
    intro i
    obtain ⟨d,hd,_,_,hreg⟩ := exists_regular_projection_with_extra
      (p i) (hp i) (hsep i) ((p i).eval 0 * (p i).eval 1)
      (mul_ne_zero (hzero i) (hone i))
    refine ⟨d,hd,fun k hk => ?_⟩
    obtain ⟨ha,hr⟩ := hreg k hk
    have he : ((p i).eval 0).eval₂ (algebraMap ℚ ℝ) k ≠ 0 ∧
        ((p i).eval 1).eval₂ (algebraMap ℚ ℝ) k ≠ 0 := by
      simpa only [Polynomial.eval₂_mul,mul_ne_zero_iff] using ha
    exact ⟨hr,by simpa only [value_zero] using he.1,
      by simpa only [value_one] using he.2⟩
  choose d hd hdi using hi
  have hij : ∀ i j, ∃ e : ℚ[X], e ≠ 0 ∧ ∀ k : ℝ,
      e.eval₂ (algebraMap ℚ ℝ) k ≠ 0 → i ≠ j →
        ∀ x : ℝ, value (p i) k x ≠ 0 ∨ value (p j) k x ≠ 0 := by
    intro i j
    by_cases heq : i = j
    · exact ⟨1,one_ne_zero,fun _ _ hne => False.elim (hne heq)⟩
    · obtain ⟨e,he,hcut⟩ := exists_collision_cut (p i) (p j) (hpair i j heq)
      exact ⟨e,he,fun k hk _ x => hcut
        (Polynomial.eval₂RingHom (algebraMap ℚ ℝ) k) hk x⟩
  choose e he hei using hij
  let D : ℚ[X] := (∏ i, d i) * ∏ i, ∏ j, e i j
  have hD : D ≠ 0 := mul_ne_zero
    (Finset.prod_ne_zero_iff.mpr (fun i _ => hd i))
    (Finset.prod_ne_zero_iff.mpr (fun i _ =>
      Finset.prod_ne_zero_iff.mpr (fun j _ => he i j)))
  refine ⟨D,hD,rational_zero_set_finite D hD,
    fun k hk => rational_zero_isAlgebraic D hD hk,fun k hk => ?_⟩
  let f : ℚ[X] →+* ℝ := Polynomial.eval₂RingHom (algebraMap ℚ ℝ) k
  have hDk : (∏ i, f (d i)) * (∏ i, ∏ j, f (e i j)) ≠ 0 := by
    have hfk : f D ≠ 0 := hk
    simpa only [D,map_mul,map_prod] using hfk
  obtain ⟨hdk,hek⟩ := mul_ne_zero_iff.mp hDk
  refine ⟨fun i => hdi i k ?_,fun i j hij x => hei i j k ?_ hij x⟩
  · exact Finset.prod_ne_zero_iff.mp hdk i (Finset.mem_univ i)
  · exact Finset.prod_ne_zero_iff.mp
      (Finset.prod_ne_zero_iff.mp hek i (Finset.mem_univ i)) j (Finset.mem_univ j)

/-- Arbitrary additional rational cuts preserve finite-family regularity. -/
theorem exists_family_projection_with_extra {ι : Type*} [Fintype ι]
    (p : ι → Bivariate) (hp : ∀ i, p i ≠ 0)
    (hsep : ∀ i, ((p i).map (algebraMap ℚ[X] (RatFunc ℚ))).Separable)
    (hpair : ∀ i j, i ≠ j → IsCoprime
      ((p i).map (algebraMap ℚ[X] (RatFunc ℚ)))
      ((p j).map (algebraMap ℚ[X] (RatFunc ℚ))))
    (hzero : ∀ i, (p i).eval 0 ≠ 0) (hone : ∀ i, (p i).eval 1 ≠ 0)
    (a : ℚ[X]) (ha : a ≠ 0) :
    ∃ d : ℚ[X], d ≠ 0 ∧
      Set.Finite {k : ℝ | d.eval₂ (algebraMap ℚ ℝ) k = 0} ∧
      (∀ k : ℝ, d.eval₂ (algebraMap ℚ ℝ) k = 0 → IsAlgebraic ℚ k) ∧
      ∀ k : ℝ, d.eval₂ (algebraMap ℚ ℝ) k ≠ 0 →
        a.eval₂ (algebraMap ℚ ℝ) k ≠ 0 ∧ RegularFamilyAt p k := by
  obtain ⟨d,hd,_,_,hreg⟩ := exists_family_projection p hp hsep hpair hzero hone
  refine ⟨a*d,mul_ne_zero ha hd,rational_zero_set_finite _ (mul_ne_zero ha hd),
    fun k hk => rational_zero_isAlgebraic _ (mul_ne_zero ha hd) hk,fun k hk => ?_⟩
  have hx : a.eval₂ (algebraMap ℚ ℝ) k ≠ 0 ∧ d.eval₂ (algebraMap ℚ ℝ) k ≠ 0 := by
    simpa only [Polynomial.eval₂_mul,mul_ne_zero_iff] using hk
  exact ⟨hx.1,hreg k hx.2⟩

end C2.CADProjection
