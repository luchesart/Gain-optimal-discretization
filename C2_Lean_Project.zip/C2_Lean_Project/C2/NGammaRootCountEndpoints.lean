import C2.NGammaRootCountBoundary
import C2.NGammaTransferEndpoint
import Mathlib.Topology.Order.IntermediateValue

/-! The real endpoint of the cascade boundary and an actual real exterior root
above the finite endpoint gain. -/
noncomputable section
open scoped BigOperators ComplexConjugate Topology
open Set Complex Polynomial Filter
namespace C2.NGamma.PolynomialModel
variable {n : ℕ} {r x : Fin n → ℝ}

theorem characteristic_neg_one_ne_zero_of_zero
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) {j : Fin n} (hj : x j = 0)
    (d : ℕ) (b : ℝ) : (characteristic r x d b).eval (-1) ≠ 0 := by
  rw [characteristic_eval_neg_one]
  have hxp : (∏ i, (x i : ℂ)) = 0 := by
    apply Finset.prod_eq_zero (Finset.mem_univ j)
    exact_mod_cast hj
  rw [hxp, mul_zero, add_zero]
  apply mul_ne_zero (pow_ne_zero _ (by norm_num))
  apply Finset.prod_ne_zero_iff.2
  intro i hi
  have hh : 0 < 2 + r i * x i := add_pos_of_pos_of_nonneg (by norm_num) (mul_nonneg (hr i).le (hx i))
  exact_mod_cast ne_of_gt hh

theorem characteristic_neg_one_factorized (hx : ∀ i, 0 < x i) (d : ℕ) (b : ℝ) :
    (characteristic r x d b).eval (-1) =
      (-1 : ℂ)^n * (∏ i, (x i : ℂ)) *
      ((-1 : ℂ)^d * ((∏ i, (r i + 2 / x i) : ℝ) : ℂ) + b) := by
  rw [characteristic_eval_neg_one]
  simp only [Fintype.card_fin, pow_add, Complex.ofReal_prod]
  have hp : (∏ i, (2 + (r i : ℂ) * x i)) =
      (∏ i, ((r i + 2 / x i : ℝ) : ℂ)) * ∏ i, (x i : ℂ) := by
    rw [← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro i hi
    push_cast
    have hn : (x i : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt (hx i)
    field_simp
    <;> ring
  rw [hp]
  ring

theorem characteristic_neg_one_ne_zero_of_lt_endpoint
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) (d : ℕ)
    {b : ℝ} (hb : 0 ≤ b) (hbinf : b < ∏ i, (r i + 2 / x i)) :
    (characteristic r x d b).eval (-1) ≠ 0 := by
  rw [characteristic_neg_one_factorized hx]
  apply mul_ne_zero
  · apply mul_ne_zero (pow_ne_zero _ (by norm_num))
    exact Finset.prod_ne_zero_iff.2 (fun i _ => by exact_mod_cast ne_of_gt (hx i))
  · intro he
    have hn := congrArg norm (show (-1 : ℂ)^d * ((∏ i, (r i+2/x i) : ℝ) : ℂ) = -(b : ℂ) by
      linear_combination he)
    have hB : 0 < ∏ i, (r i+2/x i) := Finset.prod_pos (fun i _ => add_pos (hr i) (div_pos (by norm_num) (hx i)))
    simp only [norm_mul, norm_pow, norm_neg, norm_one, one_pow, one_mul,
      Complex.norm_real, Real.norm_eq_abs, abs_of_pos hB, abs_of_nonneg hb] at hn
    linarith

theorem characteristic_eval_neg_one_ne_zero
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) (d : ℕ)
    {b : ℝ} (hb : 0 ≤ b)
    (hbound : (∃ i, x i = 0) ∨ b < ∏ i, (r i + 2 / x i)) :
    (characteristic r x d b).eval (-1) ≠ 0 := by
  by_cases hz : ∃ i, x i = 0
  · obtain ⟨i, hi⟩ := hz
    exact characteristic_neg_one_ne_zero_of_zero hr hx hi d b
  · have hxp : ∀ i, 0 < x i := by
      intro i
      apply lt_of_le_of_ne (hx i)
      intro he
      exact hz ⟨i, he.symm⟩
    exact characteristic_neg_one_ne_zero_of_lt_endpoint hr hxp d hb (hbound.resolve_left hz)

end C2.NGamma.PolynomialModel
