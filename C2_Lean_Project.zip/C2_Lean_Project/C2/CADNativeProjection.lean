import C2.CADEffectiveProjection
import C2.CADEffectiveWitnessSearch
import C2.CADIsolationBounds

/-! Correctness of the actual projection produced from native rational lists.
The finite Boolean checker, and then its total search, imply feasibility
constancy of the original input inequalities on every projection-free cell. -/
namespace C2.CADEffective.Bivariate
open Set

def rawFeasible (F : List Poly) (k : ℝ) : Prop :=
  ∃ x ∈ Icc (0:ℝ) 1, ∀ p ∈ F, 0 < CADProjection.value (denote p) k x

theorem inputFamily_positive_iff (F : List Poly) (k x : ℝ) :
    (∀ i, 0 < CADProjection.value (inputFamily F i) k x) ↔
      ∀ p ∈ F, 0 < CADProjection.value (denote p) k x := by
  constructor
  · intro h p hp
    obtain ⟨i,hi,rfl⟩ := List.mem_iff_getElem.mp hp
    simpa only [inputFamily, List.getD_eq_getElem F [] hi] using h ⟨i,hi⟩
  · intro h i
    have hm : F.getD i [] ∈ F := by
      rw [List.getD_eq_getElem F [] i.isLt]
      exact List.getElem_mem i.isLt
    exact h (F.getD i []) hm

theorem rawFeasible_iff_inputFamily (F : List Poly) (k : ℝ) :
    rawFeasible F k ↔
      ∃ x ∈ Icc (0:ℝ) 1, ∀ i, 0 < CADProjection.value (inputFamily F i) k x := by
  simp only [rawFeasible, inputFamily_positive_iff]

/-- An accepted native witness proves constancy for the actual input list,
not merely for its encoded factor basis or an assumed CAD partition. -/
theorem totalProjection_feasibility_constant (F : List Poly) (w : Witness)
    (hw : witnessCheck F w = true) (I : Set ℝ) (hI : IsPreconnected I)
    (hcut : ∀ k ∈ I,
      CADIsolation.realEval (Dense.denote (totalProjection F w)) k ≠ 0)
    {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) :
    (∃ x ∈ Icc (0:ℝ) 1, ∀ p ∈ F, 0 < CADProjection.value (denote p) a x) ↔
    (∃ x ∈ Icc (0:ℝ) 1, ∀ p ∈ F, 0 < CADProjection.value (denote p) b x) := by
  obtain ⟨hf,hp⟩ := (witnessCheck_iff F w).mp hw
  have hc : ∀ k ∈ I,
      (CADProjection.totalProjectionCut (toFactorData F w) (toProjectionData w)).eval₂
        (algebraMap ℚ ℝ) k ≠ 0 := by
    simpa only [CADIsolation.realEval, denote_totalProjection] using hcut
  have h := CADProjection.valid_data_feasibility_constant (inputFamily F)
    (toFactorData F w) (toProjectionData w) hf hp I hI hc ha hb
  simpa only [inputFamily_positive_iff] using h

/-- The projection producer itself has the required cell invariance; its
only data input is the finite rational polynomial family. -/
theorem producedProjection_feasibility_constant (F : List Poly)
    (hF : ∀ i, inputFamily F i ≠ 0)
    (I : Set ℝ) (hI : IsPreconnected I)
    (hcut : ∀ k ∈ I, CADIsolation.realEval
      (Dense.denote (totalProjection F (produceWitness F hF))) k ≠ 0)
    {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) :
    (∃ x ∈ Icc (0:ℝ) 1, ∀ p ∈ F, 0 < CADProjection.value (denote p) a x) ↔
    (∃ x ∈ Icc (0:ℝ) 1, ∀ p ∈ F, 0 < CADProjection.value (denote p) b x) :=
  totalProjection_feasibility_constant F (produceWitness F hF)
    (produceWitness_accepted F hF) I hI hcut ha hb

end C2.CADEffective.Bivariate
