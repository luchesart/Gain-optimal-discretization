import C2.NGammaRootCountBoundary
import C2.NGammaRootCountEndpoints
import C2.NGammaSinglePhase
import C2.NGammaCharacteristicLift
import C2.NGammaPhaseIndex
import C2.NGammaPolynomialDegree

/-! Exact outside-root count for the actual positive-cascade characteristic.
The argument principle is proved from polynomial factorization in this project;
no root-count, winding or convergence conclusion is assumed. -/
noncomputable section
open scoped BigOperators Topology
namespace C2.NGamma.Cayley
open PolynomialModel RootCountBridge

/-- The root-count lemma with the nonvanishing endpoint exposed as a separate
algebraic obligation. `root_count` below discharges that obligation. -/
theorem root_count_from_endpoint {n d : ℕ} (hn : 0 < n) (hd : 1 ≤ d)
    {r x : Fin n → ℝ} (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i)
    {b tb : ℝ} (htb : 0 < tb) (hBeq : amplitude r x tb = b)
    (hbound : (∃ j, x j = 0) ∨ b < ∏ i, (r i+2/x i))
    (hodd : ∀ k : ℤ, Phase.totalPhase (fun i => x i+2/r i) x d tb ≠
      (2*(k:ℝ)+1)*Real.pi)
    (hend : (characteristic r x d b).eval (-1) ≠ 0) :
    (countOutside (characteristic r x d b) : ℤ) =
      2 * phaseIndex (Phase.totalPhase (fun i => x i+2/r i) x d tb) := by
  let k := phaseIndex (Phase.totalPhase (fun i => x i+2/r i) x d tb)
  have hk := phaseIndex_bounds hodd
  have hlo : -Real.pi < Phase.totalPhase (fun i => x i+2/r i) x d tb - 2*Real.pi*k := by
    dsimp [k]
    nlinarith [hk.1]
  have hhi : Phase.totalPhase (fun i => x i+2/r i) x d tb - 2*Real.pi*k < Real.pi := by
    dsimp [k]
    nlinarith [hk.2]
  have hb : 0 < b := by rw [← hBeq]; exact amplitude_pos hr x tb
  have hroots := no_unit_roots_of_cayley_nonzero (characteristic_eval_conj r x d b)
    (characteristic_point_ne_zero hn hr hx d htb.le hBeq hlo hhi) hend
  apply exterior_count_of_cayley_argument (characteristic_ne_zero hr hx hd b)
    (characteristic_eval_conj r x d b) hroots
    (characteristicAngle_continuousOn hn hr hx d htb.le hBeq hlo hhi)
    (fun t _ => characteristicAngle_polar hr x d b tb k t)
    (characteristicAngle_tendsto_atTop hr hx d hb.le k hbound) k
  rw [characteristicAngle_zero hr x d hb htb.le k, sub_zero,
    characteristic_natDegree hr hx hd b]
  simp only [Fintype.card_fin, Nat.cast_add]
  ring

/-- Exact exterior-root count, including multiplicity, for every positive
cascade order and integer delay at a nonodd magnitude crossing. -/
theorem root_count {n d : ℕ} (hn : 0 < n) (hd : 1 ≤ d)
    {r x : Fin n → ℝ} (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i)
    {b tb : ℝ} (htb : 0 < tb) (hBeq : amplitude r x tb = b)
    (hbound : (∃ j, x j = 0) ∨ b < ∏ i, (r i+2/x i))
    (hodd : ∀ k : ℤ, Phase.totalPhase (fun i => x i+2/r i) x d tb ≠
      (2*(k:ℝ)+1)*Real.pi) :
    (countOutside (characteristic r x d b) : ℤ) =
      2 * phaseIndex (Phase.totalPhase (fun i => x i+2/r i) x d tb) := by
  have hb : 0 ≤ b := by rw [← hBeq]; exact (amplitude_pos hr x tb).le
  exact root_count_from_endpoint hn hd hr hx htb hBeq hbound hodd
    (characteristic_eval_neg_one_ne_zero hr hx d hb hbound)

theorem nonodd_of_phase_lt_pi {θ : ℝ} (hθ : 0 ≤ θ) (hpi : θ < Real.pi) :
    ∀ k : ℤ, θ ≠ (2*(k:ℝ)+1)*Real.pi := by
  intro k he
  by_cases hk : 0 ≤ k
  · have hkr : 0 ≤ (k:ℝ) := by exact_mod_cast hk
    have hp := mul_nonneg hkr Real.pi_pos.le
    nlinarith
  · have hkr : (k:ℝ) ≤ -1 := by exact_mod_cast (show k ≤ -1 by omega)
    have hp := mul_le_mul_of_nonneg_right hkr Real.pi_pos.le
    nlinarith [Real.pi_pos]

theorem exp_odd_pi (k : ℤ) :
    Complex.exp ((((2*(k:ℝ)+1)*Real.pi:ℝ):ℂ)*Complex.I) = -1 := by
  rw [← Complex.exp_pi_mul_I]
  apply Complex.exp_eq_exp_iff_exists_int.2
  refine ⟨k, ?_⟩
  push_cast
  ring

/-- Actual Schur stability at an intermediate gain is precisely the first
phase inequality. Higher odd phase levels are excluded by unit roots and all
other higher levels by a positive exterior-root count. -/
theorem schur_iff_phase_lt_pi_at_magnitude_crossing {n d : ℕ}
    (hn : 0 < n) (hd : 1 ≤ d) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i)
    {b tb : ℝ} (htb : 0 < tb) (hBeq : amplitude r x tb = b)
    (hbound : (∃ j, x j = 0) ∨ b < ∏ i, (r i+2/x i)) :
    SchurStable (characteristic r x d b) ↔
      Phase.totalPhase (fun i => x i+2/r i) x d tb < Real.pi := by
  classical
  have hb : 0 ≤ b := by rw [← hBeq]; exact (amplitude_pos hr x tb).le
  have hp := Phase.totalPhase_pos hn (a := fun i => x i+2/r i) (x := x)
    (fun i => lt_add_of_pos_right (x i) (div_pos (by norm_num) (hr i))) d htb
  by_cases hodd : ∀ k : ℤ, Phase.totalPhase (fun i => x i+2/r i) x d tb ≠ (2*(k:ℝ)+1)*Real.pi
  · let k := phaseIndex (Phase.totalPhase (fun i => x i+2/r i) x d tb)
    have hk := phaseIndex_bounds hodd
    have hlo : -Real.pi < Phase.totalPhase (fun i => x i+2/r i) x d tb - 2*Real.pi*k := by
      dsimp [k]; nlinarith [hk.1]
    have hhi : Phase.totalPhase (fun i => x i+2/r i) x d tb - 2*Real.pi*k < Real.pi := by
      dsimp [k]; nlinarith [hk.2]
    have hroots := no_unit_roots_of_cayley_nonzero (characteristic_eval_conj r x d b)
      (characteristic_point_ne_zero hn hr hx d htb.le hBeq hlo hhi)
      (characteristic_eval_neg_one_ne_zero hr hx d hb hbound)
    rw [schur_iff_countOutside_zero (characteristic_ne_zero hr hx hd b) hroots]
    have hc := root_count hn hd hr hx htb hBeq hbound hodd
    have hz : countOutside (characteristic r x d b) = 0 ↔
        phaseIndex (Phase.totalPhase (fun i => x i+2/r i) x d tb) = 0 := by omega
    rw [hz, phaseIndex_eq_zero_iff hp.le]
  · push_neg at hodd
    obtain ⟨k, he⟩ := hodd
    have hroot : (characteristic r x d b).eval (point tb) = 0 := by
      rw [characteristic_point_zero_iff_gain_phase hr x d hb]
      exact ⟨hBeq, by rw [he]; exact exp_odd_pi k⟩
    have hns : ¬ SchurStable (characteristic r x d b) := by
      intro hs
      have h := hs (point tb) hroot
      rw [point_norm] at h
      exact lt_irrefl _ h
    have hnlt : ¬ Phase.totalPhase (fun i => x i+2/r i) x d tb < Real.pi := by
      intro h
      exact nonodd_of_phase_lt_pi hp.le h k he
    exact iff_of_false hns hnlt

end C2.NGamma.Cayley
