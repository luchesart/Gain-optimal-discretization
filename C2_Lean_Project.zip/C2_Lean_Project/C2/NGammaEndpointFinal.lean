import C2.NGammaEndpointStability
import C2.NGammaGainInterval

/-! Final endpoint spectral conclusions. The open-interval stability hypothesis
of the closure lemma is discharged by the proved exact gain-interval theorem. -/
noncomputable section
open scoped BigOperators
namespace C2.NGamma.PolynomialModel

/-- At every feasible positive one-delay endpoint, all roots other than -1
are strictly inside the unit disk. -/
theorem endpoint_other_roots_inside {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) (hx1 : ∀ i, x i ≤ 1)
    (hS : Phase.endpointSum r x ≤ 1)
    {z : ℂ} (hz : (characteristic r x 1 (∏ i, (r i+2/x i))).eval z = 0)
    (hz1 : z ≠ -1) : ‖z‖ < 1 := by
  letI : Nonempty (Fin n) := ⟨⟨0,hn⟩⟩
  apply endpoint_other_roots_inside_of_stable_below hr hx
    (fun b hb hbound => Cayley.single_sample_endpoint_stable hn hr hx hx1 hS hb hbound) hz hz1

/-- Complete spectral clause for the saturated endpoint: exactly a double
root at -1, with every remaining root strictly inside the disk. All premises
are the physical design and resource assumptions from the manuscript. -/
theorem saturated_endpoint_spectrum {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) (hx1 : ∀ i, x i ≤ 1)
    (hS : ∑ i, 1 / (x i * (2+r i*x i)) = 1) :
    (characteristic r x 1 (∏ i, (r i+2/x i))).rootMultiplicity (-1) = 2 ∧
      ∀ z : ℂ, (characteristic r x 1 (∏ i, (r i+2/x i))).eval z = 0 →
        z ≠ -1 → ‖z‖ < 1 := by
  letI : Nonempty (Fin n) := ⟨⟨0,hn⟩⟩
  refine ⟨endpoint_root_multiplicity_two hr hx hS, ?_⟩
  intro z hz hz1
  apply endpoint_other_roots_inside hn hr hx hx1 _ hz hz1
  exact le_of_eq hS

end C2.NGamma.PolynomialModel
