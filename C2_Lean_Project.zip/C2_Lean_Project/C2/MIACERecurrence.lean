import C2.MIACEAreas

/-!
# Actual one-delay tracking recurrence

Nonnegativity is characterized without invoking an unformalized oscillation
argument. In the negative-discriminant case the positive successive-error
ratios would decrease by a fixed positive amount, which is impossible.
-/

noncomputable section
open scoped BigOperators Topology
open Filter

namespace C2.MIACE

def ErrorRecurrence (A B : ℝ) (e : ℕ → ℝ) : Prop :=
  e 0 = 1 ∧ e 1 = A ∧ ∀ n, e (n + 2) = A * e (n + 1) - B * e n

theorem recurrence_nonnegative_of_root_bound {A B : ℝ} {e : ℕ → ℝ}
    (hB : 0 ≤ B) (h : ErrorRecurrence A B e) (hA : 2 * Real.sqrt B ≤ A) :
    ∀ n, 0 ≤ e n := by
  rcases h with ⟨h₀, h₁, hr⟩
  have hs := Real.sqrt_nonneg B
  have hs2 := Real.sq_sqrt hB
  have hind : ∀ n, 0 ≤ e n ∧ Real.sqrt B * e n ≤ e (n + 1) := by
    intro n
    induction n with
    | zero =>
      simp only [Nat.zero_add, h₀, h₁, mul_one]
      constructor <;> linarith
    | succ n ih =>
      have hn1 : 0 ≤ e (n + 1) := le_trans (mul_nonneg hs ih.1) ih.2
      refine ⟨hn1, ?_⟩
      rw [show n + 1 + 1 = n + 2 by omega, hr]
      have hmul := mul_nonneg (by linarith : 0 ≤ A - Real.sqrt B)
        (sub_nonneg.mpr ih.2)
      have hmul' := mul_nonneg (by linarith : 0 ≤ A - 2 * Real.sqrt B)
        (mul_nonneg hs ih.1)
      conv_rhs => rw [← hs2]
      nlinarith
  exact fun n => (hind n).1

theorem recurrence_positive_of_nonnegative {A B : ℝ} {e : ℕ → ℝ}
    (hB : 0 < B) (h : ErrorRecurrence A B e) (he : ∀ n, 0 ≤ e n) :
    ∀ n, 0 < e n := by
  intro n
  induction n with
  | zero => rw [h.1]; norm_num
  | succ n ih =>
    by_contra hn
    have hn1 : e (n + 1) = 0 := le_antisymm (le_of_not_gt hn) (he _)
    have hrec := h.2.2 n
    rw [hn1, mul_zero, zero_sub] at hrec
    have hp := mul_pos hB ih
    have hn2 := he (n + 2)
    linarith

theorem recurrence_root_bound_of_nonnegative {A B : ℝ} {e : ℕ → ℝ}
    (hB : 0 ≤ B) (h : ErrorRecurrence A B e) (he : ∀ n, 0 ≤ e n) :
    2 * Real.sqrt B ≤ A := by
  have hA : 0 ≤ A := by rw [← h.2.1]; exact he 1
  by_contra hbad
  have hAlt : A < 2 * Real.sqrt B := lt_of_not_ge hbad
  have hs2 := Real.sq_sqrt hB
  have hs := Real.sqrt_nonneg B
  have hdisc : A ^ 2 < 4 * B := by nlinarith
  have hBp : 0 < B := by nlinarith [sq_nonneg A]
  have hep := recurrence_positive_of_nonnegative hBp h he
  have hAp : 0 < A := by rw [← h.2.1]; exact hep 1
  let r : ℕ → ℝ := fun n => e (n + 1) / e n
  have hrp : ∀ n, 0 < r n := fun n => div_pos (hep _) (hep _)
  have hr0 : r 0 = A := by simp [r, h.1, h.2.1]
  have hre : ∀ n, r n * r (n + 1) = A * r n - B := by
    intro n
    dsimp [r]
    rw [show n + 1 + 1 = n + 2 by omega, h.2.2 n]
    field_simp [ne_of_gt (hep n), ne_of_gt (hep (n + 1))]
    ring
  have hrle : ∀ n, r n ≤ A := by
    intro n
    cases n with
    | zero => rw [hr0]
    | succ n =>
      apply (mul_le_mul_left (hrp n)).mp
      nlinarith [hre n]
  let δ : ℝ := B - A ^ 2 / 4
  have hδ : 0 < δ := by dsimp [δ]; linarith
  have hdrop : ∀ n, A * r (n + 1) ≤ A * r n - δ := by
    intro n
    have hrec := hre n
    have hsquare := sq_nonneg (r n - A / 2)
    have hbase : δ ≤ r n * (r n - r (n + 1)) := by
      dsimp [δ]
      nlinarith
    have hdiff : 0 < r n - r (n + 1) := by
      have hp := hrp n
      nlinarith
    have hm := mul_le_mul_of_nonneg_right (hrle n) hdiff.le
    nlinarith
  have hind : ∀ n, A * r n ≤ A * r 0 - (n : ℝ) * δ := by
    intro n
    induction n with
    | zero => simp
    | succ n ih =>
      have hd := hdrop n
      push_cast
      linarith
  obtain ⟨n, hn⟩ := exists_nat_gt (A * r 0 / δ)
  have hlarge : A * r 0 < (n : ℝ) * δ := (div_lt_iff₀ hδ).mp hn
  have hlast := hind n
  have hp := mul_pos hAp (hrp n)
  linarith

theorem recurrence_nonnegative_iff {A B : ℝ} {e : ℕ → ℝ}
    (hB : 0 ≤ B) (h : ErrorRecurrence A B e) :
    (∀ n, 0 ≤ e n) ↔ 2 * Real.sqrt B ≤ A :=
  ⟨recurrence_root_bound_of_nonnegative hB h,
    recurrence_nonnegative_of_root_bound hB h⟩

theorem monotone_bound_iff {γ a : ℝ} (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (ha : 0 < a) :
    2 * Real.sqrt (a * (1 - γ)) ≤ 1 - a * γ ↔
      a ≤ 1 / (1 + Real.sqrt (1 - γ)) ^ 2 := by
  let s := Real.sqrt (1 - γ)
  let t := Real.sqrt a
  have hs : 0 ≤ s := Real.sqrt_nonneg _
  have ht : 0 ≤ t := Real.sqrt_nonneg _
  have hs2 : s ^ 2 = 1 - γ := Real.sq_sqrt (by linarith)
  have ht2 : t ^ 2 = a := Real.sq_sqrt ha.le
  have hs1 : s ≤ 1 := by nlinarith
  have hprod : Real.sqrt (a * (1 - γ)) = t * s := by
    exact Real.sqrt_mul ha.le _
  have hfactor : 1 - a * γ - 2 * (t * s) = (1 - t * (1 + s)) * (1 + t * (1 - s)) := by
    have hγ : γ = 1 - s ^ 2 := by linarith
    rw [← ht2, hγ]
    ring
  have hs1sub : 0 ≤ 1 - s := by linarith
  have hfpos : 0 < 1 + t * (1 - s) := by positivity
  have hsqpos : 0 < (1 + s) ^ 2 := by positivity
  have hL : 0 ≤ t * (1 + s) := by positivity
  have hLsq : (t * (1 + s)) ^ 2 = a * (1 + s) ^ 2 := by rw [mul_pow, ht2]
  rw [hprod]
  change 2 * (t * s) ≤ 1 - a * γ ↔ a ≤ 1 / (1 + s) ^ 2
  rw [le_div_iff₀ hsqpos]
  constructor
  · intro hbound
    have hp : 0 ≤ (1 - t * (1 + s)) * (1 + t * (1 - s)) := by linarith
    have hfirst : 0 ≤ 1 - t * (1 + s) := (mul_nonneg_iff_of_pos_right hfpos).mp hp
    nlinarith
  · intro hbound
    have hfirst : 0 ≤ 1 - t * (1 + s) := by nlinarith
    have hp := mul_nonneg hfirst hfpos.le
    linarith

theorem error_nonnegative_iff_monotone_bound {γ a : ℝ} {e : ℕ → ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (ha : 0 < a)
    (h : ErrorRecurrence (1 - a * γ) (a * (1 - γ)) e) :
    (∀ n, 0 ≤ e n) ↔ a ≤ 1 / (1 + Real.sqrt (1 - γ)) ^ 2 := by
  exact (recurrence_nonnegative_iff (mul_nonneg ha.le (by linarith)) h).trans
    (monotone_bound_iff hγ0 hγ1 ha)

theorem error_antitone_of_nonnegative {γ a : ℝ} {e : ℕ → ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (ha : 0 < a)
    (h : ErrorRecurrence (1 - a * γ) (a * (1 - γ)) e)
    (he : ∀ n, 0 ≤ e n) : Antitone e := by
  apply antitone_nat_of_succ_le
  intro n
  cases n with
  | zero =>
    rw [h.1, h.2.1]
    nlinarith [mul_nonneg ha.le hγ0]
  | succ n =>
    rw [show n + 1 + 1 = n + 2 by omega, h.2.2 n]
    have hm1 := mul_nonneg (mul_nonneg ha.le hγ0) (he (n + 1))
    have hm2 := mul_nonneg (mul_nonneg ha.le (by linarith : 0 ≤ 1 - γ)) (he n)
    nlinarith

theorem response_and_command_bounds {γ a : ℝ} {e : ℕ → ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (ha : 0 < a)
    (h : ErrorRecurrence (1 - a * γ) (a * (1 - γ)) e)
    (he : ∀ n, 0 ≤ e n) :
    Monotone (fun n => 1 - e n) ∧ Monotone (fun n => 1 - e (n + 1)) ∧
    (∀ n, 0 ≤ 1 - e n ∧ 1 - e n ≤ 1) ∧
    (∀ n, 0 ≤ 1 - e (n + 1) ∧ 1 - e (n + 1) ≤ 1) := by
  have hanti := error_antitone_of_nonnegative hγ0 hγ1 ha h he
  have hb : ∀ n, e n ≤ 1 := fun n => by simpa only [h.1] using hanti (Nat.zero_le n)
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro m n hmn
    exact sub_le_sub_left (hanti hmn) 1
  · intro m n hmn
    exact sub_le_sub_left (hanti (Nat.add_le_add_right hmn 1)) 1
  · intro n
    constructor <;> linarith [hb n, he n]
  · intro n
    constructor <;> linarith [hb (n + 1), he (n + 1)]

theorem nonnegative_error_summable {γ a : ℝ} {e : ℕ → ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (ha : 0 < a)
    (h : ErrorRecurrence (1 - a * γ) (a * (1 - γ)) e)
    (he : ∀ n, 0 ≤ e n) : Summable e := by
  have hanti := error_antitone_of_nonnegative hγ0 hγ1 ha h he
  have hA : 0 ≤ 1 - a * γ := by rw [← h.2.1]; exact he 1
  have hstep : ∀ n, e (n + 2) ≤ (1 - a) * e n := by
    intro n
    rw [h.2.2 n]
    have hm := mul_le_mul_of_nonneg_left (hanti (Nat.le_succ n)) hA
    nlinarith
  have ha1 : a ≤ 1 := by
    have hb := hstep 0
    rw [h.1] at hb
    nlinarith [he 2]
  have hev : ∀ n, e (2 * n) ≤ (1 - a) ^ n := by
    intro n
    induction n with
    | zero => simp [h.1]
    | succ n ih =>
      rw [show 2 * (n + 1) = 2 * n + 2 by omega, pow_succ]
      exact (hstep (2 * n)).trans (by
        simpa only [mul_comm] using mul_le_mul_of_nonneg_left ih (by linarith : 0 ≤ 1 - a))
  have hod : ∀ n, e (2 * n + 1) ≤ (1 - a) ^ n := fun n =>
    (hanti (Nat.le_succ _)).trans (hev n)
  have hg := summable_geometric_of_lt_one (by linarith : 0 ≤ 1 - a) (by linarith : 1 - a < 1)
  have hsev : Summable (fun n => e (2 * n)) :=
    Summable.of_nonneg_of_le (fun n => he _) hev hg
  have hsod : Summable (fun n => e (2 * n + 1)) :=
    Summable.of_nonneg_of_le (fun n => he _) hod hg
  exact hsev.even_add_odd hsod

theorem tracking_error_sum {γ a : ℝ} {e : ℕ → ℝ} (ha : 0 < a)
    (h : ErrorRecurrence (1 - a * γ) (a * (1 - γ)) e) (hs : Summable e) :
    (∑' n, e n) = 1 / a := by
  have hsplit1 := hs.sum_add_tsum_nat_add 1
  have hsplit2 := hs.sum_add_tsum_nat_add 2
  simp only [Finset.sum_range_one, h.1] at hsplit1
  simp only [Finset.sum_range_succ, Finset.sum_range_zero, zero_add, h.1, h.2.1] at hsplit2
  have hs1 := (summable_nat_add_iff 1).2 hs
  have hr : (∑' n, e (n + 2)) =
      (1 - a * γ) * (∑' n, e (n + 1)) - (a * (1 - γ)) * (∑' n, e n) := by
    simp_rw [h.2.2]
    rw [Summable.tsum_sub (hs1.mul_left _) (hs.mul_left _), tsum_mul_left, tsum_mul_left]
  have ht1 : (∑' n, e (n + 1)) = (∑' n, e n) - 1 := by linarith
  have ht2 : (∑' n, e (n + 2)) = (∑' n, e n) - 1 - (1 - a * γ) := by linarith
  rw [ht1, ht2] at hr
  apply (eq_div_iff (ne_of_gt ha)).mpr
  nlinarith

theorem monotone_tracking_iff {γ a : ℝ} {e : ℕ → ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (ha : 0 < a)
    (h : ErrorRecurrence (1 - a * γ) (a * (1 - γ)) e) :
    (Monotone (fun n => 1 - e n) ∧
      Tendsto (fun n => 1 - e n) atTop (𝓝 1)) ↔
      a ≤ 1 / (1 + Real.sqrt (1 - γ)) ^ 2 := by
  constructor
  · rintro ⟨hmono, hlim⟩
    apply (error_nonnegative_iff_monotone_bound hγ0 hγ1 ha h).mp
    intro n
    have hb : 1 - e n ≤ 1 := hmono.ge_of_tendsto hlim n
    linarith
  · intro hbound
    have he := (error_nonnegative_iff_monotone_bound hγ0 hγ1 ha h).mpr hbound
    have hmono := (response_and_command_bounds hγ0 hγ1 ha h he).1
    have hs := nonnegative_error_summable hγ0 hγ1 ha h he
    refine ⟨hmono, ?_⟩
    simpa only [sub_zero] using tendsto_const_nhds.sub hs.tendsto_atTop_zero

end C2.MIACE
