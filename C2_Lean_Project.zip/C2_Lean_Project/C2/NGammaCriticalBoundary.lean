import C2.NGammaCriticalGain
import C2.NGammaBoundaryPair

/-! The unified critical gain is an actual unit-circle boundary of the
characteristic polynomial: either -1 or a distinct conjugate pair. -/
noncomputable section
open scoped ComplexConjugate
namespace C2.NGamma.Global
open PolynomialModel Cayley

/-- Every critical gain has an actual unit-circle root. -/
theorem criticalGain_has_unit_root {n : ℕ} {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) {B : ℝ} (hB : CriticalGain r x B) :
    ∃ z : ℂ, ‖z‖ = 1 ∧ (characteristic r x 1 B).eval z = 0 := by
  rcases hB with ⟨hx, _, rfl⟩ | ⟨t, ht, hphase, rfl⟩
  · exact ⟨-1, by simp, endpoint_is_root (fun i => ne_of_gt (hx i))⟩
  · have hroot := first_crossing_gives_unit_root hr x 1 t hphase
    exact ⟨point t, hroot.2, hroot.1⟩

/-- The gain boundary itself is not strictly Schur stable. -/
theorem criticalGain_not_schur {n : ℕ} {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) {B : ℝ} (hB : CriticalGain r x B) :
    ¬ SchurStable (characteristic r x 1 B) := by
  obtain ⟨z, hz, hroot⟩ := criticalGain_has_unit_root hr hB
  intro hs
  have h := hs z hroot
  rw [hz] at h
  exact lt_irrefl _ h

/-- The finite-frequency boundary contains the distinct conjugate unit pair;
the endpoint alternative has a root at -1. -/
theorem criticalGain_boundary_kind {n : ℕ} {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) {B : ℝ} (hB : CriticalGain r x B) :
    (characteristic r x 1 B).eval (-1) = 0 ∨
      ∃ t : ℝ, 0 < t ∧
        (characteristic r x 1 B).eval (point t) = 0 ∧
        (characteristic r x 1 B).eval (conj (point t)) = 0 ∧
        ‖point t‖ = 1 ∧ ‖conj (point t)‖ = 1 ∧ point t ≠ conj (point t) := by
  rcases hB with ⟨hx, _, rfl⟩ | ⟨t, ht, hphase, rfl⟩
  · exact Or.inl (endpoint_is_root (fun i => ne_of_gt (hx i)))
  · exact Or.inr ⟨t, ht, first_crossing_conjugate_pair hr x 1 ht hphase⟩

end C2.NGamma.Global
