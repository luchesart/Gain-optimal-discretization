C2 rational-delay optimization — Lean proof project, version 0.2.0
Formalization update: 8 November 2026

All 13 numbered arbitrary-order results in the current C2 development are
formalized, including exact Schur intervals, global gain optima, endpoint
root multiplicity, full-cube initial margins, rational state realizations
and actual asymptotic state stability. See C2_NGamma_Proof_Map_EN.csv.

The complete development map still contains 45 results: 20 COMPLETE,
3 CORE_COMPLETE, 4 PARTIAL, 18 NOT_FORMALIZED. This update closes the 13 new
results, not every older statement in the development manuscript.

Pinned environment: Lean 4.19.0; mathlib
c44e0c8ee63ca166450922a373c7409c5d26b00b.
95 proof modules; 903 explicit public theorem/lemma declarations;
1080 explicit public declarations audited. The 20 original modules and
their 237 theorem/lemma declarations are preserved unchanged.

Build and check:
  lake exe cache get
  lake build
  lake env lean live/C2_Live_Lean419.lean
  python tools/theorem_inventory.py
  python tools/run_axiom_audit.py

On memory-constrained machines, use python tools/build_sequential.py
in place of lake build after restoring the mathlib cache.
After changing proof sources, first run tools/make_single_file.py.
C2.lean imports every module. live/C2_Live_Lean419.lean is generated from
the same sources and was independently checked as one file. No online
live.lean website session is claimed.

AXIOM_CHECKLIST.md and work/axiom_audit.json document the full audit.
Only propext, Classical.choice and Quot.sound are allowed; sorryAx and
custom axioms cause failure. VERIFICATION.json records actual checks,
counts and hashes. Source-only distribution: dependencies and build caches
are omitted and are restored by Lake from the pinned manifest.

MANUSCRIPT_FORMALIZATION_NOTES.md records each numbered result and the
differences between its written and formal proof routes. The argument
principle is proved from complex polynomial factorization. Outer
monotonicity uses differentiable dual upper bounds. Neither is assumed.

Scope: positive cascades have arbitrary order; the optimized law has one
aligned sample of delay. Exact fixed-parameter stable intervals cover all
positive integer delays. The full-cube result optimizes the initial stable
interval and makes no claim about other disconnected stable components.
Independent discretization weights for a general rational plant belong to
the specified real state realization. Exact physical ZOH, fractional delay,
the general CAD implementation and the older MIACE results are not made
formal by this release. The map records those separate boundaries.

The earlier 17-result IJC map is historical. No publication or external
message was performed. Original build metadata are retained under
historical/20261026; the current verification files supersede them.
