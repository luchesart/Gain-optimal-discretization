import Mathlib

/-! Mathematical coverage of the gain axis by the adjacent cells of a finite
cut set. This is a semantic partition theorem; effective encodings and ordered
root isolation are separate algorithmic obligations. -/

open Set

namespace C2.CADCells

def Adjacent (cuts : Finset ℝ) (a b : ℝ) : Prop :=
  a ∈ cuts ∧ b ∈ cuts ∧ a < b ∧ ∀ c ∈ cuts, a < c → b ≤ c

noncomputable def cells (cuts : Finset ℝ) : Finset (ℝ × ℝ) := by
  classical
  exact (cuts.product cuts).filter fun c =>
    c.1 < c.2 ∧ ∀ z ∈ cuts, c.1 < z → c.2 ≤ z

theorem mem_cells_iff (cuts : Finset ℝ) (a b : ℝ) :
    (a,b) ∈ cells cuts ↔ Adjacent cuts a b := by
  classical
  simp [cells, Adjacent, and_assoc]

theorem no_cut_inside {cuts : Finset ℝ} {a b x : ℝ}
    (h : Adjacent cuts a b) (hx : x ∈ Ioo a b) : x ∉ cuts := by
  intro hxc
  exact (not_le_of_gt hx.2) (h.2.2.2 x hxc hx.1)

theorem exists_adjacent_of_between {cuts : Finset ℝ} {K x : ℝ}
    (hzero : 0 ∈ cuts) (hK : K ∈ cuts) (hx : x ∈ Ioo 0 K)
    (hxc : x ∉ cuts) :
    ∃ a b, Adjacent cuts a b ∧ x ∈ Ioo a b := by
  classical
  let lows := cuts.filter (fun c => c < x)
  let highs := cuts.filter (fun c => x < c)
  have hl : lows.Nonempty := ⟨0, Finset.mem_filter.mpr ⟨hzero,hx.1⟩⟩
  have hh : highs.Nonempty := ⟨K, Finset.mem_filter.mpr ⟨hK,hx.2⟩⟩
  let a := lows.max' hl
  let b := highs.min' hh
  have ha : a ∈ lows := Finset.max'_mem _ _
  have hb : b ∈ highs := Finset.min'_mem _ _
  obtain ⟨hac,hax⟩ := Finset.mem_filter.mp ha
  obtain ⟨hbc,hxb⟩ := Finset.mem_filter.mp hb
  have hnext : ∀ c ∈ cuts, a < c → b ≤ c := by
    intro c hc hac'
    have hcx : ¬ c < x := by
      intro hcx
      have hca : c ≤ a := Finset.le_max' lows c (Finset.mem_filter.mpr ⟨hc,hcx⟩)
      exact (not_le_of_gt hac') hca
    have hne : c ≠ x := by
      intro heq
      exact hxc (heq ▸ hc)
    have hxc' : x < c := lt_of_le_of_ne (le_of_not_gt hcx) (Ne.symm hne)
    exact Finset.min'_le highs c (Finset.mem_filter.mpr ⟨hc,hxc'⟩)
  exact ⟨a,b,⟨hac,hbc,lt_trans hax hxb,hnext⟩,hax,hxb⟩

theorem finite_cell_cover {cuts : Finset ℝ} {K x : ℝ}
    (hzero : 0 ∈ cuts) (hK : K ∈ cuts)
    (hbound : ∀ c ∈ cuts, c ∈ Icc 0 K) :
    (∃ c ∈ cells cuts, x ∈ Ioo c.1 c.2) ↔
      x ∈ Ioo 0 K ∧ x ∉ cuts := by
  constructor
  · rintro ⟨⟨a,b⟩,hc,hx⟩
    have h := (mem_cells_iff cuts a b).mp hc
    exact ⟨⟨lt_of_le_of_lt (hbound a h.1).1 hx.1,
      lt_of_lt_of_le hx.2 (hbound b h.2.1).2⟩,no_cut_inside h hx⟩
  · rintro ⟨hx,hxc⟩
    obtain ⟨a,b,hab,hxab⟩ := exists_adjacent_of_between hzero hK hx hxc
    exact ⟨(a,b),(mem_cells_iff cuts a b).mpr hab,hxab⟩

theorem adjacent_unique_at {cuts : Finset ℝ} {a b c d x : ℝ}
    (hab : Adjacent cuts a b) (hcd : Adjacent cuts c d)
    (hxab : x ∈ Ioo a b) (hxcd : x ∈ Ioo c d) : a = c ∧ b = d := by
  have hac : a = c := by
    apply le_antisymm
    · by_contra! hca
      have hda := hcd.2.2.2 a hab.1 hca
      linarith [hxab.1,hxcd.2]
    · by_contra! hac
      have hbc := hab.2.2.2 c hcd.1 hac
      linarith [hxcd.1,hxab.2]
  refine ⟨hac,le_antisymm ?_ ?_⟩
  · exact hab.2.2.2 d hcd.2.1 (hac ▸ hcd.2.2.1)
  · exact hcd.2.2.2 b hab.2.1 (hac ▸ hab.2.2.1)

theorem rational_sample_exists {cuts : Finset ℝ} {a b : ℝ}
    (h : Adjacent cuts a b) : ∃ q : ℚ, (q : ℝ) ∈ Ioo a b := by
  exact exists_rat_btwn h.2.2.1

theorem cut_union_coverage {cuts : Finset ℝ} {K : ℝ}
    (hzero : 0 ∈ cuts) (hK : K ∈ cuts)
    (hbound : ∀ c ∈ cuts, c ∈ Icc 0 K) :
    {x | ∃ c ∈ cells cuts, x ∈ Ioo c.1 c.2} = Ioo 0 K \ (cuts : Set ℝ) := by
  ext x
  exact finite_cell_cover hzero hK hbound

end C2.CADCells
