import C2.Schur
import Mathlib.Topology.Order.IntermediateValue

/-! # Cubic Jury inequalities and actual complex poles

The proof factors out a real root, whose existence follows from the
intermediate value theorem, and uses the quadratic root criterion.
No stability predicate is replaced by an algebraic definition.
-/

namespace C2

def CubicSchur (b c d : ℝ) : Prop :=
  ∀ z : ℂ, z ^ 3 + (b : ℂ) * z ^ 2 + (c : ℂ) * z + (d : ℂ) = 0 → ‖z‖ < 1

def CubicJury (b c d : ℝ) : Prop :=
  |d| < 1 ∧ 0 < 1+b+c+d ∧ 0 < 1-b+c-d ∧ 0 < 1-c+b*d-d^2

lemma cubic_has_real_root (b c d : ℝ) :
    ∃ r : ℝ, r ^ 3 + b*r^2 + c*r+d = 0 := by
  let R : ℝ := 1+|b|+|c|+|d|
  have hR : 1 ≤ R := by
    dsimp [R]
    linarith [abs_nonneg b, abs_nonneg c, abs_nonneg d]
  have hR0 : 0 < R := by linarith
  have hR2 : R ≤ R^2 := by nlinarith
  have hRident : R = 1+|b|+|c|+|d| := rfl
  have hb1 := mul_le_mul_of_nonneg_right (neg_abs_le b) (sq_nonneg R)
  have hb2 := mul_le_mul_of_nonneg_right (le_abs_self b) (sq_nonneg R)
  have hc1 := mul_le_mul_of_nonneg_right (neg_abs_le c) hR0.le
  have hc2 := mul_le_mul_of_nonneg_right (le_abs_self c) hR0.le
  have hcR := mul_le_mul_of_nonneg_left hR2 (abs_nonneg c)
  have hdR := mul_le_mul_of_nonneg_left (show (1:ℝ) ≤ R^2 by nlinarith) (abs_nonneg d)
  have hpositive : 0 < R^3+b*R^2+c*R+d := by
    have hi : R^3-(|b|+|c|+|d|)*R^2 = R^2 := by rw [hRident]; ring
    nlinarith [neg_abs_le d, sq_pos_of_pos hR0]
  have hnegative : (-R)^3+b*(-R)^2+c*(-R)+d < 0 := by
    have hi : R^3-(|b|+|c|+|d|)*R^2 = R^2 := by rw [hRident]; ring
    nlinarith [le_abs_self d, sq_pos_of_pos hR0]
  have hf : Continuous (fun x : ℝ => x^3+b*x^2+c*x+d) := by fun_prop
  exact intermediate_value_univ (-R) R hf ⟨hnegative.le, hpositive.le⟩

lemma factor_positive_aux {r u v : ℝ} (hr : -1 < r ∧ r < 1)
    (hv : -1 < r*v ∧ r*v < 1)
    (hp : 0 < 1+u+v) (hm : 0 < 1-u+v) : 0 < 1+r*u+r^2*v := by
  by_cases hr0 : 0 ≤ r
  · have h1 := mul_nonneg hr0 hp.le
    have h2 := mul_pos (by linarith : 0 < 1-r) (by linarith : 0 < 1-r*v)
    nlinarith
  · have h1 := mul_nonneg (by linarith : 0 ≤ -r) hm.le
    have h2 := mul_pos (by linarith : 0 < 1+r) (by linarith : 0 < 1+r*v)
    nlinarith

lemma cubicJury_factor_iff (r u v : ℝ) :
    CubicJury (u-r) (v-r*u) (-r*v) ↔
      |r| < 1 ∧ 0 < 1+u+v ∧ 0 < 1-u+v ∧ 0 < 1-v := by
  classical
  constructor
  · rintro ⟨hd, hp, hm, hf⟩
    have hrv : -1 < r*v ∧ r*v < 1 := by
      have := abs_lt.mp hd
      constructor <;> linarith
    have hplus : 0 < (1-r)*(1+u+v) := by nlinarith [hp]
    have hminus : 0 < (1+r)*(1-u+v) := by nlinarith [hm]
    have hlast : 0 < (1-v)*(1+r*u+r^2*v) := by nlinarith [hf]
    have hrlt : r < 1 := by
      by_contra h
      have hr1 : 1 ≤ r := le_of_not_gt h
      have hvlt : v < 1 := by
        by_contra hv
        have hv1 : 1 ≤ v := le_of_not_gt hv
        have := mul_le_mul_of_nonneg_left hv1 (by linarith : 0 ≤ r)
        nlinarith
      have hqp : 1+u+v < 0 := by
        by_contra hq
        have := mul_nonpos_of_nonpos_of_nonneg (by linarith : 1-r ≤ 0) (le_of_not_gt hq)
        linarith
      have h1 := mul_neg_of_pos_of_neg (by linarith : 0 < r) hqp
      have h2 := mul_nonpos_of_nonneg_of_nonpos (by linarith : 0 ≤ r-1) (by linarith : r*v-1 ≤ 0)
      have hs : 1+r*u+r^2*v < 0 := by nlinarith
      have := mul_neg_of_pos_of_neg (by linarith : 0 < 1-v) hs
      linarith
    have hrgt : -1 < r := by
      by_contra h
      have hr1 : r ≤ -1 := le_of_not_gt h
      have hvlt : v < 1 := by
        by_contra hv
        have hv1 : 1 ≤ v := le_of_not_gt hv
        have := mul_le_mul_of_nonpos_left hv1 (by linarith : r ≤ 0)
        nlinarith
      have hqm : 1-u+v < 0 := by
        by_contra hq
        have := mul_nonpos_of_nonpos_of_nonneg (by linarith : 1+r ≤ 0) (le_of_not_gt hq)
        linarith
      have h1 := mul_neg_of_pos_of_neg (by linarith : 0 < -r) hqm
      have h2 := mul_nonpos_of_nonpos_of_nonneg (by linarith : r+1 ≤ 0) (by linarith : 0 ≤ r*v+1)
      have hs : 1+r*u+r^2*v < 0 := by nlinarith
      have := mul_neg_of_pos_of_neg (by linarith : 0 < 1-v) hs
      linarith
    have hqp : 0 < 1+u+v := (mul_pos_iff_of_pos_left (by linarith : 0 < 1-r)).mp hplus
    have hqm : 0 < 1-u+v := (mul_pos_iff_of_pos_left (by linarith : 0 < 1+r)).mp hminus
    have hs := factor_positive_aux ⟨hrgt, hrlt⟩ hrv hqp hqm
    exact ⟨abs_lt.mpr ⟨hrgt,hrlt⟩, hqp, hqm, (mul_pos_iff_of_pos_right hs).mp hlast⟩
  · rintro ⟨hr, hp, hm, hv⟩
    have hrr := abs_lt.mp hr
    have hvabs : |v| < 1 := abs_lt.mpr ⟨by linarith, by linarith⟩
    have hprod : |r| * |v| < 1 := by
      calc
        |r| * |v| ≤ |r| * 1 := mul_le_mul_of_nonneg_left hvabs.le (abs_nonneg r)
        _ < 1 := by simpa using hr
    have hrv : -1 < r*v ∧ r*v < 1 := abs_lt.mp (by simpa [abs_mul] using hprod)
    have hp' := mul_pos (by linarith : 0 < 1-r) hp
    have hm' := mul_pos (by linarith : 0 < 1+r) hm
    have hf' := mul_pos hv (factor_positive_aux hrr hrv hp hm)
    refine ⟨?_, by nlinarith, by nlinarith, by nlinarith⟩
    simpa [abs_mul] using hprod

theorem cubicSchur_iff_factor {b c d r u v : ℝ}
    (hb : b = u-r) (hc : c = v-r*u) (hd : d = -r*v) :
    CubicSchur b c d ↔ |r| < 1 ∧ QuadraticSchur 1 u v := by
  have hfac (z : ℂ) : z^3+(b:ℂ)*z^2+(c:ℂ)*z+(d:ℂ) =
      (z-(r:ℂ)) * ((1:ℂ)*z^2+(u:ℂ)*z+(v:ℂ)) := by
    rw [hb, hc, hd]
    push_cast
    ring
  constructor
  · intro hs
    constructor
    · have := hs (r:ℂ) (by rw [hfac]; simp)
      simpa using this
    · intro z hz
      apply hs z
      rw [hfac]
      have hz' : (1:ℂ)*z^2+(u:ℂ)*z+(v:ℂ)=0 := by simpa using hz
      rw [hz', mul_zero]
  · rintro ⟨hr,hq⟩ z hz
    rw [hfac] at hz
    rcases mul_eq_zero.mp hz with h | h
    · have : z = (r:ℂ) := sub_eq_zero.mp h
      simpa [this] using hr
    · exact hq z h

theorem cubicSchur_iff (b c d : ℝ) :
    CubicSchur b c d ↔
      |d| < 1 ∧ 0 < 1+b+c+d ∧ 0 < 1-b+c-d ∧ 0 < 1-c+b*d-d^2 := by
  obtain ⟨r,hr⟩ := cubic_has_real_root b c d
  let u := b+r
  let v := c+r*u
  have hb : b = u-r := by dsimp [u]; ring
  have hc : c = v-r*u := by dsimp [v]; ring
  have hd : d = -r*v := by dsimp [v,u]; nlinarith [hr]
  rw [cubicSchur_iff_factor hb hc hd, quadraticSchur_iff (by norm_num : (0:ℝ)<1)]
  simpa [CubicJury, hb, hc, hd] using (cubicJury_factor_iff r u v).symm

end C2
