import C2.PoleZeroSchur

namespace C2.PoleZero

/-- Every fixed-parameter positive stable gain set is open. -/
theorem stable_gain_set_isOpen {r η γ : ℝ} (hr : 0 ≤ r) (hγ : 0 ≤ γ) :
    IsOpen {a : ℝ | Stable r η γ a} := by
  have heq : {a : ℝ | Stable r η γ a} =
      {a : ℝ | 0 < a} ∩ {a : ℝ | 0 < 2 + (2*γ-1)*r + a*(1-2*γ-2*η)} ∩
      {a : ℝ | 0 < 1+r*γ-a*(1-γ-η)} := by
    ext a
    simp only [Set.mem_inter_iff, Set.mem_setOf_eq]
    rw [stable_iff_jury hr hγ]
    unfold Jury
    constructor
    · rintro ⟨h₁,h₂,h₃⟩
      exact ⟨⟨h₁,by nlinarith⟩,h₃⟩
    · rintro ⟨⟨h₁,h₂⟩,h₃⟩
      exact ⟨h₁,by nlinarith,h₃⟩
  rw [heq]
  exact ((isOpen_lt continuous_const continuous_id).inter
    (isOpen_lt continuous_const (by fun_prop))).inter
      (isOpen_lt continuous_const (by fun_prop))

/-- Affine Jury inequalities make the positive stable set order convex,
including the empty case and intervals whose lower endpoint is positive. -/
theorem stable_gain_set_ordConnected {r η γ : ℝ} (hr : 0 ≤ r) (hγ : 0 ≤ γ) :
    Set.OrdConnected {a : ℝ | Stable r η γ a} := by
  refine ⟨?_⟩
  intro x hx y hy z hz
  have hx' := (stable_iff_jury hr hγ).mp hx
  have hy' := (stable_iff_jury hr hγ).mp hy
  apply (stable_iff_jury hr hγ).mpr
  unfold Jury at hx' hy' ⊢
  obtain ⟨hx0,hx1,hx2⟩ := hx'
  obtain ⟨hy0,hy1,hy2⟩ := hy'
  obtain ⟨hxz,hzy⟩ := hz
  refine ⟨lt_of_lt_of_le hx0 hxz,?_,?_⟩
  · by_cases hc : 0 ≤ 1 - 2 * γ - 2 * η
    · nlinarith [mul_nonneg hc (sub_nonneg.mpr hxz)]
    · nlinarith [mul_nonneg_of_nonpos_of_nonpos (le_of_not_ge hc) (sub_nonpos.mpr hzy)]
  · by_cases hc : 0 ≤ 1 - γ - η
    · nlinarith [mul_nonneg hc (sub_nonneg.mpr hzy)]
    · nlinarith [mul_nonneg_of_nonpos_of_nonpos (le_of_not_ge hc) (sub_nonpos.mpr hxz)]

theorem stable_gain_set_bddAbove {r η γ : ℝ} (hr : 0 ≤ r) (hγ : 0 ≤ γ) :
    BddAbove {a : ℝ | Stable r η γ a} := by
  refine ⟨4+r*(4*γ-1),?_⟩
  intro a ha
  have h := (stable_iff_jury hr hγ).mp ha
  unfold Jury at h
  nlinarith [h.2.1,h.2.2]

/-- Full interval formulation: the positive stable gain set is either empty
or one bounded open interval. Its lower endpoint is not assumed to be zero. -/
theorem stable_gain_set_empty_or_open_interval {r η γ : ℝ}
    (hr : 0 ≤ r) (hγ : 0 ≤ γ) :
    {a : ℝ | Stable r η γ a} = ∅ ∨
      ∃ lo hi : ℝ, lo < hi ∧ {a : ℝ | Stable r η γ a} = Set.Ioo lo hi := by
  let S : Set ℝ := {a : ℝ | Stable r η γ a}
  by_cases hS : S.Nonempty
  · right
    have hb : BddBelow S := ⟨0,fun _ ha => ha.1.le⟩
    have ht : BddAbove S := stable_gain_set_bddAbove hr hγ
    have ho : IsOpen S := stable_gain_set_isOpen hr hγ
    have hc : Set.OrdConnected S := stable_gain_set_ordConnected hr hγ
    have heq : S = Set.Ioo (sInf S) (sSup S) := by
      ext a
      constructor
      · intro ha
        obtain ⟨lo,hi,⟨hla,hah⟩,hsub⟩ := mem_nhds_iff_exists_Ioo_subset.mp (ho.mem_nhds ha)
        obtain ⟨l,hll,hla'⟩ := exists_between hla
        obtain ⟨h,hah',hhh⟩ := exists_between hah
        have hlS : l ∈ S := hsub ⟨hll,hla'.trans hah⟩
        have hhS : h ∈ S := hsub ⟨hla.trans hah',hhh⟩
        exact ⟨(csInf_le hb hlS).trans_lt hla',hah'.trans_le (le_csSup ht hhS)⟩
      · rintro ⟨hl,hh⟩
        obtain ⟨l,hlS,hla⟩ := exists_lt_of_csInf_lt hS hl
        obtain ⟨h,hhS,hah⟩ := exists_lt_of_lt_csSup hS hh
        exact hc.out hlS hhS ⟨hla.le,hah.le⟩
    obtain ⟨a,ha⟩ := hS
    have ha' : a ∈ Set.Ioo (sInf S) (sSup S) := heq ▸ ha
    exact ⟨sInf S,sSup S,ha'.1.trans ha'.2,heq⟩
  · left
    exact Set.not_nonempty_iff_eq_empty.mp hS

end C2.PoleZero
