import C2.NGammaPolynomial
import C2.NGammaPhaseCrossing
import Mathlib.Analysis.SpecialFunctions.Complex.Arg

/-! Exact Cayley-coordinate bridge from the actual characteristic polynomial to
its analytic amplitude and phase on the unit circle. -/

noncomputable section
open scoped BigOperators

namespace C2.NGamma.Cayley

open PolynomialModel

def point (t : ℝ) : ℂ := (1 + Complex.I * t) / (1 - Complex.I * t)

def amplitudeFactor (r x t : ℝ) : ℝ :=
  r * Real.sqrt (1 + ((x + 2 / r) * t) ^ 2) /
    Real.sqrt (1 + (x * t) ^ 2)

def amplitude {n : ℕ} (r x : Fin n → ℝ) (t : ℝ) : ℝ :=
  ∏ i, amplitudeFactor (r i) (x i) t

def transfer {n : ℕ} (r x : Fin n → ℝ) (d : ℕ) (z : ℂ) : ℂ :=
  z ^ d * ∏ i, (factor (r i) (x i)).eval z / (q (x i)).eval z

lemma one_add_I_mul_ne_zero (s : ℝ) : 1 + Complex.I * (s : ℂ) ≠ 0 := by
  intro h
  have := congrArg Complex.re h
  simpa using this

lemma one_sub_I_mul_ne_zero (s : ℝ) : 1 - Complex.I * (s : ℂ) ≠ 0 := by
  intro h
  have := congrArg Complex.re h
  simpa using this

lemma linear_polar (s : ℝ) :
    1 + Complex.I * (s : ℂ) =
      (Real.sqrt (1+s^2) : ℂ) * Complex.exp ((Real.arctan s : ℂ) * Complex.I) := by
  have hpos : 0 < Real.sqrt (1+s^2) := Real.sqrt_pos.2 (by positivity)
  rw [Complex.exp_mul_I, ← Complex.ofReal_cos, ← Complex.ofReal_sin,
    Real.cos_arctan, Real.sin_arctan]
  have hn : (Real.sqrt (1+s^2) : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hpos
  push_cast
  field_simp
  ring

lemma q_eval_point (x t : ℝ) :
    (q x).eval (point t) = (1 + Complex.I * (x*t : ℝ)) / (1 - Complex.I * t) := by
  rw [q_eval, point]
  push_cast
  field_simp [one_sub_I_mul_ne_zero t]
  ring

lemma q_eval_point_ne_zero (x t : ℝ) : (q x).eval (point t) ≠ 0 := by
  rw [q_eval_point]
  exact div_ne_zero (one_add_I_mul_ne_zero (x*t)) (one_sub_I_mul_ne_zero t)

lemma factor_eval_point (r x t : ℝ) :
    (factor r x).eval (point t) =
      ((r : ℂ) + Complex.I * ((r*x+2)*t : ℝ)) / (1 - Complex.I*t) := by
  rw [factor_eval, q_eval_point, point]
  push_cast
  field_simp [one_sub_I_mul_ne_zero t]
  ring

lemma factor_div_q_point {r : ℝ} (hr : r ≠ 0) (x t : ℝ) :
    (factor r x).eval (point t) / (q x).eval (point t) =
      (r : ℂ) * (1+Complex.I*((x+2/r)*t : ℝ)) /
        (1+Complex.I*(x*t : ℝ)) := by
  rw [factor_eval_point, q_eval_point]
  have hrc : (r : ℂ) ≠ 0 := by exact_mod_cast hr
  push_cast
  field_simp [one_sub_I_mul_ne_zero t, one_add_I_mul_ne_zero (x*t), hrc]
  ring

lemma point_exp (t : ℝ) :
    point t = Complex.exp (((2 * Real.arctan t : ℝ) : ℂ) * Complex.I) := by
  have hpos : 0 < Real.sqrt (1+t^2) := Real.sqrt_pos.2 (by positivity)
  have hn : (Real.sqrt (1+t^2) : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hpos
  have hneg : (1 - Complex.I * (t : ℂ)) =
      (Real.sqrt (1+t^2) : ℂ) * Complex.exp (-(Real.arctan t : ℂ)*Complex.I) := by
    simpa using linear_polar (-t)
  rw [point, linear_polar, hneg, mul_div_mul_left _ _ hn, ← Complex.exp_sub]
  congr 1
  push_cast
  ring

lemma point_norm (t : ℝ) : ‖point t‖ = 1 := by
  rw [point_exp]
  exact Complex.norm_exp_ofReal_mul_I _

lemma amplitudeFactor_pos {r : ℝ} (hr : 0 < r) (x t : ℝ) :
    0 < amplitudeFactor r x t := by
  unfold amplitudeFactor
  positivity

lemma amplitude_pos {n : ℕ} {r : Fin n → ℝ} (hr : ∀ i, 0 < r i)
    (x : Fin n → ℝ) (t : ℝ) : 0 < amplitude r x t := by
  exact Finset.prod_pos (fun i _ => amplitudeFactor_pos (hr i) (x i) t)

lemma factor_div_q_polar {r : ℝ} (hr : r ≠ 0) (x t : ℝ) :
    (factor r x).eval (point t) / (q x).eval (point t) =
      (amplitudeFactor r x t : ℂ) *
        Complex.exp ((Phase.contribution (x+2/r) x t : ℂ) * Complex.I) := by
  rw [factor_div_q_point hr, linear_polar, linear_polar]
  simp only [amplitudeFactor, Phase.contribution, Complex.ofReal_div, Complex.ofReal_mul,
    Complex.ofReal_sub, sub_mul, Complex.exp_sub]
  ring

lemma transfer_polar {n : ℕ} {r : Fin n → ℝ} (hr : ∀ i, r i ≠ 0)
    (x : Fin n → ℝ) (d : ℕ) (t : ℝ) :
    transfer r x d (point t) = (amplitude r x t : ℂ) *
      Complex.exp ((Phase.totalPhase (fun i => x i + 2/r i) x d t : ℂ) * Complex.I) := by
  unfold transfer
  simp_rw [factor_div_q_polar (hr _)]
  rw [point_exp, Finset.prod_mul_distrib, ← Complex.exp_nat_mul, ← Complex.exp_sum]
  simp only [amplitude, Phase.totalPhase, Complex.ofReal_add, Complex.ofReal_sum,
    Complex.ofReal_mul, Complex.ofReal_natCast, Complex.ofReal_ofNat, Complex.ofReal_prod]
  rw [add_mul, Complex.exp_add, Finset.sum_mul]
  have he : (d : ℂ) * (2 * (Real.arctan t : ℂ) * Complex.I) =
      2 * d * Real.arctan t * Complex.I := by ring
  rw [he]
  ring

lemma characteristic_eval_point {n : ℕ} (r x : Fin n → ℝ) (d : ℕ) (b t : ℝ) :
    (characteristic r x d b).eval (point t) =
      (∏ i, (q (x i)).eval (point t)) * (transfer r x d (point t) + b) := by
  simp only [characteristic, Polynomial.eval_add, Polynomial.eval_mul,
    Polynomial.eval_pow, Polynomial.eval_prod, Polynomial.eval_X, Polynomial.eval_C,
    transfer]
  rw [Finset.prod_div_distrib]
  have hn : (∏ i, (q (x i)).eval (point t)) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (fun i _ => q_eval_point_ne_zero (x i) t)
  field_simp

lemma characteristic_point_zero_iff {n : ℕ} {r : Fin n → ℝ}
    (hr : ∀ i, r i ≠ 0) (x : Fin n → ℝ) (d : ℕ) (b t : ℝ) :
    (characteristic r x d b).eval (point t) = 0 ↔
      (amplitude r x t : ℂ) *
        Complex.exp ((Phase.totalPhase (fun i => x i+2/r i) x d t : ℂ) * Complex.I) + b = 0 := by
  rw [characteristic_eval_point, transfer_polar hr]
  exact mul_eq_zero.trans (or_iff_right
    (Finset.prod_ne_zero_iff.mpr (fun i _ => q_eval_point_ne_zero (x i) t)))

lemma transfer_norm {n : ℕ} {r : Fin n → ℝ} (hr : ∀ i, 0 < r i)
    (x : Fin n → ℝ) (d : ℕ) (t : ℝ) :
    ‖transfer r x d (point t)‖ = amplitude r x t := by
  rw [transfer_polar (fun i => ne_of_gt (hr i)), norm_mul,
    Complex.norm_real, Complex.norm_exp_ofReal_mul_I, mul_one,
    Real.norm_eq_abs, abs_of_pos (amplitude_pos hr x t)]

lemma characteristic_point_zero_iff_gain_phase {n : ℕ} {r : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (x : Fin n → ℝ) (d : ℕ) {b : ℝ} (hb : 0 ≤ b)
    (t : ℝ) :
    (characteristic r x d b).eval (point t) = 0 ↔
      amplitude r x t = b ∧
        Complex.exp ((Phase.totalPhase (fun i => x i+2/r i) x d t : ℂ) * Complex.I) = -1 := by
  rw [characteristic_point_zero_iff (fun i => ne_of_gt (hr i))]
  set B := amplitude r x t
  set E := Complex.exp ((Phase.totalPhase (fun i => x i+2/r i) x d t : ℂ) * Complex.I)
  have hB : 0 < B := amplitude_pos hr x t
  have hBn : (B : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hB
  have hE : ‖E‖ = 1 := Complex.norm_exp_ofReal_mul_I _
  constructor
  · intro he
    have he' : (B : ℂ)*E = -(b : ℂ) := by linear_combination he
    have hn := congrArg norm he'
    simp only [norm_mul, Complex.norm_real, hE, mul_one, norm_neg,
      Real.norm_eq_abs, abs_of_pos hB, abs_of_nonneg hb] at hn
    refine ⟨hn, ?_⟩
    apply (mul_left_cancel₀ hBn)
    rw [he', hn]
    ring
  · rintro ⟨hbE, hphase⟩
    rw [hbE, hphase]
    ring

lemma first_crossing_gives_unit_root {n : ℕ} {r : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (x : Fin n → ℝ) (d : ℕ) (t : ℝ)
    (hphase : Phase.totalPhase (fun i => x i+2/r i) x d t = Real.pi) :
    (characteristic r x d (amplitude r x t)).eval (point t) = 0 ∧ ‖point t‖ = 1 := by
  refine ⟨?_, point_norm t⟩
  rw [characteristic_point_zero_iff_gain_phase hr x d (le_of_lt (amplitude_pos hr x t))]
  exact ⟨rfl, by rw [hphase]; exact Complex.exp_pi_mul_I⟩

end C2.NGamma.Cayley
