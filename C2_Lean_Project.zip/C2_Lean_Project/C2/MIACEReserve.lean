import C2.MIACEAreas

/-!
# Exact gain-reserve optimization

Use `x = sqrt (1 - gamma)`. The constraints below are the monotonicity
bound and the two weak Jury inequalities at the prescribed reserve gain.
This module proves the optimization of these explicit inequalities; the
response-level equivalence is a separate obligation.
-/

noncomputable section

namespace C2.MIACE

def ReserveFeasible (R x a : ℝ) : Prop :=
  0 ≤ x ∧ x ≤ 1 ∧ 0 < a ∧ a * (1 + x) ^ 2 ≤ 1 ∧
    R * a * x ^ 2 ≤ 1 ∧ R * a * (1 - 2 * x ^ 2) ≤ 2

def reserveX (R : ℝ) : ℝ :=
  (Real.sqrt (2 * R * (R - 1)) - 2) / (2 * (R + 1))

def reserveOptimizerX (R : ℝ) : ℝ :=
  if R ≤ 2 then 0 else if R < 9 then reserveX R else 1 / 2

def reserveOptimizerGain (R : ℝ) : ℝ :=
  if R ≤ 2 then 1 else if R < 9 then 1 / (1 + reserveX R) ^ 2 else 4 / R

theorem feasible_gain_le_one {R x a : ℝ} (h : ReserveFeasible R x a) : a ≤ 1 := by
  rcases h with ⟨hx, _, ha, hm, _, _⟩
  have hs : 1 ≤ (1 + x) ^ 2 := by nlinarith
  have hp := mul_le_mul_of_nonneg_left hs ha.le
  nlinarith

theorem feasible_gain_one_unique {R x : ℝ} (h : ReserveFeasible R x 1) : x = 0 := by
  rcases h with ⟨hx, _, _, hm, _, _⟩
  nlinarith

theorem reserve_small_feasible {R : ℝ} (hR : 1 < R) (hR2 : R ≤ 2) :
    ReserveFeasible R 0 1 := by
  constructor
  · norm_num
  constructor
  · norm_num
  constructor
  · norm_num
  constructor
  · norm_num
  constructor
  · norm_num
  · simpa using hR2

theorem feasible_reserved_gain_le_four {R x a : ℝ} (h : ReserveFeasible R x a) :
    R * a ≤ 4 := by
  rcases h with ⟨_, _, _, _, h₁, h₂⟩
  nlinarith

theorem reserve_large_feasible {R : ℝ} (hR : 9 ≤ R) :
    ReserveFeasible R (1 / 2) (4 / R) := by
  have hRp : 0 < R := by linarith
  have hRn : R ≠ 0 := ne_of_gt hRp
  refine ⟨by norm_num, by norm_num, by positivity, ?_, ?_, ?_⟩
  · norm_num
    apply (div_le_iff₀ hRp).mpr
    nlinarith
  · field_simp
    norm_num
  · field_simp
    norm_num

theorem reserve_large_bound {R x a : ℝ} (hR : 9 ≤ R)
    (h : ReserveFeasible R x a) : a ≤ 4 / R := by
  apply (le_div_iff₀ (by linarith : 0 < R)).mpr
  nlinarith [feasible_reserved_gain_le_four h]

theorem reserve_large_unique {R x : ℝ} (hR : 9 ≤ R)
    (h : ReserveFeasible R x (4 / R)) : x = 1 / 2 := by
  have hRn : R ≠ 0 := by linarith
  rcases h with ⟨hx, _, _, _, h₁, h₂⟩
  field_simp [hRn] at h₁ h₂
  nlinarith

theorem reserveX_pos {R : ℝ} (hR : 2 < R) : 0 < reserveX R := by
  have harg : 0 ≤ 2 * R * (R - 1) := mul_nonneg (by linarith) (by linarith)
  have hs := Real.sq_sqrt harg
  have hsn := Real.sqrt_nonneg (2 * R * (R - 1))
  have hroot : 2 < Real.sqrt (2 * R * (R - 1)) := by nlinarith
  dsimp [reserveX]
  exact div_pos (by linarith) (by linarith)

theorem reserveX_lt_half {R : ℝ} (hR : 2 < R) (hR9 : R < 9) :
    reserveX R < 1 / 2 := by
  have harg : 0 ≤ 2 * R * (R - 1) := mul_nonneg (by linarith) (by linarith)
  have hs := Real.sq_sqrt harg
  have hsn := Real.sqrt_nonneg (2 * R * (R - 1))
  have hprod : (R - 9) * (R + 1) < 0 := mul_neg_of_neg_of_pos (by linarith) (by linarith)
  have hroot : Real.sqrt (2 * R * (R - 1)) < R + 3 := by nlinarith
  dsimp [reserveX]
  apply (div_lt_iff₀ (by linarith : 0 < 2 * (R + 1))).mpr
  linarith

theorem reserveX_equation {R : ℝ} (hR : 1 < R) :
    R * (1 - 2 * reserveX R ^ 2) = 2 * (1 + reserveX R) ^ 2 := by
  have harg : 0 ≤ 2 * R * (R - 1) := mul_nonneg (by linarith) (by linarith)
  have hs := Real.sq_sqrt harg
  have hden : 2 * (R + 1) ≠ 0 := by linarith
  generalize hz : Real.sqrt (2 * R * (R - 1)) = z at hs
  unfold reserveX
  rw [hz]
  field_simp [hden]
  nlinarith [congrArg (fun u : ℝ => (R + 1) * u) hs]

theorem reserve_middle_feasible {R : ℝ} (hR : 2 < R) (hR9 : R < 9) :
    ReserveFeasible R (reserveX R) (1 / (1 + reserveX R) ^ 2) := by
  have hx := reserveX_pos hR
  have hxhalf := reserveX_lt_half hR hR9
  have hs : 0 < (1 + reserveX R) ^ 2 := by positivity
  have hn : (1 + reserveX R) ^ 2 ≠ 0 := ne_of_gt hs
  have heq := reserveX_equation (by linarith : 1 < R)
  refine ⟨hx.le, by linarith, one_div_pos.mpr hs, ?_, ?_, ?_⟩
  · rw [one_div, inv_mul_cancel₀ hn]
  · rw [show R * (1 / (1 + reserveX R) ^ 2) * reserveX R ^ 2 =
        (R * reserveX R ^ 2) / (1 + reserveX R) ^ 2 by ring]
    apply (div_le_one hs).mpr
    have hm := mul_nonneg (by linarith : 0 ≤ R)
      (show 0 ≤ 1 - 4 * reserveX R ^ 2 by nlinarith)
    nlinarith
  · have hmul : R * (1 / (1 + reserveX R) ^ 2) * (1 - 2 * reserveX R ^ 2) = 2 := by
      field_simp [hn]
      nlinarith [heq]
    exact hmul.le

/-- Two opposing active constraints give the unique optimum, including
designs on either side of their intersection. -/
theorem reserve_intersection_bound {R q b x a : ℝ}
    (hR : 0 < R) (hq : 0 ≤ q) (hqh : q < 1 / 2) (hb : 0 < b)
    (hbmon : b * (1 + q) ^ 2 = 1)
    (hbres : R * b * (1 - 2 * q ^ 2) = 2)
    (h : ReserveFeasible R x a) : a ≤ b := by
  rcases h with ⟨hx, _, ha, hm, _, hr⟩
  by_cases hxq : q ≤ x
  · have hs : (1 + q) ^ 2 ≤ (1 + x) ^ 2 := by nlinarith
    have ham : a * (1 + q) ^ 2 ≤ 1 :=
      (mul_le_mul_of_nonneg_left hs ha.le).trans hm
    have hp : 0 < (1 + q) ^ 2 := by positivity
    exact (mul_le_mul_right hp).mp (by linarith)
  · have hxq' : x ≤ q := le_of_lt (lt_of_not_ge hxq)
    have hs : 1 - 2 * q ^ 2 ≤ 1 - 2 * x ^ 2 := by nlinarith
    have har : R * a * (1 - 2 * q ^ 2) ≤ 2 :=
      (mul_le_mul_of_nonneg_left hs (mul_pos hR ha).le).trans hr
    have hp : 0 < R * (1 - 2 * q ^ 2) := by
      apply mul_pos hR
      nlinarith
    apply (mul_le_mul_right hp).mp
    nlinarith [har, hbres]

theorem reserve_intersection_unique {R q b x : ℝ}
    (hR : 0 < R) (hq : 0 ≤ q) (hqh : q < 1 / 2) (hb : 0 < b)
    (hbmon : b * (1 + q) ^ 2 = 1)
    (hbres : R * b * (1 - 2 * q ^ 2) = 2)
    (h : ReserveFeasible R x b) : x = q := by
  rcases h with ⟨hx, _, _, hm, _, hr⟩
  have hmon : (1 + x) ^ 2 ≤ (1 + q) ^ 2 :=
    (mul_le_mul_left hb).mp (by linarith)
  have hres : 1 - 2 * x ^ 2 ≤ 1 - 2 * q ^ 2 :=
    (mul_le_mul_left (mul_pos hR hb)).mp (by linarith)
  nlinarith

/-- Explicit feasible maximizer and uniqueness of its `x` coordinate. -/
theorem reserve_three_regime_optimizer {R : ℝ} (hR : 1 < R) :
    ReserveFeasible R (reserveOptimizerX R) (reserveOptimizerGain R) ∧
    (∀ x a, ReserveFeasible R x a → a ≤ reserveOptimizerGain R) ∧
    (∀ x, ReserveFeasible R x (reserveOptimizerGain R) → x = reserveOptimizerX R) := by
  by_cases hR2 : R ≤ 2
  · simp only [reserveOptimizerX, reserveOptimizerGain, if_pos hR2]
    exact ⟨reserve_small_feasible hR hR2,
      fun _ _ h => feasible_gain_le_one h, fun _ h => feasible_gain_one_unique h⟩
  · by_cases hR9 : R < 9
    · simp only [reserveOptimizerX, reserveOptimizerGain, if_neg hR2, if_pos hR9]
      have hR2' : 2 < R := lt_of_not_ge hR2
      have hx := reserveX_pos hR2'
      have hxh := reserveX_lt_half hR2' hR9
      have hfeas := reserve_middle_feasible hR2' hR9
      have hs : 0 < (1 + reserveX R) ^ 2 := by positivity
      have hm : (1 / (1 + reserveX R) ^ 2) * (1 + reserveX R) ^ 2 = 1 := by
        field_simp
      have hr : R * (1 / (1 + reserveX R) ^ 2) * (1 - 2 * reserveX R ^ 2) = 2 := by
        have heq := reserveX_equation hR
        field_simp
        nlinarith [heq]
      exact ⟨hfeas, fun _ _ h => reserve_intersection_bound (by linarith) hx.le hxh
        (one_div_pos.mpr hs) hm hr h,
        fun _ h => reserve_intersection_unique (by linarith) hx.le hxh
          (one_div_pos.mpr hs) hm hr h⟩
    · have hR9' : 9 ≤ R := le_of_not_gt hR9
      simp only [reserveOptimizerX, reserveOptimizerGain, if_neg hR2, if_neg hR9]
      exact ⟨reserve_large_feasible hR9', fun _ _ h => reserve_large_bound hR9' h,
        fun _ h => reserve_large_unique hR9' h⟩

end C2.MIACE
