# C2 — correspondence between manuscript and Lean

All 13 numbered arbitrary-order results are covered. COMPLETE refers to mathematical assumptions and conclusions, not line-by-line identity of the written and formal proofs. The other 32 development-map entries retain their previous statuses; their coverage was not automatically upgraded by this release.

The coordinates are related by x = 2 gamma - 1. NGammaParameterization proves the inverse map, both cube correspondences, the actual numerator-factor identity, and preservation of vector uniqueness.

## lem:ngamma-phase-ratio

Strict monotonicity under exactly 0<=x<=1 and a>x; zero limit at t→0+, finite limit 1/x−1/a for x>0, divergence for x=0.

**Formal proof route:** Uses derivative/arctangent scale-ratio comparisons rather than differentiating a quotient of two unbounded kernel integrals.

**Primary declarations:**

- `C2.NGamma.Phase.normalized_phase_contribution`

## lem:ngamma-root-count

Actual roots outside the closed unit disk, counted with multiplicity, equal 2*floor((Psi(tb)+pi)/(2*pi)); unique magnitude crossing and no unit roots derived. The code proves the stronger scope xi>=0 without requiring xi<=1.

**Formal proof route:** Replaces the invoked analytic argument principle by a proved polynomial-factorization argument: each interior linear factor contributes 2pi and each exterior factor zero. Continuous-lift uniqueness uses disconnectedness of the integer lattice. Special phase lift matches the paper branch construction.

**Primary declarations:**

- `C2.NGamma.Cayley.root_count`
- `C2.NGamma.Cayley.existsUnique_amplitude_crossing_in_range`
- `C2.NGamma.RootCountBridge.exterior_count_of_cayley_argument`

## thm:ngamma-gain-interval

Both endpoint and interior cases; all b>=0; exact Schur iff b<Bcrit; unique first crossing; actual limiting unit-circle root. Conjugate root obtained using characteristic_eval_conj.

**Formal proof route:** Small gains use a direct factor norm inequality instead of root continuation. Intermediate gains use the fully proved root-count formula. All high gains are excluded by a right-half-plane lift giving exactly d exterior roots unless -1 is already a root.

**Primary declarations:**

- `C2.NGamma.Cayley.single_sample_exact_gain_interval`
- `C2.NGamma.Cayley.single_sample_endpoint_interval`
- `C2.NGamma.Cayley.single_sample_interior_interval`
- `C2.NGamma.Cayley.schur_iff_phase_lt_pi_at_magnitude_crossing`

## cor:ngamma-multiple-delay

For arbitrary d>=2 and n>=1: unique positive first crossing, strict t<tan(pi/(2d)), exact full stable gain interval and actual boundary unit root.

**Formal proof route:** Same normalized phase ordering, with the actual-root gain-interval bridge proved separately rather than assumed.

**Primary declarations:**

- `C2.NGamma.Cayley.multiple_delay_exact_gain_interval`
- `C2.NGamma.Phase.multiple_delay_unique_phase_crossing`

## thm:ngamma-endpoint-allocation

All numbered clauses: feasibility iff S1<=1; equality all-one uniqueness; unique positive scalar and clipped optimum under strict feasibility; saturated S=1; exact double root at -1 and every other actual root strictly inside; exact open stable interval and its actual supremum. EndpointFinal discharges the stability-below premise.

**Formal proof route:** Uses explicit one-dimensional marginal/Lagrangian inequalities and strict comparisons. Double-root multiplicity is proved from actual shifted polynomial derivatives; remaining roots use factorization-based closed-disk bounds instead of an enumerated root-continuity theorem.

**Primary declarations:**

- `C2.NGamma.endpoint_feasible_iff`
- `C2.NGamma.endpoint_feasible_equality_unique`
- `C2.NGamma.existsUnique_endpoint_scalar`
- `C2.NGamma.exists_endpoint_optimizer`
- `C2.NGamma.PolynomialModel.saturated_endpoint_spectrum`
- `C2.NGamma.Cayley.single_sample_endpoint_interval`
- `C2.NGamma.PolynomialModel.initialGainMargin_eq_of_exact_interval`

## lem:ngamma-concave-allocation

For every positive feasible w: scalar multiplier exists, explicit clipped formula gives feasible unique gain-maximizing vector; actual product of complex magnitudes used; multiplier uniqueness not falsely asserted.

**Formal proof route:** Proves separable Lagrangian strict inequalities directly, then sums them and converts log gain to actual magnitude product, avoiding a separate abstract concave-program/KKT existence theorem.

**Primary declarations:**

- `C2.NGamma.exists_unique_frequency_gain_optimizer`
- `C2.NGamma.frequencyFree`
- `C2.NGamma.frequencyAllocation`
- `C2.NGamma.allocationGain_eq_complexNorm`

## lem:ngamma-frequency-interval

Both interval cases in w=1/t, endpoint equations and unique endpoint vectors, n>=1 and ri>0.

**Formal proof route:** Follows manuscript normalized-ratio monotonicity and intermediate-value argument; generic existence/order lemmas are separated.

**Primary declarations:**

- `C2.NGamma.Global.feasible_frequency_interval`
- `C2.NGamma.Global.upper_frequency_existsUnique`
- `C2.NGamma.Global.lower_frequency_existsUnique`
- `C2.NGamma.Global.upper_frequency_vector_unique`
- `C2.NGamma.Global.lower_frequency_vector_unique`

## thm:ngamma-outer-monotonicity

Actual constrained optimal log gain is continuous and strictly decreasing on entire positive feasible interval, including clipping changes and positive feasible endpoints.

**Formal proof route:** Uses a compact dual minimum and differentiable upper supports. This avoids the manuscript local-Lipschitz/almost-everywhere derivative route while proving the same global conclusion without regularity hypotheses.

**Primary declarations:**

- `C2.NGamma.Global.frequencyValue_is_unique_maximum`
- `C2.NGamma.Global.frequencyValue_continuousOn_feasible`
- `C2.NGamma.Global.frequencyValue_strictAntiOn_feasible`

## thm:ngamma-global-half-cube

All three S1 regimes have explicit unique optimizer descriptions. Actual initialGainMargin equals the critical gain, all b>=0 satisfy the exact stable interval, and the limiting characteristic has a unit-circle root and is not strictly stable. Margin and boundary wrappers compiled.

**Formal proof route:** Uses compact maximizing sequences to bound zero-frequency limits and strict dual-value monotonicity; actual margin is the supremum of stable gains and is identified through exact Schur intervals, not defined as an analytic critical gain.

**Primary declarations:**

- `C2.NGamma.Global.half_cube_global_gain_theorem`
- `C2.NGamma.Global.OptimalGainDescription`

## cor:ngamma-full-cube-initial-margin

Actual sSup initial margin on [-1,1]^n; unique optimizer is the half-cube optimizer; strict reflection dominance for admissible negative coordinates; margin zero for inadmissible zero-gain factors. Final wrapper compiled. No claim about isolated stable components away from zero.

**Formal proof route:** Uses explicit root-factor lower bounds to exclude stable small gains near a zero-gain exterior root instead of general polynomial-root continuity. Reflection is applied to the actual initial margin using unit-root upper bounds and the proved half-cube exact interval.

**Primary declarations:**

- `C2.NGamma.Global.full_cube_initial_margin_global_theorem`
- `C2.NGamma.Global.OptimalGainDescription`

## cor:ngamma-identical-global

Both regimes give the actual initialGainMargin supremum, exact actual-root Schur interval and unique global optimizer. Finite regime includes the unique sine-quotient angle and sine-power gain; both explicit exponential roots and unit norms are proved for the actual characteristic, with distinctness. Endpoint formula covers n=1 and n=2. Threshold formulas agree at r=n−2. All wrappers compiled.

**Formal proof route:** Specializes the proved generic resource optimizer for the endpoint formula. The actual all-one phase condition uniquely identifies the sine angle and algebra identifies its gain. Generic global analytic optimization and the proved criticalGain-to-Schur/margin bridge complete the corollary.

**Primary declarations:**

- `C2.NGammaEqual.identical_endpoint_margin`
- `C2.NGammaEqual.identical_finite_margin`
- `C2.NGammaEqual.identical_finite_boundary_roots`
- `C2.NGammaEqual.identical_finite_boundary_distinct`
- `C2.NGammaEqual.identical_endpoint_boundary`
- `C2.NGammaEqual.endpoint_boundary_agreement`
- `C2.NGammaEqual.identical_order_three_margin`
- `C2.NGammaEqual.identical_order_four_margin`

## thm:ngamma-realization

Uncancelled transfer numerator/denominator, degrees n and <=n, actual augmented (n+d)-state matrix characteristic, and equivalence with decay of every homogeneous trajectory. detE!=0 and d>0 match manuscript. Transfer evaluation naturally excludes poles.

**Formal proof route:** Algebraic transform/causal identities, recursive appended-delay realization, determinant/adjugate identities and polynomial extension are verified. Dynamical equivalence uses spectral-radius power decay. A formal Z-transform operator is not introduced; unnumbered companion/cascade realization formulas are outside this numbered theorem.

**Primary declarations:**

- `C2.NGamma.Realization.transfer_quotient`
- `C2.NGamma.Realization.polynomial_degrees`
- `C2.NGamma.Realization.aligned_characteristic`
- `C2.NGamma.Realization.aligned_characteristic_eval`
- `C2.NGamma.Realization.aligned_state_count`
- `C2.NGamma.Realization.aligned_asymptotic_stability_iff`

## prop:ngamma-diagonal-stability

Positive diagonal P, negative definite A^T P+P A, T>0 and gamma>=1/2 imply invertible E and actual Schur stability of E^-1F; no diagonalizability or nominal-step stability premise. The bridge identifies the step matrix with the realization E^-1F. The accompanying Hurwitz-only counterexample and its explicit exterior root are also proved.

**Formal proof route:** Proves the equivalent discrete energy identity directly in state increments, avoiding an explicit A^-1 expression; complex eigenvalue contraction gives Schur stability.

**Primary declarations:**

- `C2.NGamma.diagonal_stability_of_lyapunov`
- `C2.NGamma.diagonal_stability`
- `C2.NGamma.realization_diagonal_stability`
- `C2.NGamma.hurwitz_not_sufficient`
- `C2.NGamma.counter_unstable_root`
