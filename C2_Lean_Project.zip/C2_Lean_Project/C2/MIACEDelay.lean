import C2.MIACEAreas

/-! Literal zero-prehistory pure-delay plant and its MIACE minimizers. -/
noncomputable section

namespace C2.MIACE

def delayedOutput (d : ℕ) (w : ℕ → ℝ) (n : ℕ) : ℝ :=
  if n < d then 0 else w (n - d)

def delayedError (d : ℕ) (w : ℕ → ℝ) (n : ℕ) : ℝ := 1 - delayedOutput d w n

def centeredCommand (w : ℕ → ℝ) (n : ℕ) : ℝ := w n - 1

theorem pure_delay_initial_error (d : ℕ) (w : ℕ → ℝ) (n : ℕ) (hn : n < d) :
    delayedError d w n = 1 := by simp [delayedError, delayedOutput, hn]

theorem pure_delay_timing (d : ℕ) (w : ℕ → ℝ) (n : ℕ) :
    centeredCommand w n = -delayedError d w (n + d) := by
  have hn : ¬ n + d < d := by omega
  simp [centeredCommand, delayedError, delayedOutput, hn]

theorem pure_delay_plant_area_identity (T : ℝ) (d : ℕ) (w : ℕ → ℝ)
    (hs : Summable (fun n => |delayedError d w n|)) :
    area T (delayedError d w) = (d : ℝ) * T + area T (centeredCommand w) :=
  pure_delay_area_identity T d _ _ hs (pure_delay_initial_error d w) (pure_delay_timing d w)

theorem pure_delay_command_summable (d : ℕ) (w : ℕ → ℝ)
    (hs : Summable (fun n => |delayedError d w n|)) :
    Summable (fun n => |centeredCommand w n|) := by
  have ht := (summable_nat_add_iff d).mpr hs
  apply ht.congr
  intro n
  rw [pure_delay_timing d w n, abs_neg]

theorem pure_delay_plant_minimizer_iff {ι : Type*} (S : Set ι)
    (w : ι → ℕ → ℝ) (d : ℕ) {T η : ℝ} (hT : 0 ≤ T) (hη : 0 < η)
    (hs : ∀ i ∈ S, Summable (fun n => |delayedError d (w i) n|)) (i : ι) (hi : i ∈ S) :
    (∀ j ∈ S, cost η (area T (delayedError d (w i))) (area T (centeredCommand (w i))) ≤
      cost η (area T (delayedError d (w j))) (area T (centeredCommand (w j)))) ↔
    (∀ j ∈ S, area T (delayedError d (w i)) ≤ area T (delayedError d (w j))) := by
  apply pure_delay_minimizer_iff S _ _ hη (mul_nonneg (Nat.cast_nonneg d) hT)
    (fun j _ => area_nonneg hT _) _ i hi
  intro j hj
  exact pure_delay_plant_area_identity T d (w j) (hs j hj)

end C2.MIACE
