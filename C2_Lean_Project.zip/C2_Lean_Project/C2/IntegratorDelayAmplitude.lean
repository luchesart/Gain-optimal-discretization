import Mathlib

noncomputable section
namespace C2.IntegratorDelay

def amplitude (x t : ℝ) : ℝ := 2 * t / Real.sqrt (1 + (x * t) ^ 2)

theorem amplitude_den_pos (x t : ℝ) : 0 < Real.sqrt (1 + (x * t) ^ 2) := by positivity

@[simp] theorem amplitude_zero (x : ℝ) : amplitude x 0 = 0 := by simp [amplitude]

theorem amplitude_nonneg (x : ℝ) {t : ℝ} (ht : 0 ≤ t) : 0 ≤ amplitude x t := by
  unfold amplitude
  positivity

theorem amplitude_pos (x : ℝ) {t : ℝ} (ht : 0 < t) : 0 < amplitude x t := by
  unfold amplitude
  positivity

theorem amplitude_continuous (x : ℝ) : Continuous (amplitude x) := by
  unfold amplitude
  exact (continuous_const.mul continuous_id).div
    ((continuous_const.add ((continuous_const.mul continuous_id).pow 2)).sqrt)
    (fun t => (amplitude_den_pos x t).ne')

theorem amplitude_sq (x t : ℝ) :
    amplitude x t ^ 2 = 4 * t ^ 2 / (1 + (x * t) ^ 2) := by
  unfold amplitude
  rw [div_pow, mul_pow, Real.sq_sqrt (by positivity)]
  ring

theorem amplitude_strictMonoOn (x : ℝ) : StrictMonoOn (amplitude x) (Set.Ici 0) := by
  intro s hs t ht hst
  change 0 ≤ s at hs
  change 0 ≤ t at ht
  have hsq : s ^ 2 < t ^ 2 := by nlinarith only [hs, hst]
  have hab : amplitude x s ^ 2 < amplitude x t ^ 2 := by
    rw [amplitude_sq, amplitude_sq]
    apply (div_lt_div_iff₀ (by positivity) (by positivity)).mpr
    nlinarith only [hsq]
  nlinarith only [hab, amplitude_nonneg x hs, amplitude_nonneg x ht]

theorem amplitude_endpoint_bound (x : ℝ) {t : ℝ} (ht : 0 ≤ t) :
    amplitude x t * |x| < 2 := by
  have hsq : amplitude x t ^ 2 * x ^ 2 < 4 := by
    rw [amplitude_sq]
    have he : 4 * t ^ 2 / (1 + (x * t) ^ 2) * x ^ 2 =
        4 * (x * t) ^ 2 / (1 + (x * t) ^ 2) := by ring
    rw [he]
    apply (div_lt_iff₀ (by positivity)).mpr
    linarith
  have habs := sq_abs x
  have hid : (amplitude x t * |x|) ^ 2 = amplitude x t ^ 2 * x ^ 2 := by
    rw [mul_pow, habs]
  nlinarith only [hsq, hid, mul_nonneg (amplitude_nonneg x ht) (abs_nonneg x)]

def amplitudeCrossing (x a : ℝ) : ℝ := a / Real.sqrt (4 - a ^ 2 * x ^ 2)

theorem crossing_radicand_pos {x a : ℝ} (ha : 0 < a) (hax : a * |x| < 2) :
    0 < 4 - a ^ 2 * x ^ 2 := by
  have hn : 0 ≤ a * |x| := mul_nonneg ha.le (abs_nonneg x)
  have hs : (a * |x|) ^ 2 = a ^ 2 * x ^ 2 := by rw [mul_pow, sq_abs]
  nlinarith only [ha, hax, hn, hs]

theorem amplitudeCrossing_pos {x a : ℝ} (ha : 0 < a) (hax : a * |x| < 2) :
    0 < amplitudeCrossing x a := by
  unfold amplitudeCrossing
  exact div_pos ha (Real.sqrt_pos.mpr (crossing_radicand_pos ha hax))

theorem amplitude_at_crossing {x a : ℝ} (ha : 0 < a) (hax : a * |x| < 2) :
    amplitude x (amplitudeCrossing x a) = a := by
  have hr := crossing_radicand_pos ha hax
  have ht := amplitudeCrossing_pos ha hax
  have he : amplitudeCrossing x a ^ 2 = a ^ 2 / (4 - a ^ 2 * x ^ 2) := by
    unfold amplitudeCrossing
    rw [div_pow, Real.sq_sqrt hr.le]
  have hsq : amplitude x (amplitudeCrossing x a) ^ 2 = a ^ 2 := by
    rw [amplitude_sq, mul_pow, he]
    field_simp
    <;> ring
  nlinarith only [hsq, amplitude_pos x ht, ha]

theorem existsUnique_amplitude_crossing {x a : ℝ} (ha : 0 < a) (hax : a * |x| < 2) :
    ∃! t : ℝ, 0 < t ∧ amplitude x t = a := by
  refine ⟨amplitudeCrossing x a, ⟨amplitudeCrossing_pos ha hax, amplitude_at_crossing ha hax⟩, ?_⟩
  intro y hy
  exact (amplitude_strictMonoOn x).injOn hy.1.le (amplitudeCrossing_pos ha hax).le
    (hy.2.trans (amplitude_at_crossing ha hax).symm)

theorem amplitude_lt_gain_iff {x a t : ℝ} (ha : 0 < a) (hax : a * |x| < 2)
    (ht : 0 ≤ t) : amplitude x t < a ↔ t < amplitudeCrossing x a := by
  conv_lhs => rw [← amplitude_at_crossing ha hax]
  exact (amplitude_strictMonoOn x).lt_iff_lt ht (amplitudeCrossing_pos ha hax).le

end C2.IntegratorDelay
