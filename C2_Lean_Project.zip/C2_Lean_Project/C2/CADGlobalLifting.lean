import C2.CADParameterSigns
import C2.CADGainCuts

/-! Construction of complete finite rational lifting samples at every rational
gain. This is mathematical existence from the actual finite polynomial roots;
the separate effective isolation development supplies executable encodings. -/

noncomputable section
open Polynomial Set
namespace C2.CADGlobal

/-- Exact rational evaluation, with parameter first and gain second. -/
def rationalTest (p : CADProjection.Bivariate) (γ k : ℚ) : ℚ :=
  (p.map (Polynomial.evalRingHom k)).eval γ

@[simp] theorem rational_eval_cast (p : ℚ[X]) (k : ℚ) :
    ((p.eval k : ℚ) : ℝ) = p.eval₂ (algebraMap ℚ ℝ) (k : ℝ) := by
  exact (Polynomial.eval₂_at_apply (p := p) (algebraMap ℚ ℝ) k).symm

/-- The exact rational sign test agrees with the actual real polynomial. -/
theorem rationalTest_cast (p : CADProjection.Bivariate) (γ k : ℚ) :
    ((rationalTest p γ k : ℚ) : ℝ) = CADProjection.value p k γ := by
  induction p using Polynomial.induction_on' with
  | add p q hp hq => simpa [rationalTest, CADProjection.value, CADProjection.specialize] using congrArg₂ (· + ·) hp hq
  | monomial n a =>
      simp [rationalTest, CADProjection.value, CADProjection.specialize, rational_eval_cast]

/-- Rational choices for every adjacent pair of any finite real cut set. -/
theorem exists_cell_samples (cuts : Finset ℝ) :
    ∃ samples : (ℝ × ℝ) → ℚ,
      ∀ c ∈ CADCells.cells cuts, (samples c : ℝ) ∈ Ioo c.1 c.2 := by
  classical
  have he : ∀ c : ℝ × ℝ, ∃ q : ℚ,
      c ∈ CADCells.cells cuts → (q : ℝ) ∈ Ioo c.1 c.2 := by
    intro c
    by_cases hc : c ∈ CADCells.cells cuts
    · obtain ⟨q, hq⟩ := CADCells.rational_sample_exists
        ((CADCells.mem_cells_iff cuts c.1 c.2).mp hc)
      exact ⟨q, fun _ => hq⟩
    · exact ⟨0, fun h => (hc h).elim⟩
  choose samples hsamples using he
  exact ⟨samples, hsamples⟩

/-- All actual roots of finitely many nonzero real polynomials in [0,1]
are included in one finite cut set with endpoints. -/
theorem exists_parameter_cuts {n : ℕ} (p : Fin n → ℝ[X])
    (hp : ∀ i, p i ≠ 0) :
    ∃ cuts : Finset ℝ, 0 ∈ cuts ∧ 1 ∈ cuts ∧
      (∀ c ∈ cuts, c ∈ Icc (0 : ℝ) 1) ∧
      (∀ i x, x ∈ Ioo (0 : ℝ) 1 → (p i).eval x = 0 → x ∈ cuts) := by
  classical
  let P : ℝ[X] := ∏ i, p i
  have hP : P ≠ 0 := Finset.prod_ne_zero_iff.mpr (fun i _ => hp i)
  have hfinite : Set.Finite {x : ℝ | P.eval x = 0} :=
    Polynomial.finite_setOf_isRoot hP
  let cuts : Finset ℝ := (hfinite.toFinset.filter fun x => x ∈ Icc (0 : ℝ) 1) ∪ {0, 1}
  have hmem : ∀ x : ℝ, x ∈ cuts ↔
      (P.eval x = 0 ∧ x ∈ Icc (0 : ℝ) 1) ∨ x = 0 ∨ x = 1 := by
    intro x
    simp [cuts, or_assoc, or_left_comm, or_comm]
  refine ⟨cuts, (hmem 0).mpr (Or.inr (Or.inl rfl)),
    (hmem 1).mpr (Or.inr (Or.inr rfl)), ?_, ?_⟩
  · intro x hx
    rcases (hmem x).mp hx with hx | rfl | rfl
    · exact hx.2
    · norm_num
    · norm_num
  · intro i x hx hi
    apply (hmem x).mpr
    left
    refine ⟨?_, ⟨hx.1.le, hx.2.le⟩⟩
    dsimp [P]
    rw [Polynomial.eval_prod]
    exact Finset.prod_eq_zero (Finset.mem_univ i) hi

/-- Exact lifting tests exist for every fixed rational gain. They are obtained
from all actual parameter roots and rational samples in every adjacent cell;
a zero polynomial is handled separately as an impossible strict inequality. -/
theorem exists_lifting_samples {n : ℕ}
    (tests : Fin n → ℚ → ℚ → ℚ) (gain : ℚ) (p : Fin n → ℝ[X])
    (hcast : ∀ q i, ((tests i q gain : ℚ) : ℝ) = (p i).eval (q : ℝ)) :
    ∃ samples : List ℚ,
      CADAlgorithm.markAtGain (List.ofFn tests) samples gain = true ↔
        ∃ γ ∈ Icc (0 : ℝ) 1, ∀ i, 0 < (p i).eval γ := by
  classical
  by_cases hz : ∃ i, p i = 0
  · obtain ⟨i, hi⟩ := hz
    refine ⟨[], ?_⟩
    have hinfeasible := CADAlgorithm.zero_polynomial_inequality_infeasible p hi
    constructor
    · intro h
      simp [CADAlgorithm.markAtGain] at h
    · intro h
      exact (hinfeasible h).elim
  · have hp : ∀ i, p i ≠ 0 := by simpa using hz
    obtain ⟨cuts, hzero, hone, hbound, hroots⟩ := exists_parameter_cuts p hp
    obtain ⟨samples, hsample⟩ := exists_cell_samples cuts
    exact ⟨(CADCells.cells cuts).toList.map samples,
      CADAlgorithm.polynomial_lifting_mark_correct tests gain p hcast cuts
        hzero hone hbound hroots samples hsample⟩

/-- Specialization to the actual rational bivariate input family. -/
theorem exists_bivariate_lifting_samples {n : ℕ}
    (f : Fin n → CADProjection.Bivariate) (gain : ℚ) :
    ∃ samples : List ℚ,
      CADAlgorithm.markAtGain (List.ofFn (fun i => rationalTest (f i))) samples gain = true ↔
        ∃ γ ∈ Icc (0 : ℝ) 1, ∀ i, 0 < CADProjection.value (f i) gain γ := by
  exact exists_lifting_samples (fun i => rationalTest (f i)) gain
    (fun i => CADProjection.specialize (f i) gain)
    (fun q i => rationalTest_cast (f i) q gain)

end C2.CADGlobal
