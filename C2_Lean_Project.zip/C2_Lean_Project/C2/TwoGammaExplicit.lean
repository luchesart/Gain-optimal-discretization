import C2.TwoGammaAlgebra
import C2.TwoGammaBasic
import C2.NGammaEndpoint

noncomputable section
open scoped BigOperators
open Set
namespace C2.TwoGamma
open NGamma NGamma.PolynomialModel

theorem allocation_eq_endpoint {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    endpointAllocation r₁ (scalar r₁ r₂) = allocation r₁ r₂ := by
  have hc := scalar_pos h₁ h₂
  have ht : 0 < allocation r₁ r₂ := by linarith [allocation_gt h₁ h₂]
  have hf := freeAllocation_pos h₁ hc.le
  have hs := allocation_stationarity h₁ h₂
  have hfs := freeAllocation_stationarity h₁ hc.le
  have he : freeAllocation r₁ (scalar r₁ r₂) = allocation r₁ r₂ := by
    rcases lt_trichotomy (freeAllocation r₁ (scalar r₁ r₂)) (allocation r₁ r₂) with h|h|h
    · have hh := stationaryRate_strict_mono (r := r₁) hf h
      linarith
    · exact h
    · have hh := stationaryRate_strict_mono (r := r₁) ht h
      linarith
  unfold endpointAllocation
  rw [he,max_eq_right (allocation_gt h₁ h₂).le]

theorem scalar_budget {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    allocatedResource (poles r₁ r₂) (scalar r₁ r₂) = 4 := by
  have hs₁ := allocation_stationarity h₁ h₂
  have hs₂ := allocation_stationarity h₂ h₁
  rw [scalar_comm r₁ r₂] at hs₂
  simp only [allocatedResource, Fin.sum_univ_two, poles, Matrix.cons_val_zero,
    Matrix.cons_val_one, Matrix.head_cons]
  rw [allocation_eq_endpoint h₁ h₂, ← scalar_comm r₁ r₂, allocation_eq_endpoint h₂ h₁]
  unfold resource
  unfold scalar at hs₁ hs₂
  linarith

theorem optimalX_eq_parameter {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    optimalX r₁ r₂ = endpointParameter r₁ (scalar r₁ r₂) := by
  have hg := gain_pos h₁ h₂
  have hq := gain_quadratic h₁ h₂
  have hd : gain r₁ r₂+r₁*r₂ ≠ 0 := by positivity
  have ht : allocation r₁ r₂-r₁ ≠ 0 := by linarith [allocation_gt h₁ h₂]
  have hd' : r₁+r₂+2 ≠ 0 := by positivity
  unfold endpointParameter
  rw [allocation_eq_endpoint h₁ h₂]
  unfold optimalX
  apply (div_eq_div_iff hd ht).mpr
  unfold allocation
  field_simp
  nlinarith [hq]

theorem optimalX_interior {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    0 < optimalX r₁ r₂ ∧ optimalX r₁ r₂ < 1 := by
  rw [optimalX_eq_parameter h₁ h₂]
  refine ⟨endpointParameter_pos _ _, ?_⟩
  unfold endpointParameter
  rw [allocation_eq_endpoint h₁ h₂]
  apply (div_lt_one (by linarith [allocation_gt h₁ h₂])).mpr
  linarith [allocation_gt h₁ h₂]

theorem optimalGamma_interior {r₁ r₂ : ℝ} (h₁ : 0 < r₁) (h₂ : 0 < r₂) :
    1/2 < optimalGamma r₁ r₂ ∧ optimalGamma r₁ r₂ < 1 := by
  have := optimalX_interior h₁ h₂
  unfold optimalGamma
  constructor <;> linarith

end C2.TwoGamma
