# C2 axiom and coverage checklist — version 0.5.0, 21 November 2026

- [x] Lean 4.19.0 and all nine exact pinned dependency revisions verified.
- [x] All 208 unchanged v0.4 modules freshly compiled; source hashes preserved.
- [x] New C2.RobustAsymmetric module freshly checked after integration.
- [x] The complete regenerated 209-module umbrella imports successfully.
- [x] Exact final standalone bytes independently pass Lean in isolated staging.
- [x] All 2205 explicit public declarations resolve in a fresh full axiom audit.
- [x] Only propext, Classical.choice and Quot.sound occur transitively.
- [x] No sorryAx, custom axiom, admitted proof or unsafe source declaration.
- [x] Inventory reports 1764 public theorem/lemma declarations and 209 modules.
- [x] All 45 manuscript labels remain COMPLETE: 22 main and 23 appendix claims.
- [x] Proposition 1 covers every admissible asymmetric constant uncertainty box.
- [x] Its exact cap is the supremum of actual root-stable robust gains.
- [x] The maximizing center is unique; width regimes include 0, 1/2 and 1.
- [x] The original symmetric robustness theorem remains byte-identical.
- [x] Current Theorem 16 retains actual native CAD correctness and termination.
- [x] CAD constructs all witnesses, projection, roots, samples and marks internally.
- [x] Earlier actual-root, MIACE, realization and arbitrary-order claims are retained.

The 1764 public proofs are not 1764 independent manuscript statements.
Private/generated helpers are excluded from that count but audited transitively.
The unchanged official collector shares a visited set over all 2205 roots;
its allowed axiom union proves the same condition for each root. Exact per-root
axiom lists are not claimed. The runtime CAD code uses rational lists, finite
ranks and terminating search; real interpretations are proof-only. No practical
complexity guarantee or verification of the separate SymPy program is asserted.

VERIFICATION.json records checks actually run and their exact source hashes.
The v0.4 metadata/audit snapshot is historical/20261121_v04. The previous
Theorem 3 is Theorem 16 in the current full-paper numbering. No online
live.lean session or journal submission is claimed.
