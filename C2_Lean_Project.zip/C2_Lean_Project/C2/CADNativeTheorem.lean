import C2.CADNativeOutput
import C2.CADNativeProjection
import C2.CADGlobalAssembly
import C2.CADDriverValues
import C2.CADDriverParameter
import C2.CADNativeProgram

/-! Correctness of the actual executable gain-projection calculation.
The real interpretation is used only in theorem statements and proofs; the
computed endpoints are finite natural ranks with certified rational isolation
data, and all cell marks are computed from rational samples. -/

noncomputable section
namespace C2.CADDriver
open Set
open C2.CADEffective C2.CADAlgorithm

/-- The positive gains admitted by the original native input inequalities. -/
def positiveGains (input : List Bivariate.Poly) : Set ℝ :=
  {k | 0 < k ∧ Bivariate.rawFeasible input k}

theorem positiveGains_eq (input : List Bivariate.Poly) :
    positiveGains input = CADGlobal.positiveGains (Bivariate.inputFamily input) := by
  ext k
  simp only [positiveGains, CADGlobal.positiveGains, mem_setOf_eq,
    Bivariate.rawFeasible_iff_inputFamily]

theorem positiveGains_isOpen (input : List Bivariate.Poly) :
    IsOpen (positiveGains input) := by
  rw [positiveGains_eq]
  exact CADGlobal.positiveGains_isOpen _

theorem positiveGains_empty_of_zero (input : List Bivariate.Poly)
    (hz : Bivariate.nonzeroInputs input = false) : positiveGains input = ∅ := by
  rw [positiveGains_eq]
  have hn : ¬ ∀ i, Bivariate.inputFamily input i ≠ 0 := by
    intro h
    have := (Bivariate.nonzeroInputs_iff input).mpr h
    simp [hz] at this
  push_neg at hn
  obtain ⟨i, hi⟩ := hn
  exact CADGlobal.zero_input_positiveGains_empty _ hi

/-- The marked cells actually constructed by the native driver, interpreted
using the real roots associated with its finite ranks. -/
def interpretedCells (input : List Bivariate.Poly) (data : Isolation)
    (K : ℚ) (value : ℕ → ℝ) : List (Cell ℝ) :=
  ((sampledGainCells input data K).map (fun c => c.test (rationalTests input))).map
    (Cell.mapEndpoints value)

theorem mem_interpretedCells (input : List Bivariate.Poly) (data : Isolation)
    (K : ℚ) (value : ℕ → ℝ) (c : Cell ℝ) :
    c ∈ interpretedCells input data K value ↔
      ∃ d ∈ consecutiveRanks data,
        c = ⟨value d.1, value d.2,
          Dense.betweenRanks 0 K data.mesh d.1 d.2,
          markGain input (Dense.betweenRanks 0 K data.mesh d.1 d.2)⟩ := by
  simp only [interpretedCells, sampledGainCells, List.map_map, List.mem_map]
  constructor
  · rintro ⟨d, hd, hc⟩
    exact ⟨d, hd, hc.symm⟩
  · rintro ⟨d, hd, hc⟩
    exact ⟨d, hd, hc.symm⟩

theorem mem_represented_interpretedCells (input : List Bivariate.Poly) (data : Isolation)
    (K : ℚ) (value : ℕ → ℝ) (k : ℝ) :
    k ∈ representedGains (interpretedCells input data K value) ↔
      ∃ d ∈ consecutiveRanks data,
        markGain input (Dense.betweenRanks 0 K data.mesh d.1 d.2) = true ∧
          value d.1 < k ∧ k < value d.2 := by
  constructor
  · rintro ⟨c, hc, hm, hk⟩
    obtain ⟨d, hd, rfl⟩ := (mem_interpretedCells input data K value c).mp hc
    exact ⟨d, hd, hm, hk⟩
  · rintro ⟨d, hd, hm, hk⟩
    refine ⟨_, (mem_interpretedCells input data K value _).mpr ⟨d, hd, rfl⟩, hm, hk⟩

theorem interpretedCells_valid (input : List Bivariate.Poly)
    (p : Dense.Poly) (hp : Dense.denote p ≠ 0) (K : ℚ) (hK : 0 < K) :
    ValidCells (interpretedCells input (isolate p hp 0 K hK.le) K
      (rootValue p hp 0 K hK)) := by
  intro c hc
  obtain ⟨d, hd, rfl⟩ := (mem_interpretedCells _ _ _ _ c).mp hc
  have hs := rootValue_gap_sample p hp 0 K hK hd
  exact hs.1.trans hs.2

theorem tested_cell_right_mem (input : List Bivariate.Poly) (data : Isolation)
    (K : ℚ) {c : Cell ℕ}
    (hc : c ∈ (sampledGainCells input data K).map (fun c => c.test (rationalTests input))) :
    c.right ∈ data.ranks := by
  obtain ⟨s, hs, rfl⟩ := List.mem_map.mp hc
  obtain ⟨d, hd, rfl⟩ := List.mem_map.mp hs
  exact List.mem_of_mem_tail (List.of_mem_zip hd).2

theorem tested_cell_rights_monotone (input : List Bivariate.Poly)
    (p : Dense.Poly) (hp : Dense.denote p ≠ 0) (K : ℚ) (hK : 0 < K) :
    ∀ c ∈ (sampledGainCells input (isolate p hp 0 K hK.le) K).map
        (fun c => c.test (rationalTests input)),
      ∀ d ∈ (sampledGainCells input (isolate p hp 0 K hK.le) K).map
        (fun c => c.test (rationalTests input)), c.right ≤ d.right →
      rootValue p hp 0 K hK c.right ≤ rootValue p hp 0 K hK d.right := by
  intro c hc d hd hcd
  rcases lt_or_eq_of_le hcd with hlt | heq
  · exact (rootValue_strictMono p hp 0 K hK
      (tested_cell_right_mem input _ K hc) (tested_cell_right_mem input _ K hd) hlt).le
  · rw [heq]

theorem interpretedCells_decomposition (input : List Bivariate.Poly)
    (p : Dense.Poly) (hp : Dense.denote p ≠ 0) (K : ℚ) (hK : 0 < K)
    (hsupport : positiveGains input ⊆ Ioo (0:ℝ) (K:ℝ))
    (hmark : ∀ q : ℚ, markGain input q = true ↔ Bivariate.rawFeasible input (q:ℝ))
    (hconstant : ∀ I : Set ℝ, IsPreconnected I →
      (∀ k ∈ I, CADIsolation.realEval (Dense.denote p) k ≠ 0) →
      ∀ {a b : ℝ}, a ∈ I → b ∈ I →
        (Bivariate.rawFeasible input a ↔ Bivariate.rawFeasible input b)) :
    positiveGains input \ {k | CADIsolation.realEval (Dense.denote p) k = 0} =
      representedGains (interpretedCells input (isolate p hp 0 K hK.le) K
        (rootValue p hp 0 K hK)) := by
  ext k
  rw [mem_represented_interpretedCells]
  constructor
  · rintro ⟨hk, hn⟩
    obtain ⟨r, s, hpair, hgap⟩ := rootValue_gap_cover p hp 0 K hK
      (by simpa using hsupport hk) hn
    refine ⟨(r,s), hpair, ?_, hgap⟩
    apply (hmark _).mpr
    exact (hconstant _ isPreconnected_Ioo
      (rootValue_gap_no_root p hp 0 K hK hpair) hgap
      (rootValue_gap_sample p hp 0 K hK hpair)).mp hk.2
  · rintro ⟨d, hd, hm, hk⟩
    obtain ⟨hl, _, _, _⟩ := Dense.rankPairs_properties
      (isolate_ranks_sorted p hp 0 K hK.le) hd
    have hleft := (rootValue_mem_Icc p hp 0 K hK hl).1
    have hfree := rootValue_gap_no_root p hp 0 K hK hd
    refine ⟨⟨?_, ?_⟩, hfree k hk⟩
    · exact (by simpa using hleft : 0 ≤ rootValue p hp 0 K hK d.1).trans_lt hk.1
    · exact (hconstant _ isPreconnected_Ioo hfree hk
        (rootValue_gap_sample p hp 0 K hK hd)).mpr ((hmark _).mp hm)


section ProjectedRun
variable (input : List Bivariate.Poly) (p : Dense.Poly) (hp : Dense.denote p ≠ 0)
  (K : ℚ) (hK : 0 < K)
  (hsupport : positiveGains input ⊆ Ioo (0:ℝ) (K:ℝ))
  (hmark : ∀ q : ℚ, markGain input q = true ↔ Bivariate.rawFeasible input (q:ℝ))
  (hconstant : ∀ I : Set ℝ, IsPreconnected I →
    (∀ k ∈ I, CADIsolation.realEval (Dense.denote p) k ≠ 0) →
    ∀ {a b : ℝ}, a ∈ I → b ∈ I →
      (Bivariate.rawFeasible input a ↔ Bivariate.rawFeasible input b))

include hsupport hmark hconstant

theorem projected_run_none_iff :
    (runWithProjection input p hp K hK.le).result = none ↔ positiveGains input = ∅ := by
  apply native_output_none_iff_empty
    ((sampledGainCells input (isolate p hp 0 K hK.le) K).map
      (fun c => c.test (rationalTests input)))
    (rootValue p hp 0 K hK) (positiveGains_isOpen input)
  · exact CADProjection.rational_zero_set_finite (Dense.denote p) hp
  · exact interpretedCells_valid input p hp K hK
  · exact interpretedCells_decomposition input p hp K hK hsupport hmark hconstant

theorem projected_run_some_isLUB {r : ℕ}
    (hout : (runWithProjection input p hp K hK.le).result = some r) :
    IsLUB (positiveGains input) (rootValue p hp 0 K hK r) := by
  apply native_output_isLUB
    ((sampledGainCells input (isolate p hp 0 K hK.le) K).map
      (fun c => c.test (rationalTests input)))
    (rootValue p hp 0 K hK) (positiveGains_isOpen input)
  · exact CADProjection.rational_zero_set_finite (Dense.denote p) hp
  · exact interpretedCells_valid input p hp K hK
  · exact interpretedCells_decomposition input p hp K hK hsupport hmark hconstant
  · exact tested_cell_rights_monotone input p hp K hK
  · exact hout

end ProjectedRun

end C2.CADDriver

namespace C2.CADNative
open Set C2.CADEffective

/-- The complete native program returns `none` exactly for an empty feasible
positive-gain set. Its only data arguments are the original rational polynomial
list and the rational search bound. -/
theorem run_none_iff_empty (input : List Bivariate.Poly) (K : ℚ) (hK : 0 < K)
    (K₀ : ℝ) (hbound : ∀ k ∈ CADDriver.positiveGains input, k ≤ K₀)
    (hstrict : K₀ < (K:ℝ)) :
    run input K hK = none ↔ CADDriver.positiveGains input = ∅ := by
  by_cases hz : Bivariate.nonzeroInputs input = true
  · let hF := (Bivariate.nonzeroInputs_iff input).mp hz
    rw [run_none_iff_of_nonzero input hF K hK]
    apply CADDriver.projected_run_none_iff input (projection input hF)
      (projection_nonzero input hF) K hK
    · intro k hk
      exact ⟨hk.1, (hbound k hk).trans_lt hstrict⟩
    · exact CADDriver.markGain_rawFeasible input
    · intro I hI hcut a b ha hb
      exact Bivariate.producedProjection_feasibility_constant input hF I hI hcut ha hb
  · have hf := Bool.eq_false_iff.mpr hz
    rw [run_of_zero input K hK hf, CADDriver.positiveGains_empty_of_zero input hf]
    simp

/-- A returned native root descriptor denotes exactly one real number. That
number is the least upper bound of every feasible positive gain, is algebraic,
and lies strictly inside the rational search bound. All projection, lifting,
isolation, sample and marking obligations are discharged internally. -/
theorem run_some_correct (input : List Bivariate.Poly) (K : ℚ) (hK : 0 < K)
    (K₀ : ℝ) (hbound : ∀ k ∈ CADDriver.positiveGains input, k ≤ K₀)
    (hstrict : K₀ < (K:ℝ)) {o : Output} (hout : run input K hK = some o) :
    ∃ b : ℝ,
      (∀ x : ℝ, Dense.rootAtRank o.isolation.polynomial 0 K o.isolation.mesh o.rank x ↔ x = b) ∧
      IsLUB (CADDriver.positiveGains input) b ∧ IsAlgebraic ℚ b ∧
      0 < b ∧ b ≤ K₀ ∧ b < (K:ℝ) := by
  have hne : (CADDriver.positiveGains input).Nonempty := by
    apply Set.nonempty_iff_ne_empty.mpr
    intro he
    have hn := (run_none_iff_empty input K hK K₀ hbound hstrict).mpr he
    rw [hout] at hn
    cases hn
  by_cases hz : Bivariate.nonzeroInputs input = true
  · let hF := (Bivariate.nonzeroInputs_iff input).mp hz
    obtain ⟨r, hr, rfl⟩ := (run_some_iff input hF K hK o).mp hout
    let p := projection input hF
    let hp := projection_nonzero input hF
    let b := CADDriver.rootValue p hp 0 K hK r
    have hmem := CADDriver.selected_rank_mem input p hp K hK.le hr
    have hb : Dense.rootAtRank (runNonzero input hF K hK).isolation.polynomial
        0 K (runNonzero input hF K hK).isolation.mesh r b :=
      CADDriver.rootValue_spec p hp 0 K hK hmem
    have hu := CADDriver.selected_rank_unique_root input p hp K hK hr
    have hlub : IsLUB (CADDriver.positiveGains input) b := by
      apply CADDriver.projected_run_some_isLUB input p hp K hK
      · intro k hk
        exact ⟨hk.1, (hbound k hk).trans_lt hstrict⟩
      · exact CADDriver.markGain_rawFeasible input
      · intro I hI hcut a c ha hc
        exact Bivariate.producedProjection_feasibility_constant input hF I hI hcut ha hc
      · exact hr
    obtain ⟨k, hk⟩ := hne
    have hbK : b ≤ K₀ := hlub.2 hbound
    refine ⟨b, ?_, hlub, CADDriver.rootValue_algebraic p hp 0 K hK hmem,
      hk.1.trans_le (hlub.1 hk), hbK, hbK.trans_lt hstrict⟩
    intro x
    constructor
    · intro hx
      exact hu.unique hx hb
    · intro hx
      simpa only [hx] using hb
  · have hf := Bool.eq_false_iff.mpr hz
    rw [run_of_zero input K hK hf] at hout
    cases hout

/-- End-to-end correctness of the total native CAD program. In particular the
finite maximum is the output actually computed from the input, rather than a
separately chosen mathematically valid cell calculation. -/
theorem native_gain_projection_correct (input : List Bivariate.Poly)
    (K : ℚ) (hK : 0 < K) (K₀ : ℝ)
    (hbound : ∀ k ∈ CADDriver.positiveGains input, k ≤ K₀)
    (hstrict : K₀ < (K:ℝ)) :
    (run input K hK = none ↔ CADDriver.positiveGains input = ∅) ∧
    ∀ o, run input K hK = some o →
      ∃ b : ℝ,
        (∀ x : ℝ, Dense.rootAtRank o.isolation.polynomial 0 K o.isolation.mesh o.rank x ↔ x = b) ∧
        IsLUB (CADDriver.positiveGains input) b ∧ IsAlgebraic ℚ b ∧
        0 < b ∧ b ≤ K₀ ∧ b < (K:ℝ) :=
  ⟨run_none_iff_empty input K hK K₀ hbound hstrict,
    fun _ ho => run_some_correct input K hK K₀ hbound hstrict ho⟩

/-- On a nonempty system the actual computed descriptor represents `sSup` of
all feasible positive gains, including components separated from zero. -/
theorem run_nonempty_supremum (input : List Bivariate.Poly)
    (K : ℚ) (hK : 0 < K) (K₀ : ℝ)
    (hbound : ∀ k ∈ CADDriver.positiveGains input, k ≤ K₀)
    (hstrict : K₀ < (K:ℝ)) (hne : (CADDriver.positiveGains input).Nonempty) :
    ∃ o : Output, run input K hK = some o ∧
      Dense.rootAtRank o.isolation.polynomial 0 K o.isolation.mesh o.rank
        (sSup (CADDriver.positiveGains input)) ∧
      IsAlgebraic ℚ (sSup (CADDriver.positiveGains input)) ∧
      0 < sSup (CADDriver.positiveGains input) ∧
      sSup (CADDriver.positiveGains input) ≤ K₀ ∧
      sSup (CADDriver.positiveGains input) < (K:ℝ) := by
  cases hout : run input K hK with
  | none =>
    exact (hne.ne_empty ((run_none_iff_empty input K hK K₀ hbound hstrict).mp hout)).elim
  | some o =>
    obtain ⟨b, hroot, hlub, halg, hpos, hle, hlt⟩ :=
      run_some_correct input K hK K₀ hbound hstrict hout
    have heq := hlub.csSup_eq hne
    exact ⟨o, rfl, (hroot _).mpr heq, heq.symm ▸ halg,
      heq.symm ▸ hpos, heq.symm ▸ hle, heq.symm ▸ hlt⟩

end C2.CADNative
