import C2.NGammaPhase

/-! The first phase crossing for several aligned delay samples.
This file proves phase existence, uniqueness and the strict frequency bound.
Root counting and the resulting full Schur interval are separate obligations. -/

noncomputable section
open Set Filter
open scoped Topology BigOperators

namespace C2.NGamma.Phase

def sumRatio {n : ℕ} (a x : Fin n → ℝ) (t : ℝ) : ℝ :=
  ∑ j, ratio (a j) (x j) t

def totalPhase {n : ℕ} (a x : Fin n → ℝ) (d : ℕ) (t : ℝ) : ℝ :=
  2*(d:ℝ)*Real.arctan t + ∑ j, contribution (a j) (x j) t

theorem sumRatio_strictMonoOn {n : ℕ} (hn : 0 < n) {a x : Fin n → ℝ}
    (hx : ∀ j, 0 ≤ x j) (hx1 : ∀ j, x j ≤ 1) (hax : ∀ j, x j < a j) :
    StrictMonoOn (sumRatio a x) (Ioi 0) := by
  intro s hs t ht hst
  apply Finset.sum_lt_sum
  · intro j _
    exact (ratio_strictMonoOn (hx j) (hx1 j) (hax j) hs ht hst).le
  · exact ⟨⟨0, hn⟩, Finset.mem_univ _,
      ratio_strictMonoOn (hx _) (hx1 _) (hax _) hs ht hst⟩

theorem sum_contribution_pos {n : ℕ} (hn : 0 < n) {a x : Fin n → ℝ}
    (hax : ∀ j, x j < a j) {t : ℝ} (ht : 0 < t) :
    0 < ∑ j, contribution (a j) (x j) t := by
  exact Finset.sum_pos (fun j _ => contribution_pos (hax j) ht)
    ⟨⟨0,hn⟩, Finset.mem_univ _⟩

theorem totalPhase_continuous {n : ℕ} (a x : Fin n → ℝ) (d : ℕ) :
    Continuous (totalPhase a x d) := by
  unfold totalPhase
  apply Continuous.add
  · exact continuous_const.mul Real.continuous_arctan
  · apply continuous_finset_sum
    intro j _
    unfold contribution
    exact (Real.continuous_arctan.comp (continuous_const.mul continuous_id)).sub
      (Real.continuous_arctan.comp (continuous_const.mul continuous_id))

theorem phase_eq_pi_iff_sumRatio {n : ℕ} (a x : Fin n → ℝ) (d : ℕ)
    {t : ℝ} (ht : 0 < t) :
    totalPhase a x d t = Real.pi ↔
    sumRatio a x t = 2*(d:ℝ)-((d:ℝ)-1)*Real.pi/Real.arctan (1/t) := by
  have hD : Real.arctan (1/t) ≠ 0 := (arctan_pos (one_div_pos.mpr ht)).ne'
  have hinv : Real.arctan (1/t) = Real.pi/2 - Real.arctan t := by
    simpa only [one_div] using Real.arctan_inv_of_pos ht
  have hsum : sumRatio a x t = (∑ j, contribution (a j) (x j) t)/Real.arctan (1/t) := by
    simp only [sumRatio, ratio, Finset.sum_div]
  rw [hsum]
  unfold totalPhase
  field_simp
  rw [hinv]
  constructor <;> intro h <;> linarith

theorem first_phase_crossing_exists {n d : ℕ} (hn : 0 < n) (hd : 2 ≤ d)
    {a x : Fin n → ℝ} (hax : ∀ j, x j < a j) :
    ∃ t : ℝ, 0 < t ∧ t < 1 ∧ totalPhase a x d t = Real.pi := by
  have hzero : totalPhase a x d 0 = 0 := by simp [totalPhase, contribution]
  have hone : Real.pi < totalPhase a x d 1 := by
    have hs := sum_contribution_pos hn hax (by norm_num : (0:ℝ) < 1)
    have hd' : (2:ℝ) ≤ d := by exact_mod_cast hd
    dsimp [totalPhase]
    rw [Real.arctan_one]
    nlinarith [Real.pi_pos]
  have hmem : Real.pi ∈ Icc (totalPhase a x d 0) (totalPhase a x d 1) := by
    rw [hzero]
    exact ⟨Real.pi_pos.le, hone.le⟩
  obtain ⟨t, ht, he⟩ := intermediate_value_Icc (by norm_num : (0:ℝ) ≤ 1)
    (totalPhase_continuous a x d).continuousOn hmem
  refine ⟨t, ?_, ?_, he⟩
  · by_contra! h
    have heq : t = 0 := le_antisymm h ht.1
    subst t
    rw [hzero] at he
    exact Real.pi_pos.ne he
  · by_contra hnot
    have h : 1 ≤ t := le_of_not_gt hnot
    have heq : t = 1 := le_antisymm ht.2 h
    subst t
    linarith

theorem first_phase_crossing_unique {n d : ℕ} (hn : 0 < n) (hd : 1 ≤ d)
    {a x : Fin n → ℝ} (hx : ∀ j, 0 ≤ x j) (hx1 : ∀ j, x j ≤ 1)
    (hax : ∀ j, x j < a j) {s t : ℝ} (hs : 0 < s) (ht : 0 < t)
    (hps : totalPhase a x d s = Real.pi) (hpt : totalPhase a x d t = Real.pi) : s = t := by
  have hmono := sumRatio_strictMonoOn hn hx hx1 hax
  have hc : 0 ≤ ((d:ℝ)-1)*Real.pi := by
    have hd' : (1:ℝ) ≤ d := by exact_mod_cast hd
    exact mul_nonneg (by linarith) Real.pi_pos.le
  have hanti : AntitoneOn
      (fun u : ℝ => 2*(d:ℝ)-((d:ℝ)-1)*Real.pi/Real.arctan (1/u)) (Ioi 0) := by
    intro u hu v hv huv
    have hu' : 0 < u := hu
    have hv' : 0 < v := hv
    have hDa : 0 < Real.arctan (1/v) := arctan_pos (one_div_pos.mpr hv')
    have hDb : Real.arctan (1/v) ≤ Real.arctan (1/u) :=
      Real.arctan_strictMono.monotone (one_div_le_one_div_of_le hu' huv)
    exact sub_le_sub_left (div_le_div_of_nonneg_left hc hDa hDb) _
  have hps' := (phase_eq_pi_iff_sumRatio a x d hs).mp hps
  have hpt' := (phase_eq_pi_iff_sumRatio a x d ht).mp hpt
  rcases lt_trichotomy s t with h | h | h
  · have hm := hmono hs ht h
    have ha := hanti hs ht h.le
    rw [hps', hpt'] at hm
    linarith
  · exact h
  · have hm := hmono ht hs h
    have ha := hanti ht hs h.le
    rw [hps', hpt'] at hm
    linarith

theorem phase_crossing_arctan_bound {n d : ℕ} (hn : 0 < n) (hd : 1 ≤ d)
    {a x : Fin n → ℝ} (hax : ∀ j, x j < a j) {t : ℝ} (ht : 0 < t)
    (he : totalPhase a x d t = Real.pi) :
    Real.arctan t < Real.pi/(2*(d:ℝ)) := by
  have hd' : (1:ℝ) ≤ d := by exact_mod_cast hd
  have hdpos : 0 < 2*(d:ℝ) := by linarith
  apply (lt_div_iff₀ hdpos).mpr
  have hs := sum_contribution_pos hn hax ht
  dsimp [totalPhase] at he
  nlinarith

theorem phase_crossing_frequency_bound {n d : ℕ} (hn : 0 < n) (hd : 2 ≤ d)
    {a x : Fin n → ℝ} (hax : ∀ j, x j < a j) {t : ℝ} (ht : 0 < t)
    (he : totalPhase a x d t = Real.pi) :
    t < Real.tan (Real.pi/(2*(d:ℝ))) := by
  have hd' : (2:ℝ) ≤ d := by exact_mod_cast hd
  have hpos : 0 < Real.pi/(2*(d:ℝ)) := div_pos Real.pi_pos (by linarith)
  have hhalf : Real.pi/(2*(d:ℝ)) < Real.pi/2 :=
    div_lt_div_of_pos_left Real.pi_pos (by norm_num) (by linarith)
  apply Real.arctan_strictMono.lt_iff_lt.mp
  rw [Real.arctan_tan (by linarith [Real.pi_pos]) hhalf]
  exact phase_crossing_arctan_bound hn (by omega) hax ht he

/-- Complete analytic crossing assertion of the multiple-delay corollary.
The Schur-interval conclusion is not part of this theorem. -/
theorem multiple_delay_unique_phase_crossing {n d : ℕ} (hn : 0 < n) (hd : 2 ≤ d)
    {a x : Fin n → ℝ} (hx : ∀ j, 0 ≤ x j) (hx1 : ∀ j, x j ≤ 1)
    (hax : ∀ j, x j < a j) :
    ∃! t : ℝ, 0 < t ∧ t < Real.tan (Real.pi/(2*(d:ℝ))) ∧
      totalPhase a x d t = Real.pi := by
  obtain ⟨t, ht, _, he⟩ := first_phase_crossing_exists hn hd hax
  refine ⟨t, ⟨ht, phase_crossing_frequency_bound hn hd hax ht he, he⟩, ?_⟩
  intro s hs
  exact first_phase_crossing_unique hn (by omega) hx hx1 hax hs.1 ht hs.2.2 he

end C2.NGamma.Phase
