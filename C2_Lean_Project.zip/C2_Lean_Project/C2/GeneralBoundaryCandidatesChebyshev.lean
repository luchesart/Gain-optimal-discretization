import C2.Boundary
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Chebyshev

/-! Exact Chebyshev polynomial for the imaginary cross product of two real
polynomials. The finite double sum is the ungrouped form of the manuscript's
coefficient formula c_q: the integer-index convention automatically gives
U_{-q-1}=-U_{q-1}, while U_{-1}=0. -/
noncomputable section
open scoped BigOperators
open Polynomial ComplexConjugate
namespace C2.GeneralBoundaryCandidates

def evalC (p : ℝ[X]) (z : ℂ) : ℂ := aeval z p

def point (θ : ℝ) : ℂ := Complex.exp ((θ:ℂ)*Complex.I)

def Q (H N : ℝ[X]) : ℝ[X] :=
  ∑ i ∈ H.support, ∑ j ∈ N.support,
    C (H.coeff i*N.coeff j)*Polynomial.Chebyshev.U ℝ ((i:ℤ)-(j:ℤ)-1)

theorem evalC_sum (p : ℝ[X]) (z : ℂ) :
    evalC p z = ∑ i ∈ p.support, (p.coeff i:ℂ)*z^i := by
  simp [evalC,aeval_def,Polynomial.eval₂_eq_sum,Polynomial.sum]

theorem point_re (θ : ℝ) : (point θ).re = Real.cos θ := by
  exact Complex.exp_ofReal_mul_I_re θ

theorem point_im (θ : ℝ) : (point θ).im = Real.sin θ := by
  exact Complex.exp_ofReal_mul_I_im θ

theorem power_cross_im (i j : ℕ) (θ : ℝ) :
    ((point θ)^i*star ((point θ)^j)).im =
      Real.sin θ*(Polynomial.Chebyshev.U ℝ ((i:ℤ)-(j:ℤ)-1)).eval (Real.cos θ) := by
  have he : (point θ)^i*star ((point θ)^j) =
      Complex.exp (((((i:ℝ)-(j:ℝ))*θ:ℝ):ℂ)*Complex.I) := by
    unfold point
    rw [← Complex.exp_nat_mul, ← Complex.exp_nat_mul]
    change Complex.exp _*(starRingEnd ℂ) (Complex.exp _) = _
    rw [← Complex.exp_conj, ← Complex.exp_add]
    congr 1
    simp
    push_cast
    ring
  rw [he]
  have htrig := Polynomial.Chebyshev.U_real_cos θ ((i:ℤ)-(j:ℤ)-1)
  rw [Complex.exp_ofReal_mul_I_im]
  have harg : (((i:ℤ)-(j:ℤ)-1:ℤ):ℝ)+1=(i:ℝ)-(j:ℝ) := by push_cast; ring
  rw [harg] at htrig
  simpa only [mul_comm] using htrig.symm

theorem coefficient_power_cross_im (h n : ℝ) (i j : ℕ) (θ : ℝ) :
    ((h:ℂ)*(point θ)^i*star ((n:ℂ)*(point θ)^j)).im =
      h*n*(Real.sin θ*(Polynomial.Chebyshev.U ℝ ((i:ℤ)-(j:ℤ)-1)).eval (Real.cos θ)) := by
  have he : (h:ℂ)*(point θ)^i*star ((n:ℂ)*(point θ)^j) =
      ((h*n:ℝ):ℂ)*((point θ)^i*star ((point θ)^j)) := by
    simp
    ring
  rw [he]
  rw [Complex.mul_im]
  simp only [Complex.ofReal_re,Complex.ofReal_im,zero_mul,add_zero]
  rw [power_cross_im]

theorem chebyshev_identity (H N : ℝ[X]) (θ : ℝ) :
    (evalC H (point θ)*star (evalC N (point θ))).im =
      Real.sin θ*(Q H N).eval (Real.cos θ) := by
  rw [evalC_sum,evalC_sum]
  simp only [star_sum,Finset.sum_mul,Finset.mul_sum,Complex.im_sum]
  simp_rw [coefficient_power_cross_im]
  simp only [Q,Polynomial.eval_finset_sum,Polynomial.eval_mul,Polynomial.eval_C,
    Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  ring

theorem chebyshev_identity_on_circle (H N : ℝ[X]) {z : ℂ} (hz : ‖z‖ = 1) :
    (evalC H z*star (evalC N z)).im = z.im*(Q H N).eval z.re := by
  obtain ⟨θ,rfl⟩ := (Complex.norm_eq_one_iff z).mp hz
  change (evalC H (point θ)*star (evalC N (point θ))).im = _
  rw [chebyshev_identity]
  change _ = (point θ).im*(Q H N).eval (point θ).re
  rw [point_im,point_re]

theorem evalC_conj (p : ℝ[X]) (z : ℂ) : evalC p (star z) = star (evalC p z) := by
  exact Polynomial.aeval_conj p z

theorem evalC_ofReal (p : ℝ[X]) (x : ℝ) : evalC p (x:ℂ) = ((p.eval x:ℝ):ℂ) := by
  exact Polynomial.aeval_ofReal p x

end C2.GeneralBoundaryCandidates
