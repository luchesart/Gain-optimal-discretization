import Mathlib.LinearAlgebra.Matrix.SchurComplement
import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.Tactic

/-! A concrete causal realization of arbitrary integer output delays.
Each step appends the previous output as one new state.  The determinant
formula below concerns this actual augmented matrix, not a prescribed
characteristic polynomial. -/
noncomputable section
open Matrix
namespace C2.NGamma.Realization.Delay

structure StateSpace (𝕜 : Type) where
  State : Type
  fintype : Fintype State
  decEq : DecidableEq State
  A : Matrix State State 𝕜
  B : State → 𝕜
  C : State → 𝕜
  D : 𝕜

attribute [instance] StateSpace.fintype StateSpace.decEq
variable {𝕜 : Type} [Field 𝕜]

def pencil (S : StateSpace 𝕜) (z : 𝕜) := z • (1 : Matrix S.State S.State 𝕜) - S.A

def transfer (S : StateSpace 𝕜) (z : 𝕜) := S.D + S.C ⬝ᵥ ((pencil S z)⁻¹ *ᵥ S.B)

/-- Append q[k+1] = y[k] and use q as the new output. -/
def append (S : StateSpace 𝕜) : StateSpace 𝕜 where
  State := S.State ⊕ Unit
  fintype := inferInstance
  decEq := inferInstance
  A := Matrix.fromBlocks S.A 0 (Matrix.replicateRow Unit S.C) 0
  B := Sum.elim S.B (fun _ => S.D)
  C := Sum.elim (fun _ => 0) (fun _ => 1)
  D := 0

def delay (S : StateSpace 𝕜) : ℕ → StateSpace 𝕜
  | 0 => S
  | d + 1 => append (delay S d)

lemma delay_card (S : StateSpace 𝕜) (d : ℕ) :
    Fintype.card (delay S d).State = Fintype.card S.State + d := by
  induction d with
  | zero => simp [delay]
  | succ d ih => simpa [delay, append, Fintype.card_sum] using congrArg (· + 1) ih

lemma pencil_append (S : StateSpace 𝕜) (z : 𝕜) :
    pencil (append S) z = Matrix.fromBlocks (pencil S z) 0
      (-Matrix.replicateRow Unit S.C) (z • (1 : Matrix Unit Unit 𝕜)) := by
  ext i j
  cases i <;> cases j <;>
    simp [pencil, append, Matrix.fromBlocks, Matrix.one_apply]

lemma det_pencil_append (S : StateSpace 𝕜) (z : 𝕜) :
    (pencil (append S) z).det = z * (pencil S z).det := by
  rw [pencil_append, Matrix.det_fromBlocks_zero₁₂]
  simp [Matrix.det_unique, mul_comm]

lemma det_pencil_delay (S : StateSpace 𝕜) (z : 𝕜) (d : ℕ) :
    (pencil (delay S d) z).det = z ^ d * (pencil S z).det := by
  induction d with
  | zero => simp [delay]
  | succ d ih => rw [delay, det_pencil_append, ih, pow_succ]; ring

lemma transfer_append (S : StateSpace 𝕜) {z : 𝕜} (hz : z ≠ 0)
    (hM : (pencil S z).det ≠ 0) :
    transfer (append S) z = transfer S z / z := by
  let H := pencil S z
  have hH : IsUnit H.det := isUnit_iff_ne_zero.mpr hM
  let v := Sum.elim (H⁻¹ *ᵥ S.B) (fun _ : Unit => transfer S z / z)
  have hv : pencil (append S) z *ᵥ v = (append S).B := by
    rw [pencil_append]
    change Matrix.fromBlocks H 0 (-Matrix.replicateRow Unit S.C)
      (z • (1 : Matrix Unit Unit 𝕜)) *ᵥ v = _
    rw [Matrix.fromBlocks_mulVec]
    have hinv : H *ᵥ (H⁻¹ *ᵥ S.B) = S.B := by
      rw [Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv H hH, Matrix.one_mulVec]
    ext i
    cases i with
    | inl i => simpa [v, append] using congrFun hinv i
    | inr i =>
      change ((-Matrix.replicateRow Unit S.C) *ᵥ (H⁻¹ *ᵥ S.B) +
        (z • (1 : Matrix Unit Unit 𝕜)) *ᵥ (fun _ => transfer S z / z)) i = S.D
      rw [Matrix.neg_mulVec, Matrix.replicateRow_mulVec_eq_const,
        Matrix.smul_mulVec_assoc, Matrix.one_mulVec]
      change -(S.C ⬝ᵥ (H⁻¹ *ᵥ S.B)) + z * (transfer S z / z) = S.D
      dsimp [transfer, H]
      field_simp
      <;> ring
  have hP : IsUnit (pencil (append S) z).det := by
    rw [det_pencil_append]
    exact isUnit_iff_ne_zero.mpr (mul_ne_zero hz hM)
  have hinv : (pencil (append S) z)⁻¹ *ᵥ (append S).B = v := by
    rw [← hv, Matrix.mulVec_mulVec, Matrix.nonsing_inv_mul _ hP, Matrix.one_mulVec]
  unfold transfer
  rw [hinv]
  simp [append, v, transfer, dotProduct, Fintype.sum_sum_type]

lemma transfer_delay (S : StateSpace 𝕜) {z : 𝕜} (hz : z ≠ 0)
    (hM : (pencil S z).det ≠ 0) (d : ℕ) :
    transfer (delay S d) z = transfer S z / z ^ d := by
  induction d with
  | zero => simp [delay]
  | succ d ih =>
    rw [delay, transfer_append _ hz, ih, div_div, pow_succ]
    rw [det_pencil_delay]
    exact mul_ne_zero (pow_ne_zero _ hz) hM

/-- Negative static feedback on a strictly proper state realization. -/
def closedLoop (S : StateSpace 𝕜) (k : 𝕜) : Matrix S.State S.State 𝕜 :=
  S.A - Matrix.replicateCol Unit (k • S.B) * Matrix.replicateRow Unit S.C

lemma det_closedLoop (S : StateSpace 𝕜) (z k : 𝕜)
    (hM : (pencil S z).det ≠ 0) :
    (z • (1 : Matrix S.State S.State 𝕜) - closedLoop S k).det =
      (pencil S z).det * (1 + k * (S.C ⬝ᵥ ((pencil S z)⁻¹ *ᵥ S.B))) := by
  have hp : z • (1 : Matrix S.State S.State 𝕜) - closedLoop S k =
      pencil S z + Matrix.replicateCol Unit (k • S.B) * Matrix.replicateRow Unit S.C := by
    unfold closedLoop pencil
    abel
  rw [hp, Matrix.det_add_replicateCol_mul_replicateRow (isUnit_iff_ne_zero.mpr hM)]
  simp only [Matrix.det_unique]
  congr 1
  simp only [Matrix.add_apply, Matrix.one_apply_eq, Matrix.mul_apply,
    Matrix.replicateRow, Matrix.replicateCol, Matrix.mulVec,
    dotProduct, Finset.mul_sum, Finset.sum_mul, Pi.smul_apply, smul_eq_mul]
  congr 1
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro j hj
  simp only [Matrix.of_apply]
  ring

lemma delay_feedthrough (S : StateSpace 𝕜) {d : ℕ} (hd : 0 < d) : (delay S d).D = 0 := by
  obtain ⟨d, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hd)
  rfl

/-- Exact determinant of the concrete n+d dimensional feedback realization,
initially away from z=0 and the plant eigenvalues. -/
lemma delayed_closedLoop_determinant (S : StateSpace 𝕜) {d : ℕ} (hd : 0 < d)
    (z k : 𝕜) (hz : z ≠ 0) (hM : (pencil S z).det ≠ 0) :
    (z • (1 : Matrix (delay S d).State (delay S d).State 𝕜) -
      closedLoop (delay S d) k).det =
      z ^ d * (pencil S z).det + k * ((pencil S z).det * transfer S z) := by
  have hMd : (pencil (delay S d) z).det ≠ 0 := by
    rw [det_pencil_delay]
    exact mul_ne_zero (pow_ne_zero _ hz) hM
  rw [det_closedLoop _ _ _ hMd, det_pencil_delay]
  have ht : (delay S d).C ⬝ᵥ ((pencil (delay S d) z)⁻¹ *ᵥ (delay S d).B) =
      transfer S z / z ^ d := by
    simpa [transfer, delay_feedthrough S hd] using transfer_delay S hz hM d
  rw [ht]
  field_simp
  <;> ring

end C2.NGamma.Realization.Delay
