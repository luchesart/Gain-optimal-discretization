import C2.NGammaRealization

/-! Polynomial numerator/denominator of the actual state realization.
The numerator degree bound uses Cramer's rule: each replacement column is
still affine in z, so every determinant has degree at most the state count. -/
noncomputable section
namespace C2.NGamma.Realization
open Matrix Polynomial
variable {ι : Type*} [Fintype ι] [DecidableEq ι]
variable {𝕜 : Type*} [Field 𝕜]

def pencil (T : 𝕜) (Γ A : Matrix ι ι 𝕜) : Matrix ι ι 𝕜[X] :=
  (X : 𝕜[X]) • (E T Γ A).map Polynomial.C + (-F T Γ A).map Polynomial.C

def inputPencil (Γ : Matrix ι ι 𝕜) (B : ι → 𝕜) : ι → 𝕜[X] :=
  fun i => X * Polynomial.C ((Γ *ᵥ B) i) + Polynomial.C (((1-Γ) *ᵥ B) i)

def denominator (T : 𝕜) (Γ A : Matrix ι ι 𝕜) : 𝕜[X] := (pencil T Γ A).det

def numerator (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D : 𝕜) : 𝕜[X] :=
  Polynomial.C D * denominator T Γ A + Polynomial.C T *
    dotProduct (fun i => Polynomial.C (C i))
      ((pencil T Γ A).adjugate *ᵥ inputPencil Γ B)

lemma denominator_degree_le (T : 𝕜) (Γ A : Matrix ι ι 𝕜) :
    (denominator T Γ A).natDegree ≤ Fintype.card ι :=
  Polynomial.natDegree_det_X_add_C_le _ _

lemma denominator_top_coeff (T : 𝕜) (Γ A : Matrix ι ι 𝕜) :
    (denominator T Γ A).coeff (Fintype.card ι) = (E T Γ A).det :=
  Polynomial.coeff_det_X_add_C_card _ _

/-- The denominator has exactly n degrees; det E is retained, not cancelled. -/
theorem denominator_degree (T : 𝕜) (Γ A : Matrix ι ι 𝕜)
    (hE : (E T Γ A).det ≠ 0) :
    (denominator T Γ A).natDegree = Fintype.card ι := by
  apply le_antisymm (denominator_degree_le T Γ A)
  exact Polynomial.le_natDegree_of_ne_zero (by rwa [denominator_top_coeff])

lemma replacement_affine (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B : ι → 𝕜) (i : ι) :
    (pencil T Γ A).updateCol i (inputPencil Γ B) =
      (X : 𝕜[X]) • ((E T Γ A).updateCol i (Γ *ᵥ B)).map Polynomial.C +
        ((-F T Γ A).updateCol i ((1-Γ) *ᵥ B)).map Polynomial.C := by
  ext j k
  by_cases hk : k = i
  · subst k
    simp [pencil, inputPencil, Matrix.updateCol_apply, Matrix.map_apply]
  · simp [pencil, inputPencil, Matrix.updateCol_apply, Matrix.map_apply, hk]

/-- The uncancelled numerator has degree at most n, including feedthrough. -/
theorem numerator_degree_le (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D : 𝕜) :
    (numerator T Γ A B C D).natDegree ≤ Fintype.card ι := by
  unfold numerator
  apply (Polynomial.natDegree_add_le _ _).trans
  apply max_le
  · exact (Polynomial.natDegree_C_mul_le _ _).trans (denominator_degree_le T Γ A)
  · apply (Polynomial.natDegree_C_mul_le _ _).trans
    rw [← Matrix.cramer_eq_adjugate_mulVec]
    unfold dotProduct
    apply Polynomial.natDegree_sum_le_of_forall_le
    intro i _
    apply (Polynomial.natDegree_C_mul_le _ _).trans
    rw [Matrix.cramer_apply, replacement_affine]
    exact Polynomial.natDegree_det_X_add_C_le _ _

lemma pencil_eval (T z : 𝕜) (Γ A : Matrix ι ι 𝕜) :
    (pencil T Γ A).map (Polynomial.eval z) = M T Γ A z := by
  ext i j
  simp [pencil, M, Matrix.map_apply]
  ring

lemma inputPencil_eval (Γ : Matrix ι ι 𝕜) (B : ι → 𝕜) (z : 𝕜) :
    (fun i => Polynomial.eval z (inputPencil Γ B i)) = Q Γ z *ᵥ B := by
  ext i
  simp [inputPencil, Q, Matrix.add_mulVec, Matrix.smul_mulVec_assoc]
  ring

lemma denominator_eval (T z : 𝕜) (Γ A : Matrix ι ι 𝕜) :
    (denominator T Γ A).eval z = (M T Γ A z).det := by
  exact ((Polynomial.evalRingHom z).map_det (pencil T Γ A)).trans
    (congrArg Matrix.det (pencil_eval T z Γ A))

lemma numerator_eval (T z : 𝕜) (Γ A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D : 𝕜) :
    (numerator T Γ A B C D).eval z =
      D*(M T Γ A z).det + T*dotProduct C ((M T Γ A z).adjugate *ᵥ (Q Γ z *ᵥ B)) := by
  have ha := (Polynomial.evalRingHom z).map_adjugate (pencil T Γ A)
  change ((pencil T Γ A).adjugate.map (Polynomial.eval z)) =
    ((pencil T Γ A).map (Polynomial.eval z)).adjugate at ha
  rw [pencil_eval] at ha
  unfold numerator
  simp only [Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_C, denominator_eval]
  congr 2
  simp only [dotProduct, Matrix.mulVec, Polynomial.eval_finset_sum, Polynomial.eval_mul,
    Polynomial.eval_C]
  apply Finset.sum_congr rfl
  intro i _
  congr 1
  apply Finset.sum_congr rfl
  intro j _
  have hb := congrFun (inputPencil_eval Γ B z) j
  change _ = (Q Γ z *ᵥ B) j at hb
  rw [hb]
  exact congrArg (fun a => a * (Q Γ z *ᵥ B) j) (congrFun (congrFun ha i) j)

/-- Exact rational transfer identity at every nonsingular transform point. -/
theorem transfer_quotient (T z : 𝕜) (Γ A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D : 𝕜)
    (hM : (M T Γ A z).det ≠ 0) :
    D + T*dotProduct C ((M T Γ A z)⁻¹ *ᵥ (Q Γ z *ᵥ B)) =
      (numerator T Γ A B C D).eval z / (denominator T Γ A).eval z := by
  rw [numerator_eval, denominator_eval, Matrix.inv_def, Ring.inverse_eq_inv,
    Matrix.smul_mulVec_assoc, dotProduct_smul]
  simp only [smul_eq_mul]
  field_simp

/-- Literal degree statements, with the zero numerator correctly having
 degree minus infinity. -/
theorem polynomial_degrees (T : 𝕜) (Γ A : Matrix ι ι 𝕜) (B C : ι → 𝕜) (D : 𝕜)
    (hE : (E T Γ A).det ≠ 0) :
    (denominator T Γ A).degree = (Fintype.card ι : WithBot ℕ) ∧
      (numerator T Γ A B C D).degree ≤ (Fintype.card ι : WithBot ℕ) := by
  constructor
  · have hd : denominator T Γ A ≠ 0 := by
      intro h
      have hc := denominator_top_coeff T Γ A
      rw [h, Polynomial.coeff_zero] at hc
      exact hE hc.symm
    rw [Polynomial.degree_eq_natDegree hd, denominator_degree T Γ A hE]
  · exact Polynomial.degree_le_of_natDegree_le (numerator_degree_le T Γ A B C D)

end C2.NGamma.Realization
