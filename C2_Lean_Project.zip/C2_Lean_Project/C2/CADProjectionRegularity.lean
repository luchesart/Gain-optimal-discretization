import C2.CADProjectionBezout

/-! A finite algebraic exceptional set for rational bivariate polynomials.
The exceptional polynomial is derived from generic separability through the
proved Bezout construction. These are mathematical projection results; the
choice of the Bezout coefficients is not advertised as executable code. -/
noncomputable section
open Polynomial
namespace C2.CADProjection

abbrev Bivariate := Polynomial (Polynomial ℚ)

def specialize (p : Bivariate) (k : ℝ) : ℝ[X] :=
  p.map (Polynomial.eval₂RingHom (algebraMap ℚ ℝ) k)

def value (p : Bivariate) (k x : ℝ) : ℝ := (specialize p k).eval x

def RegularAt (p : Bivariate) (k : ℝ) : Prop :=
  (specialize p k).natDegree = p.natDegree ∧
  ∀ x : ℝ, value p k x = 0 → (specialize p k).derivative.eval x ≠ 0

@[simp] theorem value_derivative (p : Bivariate) (k x : ℝ) :
    value p.derivative k x = (specialize p k).derivative.eval x := by
  simp only [value, specialize, Polynomial.derivative_map]

@[simp] theorem value_mul (p q : Bivariate) (k x : ℝ) :
    value (p*q) k x = value p k x * value q k x := by
  simp [value,specialize]

@[simp] theorem value_X (k x : ℝ) : value (X : Bivariate) k x = x := by
  simp [value,specialize]

@[simp] theorem value_C (p : ℚ[X]) (k x : ℝ) :
    value (C p) k x = p.eval₂ (algebraMap ℚ ℝ) k := by
  simp [value,specialize]

@[simp] theorem value_sub (p q : Bivariate) (k x : ℝ) :
    value (p-q) k x = value p k x - value q k x := by
  simp [value,specialize]

/-- Joint continuity in the gain and parameter, without any root hypotheses. -/
theorem continuous_value (p : Bivariate) :
    Continuous (fun y : ℝ × ℝ => value p y.1 y.2) := by
  induction p using Polynomial.induction_on' with
  | add p q hp hq =>
      simpa [value,specialize] using hp.add hq
  | monomial n a =>
      simpa [value,specialize] using
        ((a.continuous_eval₂ (algebraMap ℚ ℝ)).comp continuous_fst).mul
          (continuous_snd.pow n)

/-- A nonzero rational polynomial has finitely many real zeros. -/
theorem rational_zero_set_finite (p : ℚ[X]) (hp : p ≠ 0) :
    Set.Finite {k : ℝ | p.eval₂ (algebraMap ℚ ℝ) k = 0} := by
  have hm : p.map (algebraMap ℚ ℝ) ≠ 0 := by
    intro h
    exact hp ((Polynomial.map_injective (f:=algebraMap ℚ ℝ)
      (algebraMap ℚ ℝ).injective) (by simpa using h))
  simpa only [Polynomial.IsRoot,Polynomial.eval_map] using
    Polynomial.finite_setOf_isRoot hm

/-- Every zero of the projection polynomial is a real algebraic number. -/
theorem rational_zero_isAlgebraic (p : ℚ[X]) (hp : p ≠ 0) {k : ℝ}
    (hk : p.eval₂ (algebraMap ℚ ℝ) k = 0) : IsAlgebraic ℚ k :=
  ⟨p,hp,hk⟩

/-- A separable generic polynomial admits one nonzero rational gain
polynomial excluding all degree losses and all multiple specialized roots. -/
theorem exists_regular_projection (p : Bivariate) (hp : p ≠ 0)
    (hsep : (p.map (algebraMap ℚ[X] (RatFunc ℚ))).Separable) :
    ∃ d : ℚ[X], d ≠ 0 ∧
      Set.Finite {k : ℝ | d.eval₂ (algebraMap ℚ ℝ) k = 0} ∧
      (∀ k : ℝ, d.eval₂ (algebraMap ℚ ℝ) k = 0 → IsAlgebraic ℚ k) ∧
      ∀ k : ℝ, d.eval₂ (algebraMap ℚ ℝ) k ≠ 0 → RegularAt p k := by
  obtain ⟨r,hr,hcut⟩ := exists_simple_root_cut p hsep
  let d := p.leadingCoeff * r
  have hd : d ≠ 0 := mul_ne_zero (Polynomial.leadingCoeff_ne_zero.mpr hp) hr
  refine ⟨d,hd,rational_zero_set_finite d hd,fun k hk =>
    rational_zero_isAlgebraic d hd hk,fun k hk => ?_⟩
  have hparts : p.leadingCoeff.eval₂ (algebraMap ℚ ℝ) k ≠ 0 ∧
      r.eval₂ (algebraMap ℚ ℝ) k ≠ 0 := by
    simpa only [d,Polynomial.eval₂_mul,mul_ne_zero_iff] using hk
  refine ⟨?_,fun x hx => ?_⟩
  · exact Polynomial.natDegree_map_eq_iff.mpr (Or.inl hparts.1)
  · exact hcut (Polynomial.eval₂RingHom (algebraMap ℚ ℝ) k) hparts.2 x hx

/-- Additional denominators or gain-only factors can be added to the
projection without invalidating the proved generic-root regularity. -/
theorem exists_regular_projection_with_extra (p : Bivariate) (hp : p ≠ 0)
    (hsep : (p.map (algebraMap ℚ[X] (RatFunc ℚ))).Separable)
    (a : ℚ[X]) (ha : a ≠ 0) :
    ∃ d : ℚ[X], d ≠ 0 ∧
      Set.Finite {k : ℝ | d.eval₂ (algebraMap ℚ ℝ) k = 0} ∧
      (∀ k : ℝ, d.eval₂ (algebraMap ℚ ℝ) k = 0 → IsAlgebraic ℚ k) ∧
      ∀ k : ℝ, d.eval₂ (algebraMap ℚ ℝ) k ≠ 0 →
        a.eval₂ (algebraMap ℚ ℝ) k ≠ 0 ∧ RegularAt p k := by
  obtain ⟨d,hd,_,_,hreg⟩ := exists_regular_projection p hp hsep
  refine ⟨a*d,mul_ne_zero ha hd,rational_zero_set_finite _ (mul_ne_zero ha hd),
    fun k hk => rational_zero_isAlgebraic _ (mul_ne_zero ha hd) hk,fun k hk => ?_⟩
  have hx : a.eval₂ (algebraMap ℚ ℝ) k ≠ 0 ∧ d.eval₂ (algebraMap ℚ ℝ) k ≠ 0 := by
    simpa only [Polynomial.eval₂_mul,mul_ne_zero_iff] using hk
  exact ⟨hx.1,hreg k hx.2⟩

end C2.CADProjection
