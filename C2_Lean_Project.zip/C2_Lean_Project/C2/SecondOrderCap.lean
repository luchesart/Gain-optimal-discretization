import C2.SecondOrder

/-!
# Exact stable-gain threshold, including parameters with no positive stable gain

This module matches the paper's convention `sup ({0} ∪ stable positive gains)`.
The zero is only a convention for the threshold: it is not declared strictly stable.
-/
noncomputable section
namespace C2.SecondOrder

/-- The upper stable-gain threshold used in the paper. -/
def gainCap (u v t : ℝ) : ℝ := sSup (insert 0 (stableGains u v t))

theorem stableGains_bddAbove {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (ht : -1 ≤ t) : BddAbove (stableGains u v t) := by
  refine ⟨optimum u r,?_⟩
  intro b hb
  exact le_of_lt (schur_global_gain_bound hu hv hr hr1 hf ht hb.1 hb.2)

theorem gainCap_eq_zero_of_empty {u v t : ℝ} (hs : stableGains u v t = ∅) :
    gainCap u v t = 0 := by
  simp [gainCap,hs]

theorem gainCap_eq_sSup_of_nonempty {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (ht : -1 ≤ t) (hs : (stableGains u v t).Nonempty) :
    gainCap u v t = sSup (stableGains u v t) := by
  have hbdd := stableGains_bddAbove hu hv hr hr1 hf ht
  unfold gainCap
  rw [csSup_insert hbdd hs]
  obtain ⟨b,hb⟩ := hs
  exact max_eq_right (le_of_lt (lt_of_lt_of_le hb.1 (le_csSup hbdd hb)))

theorem gainCap_at_optimum {u v r : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) : gainCap u v r = optimum u r := by
  have hs := (optimal_gain_isLUB hu hv hr hr1 hf).insert 0
  have hmax : (0:ℝ) ⊔ optimum u r = optimum u r :=
    max_eq_right (le_of_lt (optimum_positive hu hr))
  rw [hmax] at hs
  exact hs.csSup_eq ⟨0,Set.mem_insert _ _⟩

/-- Strict loss at every other admissible parameter, including those
for which the positive stable-gain set is empty. -/
theorem gainCap_strictly_suboptimal {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (ht : -1 ≤ t) (hne : t ≠ r) :
    gainCap u v t < optimum u r := by
  by_cases hs : (stableGains u v t).Nonempty
  · rw [gainCap_eq_sSup_of_nonempty hu hv hr hr1 hf ht hs]
    exact suboptimal_parameter_strict hu hv hr hr1 hf ht hne hs
  · rw [gainCap_eq_zero_of_empty (Set.not_nonempty_iff_eq_empty.mp hs)]
    exact optimum_positive hu hr

theorem gainCap_global_bound {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (ht : -1 ≤ t) :
    gainCap u v t ≤ optimum u r := by
  by_cases htr : t = r
  · subst t
    exact le_of_eq (gainCap_at_optimum hu hv hr hr1 hf)
  · exact le_of_lt (gainCap_strictly_suboptimal hu hv hr hr1 hf ht htr)

theorem gainCap_eq_optimum_iff {u v r t : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) (ht : -1 ≤ t) :
    gainCap u v t = optimum u r ↔ t = r := by
  constructor
  · intro heq
    by_contra hne
    have hh := gainCap_strictly_suboptimal hu hv hr hr1 hf ht hne
    linarith
  · intro heq
    subst t
    exact gainCap_at_optimum hu hv hr hr1 hf

/-- Full existence, sharpness and unique gamma maximization with the paper's
zero-adjoined threshold convention. -/
theorem global_gamma_gainCap {u v : ℝ} (hu : 0 < u) (hv : 0 < v) :
    ∃ r : ℝ, 0 < r ∧ r < 1 ∧ f u v r = 0 ∧
      (∀ g : ℝ, 0 ≤ g → g ≤ 1 → gainCap u v (2*g-1) ≤ optimum u r) ∧
      (∀ g : ℝ, 0 ≤ g → g ≤ 1 →
        (gainCap u v (2*g-1) = optimum u r ↔ g = gamma r)) := by
  obtain ⟨r,⟨hr,hr1,hf⟩,_⟩ := exists_unique_optimal_root hu hv
  refine ⟨r,hr,hr1,hf,?_,?_⟩
  · intro g hg _
    exact gainCap_global_bound hu hv hr hr1 hf (by linarith)
  · intro g hg _
    rw [gainCap_eq_optimum_iff hu hv hr hr1 hf (by linarith)]
    unfold gamma
    constructor <;> intro h <;> linarith

end C2.SecondOrder
