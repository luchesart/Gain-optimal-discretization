import C2.NGammaRootCount
import C2.NGammaLowGain
import C2.NGammaPhaseOrder
import C2.NGammaAmplitudeOrder

/-! Exact gain interval below the finite or infinite amplitude endpoint.
All stability statements concern roots of the actual characteristic polynomial. -/
noncomputable section
open scoped BigOperators
namespace C2.NGamma.Cayley
open PolynomialModel

lemma existsUnique_amplitude_crossing_in_range {n : ℕ} (hn : 0 < n)
    {r x : Fin n → ℝ} (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i)
    {b : ℝ} (hb : (∏ i, r i) < b)
    (hbound : (∃ j, x j = 0) ∨ b < ∏ i, (r i+2/x i)) :
    ∃! t : ℝ, 0 < t ∧ amplitude r x t = b := by
  by_cases hz : ∃ j, x j = 0
  · obtain ⟨j, hj⟩ := hz
    exact existsUnique_amplitude_crossing_of_zero hn hr hx hj hb
  · have hxp : ∀ i, 0 < x i := fun i =>
      lt_of_le_of_ne (hx i) (Ne.symm (fun he => hz ⟨i, he⟩))
    exact existsUnique_amplitude_crossing hn hr hxp hb (hbound.resolve_left hz)

lemma interior_interval_below_endpoint {n d : ℕ} (hn : 0 < n) (hd : 1 ≤ d)
    {r x : Fin n → ℝ} (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i)
    (hx1 : ∀ i, x i ≤ 1) {s : ℝ} (hs : 0 < s)
    (hphase : Phase.totalPhase (fun i => x i+2/r i) x d s = Real.pi)
    {b : ℝ} (hb : 0 ≤ b)
    (hbound : (∃ j, x j = 0) ∨ b < ∏ i, (r i+2/x i)) :
    SchurStable (characteristic r x d b) ↔ b < amplitude r x s := by
  have hbase := base_gain_lt_amplitude hn hr hx hs
  by_cases hlow : b ≤ ∏ i, r i
  · exact iff_of_true (low_gain_schur_fin hn hr hx d hb hlow) (lt_of_le_of_lt hlow hbase)
  · obtain ⟨t, ⟨ht, hBt⟩, _⟩ := existsUnique_amplitude_crossing_in_range hn hr hx
      (lt_of_not_ge hlow) hbound
    rw [schur_iff_phase_lt_pi_at_magnitude_crossing hn hd hr hx ht hBt hbound]
    rw [(Phase.phase_before_after_crossing hn hd hx hx1
      (fun i => lt_add_of_pos_right _ (div_pos (by norm_num) (hr i))) hs ht hphase).1]
    rw [← hBt]
    exact ((amplitude_strictMonoOn hn hr hx).lt_iff_lt ht.le hs.le).symm

lemma single_sample_endpoint_stable {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 < x i) (hx1 : ∀ i, x i ≤ 1)
    (hS : Phase.endpointSum r x ≤ 1) {b : ℝ} (hb : 0 ≤ b)
    (hbound : b < ∏ i, (r i+2/x i)) :
    SchurStable (characteristic r x 1 b) := by
  by_cases hlow : b ≤ ∏ i, r i
  · exact low_gain_schur_fin hn hr (fun i => (hx i).le) 1 hb hlow
  · obtain ⟨t, ⟨ht, hBt⟩, _⟩ := existsUnique_amplitude_crossing hn hr hx
      (lt_of_not_ge hlow) hbound
    apply (schur_iff_phase_lt_pi_at_magnitude_crossing hn (le_refl 1) hr
      (fun i => (hx i).le) ht hBt (Or.inr hbound)).2
    exact Phase.single_phase_below_pi_of_endpoint hn hr hx hx1 hS ht

end C2.NGamma.Cayley
