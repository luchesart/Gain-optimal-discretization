import C2.CADAlgorithmAssembly

/-! Fixed-gain lifting from actual polynomial root cuts. Unlike the generic
lifting interface, sign constancy is proved here by the intermediate value
theorem and the absence of polynomial roots inside adjacent cells. -/

noncomputable section
open Set
namespace C2.CADAlgorithm

theorem positive_iff_on_preconnected {S : Set ℝ} (hS : IsPreconnected S)
    {f : ℝ → ℝ} (hf : ContinuousOn f S) (hzero : ∀ x ∈ S, f x ≠ 0)
    {x y : ℝ} (hx : x ∈ S) (hy : y ∈ S) : 0 < f x ↔ 0 < f y := by
  have step : ∀ a ∈ S, ∀ b ∈ S, 0 < f a → 0 < f b := by
    intro a ha b hb hfa
    by_contra hfb
    obtain ⟨z, hz, hz0⟩ := hS.intermediate_value₂ hb ha hf continuousOn_const
      (le_of_not_gt hfb) hfa.le
    exact hzero z hz hz0
  exact ⟨step x hx y hy, step y hy x hx⟩

theorem polynomial_sign_constant_on_adjacent {cuts : Finset ℝ}
    {p : Polynomial ℝ} {a b x y : ℝ}
    (hadj : C2.CADCells.Adjacent cuts a b)
    (hroots : ∀ z ∈ Ioo a b, p.eval z = 0 → z ∈ cuts)
    (hx : x ∈ Ioo a b) (hy : y ∈ Ioo a b) :
    0 < p.eval x ↔ 0 < p.eval y := by
  apply positive_iff_on_preconnected isPreconnected_Ioo p.continuous.continuousOn
    _ hx hy
  intro z hz hzero
  exact C2.CADCells.no_cut_inside hadj hz (hroots z hz hzero)

def parameterCells (cuts : Finset ℝ) (samples : (ℝ × ℝ) → ℚ) : List (Cell ℝ) :=
  (C2.CADCells.cells cuts).toList.map fun c =>
    {left := c.1, right := c.2, sample := samples c, marked := false}

/-- Once all polynomial roots in (0,1) are among the cuts, one rational sample
in each actual adjacent cell decides the entire closed parameter interval. -/
theorem polynomial_parameter_feasibility_iff {ι : Type*} [Finite ι]
    (p : ι → Polynomial ℝ) (cuts : Finset ℝ)
    (hzero : 0 ∈ cuts) (hone : 1 ∈ cuts)
    (hbound : ∀ c ∈ cuts, c ∈ Icc (0 : ℝ) 1)
    (hroots : ∀ i z, z ∈ Ioo (0 : ℝ) 1 → (p i).eval z = 0 → z ∈ cuts)
    (samples : (ℝ × ℝ) → ℚ)
    (hsample : ∀ c ∈ C2.CADCells.cells cuts, (samples c : ℝ) ∈ Ioo c.1 c.2) :
    (∃ γ ∈ Icc (0 : ℝ) 1, ∀ i, 0 < (p i).eval γ) ↔
      ∃ c ∈ C2.CADCells.cells cuts, ∀ i, 0 < (p i).eval (samples c : ℝ) := by
  have hcover : ∀ γ ∈ Ioo (0 : ℝ) 1, γ ∉ (cuts : Set ℝ) →
      ∃ c ∈ parameterCells cuts samples, γ ∈ Ioo c.left c.right := by
    intro γ hγ hγc
    obtain ⟨c, hc, hγcell⟩ :=
      (C2.CADCells.finite_cell_cover hzero hone hbound).mpr ⟨hγ, hγc⟩
    exact ⟨⟨c.1, c.2, samples c, false⟩,
      List.mem_map.mpr ⟨c, Finset.mem_toList.mpr hc, rfl⟩, hγcell⟩
  have hbounded : ∀ c ∈ parameterCells cuts samples, 0 ≤ c.left ∧ c.right ≤ 1 := by
    intro c hc
    obtain ⟨d, hd, rfl⟩ := List.mem_map.mp hc
    have hadj := (C2.CADCells.mem_cells_iff cuts d.1 d.2).mp (Finset.mem_toList.mp hd)
    exact ⟨(hbound d.1 hadj.1).1, (hbound d.2 hadj.2.1).2⟩
  have hsample' : ∀ c ∈ parameterCells cuts samples,
      (c.sample : ℝ) ∈ Ioo c.left c.right := by
    intro c hc
    obtain ⟨d, hd, rfl⟩ := List.mem_map.mp hc
    exact hsample d (Finset.mem_toList.mp hd)
  have hconstant : ∀ c ∈ parameterCells cuts samples, ∀ γ ∈ Ioo c.left c.right,
      (∀ i, 0 < (p i).eval γ) ↔ ∀ i, 0 < (p i).eval (c.sample : ℝ) := by
    intro c hc γ hγ
    obtain ⟨d, hd, rfl⟩ := List.mem_map.mp hc
    have hd' := Finset.mem_toList.mp hd
    have hadj := (C2.CADCells.mem_cells_iff cuts d.1 d.2).mp hd'
    apply forall_congr'
    intro i
    apply polynomial_sign_constant_on_adjacent hadj _ hγ (hsample d hd')
    intro z hz hzeq
    have hz01 := (C2.CADCells.finite_cell_cover hzero hone hbound).mp ⟨d, hd', hz⟩
    exact hroots i z hz01.1 hzeq
  rw [closed_parameter_feasibility_iff_cell_test (fun γ i => (p i).eval γ)
    (fun i => (p i).continuous) (parameterCells cuts samples) (cuts : Set ℝ)
    cuts.finite_toSet hcover hbounded hsample' hconstant]
  constructor
  · rintro ⟨c, hc, hpos⟩
    obtain ⟨d, hd, rfl⟩ := List.mem_map.mp hc
    exact ⟨d, Finset.mem_toList.mp hd, hpos⟩
  · rintro ⟨d, hd, hpos⟩
    exact ⟨⟨d.1, d.2, samples d, false⟩,
      List.mem_map.mpr ⟨d, Finset.mem_toList.mpr hd, rfl⟩, hpos⟩

/-- Exact rational marking for a fixed gain, with sign constancy derived from
the actual polynomial root cuts rather than supplied as a hypothesis. -/
theorem polynomial_lifting_mark_correct {n : ℕ}
    (tests : Fin n → ℚ → ℚ → ℚ) (gain : ℚ) (p : Fin n → Polynomial ℝ)
    (hcast : ∀ q i, ((tests i q gain : ℚ) : ℝ) = (p i).eval (q : ℝ))
    (cuts : Finset ℝ) (hzero : 0 ∈ cuts) (hone : 1 ∈ cuts)
    (hbound : ∀ c ∈ cuts, c ∈ Icc (0 : ℝ) 1)
    (hroots : ∀ i z, z ∈ Ioo (0 : ℝ) 1 → (p i).eval z = 0 → z ∈ cuts)
    (samples : (ℝ × ℝ) → ℚ)
    (hsample : ∀ c ∈ C2.CADCells.cells cuts, (samples c : ℝ) ∈ Ioo c.1 c.2) :
    markAtGain (List.ofFn tests) ((C2.CADCells.cells cuts).toList.map samples) gain = true ↔
      ∃ γ ∈ Icc (0 : ℝ) 1, ∀ i, 0 < (p i).eval γ := by
  rw [markAtGain_ofFn_iff, polynomial_parameter_feasibility_iff
    p cuts hzero hone hbound hroots samples hsample]
  have hpos : ∀ q i, 0 < tests i q gain ↔ 0 < (p i).eval (q : ℝ) := by
    intro q i
    rw [← hcast q i]
    exact Rat.cast_pos.symm
  simp_rw [hpos]
  constructor
  · rintro ⟨q, hq, hpos⟩
    obtain ⟨c, hc, rfl⟩ := List.mem_map.mp hq
    exact ⟨c, Finset.mem_toList.mp hc, hpos⟩
  · rintro ⟨c, hc, hpos⟩
    exact ⟨samples c, List.mem_map.mpr ⟨c, Finset.mem_toList.mpr hc, rfl⟩, hpos⟩

theorem zero_polynomial_inequality_infeasible {ι : Type*}
    (p : ι → Polynomial ℝ) {i : ι} (hzero : p i = 0) :
    ¬∃ γ ∈ Icc (0 : ℝ) 1, ∀ j, 0 < (p j).eval γ := by
  rintro ⟨γ, _, hpos⟩
  have := hpos i
  simpa [hzero] using this

theorem zero_rational_test_never_marks {n : ℕ}
    (tests : Fin n → ℚ → ℚ → ℚ) (gain : ℚ) (samples : List ℚ)
    {i : Fin n} (hzero : ∀ q, tests i q gain = 0) :
    markAtGain (List.ofFn tests) samples gain = false := by
  rw [Bool.eq_false_iff, ne_eq, markAtGain_ofFn_iff]
  rintro ⟨q, _, hpos⟩
  have := hpos i
  simpa [hzero] using this

end C2.CADAlgorithm
