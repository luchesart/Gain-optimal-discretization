import C2.SecondOrder

/-! # The actual delayed characteristic polynomial for the second-order factor

This file connects the coefficient representation used by the optimization
proof to `z ((z-1)^2 + u (z-1) q + v q^2) + b q^2`, where
`q = gamma z + 1-gamma` and `gamma = (1+t)/2`.
-/

noncomputable section
namespace C2.SecondOrder

def delayCharacteristic (u v t b : ℝ) (z : ℂ) : ℂ :=
  let q := (gamma t : ℂ)*z + (1-(gamma t : ℂ))
  z*((z-1)^2+(u:ℂ)*(z-1)*q+(v:ℂ)*q^2)+(b:ℂ)*q^2

theorem delay_characteristic_identity (u v t b : ℝ) (z : ℂ) :
    delayCharacteristic u v t b z =
      (L u v t : ℂ)*z^3+(B u v t b : ℂ)*z^2+
        (C u v t b : ℂ)*z+(D t b : ℂ) := by
  simp only [delayCharacteristic, gamma, B, C, D, c, A0, A3, L]
  push_cast
  ring

theorem schur_iff_delay_characteristic {u v t b : ℝ} (hL : 0 < L u v t) :
    Schur u v t b ↔ ∀ z : ℂ, delayCharacteristic u v t b z = 0 → ‖z‖ < 1 := by
  have hLc : (L u v t : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hL
  have hfactor (z : ℂ) : delayCharacteristic u v t b z = (L u v t : ℂ) *
      (z^3+(B u v t b / L u v t : ℝ)*z^2+
        (C u v t b / L u v t : ℝ)*z+(D t b / L u v t : ℝ)) := by
    rw [delay_characteristic_identity]
    push_cast
    field_simp [hLc]
    ring
  constructor
  · intro hs z hz
    apply hs z
    rw [hfactor] at hz
    exact (mul_eq_zero.mp hz).resolve_left hLc
  · intro hs z hz
    apply hs z
    rw [hfactor, hz, mul_zero]

theorem optimal_boundary_factorization {u v r : ℝ}
    (hr : 0 < r) (hf : f u v r = 0) (z : ℂ) :
    delayCharacteristic u v r (optimum u r) z =
      (z+1)^2*((L u v r : ℂ)*z+(D r (optimum u r) : ℂ)) := by
  have hB : B u v r (optimum u r) = 2*L u v r+D r (optimum u r) := by
    rw [root_identity hr hf]
    simp only [B, D, c, A0, A3, L, rootV, optimum]
    field_simp [ne_of_gt hr]
    ring
  have hC : C u v r (optimum u r) = L u v r+2*D r (optimum u r) := by
    rw [root_identity hr hf]
    simp only [C, D, c, A0, A3, L, rootV, optimum]
    field_simp [ne_of_gt hr]
    ring
  rw [delay_characteristic_identity, hB, hC]
  push_cast
  ring

theorem optimal_third_root_ratio {u v r : ℝ}
    (hu : 0 < u) (hv : 0 < v) (hr : 0 < r) (hr1 : r < 1)
    (hf : f u v r = 0) :
    0 < D r (optimum u r) / L u v r ∧
      D r (optimum u r) / L u v r < 1 := by
  have hl : 0 < L u v r := by unfold L; positivity
  have hb := optimum_positive hu hr
  have hrem : 0 < 1-r := sub_pos.mpr hr1
  have hd : 0 < D r (optimum u r) := by unfold D c; positivity
  have hgap : 0 < L u v r-D r (optimum u r) := by
    rw [root_identity hr hf, third_root_gap u r (ne_of_gt hr)]
    have h64 : 0 < 6-4*r := by linarith
    positivity
  exact ⟨div_pos hd hl, (div_lt_one hl).mpr (by linarith)⟩

end C2.SecondOrder
