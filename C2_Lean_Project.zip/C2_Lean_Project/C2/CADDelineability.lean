import C2.GainProjection

/-!
# Direct CAD fiber constancy from simple disjoint roots

For strict feasibility on a compact parameter interval, global ordered root
sections can be avoided: a weakly feasible limiting parameter can be made
strictly feasible whenever at most one basis factor vanishes there and its
parameter derivative is nonzero. Compactness then makes each feasible sign
pattern closed on the regular gain set; openness is already elementary.
-/

noncomputable section
open Set Filter
open scoped Topology

namespace C2.CADDelineability

/-- A simple real zero has positive values in every neighborhood. This is the
contrapositive of Fermat's theorem, not a root-continuation hypothesis. -/
theorem simple_zero_positive_near {f : ℝ → ℝ} {x d : ℝ}
    (hf : HasDerivAt f d x) (hd : d ≠ 0) (hx : f x = 0)
    {U : Set ℝ} (hU : U ∈ 𝓝 x) : ∃ y ∈ U, 0 < f y := by
  by_contra h
  have hm : IsLocalMax f x := by
    change ∀ᶠ y in 𝓝 x, f y ≤ f x
    filter_upwards [hU] with y hy
    rw [hx]
    exact le_of_not_gt (fun hpos => h ⟨y, hy, hpos⟩)
  exact hd (hm.hasDerivAt_eq_zero hf)

/-- On the closed parameter interval, a nonnegative sign pattern is attainable
strictly if roots are pairwise disjoint and simple and no factor vanishes at
an endpoint. The theorem applies also after independently reversing signs. -/
theorem weak_pattern_implies_strict {ι : Type*} [Finite ι]
    (F : ι → ℝ → ℝ) (hcont : ∀ i, Continuous (F i))
    (hzero : ∀ i, F i 0 ≠ 0) (hone : ∀ i, F i 1 ≠ 0)
    {x : ℝ} (hx : x ∈ Icc (0 : ℝ) 1) (hweak : ∀ i, 0 ≤ F i x)
    (hdisjoint : ∀ i j, i ≠ j → F i x = 0 → F j x ≠ 0)
    (hsimple : ∀ i, F i x = 0 → ∃ d : ℝ, d ≠ 0 ∧ HasDerivAt (F i) d x) :
    ∃ y ∈ Icc (0 : ℝ) 1, ∀ i, 0 < F i y := by
  classical
  by_cases hz : ∃ j, F j x = 0
  · obtain ⟨j, hj⟩ := hz
    have hx0 : x ≠ 0 := by intro h; subst x; exact hzero j hj
    have hx1 : x ≠ 1 := by intro h; subst x; exact hone j hj
    have hxi : x ∈ Ioo (0 : ℝ) 1 :=
      ⟨lt_of_le_of_ne hx.1 (Ne.symm hx0), lt_of_le_of_ne hx.2 hx1⟩
    have hother : ∀ᶠ y in 𝓝 x, ∀ i, i ≠ j → 0 < F i y := by
      apply Filter.eventually_all.mpr
      intro i
      by_cases hij : i = j
      · exact Filter.Eventually.of_forall (by simp [hij])
      · have hi : 0 < F i x :=
          lt_of_le_of_ne (hweak i) (Ne.symm (hdisjoint j i (Ne.symm hij) hj))
        exact ((hcont i).continuousAt.eventually (Ioi_mem_nhds hi)).mono
          (fun y hy _ => hy)
    obtain ⟨d, hd, hf⟩ := hsimple j hj
    obtain ⟨y, hy, hpos⟩ := simple_zero_positive_near hf hd hj
      (inter_mem (Ioo_mem_nhds hxi.1 hxi.2) hother)
    refine ⟨y, ⟨hy.1.1.le, hy.1.2.le⟩, ?_⟩
    intro i
    by_cases hij : i = j
    · simpa [hij] using hpos
    · exact hy.2 i hij
  · refine ⟨x, hx, fun i => ?_⟩
    exact lt_of_le_of_ne (hweak i) (by intro hi; exact hz ⟨i, hi.symm⟩)

/-- Strict realization of one signed basis pattern. The first coordinate is
 gain and the second coordinate is the bounded design parameter. -/
def patternGains {ι : Type*} (F : ι → ℝ × ℝ → ℝ) : Set ℝ :=
  {k | ∃ x ∈ Icc (0 : ℝ) 1, ∀ i, 0 < F i (k, x)}

/-- Compactness plus a transverse simple root closes the feasible sign-pattern
 projection at every regular gain. No root-ordering or CAD invariance is assumed. -/
theorem pattern_limit_feasible {ι : Type*} [Finite ι]
    (F : ι → ℝ × ℝ → ℝ) (hcont : ∀ i, Continuous (F i))
    {k : ℝ} (hzero : ∀ i, F i (k, 0) ≠ 0) (hone : ∀ i, F i (k, 1) ≠ 0)
    (hdisjoint : ∀ x ∈ Icc (0 : ℝ) 1, ∀ i j,
      i ≠ j → F i (k, x) = 0 → F j (k, x) ≠ 0)
    (hsimple : ∀ x ∈ Icc (0 : ℝ) 1, ∀ i, F i (k, x) = 0 →
      ∃ d : ℝ, d ≠ 0 ∧ HasDerivAt (fun y => F i (k, y)) d x)
    {ks : ℕ → ℝ} (hks : ∀ n, ks n ∈ patternGains F)
    (hlim : Tendsto ks atTop (𝓝 k)) : k ∈ patternGains F := by
  classical
  choose xs hxs hpos using hks
  obtain ⟨x, hx, φ, hφ, hxlim⟩ := isCompact_Icc.tendsto_subseq hxs
  have hkφ : Tendsto (ks ∘ φ) atTop (𝓝 k) := hlim.comp hφ.tendsto_atTop
  have hp : Tendsto (fun n => (ks (φ n), xs (φ n))) atTop (𝓝 (k, x)) :=
    hkφ.prodMk_nhds hxlim
  have hweak : ∀ i, 0 ≤ F i (k, x) := by
    intro i
    exact ge_of_tendsto ((hcont i).continuousAt.tendsto.comp hp)
      (Filter.Eventually.of_forall (fun n => (hpos (φ n) i).le))
  exact weak_pattern_implies_strict (fun i y => F i (k, y))
    (fun i => (hcont i).comp (continuous_const.prodMk continuous_id))
    hzero hone hx hweak (hdisjoint x hx) (hsimple x hx)

/-- The sign-pattern projection is always open, regardless of regularity. -/
theorem patternGains_isOpen {ι : Type*} [Finite ι]
    (F : ι → ℝ × ℝ → ℝ) (hcont : ∀ i, Continuous (F i)) :
    IsOpen (patternGains F) :=
  C2.GainProjection.feasibleGains_isOpen (Icc (0 : ℝ) 1)
    (fun x k i => F i (k, x))
    (fun x _ i => (hcont i).comp (continuous_id.prodMk continuous_const))

/-- Algebraic regularity is stated pointwise on the gain set. -/
def Regular {ι : Type*} (F : ι → ℝ × ℝ → ℝ) (k : ℝ) : Prop :=
  (∀ i, F i (k, 0) ≠ 0) ∧ (∀ i, F i (k, 1) ≠ 0) ∧
  (∀ x ∈ Icc (0 : ℝ) 1, ∀ i j,
    i ≠ j → F i (k, x) = 0 → F j (k, x) ≠ 0) ∧
  (∀ x ∈ Icc (0 : ℝ) 1, ∀ i, F i (k, x) = 0 →
    ∃ d : ℝ, d ≠ 0 ∧ HasDerivAt (fun y => F i (k, y)) d x)

/-- On an arbitrary set of regular gains, the strict pattern projection is
 relatively closed. Openness and connectedness will give sample invariance. -/
theorem patternGains_isClosed_relative {ι : Type*} [Finite ι]
    (F : ι → ℝ × ℝ → ℝ) (hcont : ∀ i, Continuous (F i))
    (I : Set ℝ) (hreg : ∀ k ∈ I, Regular F k) :
    IsClosed {k : I | (k : ℝ) ∈ patternGains F} := by
  apply isSeqClosed_iff_isClosed.mp
  intro ks k hks hlim
  have hk := hreg k k.property
  exact pattern_limit_feasible F hcont hk.1 hk.2.1 hk.2.2.1 hk.2.2.2 hks
    (continuous_subtype_val.continuousAt.tendsto.comp hlim)

/-- One rational sample therefore determines feasibility of this complete sign
 pattern on every connected projection-free gain interval. -/
theorem pattern_constant_on_preconnected {ι : Type*} [Finite ι]
    (F : ι → ℝ × ℝ → ℝ) (hcont : ∀ i, Continuous (F i))
    (I : Set ℝ) (hI : IsPreconnected I) (hreg : ∀ k ∈ I, Regular F k)
    {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) :
    a ∈ patternGains F ↔ b ∈ patternGains F := by
  letI : PreconnectedSpace I := isPreconnected_iff_preconnectedSpace.mp hI
  have hc : IsClopen {k : I | (k : ℝ) ∈ patternGains F} :=
    ⟨patternGains_isClosed_relative F hcont I hreg,
      (patternGains_isOpen F hcont).preimage continuous_subtype_val⟩
  constructor
  · intro h
    have hu := hc.eq_univ ⟨⟨a, ha⟩, h⟩
    have : (⟨b, hb⟩ : I) ∈ ({k : I | (k : ℝ) ∈ patternGains F}) := by rw [hu]; trivial
    exact this
  · intro h
    have hu := hc.eq_univ ⟨⟨b, hb⟩, h⟩
    have : (⟨a, ha⟩ : I) ∈ ({k : I | (k : ℝ) ∈ patternGains F}) := by rw [hu]; trivial
    exact this

end C2.CADDelineability
