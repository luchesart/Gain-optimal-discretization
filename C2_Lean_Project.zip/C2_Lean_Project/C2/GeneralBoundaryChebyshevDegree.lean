import C2.GeneralBoundaryCandidatesChebyshev
import Mathlib

/-! The degree bound for the explicit Chebyshev boundary polynomial. -/
noncomputable section
open scoped BigOperators
open Polynomial

namespace C2.GeneralBoundaryCandidates

theorem chebyshev_U_natDegree_le (n : ℕ) :
    (Polynomial.Chebyshev.U ℝ (n : ℤ)).natDegree ≤ n := by
  induction n using Nat.twoStepInduction with
  | zero => simp
  | one =>
    rw [Nat.cast_one, Polynomial.Chebyshev.U_one]
    exact (natDegree_mul_le).trans (by simp)
  | more n hn hn1 =>
    rw [show ((n + 2 : ℕ) : ℤ) = (n : ℤ) + 2 by omega,
      Polynomial.Chebyshev.U_add_two]
    have htwo : ((2 : ℝ[X]) * X).natDegree ≤ 1 :=
      natDegree_mul_le.trans (by simp)
    have hp : (((2 : ℝ[X]) * X) * Polynomial.Chebyshev.U ℝ ((n : ℤ) + 1)).natDegree ≤ n + 2 := by
      have hd := natDegree_mul_le (p := (2 : ℝ[X]) * X)
        (q := Polynomial.Chebyshev.U ℝ ((n : ℤ) + 1))
      have hn1' : (Polynomial.Chebyshev.U ℝ ((n : ℤ) + 1)).natDegree ≤ n + 1 := by
        simpa using hn1
      omega
    exact (natDegree_sub_le _ _).trans (max_le hp (by omega))

/-- Positive and negative frequency differences have the same degree bound;
the equal-frequency term is exactly U(-1)=0. -/
theorem chebyshev_difference_natDegree_le {i j L : ℕ} (hi : i ≤ L) (hj : j ≤ L) :
    (Polynomial.Chebyshev.U ℝ ((i : ℤ) - (j : ℤ) - 1)).natDegree ≤ L - 1 := by
  rcases lt_trichotomy i j with hij | hij | hij
  · have he : (i : ℤ) - (j : ℤ) - 1 = -((j - i - 1 : ℕ) : ℤ) - 2 := by omega
    rw [he, Polynomial.Chebyshev.U_neg_sub_two, natDegree_neg]
    exact (chebyshev_U_natDegree_le (j - i - 1)).trans (by omega)
  · subst j
    simp
  · have he : (i : ℤ) - (j : ℤ) - 1 = ((i - j - 1 : ℕ) : ℤ) := by omega
    rw [he]
    exact (chebyshev_U_natDegree_le (i - j - 1)).trans (by omega)

/-- The manuscript bound deg Q <= L-1 with L=deg H and deg N<=deg H.
The result is also valid for Q=0 when expressed using natDegree. -/
theorem Q_natDegree_le (H N : ℝ[X]) (hN : N.natDegree ≤ H.natDegree) :
    (Q H N).natDegree ≤ H.natDegree - 1 := by
  classical
  unfold Q
  apply natDegree_sum_le_of_forall_le
  intro i hi
  apply natDegree_sum_le_of_forall_le
  intro j hj
  apply (natDegree_C_mul_le _ _).trans
  exact chebyshev_difference_natDegree_le (le_natDegree_of_mem_supp i hi)
    ((le_natDegree_of_mem_supp j hj).trans hN)

end C2.GeneralBoundaryCandidates
