import C2.NGammaPiecewiseLift
import C2.NGammaTransferEndpoint

/-! The explicit continuous argument of the actual characteristic polynomial
on the upper Cayley semicircle. Its endpoint change is (n+d)π−2πk. -/

noncomputable section
open Set Filter
open scoped Topology BigOperators

namespace C2.NGamma.Cayley
open PolynomialModel ArgumentMatch

def characteristicAngle {n : ℕ} (r x : Fin n → ℝ) (d : ℕ) (b tb : ℝ) (k : ℤ)
    (t : ℝ) : ℝ :=
  (∑ i, qPhase (x i) t) +
    translatedAngle (amplitude r x) (Phase.totalPhase (fun i => x i+2/r i) x d) b tb k t

lemma q_product_polar {n : ℕ} (x : Fin n → ℝ) (t : ℝ) :
    (∏ i, (q (x i)).eval (point t)) = (‖∏ i, (q (x i)).eval (point t)‖ : ℂ)*
      Complex.exp (((∑ i, qPhase (x i) t : ℝ) : ℂ)*Complex.I) := by
  have hn : ‖∏ i, (q (x i)).eval (point t)‖ = ∏ i, qAmplitude (x i) t := by
    rw [norm_prod]
    apply Finset.prod_congr rfl
    intro i _
    rw [q_polar, norm_mul, Complex.norm_real, Real.norm_eq_abs,
      abs_of_pos (qAmplitude_pos _ _), Complex.norm_exp_ofReal_mul_I, mul_one]
  rw [hn]
  simp only [q_polar, Finset.prod_mul_distrib, Complex.ofReal_prod, Complex.ofReal_sum,
    Finset.sum_mul, Complex.exp_sum]

lemma polar_mul {z w : ℂ} {a c : ℝ}
    (hz : z = (‖z‖:ℂ)*Complex.exp ((a:ℂ)*Complex.I))
    (hw : w = (‖w‖:ℂ)*Complex.exp ((c:ℂ)*Complex.I)) :
    z*w = (‖z*w‖:ℂ)*Complex.exp (((a+c:ℝ):ℂ)*Complex.I) := by
  rw [norm_mul, Complex.ofReal_mul, Complex.ofReal_add, add_mul, Complex.exp_add]
  calc
    z*w = ((‖z‖:ℂ)*Complex.exp ((a:ℂ)*Complex.I))*
        ((‖w‖:ℂ)*Complex.exp ((c:ℂ)*Complex.I)) := by rw [← hz, ← hw]
    _ = _ := by ring

lemma characteristicAngle_polar {n : ℕ} {r : Fin n → ℝ} (hr : ∀ i, 0 < r i)
    (x : Fin n → ℝ) (d : ℕ) (b tb : ℝ) (k : ℤ) (t : ℝ) :
    (characteristic r x d b).eval (point t) =
      (‖(characteristic r x d b).eval (point t)‖ : ℂ)*
        Complex.exp ((characteristicAngle r x d b tb k t : ℂ)*Complex.I) := by
  rw [characteristic_eval_point]
  unfold characteristicAngle
  apply polar_mul (q_product_polar x t)
  have h := translatedAngle_polar (b := b) (tb := tb) (k := k)
    (ψ := Phase.totalPhase (fun i => x i+2/r i) x d) (amplitude_pos hr x t)
  simpa only [polarCurve, ← transfer_polar (fun i => ne_of_gt (hr i))] using h

lemma characteristicAngle_continuousOn {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) (d : ℕ) {b tb : ℝ} {k : ℤ}
    (htb : 0 ≤ tb) (hBeq : amplitude r x tb = b)
    (hlo : -Real.pi < Phase.totalPhase (fun i => x i+2/r i) x d tb-2*Real.pi*k)
    (hhi : Phase.totalPhase (fun i => x i+2/r i) x d tb-2*Real.pi*k < Real.pi) :
    ContinuousOn (characteristicAngle r x d b tb k) (Ici 0) := by
  apply ContinuousOn.add
  · exact (continuous_finset_sum _ (fun i _ => qPhase_continuous (x i))).continuousOn
  · exact translatedAngle_continuousOn (amplitude_continuous r x)
      (Phase.totalPhase_continuous _ x d) (fun t _ => amplitude_pos hr x t)
      (amplitude_strictMonoOn hn hr hx) htb hBeq hlo hhi

lemma characteristic_point_ne_zero {n : ℕ} (hn : 0 < n) {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) (d : ℕ) {b tb : ℝ} {k : ℤ}
    (htb : 0 ≤ tb) (hBeq : amplitude r x tb = b)
    (hlo : -Real.pi < Phase.totalPhase (fun i => x i+2/r i) x d tb-2*Real.pi*k)
    (hhi : Phase.totalPhase (fun i => x i+2/r i) x d tb-2*Real.pi*k < Real.pi)
    (t : ℝ) (ht : 0 ≤ t) : (characteristic r x d b).eval (point t) ≠ 0 := by
  rw [characteristic_eval_point]
  apply mul_ne_zero (Finset.prod_ne_zero_iff.mpr (fun i _ => q_eval_point_ne_zero (x i) t))
  have h := translated_curve_ne_zero (fun t _ => amplitude_pos hr x t)
    (amplitude_strictMonoOn hn hr hx) htb hBeq hlo hhi ht
  simpa only [polarCurve, ← transfer_polar (fun i => ne_of_gt (hr i))] using h

lemma characteristicAngle_zero {n : ℕ} {r : Fin n → ℝ} (hr : ∀ i, 0 < r i)
    (x : Fin n → ℝ) (d : ℕ) {b tb : ℝ} (hb : 0 < b) (htb : 0 ≤ tb) (k : ℤ) :
    characteristicAngle r x d b tb k 0 = 0 := by
  unfold characteristicAngle
  have h := translatedAngle_zero (k := k) (ψ := Phase.totalPhase (fun i => x i+2/r i) x d)
    (amplitude_pos hr x 0) hb htb (by simp [Phase.totalPhase, Phase.contribution])
  simpa only [qPhase, mul_zero, Real.arctan_zero, add_zero, zero_add, Finset.sum_const_zero] using h

lemma characteristicAngle_tendsto_atTop {n : ℕ} {r x : Fin n → ℝ}
    (hr : ∀ i, 0 < r i) (hx : ∀ i, 0 ≤ x i) (d : ℕ) {b tb : ℝ} (hb : 0 ≤ b) (k : ℤ)
    (hbound : (∃ j, x j = 0) ∨ b < ∏ i, (r i+2/x i)) :
    Tendsto (characteristicAngle r x d b tb k) atTop
      (𝓝 (((n:ℝ)+(d:ℝ))*Real.pi-2*Real.pi*k)) := by
  have hcorr : Tendsto (fun t => Complex.arg (1+(b:ℂ)/transfer r x d (point t))) atTop (𝓝 0) := by
    by_cases hz : ∃ j, x j = 0
    · obtain ⟨j, hj⟩ := hz
      exact transfer_correction_arg_tendsto_zero_of_zero hr hx hj d b
    · have hxp : ∀ i, 0 < x i := fun i =>
        lt_of_le_of_ne (hx i) (Ne.symm (fun he => hz ⟨i, he⟩))
      exact transfer_correction_arg_tendsto_zero hr hxp d hb (hbound.resolve_left hz)
  have hcorr' : Tendsto (fun t => Complex.arg (1+(b:ℂ)/polarCurve (amplitude r x)
      (Phase.totalPhase (fun i => x i+2/r i) x d) t)) atTop (𝓝 0) := by
    simpa only [polarCurve, ← transfer_polar (fun i => ne_of_gt (hr i))] using hcorr
  have h := (sum_qPhase_tendsto_atTop hx).add
    (translatedAngle_tendsto_atTop (tb := tb) (k := k) (totalPhase_tendsto_atTop hr hx d) hcorr')
  convert h using 1
  ring

end C2.NGamma.Cayley
