import C2.ZOH
import C2.CubicSchur

/-! Root-based completion of the exact sampled-lag theorem. -/
noncomputable section
namespace C2

/-- Genuine complex-root Schur stability equals the exact positive-gain interval. -/
theorem zoh_cubicSchur_iff_gain_interval {ρ a β : ℝ}
    (hρ : 0 < ρ) (hρ1 : ρ < 1) (ha : 0 < a) (hβ : 0 ≤ β) (hβ1 : β ≤ 1) :
    CubicSchur (-(1+ρ)) (ρ+a*(1-β)) (a*β) ↔ a < zohThreshold ρ β := by
  rw [cubicSchur_iff]
  have hi : 1 - (ρ+a*(1-β)) + (-(1+ρ))*(a*β) - (a*β)^2 =
      1 - (a*β)^2 - (ρ+a*(1-β)) + (-(1+ρ))*(a*β) := by ring
  rw [hi]
  exact zoh_jury_iff_gain_interval hρ hρ1 ha hβ hβ1

/-- The root-based stable-gain interval at the uniquely optimal parameter. -/
theorem zoh_backward_euler_schur_iff {ρ a : ℝ}
    (hρ : 0 < ρ) (hρ1 : ρ < 1) (ha : 0 < a) :
    CubicSchur (-(1+ρ)) (ρ+a) 0 ↔ a < 1-ρ := by
  have h := zoh_cubicSchur_iff_gain_interval hρ hρ1 ha (le_refl 0) (by norm_num : (0:ℝ) ≤ 1)
  simpa [zoh_threshold_beta_zero] using h

/-- No parameter admits a stable gain at or above the backward-Euler cap. -/
theorem zoh_schur_gain_lt_cap {ρ a β : ℝ}
    (hρ : 0 < ρ) (hρ1 : ρ < 1) (ha : 0 < a) (hβ : 0 ≤ β) (hβ1 : β ≤ 1)
    (hs : CubicSchur (-(1+ρ)) (ρ+a*(1-β)) (a*β)) : a < 1-ρ := by
  have h := (zoh_cubicSchur_iff_gain_interval hρ hρ1 ha hβ hβ1).mp hs
  have hf := (zohF_pos_iff_lt_threshold hρ.le hρ1 ha.le hβ).mpr h
  exact zoh_gain_lt_cap hρ ha hβ hf

end C2
