import C2.NGammaCriticalGain
import C2.NGammaReflectionOrder
import C2.NGammaNegativePhase
import C2.NGammaGainInterval
import C2.NGammaInitialMargin

/-! Global optimization of the actual initial Schur-stable gain margin.
The margin is the supremum from the manuscript, not an abstract surrogate.
The full-cube argument includes inadmissible zero-gain factors and reflection
of every admissible negative component. -/
noncomputable section
open scoped BigOperators
open Set
namespace C2.NGamma.Global
open PolynomialModel

theorem criticalGain_exact_interval {n : ℕ} (hn : 0 < n)
    (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    {B : ℝ} (hB : CriticalGain r x B) {b : ℝ} (hb : 0 ≤ b) :
    SchurStable (characteristic r x 1 b) ↔ b < B := by
  rcases hB with ⟨hxp,hS,rfl⟩ | ⟨t,ht,hp,rfl⟩
  · exact Cayley.single_sample_endpoint_interval hn hr hxp (fun j => (hx j).2) hS hb
  · exact Cayley.interior_exact_gain_interval hn (le_refl 1) hr
      (fun j => (hx j).1) (fun j => (hx j).2) ht hp hb

theorem criticalGain_eq_initialMargin {n : ℕ} (hn : 0 < n)
    (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    {B : ℝ} (hB : CriticalGain r x B) : initialGainMargin r x 1 = B := by
  exact initialGainMargin_eq_of_exact_interval (criticalGain_pos hr hB)
    (fun b hb => criticalGain_exact_interval hn r x hr hx hB hb)

/-- The actual initial stable margin strictly increases when every negative
coordinate is reflected, provided the zero-gain factors are admissible. -/
theorem negative_reflection_initial_margin_strict {n : ℕ} (hn : 0 < n)
    (r x : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    (hx : ∀ j, x j ∈ Icc (-1:ℝ) 1)
    (hlo : ∀ j, -(2/r j) ≤ x j) (hneg : ∃ j, x j < 0) :
    initialGainMargin r x 1 < initialGainMargin r (fun j => |x j|) 1 := by
  have habs : ∀ j, |x j| ≤ 1 := fun j => abs_le.mpr (hx j)
  have habscube : ∀ j, |x j| ∈ Icc (0:ℝ) 1 := fun j => ⟨abs_nonneg _,habs j⟩
  obtain ⟨t,⟨ht,hcross⟩,_⟩ := negative_first_phase_crossing r x hr hlo (fun j => (hx j).2) hneg
  have hphase : Phase.totalPhase (fun j => x j+2/r j) x 1 t = Real.pi := by
    apply (Phase.phase_eq_pi_iff_sumRatio _ _ 1 ht).mpr
    simpa only [Phase.sumRatio,sumRatio,Nat.cast_one,mul_one,sub_self,zero_mul,zero_div,sub_zero] using hcross
  have hroot := Cayley.first_crossing_gives_unit_root hr x 1 t hphase
  have hbound : initialGainMargin r x 1 ≤ Cayley.amplitude r x t :=
    initialGainMargin_le_of_unit_root (Cayley.amplitude_pos hr x t) hroot.1 hroot.2.ge
  obtain ⟨B,hB⟩ := criticalGain_exists hn r (fun j => |x j|) hr habscube
  rw [criticalGain_eq_initialMargin hn r _ hr habscube hB]
  apply lt_of_le_of_lt hbound
  rcases hB with ⟨hxp,hS,rfl⟩ | ⟨s,hs,hps,rfl⟩
  · exact reflected_endpoint_critical_gain_strict hn r x hr hxp hneg ht
  · exact (reflected_finite_critical_gain_strict hn r x hr habs hlo hneg ht hs hphase hps).2

/-- Unified half-cube theorem for the actual polynomial: a unique maximizing
parameter vector, an exact stable interval, and its actual supremum. -/
theorem exists_unique_half_cube_margin_optimizer {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    ∃ xstar : Fin n → ℝ, ∃ Bstar : ℝ,
      (∀ j, xstar j ∈ Icc (0:ℝ) 1) ∧ CriticalGain r xstar Bstar ∧
      initialGainMargin r xstar 1 = Bstar ∧
      (∀ b : ℝ, 0 ≤ b → (SchurStable (characteristic r xstar 1 b) ↔ b < Bstar)) ∧
      ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) →
        initialGainMargin r x 1 ≤ Bstar ∧ (initialGainMargin r x 1 = Bstar ↔ x = xstar) := by
  obtain ⟨xstar,Bstar,hxs,hBs,hopt⟩ := exists_unique_global_critical_gain hn r hr
  refine ⟨xstar,Bstar,hxs,hBs,criticalGain_eq_initialMargin hn r _ hr hxs hBs,
    fun b hb => criticalGain_exact_interval hn r _ hr hxs hBs hb,?_⟩
  intro x hx
  obtain ⟨B,hB⟩ := criticalGain_exists hn r x hr hx
  rw [criticalGain_eq_initialMargin hn r x hr hx hB]
  exact hopt x hx B hB

/-- Full-cube corollary for the supremum of the stable interval adjacent to
zero. Every maximizing coordinate lies in the nonnegative half cube. -/
theorem exists_unique_full_cube_margin_optimizer {n : ℕ} (hn : 0 < n)
    (r : Fin n → ℝ) (hr : ∀ j, 0 < r j) :
    ∃ xstar : Fin n → ℝ, ∃ Bstar : ℝ,
      (∀ j, xstar j ∈ Icc (0:ℝ) 1) ∧ CriticalGain r xstar Bstar ∧
      initialGainMargin r xstar 1 = Bstar ∧
      (∀ b : ℝ, 0 ≤ b → (SchurStable (characteristic r xstar 1 b) ↔ b < Bstar)) ∧
      ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (-1:ℝ) 1) →
        initialGainMargin r x 1 ≤ Bstar ∧ (initialGainMargin r x 1 = Bstar ↔ x = xstar) := by
  obtain ⟨xstar,Bstar,hxs,hBs,hmargin,hstable,hopt⟩ := exists_unique_half_cube_margin_optimizer hn r hr
  refine ⟨xstar,Bstar,hxs,hBs,hmargin,hstable,?_⟩
  intro x hx
  by_cases hnonneg : ∀ j, 0 ≤ x j
  · exact hopt x (fun j => ⟨hnonneg j,(hx j).2⟩)
  have hneg : ∃ j, x j < 0 := by simpa only [not_forall,not_le] using hnonneg
  have hlt : initialGainMargin r x 1 < Bstar := by
    by_cases hadmiss : ∀ j, -(2/r j) ≤ x j
    · have hreflection := negative_reflection_initial_margin_strict hn r x hr hx hadmiss hneg
      have habscube : ∀ j, |x j| ∈ Icc (0:ℝ) 1 := fun j => ⟨abs_nonneg _,abs_le.mpr (hx j)⟩
      exact lt_of_lt_of_le hreflection (hopt (fun j => |x j|) habscube).1
    · obtain ⟨j,hbad⟩ : ∃ j, x j < -(2/r j) := by simpa only [not_forall,not_le] using hadmiss
      rw [initialGainMargin_bad_coordinate_eq_zero hr (fun j => (hx j).1) (le_refl 1) j
        (by simpa only [neg_div] using hbad)]
      exact criticalGain_pos hr hBs
  refine ⟨hlt.le,?_,?_⟩
  · intro heq
    exact False.elim ((ne_of_lt hlt) heq)
  · intro heq
    subst x
    exact hmargin

end C2.NGamma.Global
