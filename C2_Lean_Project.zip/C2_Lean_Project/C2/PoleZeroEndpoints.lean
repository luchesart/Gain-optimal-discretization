import C2.PoleZeroInterior

/-! Endpoint regimes for the first-order pole-zero optimization.
The admissible gains are strict open intervals; their right endpoints are
suprema, not attained stable gains. All conclusions use the same `Jury`
inequalities as `PoleZeroInterior`. -/

noncomputable section
namespace C2.PoleZero

def aFE (r η : ℝ) : ℝ := (2 - r) / (2 * η - 1)
def aBE (r η : ℝ) : ℝ := (r + 2) / (1 + 2 * η)

/-- Algebraic consequences of the unconstrained optimum lying to the left
of the admissible parameter interval. -/
theorem fe_regime_consequences {r η : ℝ} (hr : 0 ≤ r)
    (hv : 0 < v r η) (hleft : γInterior r η < 0) :
    1 / 2 < η ∧ r < 2 ∧ 0 < r * (1 - η) + 4 * η - 3 := by
  let u := Real.sqrt (1 + r / v r η)
  have hu : 1 ≤ u := (FirstOrder.sqrt_param (div_nonneg hr (le_of_lt hv))).1
  have hud : 0 < 1 + u := by linarith
  let t : ℝ := 1 / (1 + u)
  have ht : 0 < t := one_div_pos.mpr hud
  have heq : FirstOrder.γStar (r / v r η) = 1 / 2 + t / 2 := by
    change 1 / 2 + 1 / (2 * (1 + u)) = 1 / 2 + (1 / (1 + u)) / 2
    field_simp [ne_of_gt hud]
    ring_nf
    simp
  have hη : 1 / 2 + t / 2 < η := by
    unfold γInterior at hleft
    rw [heq] at hleft
    linarith
  have hhalf : 1 / 2 < η := by linarith
  have hvr : v r η = 1 - r * η := rfl
  have hr2 : r < 2 := by nlinarith
  have hs : u ^ 2 = 1 + r / v r η := Real.sq_sqrt (by positivity)
  have hru : r = v r η * (u ^ 2 - 1) := by
    have hd := (eq_div_iff (ne_of_gt hv)).1 (by linarith : u ^ 2 - 1 = r / v r η)
    nlinarith [hd]
  have hroot : r * t ^ 2 + 2 * v r η * t - v r η = 0 := by
    dsimp [t]
    field_simp [ne_of_gt hud]
    nlinarith [hru]
  have hdiff : 0 < (2 * η - 1 - t) *
      (r * (2 * η - 1 + t) + 2 * v r η) := by
    apply mul_pos
    · linarith
    · have hm := mul_nonneg hr (by linarith : 0 ≤ 2 * η - 1 + t)
      linarith
  have hpoly : r * (2 * η - 1) ^ 2 +
      2 * v r η * (2 * η - 1) - v r η =
      r * (1 - η) + 4 * η - 3 := by unfold v; ring
  exact ⟨hhalf, hr2, by nlinarith [hroot, hpoly]⟩

theorem fe_gain_pos {r η : ℝ} (hr2 : r < 2) (hη : 1 / 2 < η) :
    0 < aFE r η := div_pos (by linarith) (by linarith)

theorem fe_gain_above_pole {r η : ℝ} (hv : 0 < v r η)
    (hη : 1 / 2 < η) : r < aFE r η := by
  have hd : 0 < 2 * η - 1 := by linarith
  apply (lt_div_iff₀ hd).2
  unfold v at hv
  nlinarith

/-- The FE endpoint is a global upper bound for every admissible gamma. -/
theorem fe_global_gain_bound {r η γ a : ℝ} (hv : 0 < v r η)
    (hη : 1 / 2 < η) (hγ : 0 ≤ γ) (h : Jury r η γ a) :
    a < aFE r η := by
  have hd : 0 < 2 * η - 1 := by linarith
  have hA := fe_gain_above_pole hv hη
  have hcross : aFE r η * (2 * η - 1) = 2 - r :=
    div_mul_cancel₀ _ (ne_of_gt hd)
  by_contra hn
  have ha : aFE r η ≤ a := le_of_not_gt hn
  have hm := mul_nonneg (sub_nonneg.mpr ha)
    (by linarith : 0 ≤ 2 * γ + 2 * η - 1)
  have hg := mul_nonneg hγ (sub_nonneg.mpr (le_of_lt hA))
  have hj := h.2.1
  nlinarith

/-- The whole interval below the FE upper endpoint is attained at gamma=0. -/
theorem fe_admissible_iff {r η a : ℝ} (hr2 : r < 2)
    (hη : 1 / 2 < η) (hF : 0 < r * (1 - η) + 4 * η - 3) :
    Jury r η 0 a ↔ 0 < a ∧ a < aFE r η := by
  have hd : 0 < 2 * η - 1 := by linarith
  have hcross : aFE r η * (2 * η - 1) = 2 - r :=
    div_mul_cancel₀ _ (ne_of_gt hd)
  have hA := fe_gain_pos hr2 hη
  constructor
  · intro h
    refine ⟨h.1, (lt_div_iff₀ hd).2 ?_⟩
    have hj := h.2.1
    nlinarith
  · rintro ⟨ha, haA⟩
    have hm := mul_pos (sub_pos.mpr haA) hd
    have hJ0A : 0 < 1 - aFE r η * (1 - η) := by
      have heq : (1 - aFE r η * (1 - η)) * (2 * η - 1) =
          r * (1 - η) + 4 * η - 3 := by nlinarith [hcross]
      exact pos_of_mul_pos_left (by rw [heq]; exact hF) (le_of_lt hd)
    refine ⟨ha, ?_, ?_⟩
    · nlinarith
    · by_cases he : η ≤ 1
      · have hx := mul_nonneg (sub_nonneg.mpr (le_of_lt haA)) (sub_nonneg.mpr he)
        nlinarith
      · have hx := mul_nonneg (le_of_lt ha) (by linarith : 0 ≤ η - 1)
        nlinarith

/-- Complete projection of the feasible set in the FE regime. -/
theorem fe_admissible_projection {r η a : ℝ} (hr : 0 ≤ r)
    (hv : 0 < v r η) (hleft : γInterior r η < 0) :
    (∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r η γ a) ↔
      0 < a ∧ a < aFE r η := by
  obtain ⟨hη, hr2, hF⟩ := fe_regime_consequences hr hv hleft
  constructor
  · rintro ⟨γ, hγ, _, hj⟩
    exact ⟨hj.1, fe_global_gain_bound hv hη hγ hj⟩
  · intro h
    exact ⟨0, le_refl _, by norm_num, (fe_admissible_iff hr2 hη hF).2 h⟩

/-- When v<0 every stable point lies to the right of the denominator change. -/
theorem be_positive_shift {r η γ a : ℝ} (hr : 0 ≤ r)
    (hv : v r η < 0) (h : Jury r η γ a) : 0 < 2 * γ + 2 * η - 1 := by
  let t := 2 * γ + 2 * η - 1
  have hj : 0 < 2 * v r η + t * (r - a) := by
    have h₁ := h.2.1
    dsimp [t]
    unfold v
    nlinarith
  have hk : 0 < r - a + 2 * v r η + t * (r + a) := by
    have h₂ := h.2.2
    dsimp [t]
    unfold v
    nlinarith
  by_contra hn
  have ht : t ≤ 0 := le_of_not_gt hn
  have har : r < a := by
    by_contra hn'
    have hm := mul_nonpos_of_nonpos_of_nonneg ht (sub_nonneg.mpr (le_of_not_gt hn'))
    linarith
  have hm := mul_nonpos_of_nonpos_of_nonneg ht (by linarith [h.1] : 0 ≤ r + a)
  linarith

theorem be_gain_pos {r η : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η) :
    0 < aBE r η := div_pos (by linarith) (by linarith)

theorem be_gain_below_pole {r η : ℝ} (hη : 0 ≤ η)
    (hv : v r η < 0) : aBE r η < r := by
  have hd : 0 < 1 + 2 * η := by linarith
  apply (div_lt_iff₀ hd).2
  unfold v at hv
  nlinarith

/-- The BE endpoint globally bounds all stable admissible parameters. -/
theorem be_global_gain_bound {r η γ a : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η)
    (hv : v r η < 0) (hγ : γ ≤ 1) (h : Jury r η γ a) :
    a < aBE r η := by
  have hd : 0 < 1 + 2 * η := by linarith
  have hA := be_gain_below_pole hη hv
  have ht := be_positive_shift hr hv h
  have hcross : aBE r η * (1 + 2 * η) = r + 2 :=
    div_mul_cancel₀ _ (ne_of_gt hd)
  by_contra hn
  have ha : aBE r η ≤ a := le_of_not_gt hn
  have hm := mul_nonneg (sub_nonneg.mpr ha) (le_of_lt ht)
  have hg := mul_nonneg (sub_nonneg.mpr hγ) (sub_nonneg.mpr (le_of_lt hA))
  have hj := h.2.1
  nlinarith

theorem be_admissible_iff {r η a : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η) :
    Jury r η 1 a ↔ 0 < a ∧ a < aBE r η := by
  have hd : 0 < 1 + 2 * η := by linarith
  constructor
  · intro h
    refine ⟨h.1, (lt_div_iff₀ hd).2 ?_⟩
    have hj := h.2.1
    nlinarith
  · rintro ⟨ha, haA⟩
    have hc := (lt_div_iff₀ hd).1 haA
    have hm := mul_nonneg (le_of_lt ha) hη
    exact ⟨ha, by nlinarith, by nlinarith⟩

/-- Complete projection of the feasible set in the negative-residual regime. -/
theorem be_admissible_projection {r η a : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η)
    (hv : v r η < 0) :
    (∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r η γ a) ↔
      0 < a ∧ a < aBE r η := by
  constructor
  · rintro ⟨γ, _, hγ, hj⟩
    exact ⟨hj.1, be_global_gain_bound hr hη hv hγ hj⟩
  · intro h
    exact ⟨1, by norm_num, le_refl _, (be_admissible_iff hr hη).2 h⟩

private theorem gain_isLUB_of_projection {S : Set ℝ} {A : ℝ}
    (hA : 0 < A) (hproj : ∀ a, a ∈ S ↔ 0 < a ∧ a < A) : IsLUB S A := by
  constructor
  · intro a ha
    exact le_of_lt ((hproj a).1 ha).2
  · intro b hb
    by_contra hn
    have hbA : b < A := lt_of_not_ge hn
    let a : ℝ := (max b 0 + A) / 2
    have hmax : max b 0 < A := max_lt_iff.mpr ⟨hbA, hA⟩
    have ha : 0 < a := by dsimp [a]; nlinarith [le_max_right b 0]
    have haA : a < A := by dsimp [a]; linarith
    have hba : b < a := by dsimp [a]; nlinarith [le_max_left b 0]
    have := hb ((hproj a).2 ⟨ha, haA⟩)
    linarith

theorem fe_gain_isLUB {r η : ℝ} (hr : 0 ≤ r)
    (hv : 0 < v r η) (hleft : γInterior r η < 0) :
    IsLUB {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r η γ a} (aFE r η) := by
  obtain ⟨hη, hr2, _⟩ := fe_regime_consequences hr hv hleft
  exact gain_isLUB_of_projection (fe_gain_pos hr2 hη)
    (fun _ => fe_admissible_projection hr hv hleft)

theorem be_gain_isLUB {r η : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η)
    (hv : v r η < 0) :
    IsLUB {a : ℝ | ∃ γ : ℝ, 0 ≤ γ ∧ γ ≤ 1 ∧ Jury r η γ a} (aBE r η) :=
  gain_isLUB_of_projection (be_gain_pos hr hη)
    (fun _ => be_admissible_projection hr hη hv)

theorem fe_parameter_isLUB {r η : ℝ} (hr : 0 ≤ r)
    (hv : 0 < v r η) (hleft : γInterior r η < 0) :
    IsLUB {a : ℝ | Jury r η 0 a} (aFE r η) := by
  obtain ⟨hη, hr2, hF⟩ := fe_regime_consequences hr hv hleft
  exact gain_isLUB_of_projection (fe_gain_pos hr2 hη)
    (fun _ => fe_admissible_iff hr2 hη hF)

theorem be_parameter_isLUB {r η : ℝ} (hr : 0 ≤ r) (hη : 0 ≤ η) :
    IsLUB {a : ℝ | Jury r η 1 a} (aBE r η) :=
  gain_isLUB_of_projection (be_gain_pos hr hη)
    (fun _ => be_admissible_iff hr hη)

/-- FE is the unique parameter whose strict stable gain set has the global
supremum, in the regime where the unconstrained optimum is negative. -/
theorem fe_maximizing_parameter_unique {r η γ : ℝ} (hr : 0 ≤ r)
    (hv : 0 < v r η) (hleft : γInterior r η < 0) (hγ : 0 ≤ γ)
    (hS : IsLUB {a : ℝ | Jury r η γ a} (aFE r η)) : γ = 0 := by
  obtain ⟨hη, _, _⟩ := fe_regime_consequences hr hv hleft
  have hA := fe_gain_above_pole hv hη
  have hd : 0 < 2 * η - 1 := by linarith
  have hcross : aFE r η * (2 * η - 1) = 2 - r :=
    div_mul_cancel₀ _ (ne_of_gt hd)
  have hj := FirstOrder.affine_nonneg_at_lub
    (b := 2 + r * (2 * γ - 1)) (c := 1 - 2 * γ - 2 * η) hS (by
      intro a ha
      simpa only [mul_comm] using ha.2.1)
  by_contra hn
  have hγp : 0 < γ := lt_of_le_of_ne hγ (Ne.symm hn)
  have hm := mul_pos hγp (sub_pos.mpr hA)
  nlinarith

/-- BE is the unique maximizing parameter when the residual v is negative. -/
theorem be_maximizing_parameter_unique {r η γ : ℝ} (hη : 0 ≤ η)
    (hv : v r η < 0) (hγ : γ ≤ 1)
    (hS : IsLUB {a : ℝ | Jury r η γ a} (aBE r η)) : γ = 1 := by
  have hA := be_gain_below_pole hη hv
  have hd : 0 < 1 + 2 * η := by linarith
  have hcross : aBE r η * (1 + 2 * η) = r + 2 :=
    div_mul_cancel₀ _ (ne_of_gt hd)
  have hj := FirstOrder.affine_nonneg_at_lub
    (b := 2 + r * (2 * γ - 1)) (c := 1 - 2 * γ - 2 * η) hS (by
      intro a ha
      simpa only [mul_comm] using ha.2.1)
  by_contra hn
  have hγp : γ < 1 := lt_of_le_of_ne hγ hn
  have hm := mul_pos (sub_pos.mpr hγp) (sub_pos.mpr hA)
  nlinarith

end C2.PoleZero
