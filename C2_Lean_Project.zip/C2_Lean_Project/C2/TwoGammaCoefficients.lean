import C2.TwoGammaAlgebra

/-! Exact cubic coefficient and high-gain exclusion algebra. -/
noncomputable section
namespace C2.TwoGamma

def A0 (r₁ r₂ b : ℝ) : ℝ := r₁*r₂+b
def A1 (r₁ r₂ x y b : ℝ) : ℝ := 2*(r₁+r₂)+r₁*r₂-b+(r₁*r₂+b)*(x+y)
def A2 (r₁ r₂ x y b : ℝ) : ℝ :=
  4+2*(r₁+r₂)+(2*r₁+r₁*r₂-b)*x+(2*r₂+r₁*r₂-b)*y+(r₁*r₂+b)*x*y
def A3 (r₁ r₂ x y b : ℝ) : ℝ := 4+2*r₁*x+2*r₂*y+(r₁*r₂-b)*x*y
def H (r₁ r₂ x y b : ℝ) : ℝ := A1 r₁ r₂ x y b*A2 r₁ r₂ x y b-A0 r₁ r₂ b*A3 r₁ r₂ x y b

def leading (r₁ r₂ x y : ℝ) : ℝ := (1+r₁*(1+x)/2)*(1+r₂*(1+y)/2)
def constantCoeff (x y b : ℝ) : ℝ := b*(1-x)*(1-y)/4
def middleB (r₁ r₂ x y b : ℝ) : ℝ := (A0 r₁ r₂ b-A3 r₁ r₂ x y b)/2-constantCoeff x y b
def middleC (r₁ r₂ x y b : ℝ) : ℝ := (A0 r₁ r₂ b+A3 r₁ r₂ x y b)/2-leading r₁ r₂ x y

theorem coefficient_identities (r₁ r₂ x y b : ℝ) :
    leading r₁ r₂ x y+middleB r₁ r₂ x y b+middleC r₁ r₂ x y b+constantCoeff x y b = A0 r₁ r₂ b ∧
    leading r₁ r₂ x y-middleB r₁ r₂ x y b+middleC r₁ r₂ x y b-constantCoeff x y b = A3 r₁ r₂ x y b ∧
    8*(leading r₁ r₂ x y^2-leading r₁ r₂ x y*middleC r₁ r₂ x y b+
      middleB r₁ r₂ x y b*constantCoeff x y b-constantCoeff x y b^2)=H r₁ r₂ x y b ∧
    A1 r₁ r₂ x y b+A2 r₁ r₂ x y b=6*leading r₁ r₂ x y-2*middleC r₁ r₂ x y b := by
  simp only [leading, middleB, middleC, constantCoeff, H, A0, A1, A2, A3]
  constructor
  · ring
  constructor
  · ring
  constructor <;> ring

theorem gain_discriminant_nonneg {r₁ r₂ b : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂) (hb : gain r₁ r₂ ≤ b) :
    0 ≤ (b-r₁*r₂)^2-4*(1+r₁+r₂)*b := by
  have hq := gain_quadratic h₁ h₂
  have he := gain_expanded h₁ h₂
  have hr : 0 ≤ radical r₁ r₂ := Real.sqrt_nonneg _
  have hh : 0 ≤ b+gain r₁ r₂-2*r₁*r₂-4*(1+r₁+r₂) := by linarith
  have hp := mul_nonneg (sub_nonneg.mpr hb) hh
  nlinarith [hq]

theorem gain_minus_product_gt {r₁ r₂ b : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂) (hb : gain r₁ r₂ ≤ b) :
    2*(r₁+r₂) < b-r₁*r₂ := by
  have he := gain_expanded h₁ h₂
  have hr : 0 ≤ radical r₁ r₂ := Real.sqrt_nonneg _
  linarith

theorem centered_identities (r₁ r₂ x y b : ℝ) :
    let w := b+r₁*r₂
    let l := b-r₁*r₂
    let U := l-2*r₂-w*x
    let V := l-2*r₁-w*y
    let E := l^2-4*(1+r₁+r₂)*b
    A1 r₁ r₂ x y b = l-U-V ∧
    w*A2 r₁ r₂ x y b = U*V-E ∧
    w*H r₁ r₂ x y b = U*V*(2*l-U-V)-4*b*((1+r₁)*V+(1+r₂)*U) := by
  dsimp
  simp only [A1, A2, H, A0, A3]
  constructor
  · ring
  constructor <;> ring

/-- Even the closed limiting necessary inequalities at a gain at least B
exclude any nonpositive first coordinate. This also handles uniqueness of
limiting optimizers, not just strict stability. -/
theorem closed_high_gain_exclusion_left {r₁ r₂ x y b : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂) (hb : gain r₁ r₂ ≤ b) (hx : x ≤ 0)
    (hA1 : 0 ≤ A1 r₁ r₂ x y b) (hA2 : 0 ≤ A2 r₁ r₂ x y b)
    (hH : 0 ≤ H r₁ r₂ x y b) : False := by
  let w := b+r₁*r₂
  let l := b-r₁*r₂
  let U := l-2*r₂-w*x
  let V := l-2*r₁-w*y
  let E := l^2-4*(1+r₁+r₂)*b
  have hb0 : 0 < b := lt_of_lt_of_le (gain_pos h₁ h₂) hb
  have hw : 0 < w := by dsimp [w]; positivity
  have hl : 2*(r₁+r₂) < l := gain_minus_product_gt h₁ h₂ hb
  have hE : 0 ≤ E := gain_discriminant_nonneg h₁ h₂ hb
  have hUbound : l-2*r₂ ≤ U := by
    dsimp [U]
    have hh := mul_nonpos_of_nonneg_of_nonpos hw.le hx
    linarith
  have hU : 0 < U := by linarith
  obtain ⟨ha₁,ha₂,hHid⟩ := centered_identities r₁ r₂ x y b
  change A1 r₁ r₂ x y b = l-U-V at ha₁
  change w*A2 r₁ r₂ x y b = U*V-E at ha₂
  change w*H r₁ r₂ x y b = U*V*(2*l-U-V)-4*b*((1+r₁)*V+(1+r₂)*U) at hHid
  have hlb : l < b := by dsimp [l]; nlinarith [mul_pos h₁ h₂]
  clear_value w l U V E
  have hUV : 0 ≤ U*V := by nlinarith [mul_nonneg hw.le hA2]
  have hV : 0 ≤ V := (mul_nonneg_iff_of_pos_left hU).mp hUV
  have hVbound : V ≤ 2*r₂ := by linarith
  have hsmall : l*V < 2*b*(1+r₂) := by
    have hh := mul_nonneg (by linarith : 0 ≤ b-l) hV
    have hh' := mul_nonneg hb0.le (by linarith : 0 ≤ 2*r₂-V)
    nlinarith
  have hmain := mul_pos hU (show 0 < 2*b*(1+r₂)-l*V by linarith)
  have hother := mul_nonneg (by positivity : 0 ≤ 4*b*(1+r₁)) hV
  have hUVsum := mul_nonneg hUV (by linarith : 0 ≤ U+V)
  have hstable := mul_nonneg hw.le hH
  nlinarith [hHid]

theorem swap_coefficients (r₁ r₂ x y b : ℝ) :
    A1 r₂ r₁ y x b = A1 r₁ r₂ x y b ∧
    A2 r₂ r₁ y x b = A2 r₁ r₂ x y b ∧
    H r₂ r₁ y x b = H r₁ r₂ x y b := by
  simp only [A1, A2, H, A0, A3]
  constructor
  · ring
  constructor <;> ring

theorem closed_high_gain_exclusion_right {r₁ r₂ x y b : ℝ}
    (h₁ : 0 < r₁) (h₂ : 0 < r₂) (hb : gain r₁ r₂ ≤ b) (hy : y ≤ 0)
    (hA1 : 0 ≤ A1 r₁ r₂ x y b) (hA2 : 0 ≤ A2 r₁ r₂ x y b)
    (hH : 0 ≤ H r₁ r₂ x y b) : False := by
  obtain ⟨ha,hb',hc⟩ := swap_coefficients r₁ r₂ x y b
  apply closed_high_gain_exclusion_left (x := y) (y := x) h₂ h₁ (by simpa [gain_comm] using hb) hy
  · simpa only [ha] using hA1
  · simpa only [hb'] using hA2
  · simpa only [hc] using hH

end C2.TwoGamma
