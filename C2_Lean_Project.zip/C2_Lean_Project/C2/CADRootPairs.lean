import C2.CADEffectiveRootGaps

/-! Finite adjacent-pair enumeration and coverage for the ordered root output. -/
namespace C2.CADEffective.Dense
open Set

def rankPairs (rs : List ℕ) : List (ℕ × ℕ) := rs.zip rs.tail

@[simp] theorem rankPairs_nil : rankPairs [] = [] := rfl
@[simp] theorem rankPairs_singleton (r : ℕ) : rankPairs [r] = [] := rfl
@[simp] theorem rankPairs_cons_cons (r s : ℕ) (rs : List ℕ) :
    rankPairs (r::s::rs) = (r,s)::rankPairs (s::rs) := rfl

/-- A computed neighboring pair consists of ordered list members with no
other returned rank strictly between them. -/
theorem rankPairs_properties {rs : List ℕ} (hsort : rs.Pairwise (· < ·))
    {r s : ℕ} (hpair : (r,s) ∈ rankPairs rs) :
    r ∈ rs ∧ s ∈ rs ∧ r < s ∧
      ∀ t ∈ rs, r < t → t < s → False := by
  induction rs with
  | nil => simp at hpair
  | cons a tail ih =>
    cases tail with
    | nil => simp at hpair
    | cons b bs =>
      obtain ⟨ha,hbt⟩ := List.pairwise_cons.mp hsort
      rw [rankPairs_cons_cons] at hpair
      rcases List.mem_cons.mp hpair with he | ht
      · cases he
        refine ⟨by simp,by simp,ha s (by simp),?_⟩
        intro t htm hrt hts
        rcases List.mem_cons.mp htm with hta | htm
        · subst t
          exact (lt_irrefl _) hrt
        · have hb : s ≤ t := by
            rcases List.mem_cons.mp htm with htb | htm
            · subst t; rfl
            · exact ((List.pairwise_cons.mp hbt).1 t htm).le
          exact (not_lt_of_ge hb) hts
      · obtain ⟨hr,hs,hrs,hcon⟩ := ih hbt ht
        refine ⟨List.mem_cons_of_mem a hr,List.mem_cons_of_mem a hs,hrs,?_⟩
        intro t htm hrt hts
        rcases List.mem_cons.mp htm with hta | htm
        · subst t
          exact (not_lt_of_ge (ha r hr).le) hrt
        · exact hcon t htm hrt hts

/-- Any finite sequence starting below a point and later lying above it has
an adjacent bracket, if no member equals the point. -/
theorem rankPairs_bracket_from_head (v : ℕ → ℝ) (z : ℝ) (a : ℕ) (tail : List ℕ)
    (ha : v a < z) (hhigh : ∃ s ∈ a::tail, z < v s)
    (hne : ∀ t ∈ a::tail, z ≠ v t) :
    ∃ r s, (r,s) ∈ rankPairs (a::tail) ∧ v r < z ∧ z < v s := by
  induction tail generalizing a with
  | nil =>
    obtain ⟨s,hs,hzs⟩ := hhigh
    have he : s = a := by simpa using hs
    subst s
    exact (not_lt_of_ge ha.le hzs).elim
  | cons b bs ih =>
    by_cases hzb : z < v b
    · exact ⟨a,b,by simp,ha,hzb⟩
    · have hb : v b < z := lt_of_le_of_ne (not_lt.mp hzb) (Ne.symm (hne b (by simp)))
      have hh : ∃ s ∈ b::bs, z < v s := by
        obtain ⟨s,hs,hzs⟩ := hhigh
        rcases List.mem_cons.mp hs with he | hs
        · subst s
          exact (not_lt_of_ge ha.le hzs).elim
        · exact ⟨s,hs,hzs⟩
      obtain ⟨r,s,hpair,hr,hs⟩ := ih b hb hh (fun t ht => hne t (List.mem_cons_of_mem a ht))
      exact ⟨r,s,by simp only [rankPairs_cons_cons,List.mem_cons]; exact Or.inr hpair,hr,hs⟩

/-- Every point between some two returned roots, and unequal to all roots,
is bracketed by a computed neighboring pair. -/
theorem exists_rankPair_bracket (rs : List ℕ) (v : ℕ → ℝ) (z : ℝ)
    (hsort : rs.Pairwise (fun r s => v r < v s))
    (hlow : ∃ r ∈ rs, v r < z) (hhigh : ∃ s ∈ rs, z < v s)
    (hne : ∀ t ∈ rs, z ≠ v t) :
    ∃ r s, (r,s) ∈ rankPairs rs ∧ v r < z ∧ z < v s := by
  cases rs with
  | nil => simpa using hlow
  | cons a tail =>
    have ha : v a < z := by
      obtain ⟨r,hr,hrz⟩ := hlow
      rcases List.mem_cons.mp hr with he | hr
      · subst r; exact hrz
      · exact ((List.pairwise_cons.mp hsort).1 r hr).trans hrz
    exact rankPairs_bracket_from_head v z a tail ha hhigh hne

/-- Descriptor semantics turn the sorted natural ranks into a strictly
increasing real interpretation. This function is used only in specifications. -/
theorem rootRanks_values_sorted (p : Poly) {a b : ℚ} (hab : a < b)
    (n : ℕ) (v : ℕ → ℝ)
    (hv : ∀ r ∈ rootRanks p a b n, rootAtRank p a b n r (v r)) :
    (rootRanks p a b n).Pairwise (fun r s => v r < v s) := by
  exact (rootRanks_sorted p a b n).imp_of_mem
    (fun hr hs hrs => root_rank_order p hab hr hs hrs (hv _ hr) (hv _ hs))

end C2.CADEffective.Dense
