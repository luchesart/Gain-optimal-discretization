import C2.RationalTransform

/-! Common declared degree, exact rational evaluation and absence of common roots. -/
noncomputable section
namespace C2
open Polynomial Finset

/-- Homogeneous coefficient substitution, with the same declared degree for both
members of a rational function. `U` clears the denominator and `V/U` replaces s. -/
def commonDegreeTransform {K : Type*} [CommRing K]
    (p : K[X]) (d : ℕ) (U V : K[X]) : K[X] :=
  ∑ j ∈ Finset.range (d+1), C (p.coeff j) * V^j * U^(d-j)

theorem commonDegreeTransform_eval {K : Type*} [CommRing K]
    (p : K[X]) (d : ℕ) (U V : K[X]) (z : K) :
    (commonDegreeTransform p d U V).eval z =
      ∑ j ∈ Finset.range (d+1), p.coeff j * (V.eval z)^j * (U.eval z)^(d-j) := by
  simp [commonDegreeTransform, eval_finset_sum]

/-- The polynomial substitution agrees with the denominator-cleared rational
substitution whenever the clearing factor is nonzero. -/
theorem commonDegreeTransform_eval_div {K : Type*} [Field K]
    (p : K[X]) (d : ℕ) (U V : K[X]) (z : K)
    (hp : p.natDegree ≤ d) (hU : U.eval z ≠ 0) :
    (commonDegreeTransform p d U V).eval z =
      (U.eval z)^d * p.eval (V.eval z / U.eval z) := by
  rw [commonDegreeTransform_eval, eval_eq_sum_range' (Nat.lt_succ_of_le hp),
    Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j hj
  have hjd : j ≤ d := by simpa only [Finset.mem_range, Nat.lt_succ_iff] using hj
  have hpow : (U.eval z)^d = (U.eval z)^(d-j) * (U.eval z)^j := by
    rw [← pow_add, Nat.sub_add_cancel hjd]
  rw [div_pow, hpow]
  field_simp
  ring

/-- At a zero of the clearing factor only the leading homogeneous term remains. -/
theorem commonDegreeTransform_eval_zero {K : Type*} [Field K]
    (p : K[X]) (d : ℕ) (U V : K[X]) (z : K) (hU : U.eval z = 0) :
    (commonDegreeTransform p d U V).eval z = p.coeff d * (V.eval z)^d := by
  rw [commonDegreeTransform_eval]
  trans p.coeff d * (V.eval z)^d * (U.eval z)^(d-d)
  · apply Finset.sum_eq_single_of_mem d (by simp)
    intro j hj hne
    have hjd : j < d := by
      have : j < d+1 := Finset.mem_range.mp hj
      omega
    have hpos : 0 < d-j := Nat.sub_pos_of_lt hjd
    simp [hU, zero_pow (ne_of_gt hpos)]
  · simp

/-- A linear homogeneous substitution cannot increase the declared degree. -/
theorem commonDegreeTransform_natDegree_le {K : Type*} [Field K]
    (p : K[X]) (d : ℕ) (U V : K[X])
    (hU : U.natDegree ≤ 1) (hV : V.natDegree ≤ 1) :
    (commonDegreeTransform p d U V).natDegree ≤ d := by
  unfold commonDegreeTransform
  apply natDegree_sum_le_of_forall_le
  intro j hj
  have hjd : j ≤ d := by simpa only [Finset.mem_range, Nat.lt_succ_iff] using hj
  have hVj : (V^j).natDegree ≤ j := by
    simpa using natDegree_pow_le_of_le j hV
  have hUj : (U^(d-j)).natDegree ≤ d-j := by
    simpa using natDegree_pow_le_of_le (d-j) hU
  have hc : (C (p.coeff j) * V^j).natDegree ≤ j :=
    le_trans (natDegree_C_mul_le _ _) hVj
  have hm := natDegree_mul_le_of_le hc hUj
  simpa [Nat.add_sub_of_le hjd] using hm

/-- Coprime input polynomials remain without a common evaluation zero, including
points where the rational substitution itself would have a zero denominator. -/
theorem commonDegreeTransform_no_common_zero {K : Type*} [Field K]
    (A B U V : K[X]) (d : ℕ) (hA : A.natDegree ≤ d) (hB : B.natDegree ≤ d)
    (hAd : A.coeff d ≠ 0) (hAB : IsCoprime A B)
    (hUV : ∀ z : K, U.eval z ≠ 0 ∨ V.eval z ≠ 0) (z : K) :
    (commonDegreeTransform A d U V).eval z ≠ 0 ∨
      (commonDegreeTransform B d U V).eval z ≠ 0 := by
  by_cases hU : U.eval z = 0
  · left
    rw [commonDegreeTransform_eval_zero A d U V z hU]
    have hV : V.eval z ≠ 0 := (hUV z).resolve_left (not_not_intro hU)
    exact mul_ne_zero hAd (pow_ne_zero d hV)
  · have hd : (U.eval z)^d ≠ 0 := pow_ne_zero d hU
    rcases hAB with ⟨f, g, hfg⟩
    by_contra! hz
    have hAz : A.eval (V.eval z / U.eval z) = 0 := by
      rw [commonDegreeTransform_eval_div A d U V z hA hU] at hz
      exact (mul_eq_zero.mp hz.1).resolve_left hd
    have hBz : B.eval (V.eval z / U.eval z) = 0 := by
      have h := hz.2
      rw [commonDegreeTransform_eval_div B d U V z hB hU] at h
      exact (mul_eq_zero.mp h).resolve_left hd
    have h := congrArg (fun p : K[X] => p.eval (V.eval z / U.eval z)) hfg
    simp [hAz, hBz] at h

/-- Linear clearing polynomial for the common theta parameter. -/
def thetaScale {K : Type*} [CommRing K] (T γ : K) : K[X] :=
  C T * (C γ * X + C (1-γ))

def thetaNumerator {K : Type*} [CommRing K] : K[X] := X - 1

theorem theta_no_common_zero {K : Type*} [Field K] (T γ : K) (hT : T ≠ 0)
    (z : K) : (thetaScale T γ).eval z ≠ 0 ∨ (thetaNumerator : K[X]).eval z ≠ 0 := by
  by_cases hz : z = 1
  · left
    subst z
    simpa [thetaScale] using hT
  · right
    simpa [thetaNumerator] using sub_ne_zero.mpr hz

@[simp] theorem commonDegreeTransform_integrator_den {K : Type*} [CommRing K]
    (U V : K[X]) : commonDegreeTransform X 1 U V = V := by
  simp [commonDegreeTransform, Finset.sum_range_succ, coeff_one]

@[simp] theorem commonDegreeTransform_integrator_num {K : Type*} [CommRing K]
    (U V : K[X]) : commonDegreeTransform 1 1 U V = U := by
  simp [commonDegreeTransform, Finset.sum_range_succ, coeff_one]

private theorem linear_pow_coeff {K : Type*} [Field K]
    (p : K[X]) (hp : p.natDegree ≤ 1) (n : ℕ) :
    (p^n).coeff n = (p.coeff 1)^n := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hn : (p^n).natDegree ≤ n := by
      simpa using natDegree_pow_le_of_le n hp
    rw [pow_succ, coeff_mul_add_eq_of_natDegree_le hn hp, ih, pow_succ]

/-- Exact coefficient at the common declared degree. It also records all
possible degree degeneracies caused by the parameter. -/
theorem commonDegreeTransform_top_coeff {K : Type*} [Field K]
    (p : K[X]) (d : ℕ) (U V : K[X])
    (hU : U.natDegree ≤ 1) (hV : V.natDegree ≤ 1) :
    (commonDegreeTransform p d U V).coeff d =
      ∑ j ∈ Finset.range (d+1), p.coeff j * (V.coeff 1)^j * (U.coeff 1)^(d-j) := by
  unfold commonDegreeTransform
  rw [finset_sum_coeff]
  apply Finset.sum_congr rfl
  intro j hj
  have hjd : j ≤ d := by simpa only [Finset.mem_range, Nat.lt_succ_iff] using hj
  have hVj : (V^j).natDegree ≤ j := by
    simpa using natDegree_pow_le_of_le j hV
  have hUj : (U^(d-j)).natDegree ≤ d-j := by
    simpa using natDegree_pow_le_of_le (d-j) hU
  have hprod : (V^j * U^(d-j)).coeff d =
      (V^j).coeff j * (U^(d-j)).coeff (d-j) := by
    simpa [Nat.add_sub_of_le hjd] using coeff_mul_add_eq_of_natDegree_le hVj hUj
  rw [mul_assoc, coeff_C_mul, hprod,
    linear_pow_coeff V hV j, linear_pow_coeff U hU (d-j)]
  ring

/-- Exact transformed degree, with the sole exceptional leading-coefficient
condition stated explicitly. -/
theorem commonDegreeTransform_natDegree {K : Type*} [Field K]
    (p : K[X]) (d : ℕ) (U V : K[X])
    (hU : U.natDegree ≤ 1) (hV : V.natDegree ≤ 1)
    (htop : (∑ j ∈ Finset.range (d+1),
      p.coeff j * (V.coeff 1)^j * (U.coeff 1)^(d-j)) ≠ 0) :
    (commonDegreeTransform p d U V).natDegree = d := by
  apply natDegree_eq_of_le_of_coeff_ne_zero
    (commonDegreeTransform_natDegree_le p d U V hU hV)
  rwa [commonDegreeTransform_top_coeff p d U V hU hV]

/-- The transformed rational quotient exactly equals the original quotient
evaluated at V/U wherever U is nonzero. -/
theorem commonDegreeTransform_quotient {K : Type*} [Field K]
    (A B U V : K[X]) (d : ℕ) (hA : A.natDegree ≤ d) (hB : B.natDegree ≤ d)
    (z : K) (hU : U.eval z ≠ 0) :
    (commonDegreeTransform B d U V).eval z /
        (commonDegreeTransform A d U V).eval z =
      B.eval (V.eval z / U.eval z) / A.eval (V.eval z / U.eval z) := by
  rw [commonDegreeTransform_eval_div B d U V z hB hU,
    commonDegreeTransform_eval_div A d U V z hA hU]
  exact common_degree_quotient _ _ _ _ hU

theorem thetaScale_natDegree_le {K : Type*} [Field K] (T γ : K) :
    (thetaScale T γ).natDegree ≤ 1 := by
  unfold thetaScale
  apply le_trans (natDegree_C_mul_le _ _)
  apply le_trans (natDegree_add_le _ _)
  apply max_le
  · exact le_trans (natDegree_C_mul_le _ _) (by simp)
  · simp

theorem thetaNumerator_natDegree_le {K : Type*} [Field K] :
    (thetaNumerator : K[X]).natDegree ≤ 1 := by
  unfold thetaNumerator
  apply le_trans (natDegree_sub_le _ _)
  simp

/-- The concrete common-theta transformation preserves absence of common roots. -/
theorem thetaTransform_no_common_zero {K : Type*} [Field K]
    (A B : K[X]) (d : ℕ) (T γ : K) (hT : T ≠ 0)
    (hA : A.natDegree ≤ d) (hB : B.natDegree ≤ d)
    (hAd : A.coeff d ≠ 0) (hAB : IsCoprime A B) (z : K) :
    (commonDegreeTransform A d (thetaScale T γ) thetaNumerator).eval z ≠ 0 ∨
    (commonDegreeTransform B d (thetaScale T γ) thetaNumerator).eval z ≠ 0 :=
  commonDegreeTransform_no_common_zero A B _ _ d hA hB hAd hAB
    (theta_no_common_zero T γ hT) z

/-- For any nondegenerate common-degree substitution, adding a positive integer
sample delay gives a degree d+m characteristic polynomial for every gain. -/
theorem transformedDelayedCharacteristic_natDegree
    (A B U V : ℝ[X]) (d m : ℕ) (k : ℝ)
    (hU : U.natDegree ≤ 1) (hV : V.natDegree ≤ 1) (hm : 0 < m)
    (htop : (∑ j ∈ Finset.range (d+1),
      A.coeff j * (V.coeff 1)^j * (U.coeff 1)^(d-j)) ≠ 0) :
    (delayedCharacteristic (commonDegreeTransform A d U V)
      (commonDegreeTransform B d U V) m k).natDegree = d+m := by
  have hd := commonDegreeTransform_natDegree A d U V hU hV htop
  have hD : commonDegreeTransform A d U V ≠ 0 := by
    intro hz
    have hc := commonDegreeTransform_top_coeff A d U V hU hV
    rw [hz, coeff_zero] at hc
    exact htop hc.symm
  have hN : (commonDegreeTransform B d U V).natDegree ≤
      (commonDegreeTransform A d U V).natDegree := by
    rw [hd]
    exact commonDegreeTransform_natDegree_le B d U V hU hV
  rw [delayedCharacteristic_natDegree k hD hm hN, hd]



theorem commonDegreeTransform_map {K L : Type*} [Field K] [Field L]
    (f : K →+* L) (p : K[X]) (d : ℕ) (U V : K[X]) :
    (commonDegreeTransform p d U V).map f =
      commonDegreeTransform (p.map f) d (U.map f) (V.map f) := by
  simp [commonDegreeTransform, Polynomial.map_sum]

theorem thetaTransform_coprime (A B : ℝ[X]) (d : ℕ) (T γ : ℝ) (hT : T ≠ 0)
    (hA : A.natDegree ≤ d) (hB : B.natDegree ≤ d)
    (hAd : A.coeff d ≠ 0) (hAB : IsCoprime A B) :
    IsCoprime (commonDegreeTransform A d (thetaScale T γ) thetaNumerator)
      (commonDegreeTransform B d (thetaScale T γ) thetaNumerator) := by
  apply (Polynomial.isCoprime_iff_aeval_ne_zero_of_isAlgClosed ℝ ℂ _ _).mpr
  intro z
  let f : ℝ →+* ℂ := algebraMap ℝ ℂ
  have hTm : f T ≠ 0 := by simpa [f] using hT
  have hAm : (A.map f).natDegree ≤ d := by simpa using hA
  have hBm : (B.map f).natDegree ≤ d := by simpa using hB
  have hAdm : (A.map f).coeff d ≠ 0 := by simpa [f] using hAd
  have hABm : IsCoprime (A.map f) (B.map f) := hAB.map (Polynomial.mapRingHom f)
  have h := thetaTransform_no_common_zero (A.map f) (B.map f) d (f T) (f γ)
    hTm hAm hBm hAdm hABm z
  simpa only [← eval_map_algebraMap, commonDegreeTransform_map,
    thetaScale, thetaNumerator, Polynomial.map_mul, Polynomial.map_add,
    Polynomial.map_sub, Polynomial.map_C, Polynomial.map_X, Polynomial.map_one,
    map_sub, map_one] using h

/-- A sample delay can introduce only zero as a common numerator/denominator
root; it cannot create a hidden root outside the unit disk. -/
theorem delayed_common_zero_is_zero {K : Type*} [Field K]
    (D N : K[X]) (m : ℕ)
    (hDN : ∀ z : K, D.eval z ≠ 0 ∨ N.eval z ≠ 0) (z : K)
    (hD : (X^m*D).eval z = 0) (hN : N.eval z = 0) : z = 0 := by
  by_contra hz
  have hDz : D.eval z = 0 := by
    simp only [eval_mul, eval_pow, eval_X] at hD
    exact (mul_eq_zero.mp hD).resolve_left (pow_ne_zero m hz)
  rcases hDN z with h | h
  · exact h hDz
  · exact h hN

/-- The delayed characteristic's leading coefficient is exactly the common-
degree top-coefficient expression, independent of the feedback gain. -/
theorem transformedDelayedCharacteristic_leadingCoeff
    (A B U V : ℝ[X]) (d m : ℕ) (k : ℝ)
    (hU : U.natDegree ≤ 1) (hV : V.natDegree ≤ 1) (hm : 0 < m)
    (htop : (∑ j ∈ Finset.range (d+1),
      A.coeff j * (V.coeff 1)^j * (U.coeff 1)^(d-j)) ≠ 0) :
    (delayedCharacteristic (commonDegreeTransform A d U V)
      (commonDegreeTransform B d U V) m k).leadingCoeff =
      ∑ j ∈ Finset.range (d+1),
        A.coeff j * (V.coeff 1)^j * (U.coeff 1)^(d-j) := by
  have hd := commonDegreeTransform_natDegree A d U V hU hV htop
  have hD : commonDegreeTransform A d U V ≠ 0 := by
    intro hz
    have hc := commonDegreeTransform_top_coeff A d U V hU hV
    rw [hz, coeff_zero] at hc
    exact htop hc.symm
  have hN : (commonDegreeTransform B d U V).natDegree ≤
      (commonDegreeTransform A d U V).natDegree := by
    rw [hd]
    exact commonDegreeTransform_natDegree_le B d U V hU hV
  rw [delayedCharacteristic_leadingCoeff k hD hm hN, leadingCoeff, hd,
    commonDegreeTransform_top_coeff A d U V hU hV]

end C2
