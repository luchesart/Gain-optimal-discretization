import C2.CADProjectionFamily
import C2.CADSignPatterns

/-! The algebraic projection gives actual gain-cell feasibility invariance. -/
noncomputable section
open Polynomial Set
namespace C2.CADProjection

theorem RegularFamilyAt.analytic {ι : Type*} {p : ι → Bivariate} {k : ℝ}
    (h : RegularFamilyAt p k) :
    C2.CADDelineability.Regular (fun i z => value (p i) z.1 z.2) k := by
  refine ⟨fun i => (h.1 i).2.1,fun i => (h.1 i).2.2,?_,?_⟩
  · intro x _ i j hij hi
    exact (h.2 i j hij x).resolve_left (not_not.mpr hi)
  · intro x _ i hi
    refine ⟨(specialize (p i) k).derivative.eval x,(h.1 i).1.2 x hi,?_⟩
    exact (specialize (p i) k).hasDerivAt x

/-- Root regularity from a verified projection implies exact constancy of all
strict basis-sign patterns on each connected set avoiding its zeros. -/
theorem projected_signed_pattern_constant {ι : Type*} [Fintype ι]
    (p : ι → Bivariate) (d : ℚ[X])
    (hreg : ∀ k : ℝ, d.eval₂ (algebraMap ℚ ℝ) k ≠ 0 → RegularFamilyAt p k)
    (I : Set ℝ) (hI : IsPreconnected I)
    (hcut : ∀ k ∈ I, d.eval₂ (algebraMap ℚ ℝ) k ≠ 0)
    (σ : ι → Bool) {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) :
    a ∈ C2.CADDelineability.patternGains (fun i z =>
      C2.CADDelineability.signMultiplier (σ i) * value (p i) z.1 z.2) ↔
    b ∈ C2.CADDelineability.patternGains (fun i z =>
      C2.CADDelineability.signMultiplier (σ i) * value (p i) z.1 z.2) := by
  exact C2.CADDelineability.signed_pattern_constant
    (fun i z => value (p i) z.1 z.2) (fun i => continuous_value (p i)) I hI
    (fun k hk => (hreg k (hcut k hk)).analytic) σ ha hb

/-- The positivity projection of a polynomial product system is constant on
an entire connected gain cell, not only at the selected rational sample. -/
theorem projected_products_constant {ι τ : Type*} [Fintype ι]
    (p : ι → Bivariate) (d : ℚ[X])
    (hreg : ∀ k : ℝ, d.eval₂ (algebraMap ℚ ℝ) k ≠ 0 → RegularFamilyAt p k)
    (c : τ → ℝ) (e : τ → ι → ℕ) (hused : ∀ i, ∃ j, e j i ≠ 0)
    (I : Set ℝ) (hI : IsPreconnected I)
    (hcut : ∀ k ∈ I, d.eval₂ (algebraMap ℚ ℝ) k ≠ 0)
    {a b : ℝ} (ha : a ∈ I) (hb : b ∈ I) :
    a ∈ C2.CADDelineability.patternGains (fun j z =>
      c j * ∏ i, value (p i) z.1 z.2 ^ e j i) ↔
    b ∈ C2.CADDelineability.patternGains (fun j z =>
      c j * ∏ i, value (p i) z.1 z.2 ^ e j i) := by
  exact C2.CADDelineability.products_constant_on_preconnected
    (fun i z => value (p i) z.1 z.2) (fun i => continuous_value (p i))
    c e hused I hI (fun k hk => (hreg k (hcut k hk)).analytic) ha hb

end C2.CADProjection
