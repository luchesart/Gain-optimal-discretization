import C2.CubicSchur
import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-! The exact two-sample integrator region, including the closed-form threshold.
Stability here quantifies over the actual complex roots of the cubic; it is
not defined by the inequalities that are to be proved. -/

noncomputable section
namespace C2.IntegratorDelay

def characteristic (n : ℕ) (γ a : ℝ) (z : ℂ) : ℂ :=
  z ^ n * (z - 1) + (a : ℂ) * ((γ : ℂ) * z + 1 - γ)

def Stable (n : ℕ) (γ a : ℝ) : Prop :=
  ∀ z : ℂ, characteristic n γ a z = 0 → ‖z‖ < 1

theorem two_characteristic (γ a : ℝ) (z : ℂ) :
    characteristic 2 γ a z =
      z ^ 3 + (-1 : ℂ) * z ^ 2 + (a * γ : ℝ) * z + (a * (1 - γ) : ℝ) := by
  simp only [characteristic]
  push_cast
  ring

theorem two_stable_iff_cubic (γ a : ℝ) :
    Stable 2 γ a ↔ C2.CubicSchur (-1) (a * γ) (a * (1 - γ)) := by
  simp only [Stable, C2.CubicSchur, two_characteristic, Complex.ofReal_neg,
    Complex.ofReal_one]

/-- Corollary `cor:n2`, the full strict region, including positivity of gain. -/
theorem two_stable_iff {γ a : ℝ} (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    Stable 2 γ a ↔ 0 < a ∧ a + (1 - γ) ^ 2 * a ^ 2 < 1 := by
  rw [two_stable_iff_cubic, C2.cubicSchur_iff]
  constructor
  · rintro ⟨_, hp, _, hf⟩
    exact ⟨by nlinarith, by nlinarith⟩
  · rintro ⟨ha, hf⟩
    have hq : 0 ≤ (1 - γ) ^ 2 * a ^ 2 := mul_nonneg (sq_nonneg _) (sq_nonneg _)
    have ha1 : a < 1 := by linarith
    have hc0 : 0 ≤ a * (1 - γ) := mul_nonneg ha.le (by linarith)
    have hc1 : a * (1 - γ) < 1 := by nlinarith
    refine ⟨by simpa only [abs_of_nonneg hc0] using hc1, ?_, ?_, ?_⟩
    · nlinarith
    · nlinarith [mul_nonneg ha.le hγ0]
    · nlinarith

def twoThreshold (γ : ℝ) : ℝ :=
  2 / (1 + Real.sqrt (1 + 4 * (1 - γ) ^ 2))

theorem twoThreshold_pos (γ : ℝ) : 0 < twoThreshold γ := by
  unfold twoThreshold
  positivity

theorem twoThreshold_equation (γ : ℝ) :
    twoThreshold γ + (1 - γ) ^ 2 * (twoThreshold γ) ^ 2 = 1 := by
  have hs := Real.sq_sqrt (show 0 ≤ 1 + 4 * (1 - γ) ^ 2 by positivity)
  have hd : 1 + Real.sqrt (1 + 4 * (1 - γ) ^ 2) ≠ 0 := by positivity
  unfold twoThreshold
  field_simp
  nlinarith

theorem twoThreshold_le_one (γ : ℝ) : twoThreshold γ ≤ 1 := by
  have h := twoThreshold_equation γ
  nlinarith [mul_nonneg (sq_nonneg (1 - γ)) (sq_nonneg (twoThreshold γ))]

theorem two_quadratic_iff_threshold {γ a : ℝ} (ha : 0 < a) :
    a + (1 - γ) ^ 2 * a ^ 2 < 1 ↔ a < twoThreshold γ := by
  have ht := twoThreshold_pos γ
  have he := twoThreshold_equation γ
  have hfac : a + (1 - γ) ^ 2 * a ^ 2 - 1 =
      (a - twoThreshold γ) * (1 + (1 - γ) ^ 2 * (a + twoThreshold γ)) := by
    nlinarith [he]
  have hpos : 0 < 1 + (1 - γ) ^ 2 * (a + twoThreshold γ) := by positivity
  calc
    a + (1 - γ) ^ 2 * a ^ 2 < 1 ↔
        a + (1 - γ) ^ 2 * a ^ 2 - 1 < 0 := sub_neg.symm
    _ ↔ (a - twoThreshold γ) * (1 + (1 - γ) ^ 2 * (a + twoThreshold γ)) < 0 := by
      rw [hfac]
    _ ↔ a - twoThreshold γ < 0 := by
      constructor
      · intro h
        rcases mul_neg_iff.mp h with h | h
        · linarith [h.2]
        · exact h.1
      · intro h
        exact mul_neg_of_neg_of_pos h hpos
    _ ↔ a < twoThreshold γ := sub_neg

/-- The rationalized expression remains valid at backward Euler (`γ = 1`). -/
theorem two_stable_iff_threshold {γ a : ℝ} (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    Stable 2 γ a ↔ 0 < a ∧
      a < 2 / (1 + Real.sqrt (1 + 4 * (1 - γ) ^ 2)) := by
  rw [two_stable_iff hγ0 hγ1]
  constructor
  · rintro ⟨ha, h⟩
    exact ⟨ha, (two_quadratic_iff_threshold ha).mp h⟩
  · rintro ⟨ha, h⟩
    exact ⟨ha, (two_quadratic_iff_threshold ha).mpr h⟩

@[simp] theorem twoThreshold_one : twoThreshold 1 = 1 := by
  norm_num [twoThreshold]

theorem two_threshold_unique_max {γ : ℝ} :
    twoThreshold γ = 1 ↔ γ = 1 := by
  constructor
  · intro h
    have he := twoThreshold_equation γ
    rw [h] at he
    nlinarith [sq_nonneg (1 - γ)]
  · rintro rfl
    exact twoThreshold_one

theorem two_threshold_strictMono : StrictMonoOn twoThreshold (Set.Icc 0 1) := by
  intro γ hγ δ hδ hlt
  have hc : (1 - δ) ^ 2 < (1 - γ) ^ 2 := by nlinarith [hγ.2, hδ.2]
  have htγ := twoThreshold_pos γ
  have htδ := twoThreshold_pos δ
  have heγ := twoThreshold_equation γ
  have heδ := twoThreshold_equation δ
  have hprod := mul_lt_mul_of_pos_right hc (sq_pos_of_pos htγ)
  have hsmall : twoThreshold γ + (1 - δ) ^ 2 * (twoThreshold γ) ^ 2 < 1 := by
    linarith
  exact (two_quadratic_iff_threshold htγ).mp hsmall

end C2.IntegratorDelay
