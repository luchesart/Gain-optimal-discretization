import C2.CompactSchur
import C2.NGammaRealizationDynamics
import C2.MIACETail

/-! The compact Schur-stable state-space hypotheses imply the uniform
envelopes needed by the MIACE continuity and existence theorem. -/

noncomputable section
open scoped BigOperators Topology
open Filter Matrix

namespace C2.MIACE

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

def stateOutput {X : Type*} (A : X → Matrix ι ι ℝ)
    (x₀ c : X → ι → ℝ) (n : ℕ) (x : X) : ℝ :=
  dotProduct (c x) ((A x) ^ n *ᵥ x₀ x)

theorem stateOutput_continuous {X : Type*} [TopologicalSpace X]
    (A : X → Matrix ι ι ℝ) (x₀ c : X → ι → ℝ)
    (hA : Continuous A) (hx : Continuous x₀) (hc : Continuous c) (n : ℕ) :
    Continuous (stateOutput A x₀ c n) := by
  exact hc.matrix_dotProduct ((hA.pow n).matrix_mulVec hx)

theorem dotProduct_abs_bound (c v : ι → ℝ) :
    |dotProduct c v| ≤ (∑ i, |c i|) * ‖v‖ := by
  unfold dotProduct
  calc
    |∑ i, c i * v i| ≤ ∑ i, |c i * v i| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i, |c i| * ‖v‖ := by
      apply Finset.sum_le_sum
      intro i _
      rw [abs_mul]
      exact mul_le_mul_of_nonneg_left (by simpa only [Real.norm_eq_abs] using norm_le_pi_norm v i)
        (abs_nonneg _)
    _ = (∑ i, |c i|) * ‖v‖ := (Finset.sum_mul _ _ _).symm

theorem real_matrix_powers_tendsto_zero (A : Matrix ι ι ℝ)
    (h : C2.NGamma.MatrixSchurStable A) :
    Tendsto (fun n : ℕ => A ^ n) atTop (𝓝 0) := by
  apply tendsto_pi_nhds.mpr
  intro i
  apply tendsto_pi_nhds.mpr
  intro j
  have ht := C2.NGamma.Realization.asymptoticallyStable_of_schur A h (Pi.single j 1)
  simpa only [Matrix.mulVec_single_one, Pi.zero_apply, Matrix.zero_apply] using
    tendsto_pi_nhds.mp ht i

theorem compact_schur_output_envelopes
    {X : Type*} [TopologicalSpace X] [CompactSpace X]
    (A : X → Matrix ι ι ℝ) (x₀ ce cu : X → ι → ℝ)
    (hA : Continuous A) (hx : Continuous x₀) (he : Continuous ce) (hu : Continuous cu)
    (hstable : ∀ x, C2.NGamma.MatrixSchurStable (A x)) :
    ∃ Ce Cu q : ℝ, 0 ≤ Ce ∧ 0 ≤ Cu ∧ 0 < q ∧ q < 1 ∧
      (∀ n x, |stateOutput A x₀ ce n x| ≤ Ce * q ^ n) ∧
      (∀ n x, |stateOutput A x₀ cu n x| ≤ Cu * q ^ n) := by
  classical
  cases isEmpty_or_nonempty ι with
  | inl hi =>
    letI := hi
    refine ⟨0, 0, 1 / 2, by norm_num, by norm_num, by norm_num, by norm_num, ?_, ?_⟩
    · intro n x
      simp [stateOutput, dotProduct]
    · intro n x
      simp [stateOutput, dotProduct]
  | inr hi =>
    letI := hi
    letI : NormedRing (Matrix ι ι ℝ) := Matrix.linftyOpNormedRing
    obtain ⟨C, q, hC, hq0, hq1, hb⟩ :=
      C2.CompactSchur.uniform_geometric_of_compact_power_decay A hA
        (fun x => real_matrix_powers_tendsto_zero (A x) (hstable x))
    obtain ⟨V, hV, hv⟩ := (isCompact_range hx).isBounded.exists_pos_norm_le
    have hce : Continuous (fun x => ∑ i, |ce x i|) := by
      apply continuous_finset_sum
      intro i _
      exact ((continuous_apply i).comp he).abs
    have hcu : Continuous (fun x => ∑ i, |cu x i|) := by
      apply continuous_finset_sum
      intro i _
      exact ((continuous_apply i).comp hu).abs
    obtain ⟨E, hE, heB⟩ := (isCompact_range hce).isBounded.exists_pos_norm_le
    obtain ⟨U, hU, huB⟩ := (isCompact_range hcu).isBounded.exists_pos_norm_le
    have heB' : ∀ x, (∑ i, |ce x i|) ≤ E := by
      intro x
      have ht := heB _ (Set.mem_range_self x)
      rw [Real.norm_eq_abs, abs_of_nonneg (Finset.sum_nonneg (fun _ _ => abs_nonneg _))] at ht
      exact ht
    have huB' : ∀ x, (∑ i, |cu x i|) ≤ U := by
      intro x
      have ht := huB _ (Set.mem_range_self x)
      rw [Real.norm_eq_abs, abs_of_nonneg (Finset.sum_nonneg (fun _ _ => abs_nonneg _))] at ht
      exact ht
    have hstate : ∀ n x, ‖(A x) ^ n *ᵥ x₀ x‖ ≤ (C * V) * q ^ n := by
      intro n x
      calc
        ‖(A x) ^ n *ᵥ x₀ x‖ ≤ ‖(A x) ^ n‖ * ‖x₀ x‖ := Matrix.linfty_opNorm_mulVec _ _
        _ ≤ (C * q ^ n) * V :=
          mul_le_mul (hb x n) (hv _ (Set.mem_range_self x)) (norm_nonneg _) (by positivity)
        _ = (C * V) * q ^ n := by ring
    refine ⟨E * C * V, U * C * V, q, by positivity, by positivity, hq0, hq1, ?_, ?_⟩
    · intro n x
      calc
        |stateOutput A x₀ ce n x| ≤ (∑ i, |ce x i|) * ‖(A x) ^ n *ᵥ x₀ x‖ :=
          dotProduct_abs_bound _ _
        _ ≤ E * ((C * V) * q ^ n) :=
          mul_le_mul (heB' x) (hstate n x) (norm_nonneg _) hE.le
        _ = E * C * V * q ^ n := by ring
    · intro n x
      calc
        |stateOutput A x₀ cu n x| ≤ (∑ i, |cu x i|) * ‖(A x) ^ n *ᵥ x₀ x‖ :=
          dotProduct_abs_bound _ _
        _ ≤ U * ((C * V) * q ^ n) :=
          mul_le_mul (huB' x) (hstate n x) (norm_nonneg _) hU.le
        _ = U * C * V * q ^ n := by ring

theorem uniform_scaled_area_series {X : Type*} (s : ℕ → X → ℝ) (T : X → ℝ)
    {C M q : ℝ} (hC : 0 ≤ C) (hM : 0 ≤ M) (hq0 : 0 ≤ q) (hq1 : q < 1)
    (hT : ∀ x, |T x| ≤ M) (hbound : ∀ n x, |s n x| ≤ C * q ^ n) :
    TendstoUniformly (fun N x => partialArea (T x) (fun n => s n x) N)
      (fun x => area (T x) (fun n => s n x)) atTop := by
  have hsum := (summable_geometric_of_lt_one hq0 hq1).mul_left (M * C)
  have hb : ∀ n x, ‖T x * |s n x|‖ ≤ (M * C) * q ^ n := by
    intro n x
    rw [Real.norm_eq_abs, abs_mul, abs_abs]
    calc
      |T x| * |s n x| ≤ M * (C * q ^ n) :=
        mul_le_mul (hT x) (hbound n x) (abs_nonneg _) hM
      _ = (M * C) * q ^ n := by ring
  have ht := tendstoUniformly_tsum_nat hsum hb
  simpa only [partialArea, area, Finset.mul_sum, tsum_mul_left] using ht

/-- All convergence, continuity, and attainment clauses under exactly the
compact continuous strictly Schur-stable family hypotheses. -/
theorem compact_schur_miace_existence
    {X : Type*} [TopologicalSpace X] [CompactSpace X] [Nonempty X]
    (A : X → Matrix ι ι ℝ) (x₀ ce cu : X → ι → ℝ) (T : X → ℝ) (η : ℝ)
    (hA : Continuous A) (hx : Continuous x₀) (he : Continuous ce) (hu : Continuous cu)
    (hT : Continuous T) (hstable : ∀ x, C2.NGamma.MatrixSchurStable (A x)) :
    TendstoUniformly (fun N x => partialArea (T x) (fun n => stateOutput A x₀ ce n x) N)
      (fun x => area (T x) (fun n => stateOutput A x₀ ce n x)) atTop ∧
    TendstoUniformly (fun N x => partialArea (T x) (fun n => stateOutput A x₀ cu n x) N)
      (fun x => area (T x) (fun n => stateOutput A x₀ cu n x)) atTop ∧
    Continuous (fun x => cost η (area (T x) (fun n => stateOutput A x₀ ce n x))
      (area (T x) (fun n => stateOutput A x₀ cu n x))) ∧
    ∃ x, ∀ y,
      cost η (area (T x) (fun n => stateOutput A x₀ ce n x))
        (area (T x) (fun n => stateOutput A x₀ cu n x)) ≤
      cost η (area (T y) (fun n => stateOutput A x₀ ce n y))
        (area (T y) (fun n => stateOutput A x₀ cu n y)) := by
  obtain ⟨Ce, Cu, q, hCe, hCu, hq0, hq1, hbe, hbu⟩ :=
    compact_schur_output_envelopes A x₀ ce cu hA hx he hu hstable
  have hmin := miace_continuous_and_attains_minimum
    (stateOutput A x₀ ce) (stateOutput A x₀ cu) T η
    (stateOutput_continuous A x₀ ce hA hx he) (stateOutput_continuous A x₀ cu hA hx hu)
    hT hq0.le hq1 hbe hbu
  obtain ⟨M, hM, hMb⟩ := (isCompact_range hT).isBounded.exists_pos_norm_le
  have hMT : ∀ x, |T x| ≤ M := fun x => by
    simpa only [Real.norm_eq_abs] using hMb _ (Set.mem_range_self x)
  exact ⟨uniform_scaled_area_series _ T hCe hM.le hq0.le hq1 hMT hbe,
    uniform_scaled_area_series _ T hCu hM.le hq0.le hq1 hMT hbu,
    hmin.1, hmin.2⟩

end C2.MIACE
