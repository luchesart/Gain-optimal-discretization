C2 rational-delay optimization — Lean proof project, version 0.4.0
Formalization completion: 9 November 2026

All 45 numbered results in the development map are COMPLETE. The final
result, Theorem 3 (thm:exact-gain-projection), now includes the correctness
and finite termination of the general exact gain-projection calculation.
COMPLETE means the numbered hypotheses and conclusions are covered; it does
not mean that each printed proof or external program is reproduced literally.
See PROOF_MAP_EN.csv and MANUSCRIPT_FORMALIZATION_NOTES.md for exact scope.

C2.CADNative.run takes a finite list of rational bivariate inequalities and
a positive rational search bound. It constructs factor and Bézout witnesses,
the projection polynomial, squarefree reductions, certified dyadic root
isolation, rational gap samples and exact finite sign tests internally.
C2.CADNative.native_gain_projection_correct proves that its actual output is
none exactly when the feasible positive-gain set is empty; otherwise its
unique real algebraic root descriptor is the global least upper bound,
including disconnected feasible components, with 0 < sup <= K0 < K.
No supplied factorization, root oracle, cell partition or marking oracle is
assumed. The exact rational-list witness search is total but may be
impractically slow. The literal SymPy/resultant implementation is unverified;
the Lean implementation proves the theorem through an equivalent exact
projection and lifting construction using checked polynomial identities.

Pinned environment: Lean 4.19.0; mathlib
c44e0c8ee63ca166450922a373c7409c5d26b00b.
208 proof modules; 1741 explicit public theorem/lemma declarations;
2176 explicit public declarations audited. All 156 proof modules from
version 0.3.0 are preserved byte-for-byte. The 52 additional modules contain
386 new public theorems/lemmas. Only propext, Classical.choice and Quot.sound
occur in the transitive axiom audit. No sorryAx or custom axioms are accepted.
The audit uses the unchanged official Lean.CollectAxioms.collect with one
shared visited set across all public roots. Its axiom union satisfies the
same allowed-axiom condition as all individual checks; exact per-root lists
are not produced. Evidence: work/SharedAxiomAudit.log and work/axiom_audit.json.
AxiomAudit.lean remains an optional per-root reporting input.

Build and check on a normal pinned installation:
  lake exe cache get
  python tools/make_single_file.py
  python tools/theorem_inventory.py
  lake build
  lake env lean -j1 live/C2_Live_Lean419.lean
  python tools/run_axiom_audit.py

After restoring the cache, tools/build_direct.py provides direct topological
compilation with one Lean job and pinned-dependency checks. Run --help for
its options. It avoids rebuilding the cached mathlib dependency graph.
This release used direct Lean compilations, the complete umbrella import,
the generated standalone file and the all-public-declaration audit.
VERIFICATION.json records the actual checks; a fresh lake build is not claimed.

C2.lean imports every module. live/C2_Live_Lean419.lean is generated from
the same sources and was checked independently as one file. This is a local
Lean check; no online live.lean website session is claimed. The distribution
omits dependency repositories, compiled objects and caches; Lake restores
dependencies from the pinned manifest.

In the general realization theorem, minimal explicitly means dimension
deg(D_gamma). Equivalence with the separate Kalman controllability and
observability definition is not claimed. The full-cube result concerns the
initial interval adjacent to zero; it does not assert optimization of all
disconnected components. The general CAD theorem separately includes every
feasible gain component. Positive-cascade optimization is for one aligned
sample. Fractional delays and arbitrary new plant classes are outside the
current numbered statements.

Earlier numerical outputs and the IJC checkpoint remain historical material.
The version 0.3.0 documentation is archived under historical/20261109_v03.
No new numerical experiment, journal submission or external message is claimed.
