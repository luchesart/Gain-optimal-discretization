#!/usr/bin/env python3
"""Enumerate explicit Lean declarations, respecting namespace and comment scope.

This is a source inventory, not a replacement for Lean elaboration.  The generated
AxiomAudit.lean resolves every public declaration and asks Lean itself to enumerate
its transitive axiom dependencies.  Private declarations are listed in JSON but
excluded from the public audit because Lean gives them generated private names.
"""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
import pathlib
import re


def without_comments_and_strings(text: str) -> str:
    out = list(text)
    i, depth, string = 0, 0, False
    while i < len(text):
        if depth:
            if text.startswith('/-', i):
                out[i:i+2] = '  '; depth += 1; i += 2
            elif text.startswith('-/', i):
                out[i:i+2] = '  '; depth -= 1; i += 2
            else:
                if text[i] != '\n': out[i] = ' '
                i += 1
        elif string:
            if text[i] == '\\' and i+1 < len(text):
                out[i:i+2] = '  '; i += 2
            else:
                if text[i] == '"': string = False
                if text[i] != '\n': out[i] = ' '
                i += 1
        elif text.startswith('/-', i):
            out[i:i+2] = '  '; depth = 1; i += 2
        elif text.startswith('--', i):
            while i < len(text) and text[i] != '\n': out[i] = ' '; i += 1
        elif text[i] == '"':
            out[i] = ' '; string = True; i += 1
        else:
            i += 1
    if depth or string:
        raise ValueError('Unterminated Lean block comment/string')
    return ''.join(out)


def enumerate_file(path: pathlib.Path, root: pathlib.Path):
    text = path.read_text(encoding='utf-8')
    clean = without_comments_and_strings(text)
    stack, namespace, declarations = [], '', []
    decl = re.compile(r'^\s*((?:(?:private|protected|noncomputable|unsafe|partial|nonrec)\s+)*)'
                      r'(theorem|lemma|def|abbrev|axiom|opaque|structure|inductive)\s+([^\s:({\[]+)')
    for lineno, line in enumerate(clean.splitlines(), 1):
        m = re.match(r'^\s*namespace\s+(\S+)', line)
        if m:
            name = m.group(1)
            stack.append(('namespace', name, namespace))
            namespace = name.removeprefix('_root_.') if name.startswith('_root_.') else '.'.join(filter(None,[namespace,name]))
            continue
        if re.match(r'^\s*(?:noncomputable\s+)?section(?:\s|$)', line):
            stack.append(('section', None, namespace)); continue
        m = re.match(r'^\s*end(?:\s+(\S+))?\s*$', line)
        if m:
            if not stack: raise ValueError(f'{path}:{lineno}: unmatched end')
            _, _, namespace = stack.pop(); continue
        # Lean attributes may precede a declaration on the same source line.
        decl_line = re.sub(r'^\s*(?:@\[[^\]]*\]\s*)+', '', line)
        m = decl.match(decl_line)
        if m:
            modifiers, kind, name = m.groups()
            fullname = name.removeprefix('_root_.') if name.startswith('_root_.') else '.'.join(filter(None,[namespace,name]))
            declarations.append(dict(name=fullname,kind=kind,private='private' in modifiers.split(),
                                     source=str(path.relative_to(root)),line=lineno,
                                     module='.'.join(path.relative_to(root).with_suffix('').parts)))
    if any(k == 'namespace' for k, _, _ in stack):
        raise ValueError(f'{path}: unclosed namespace')
    return declarations, hashlib.sha256(text.encode()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=pathlib.Path, default=pathlib.Path(__file__).resolve().parents[1])
    ap.add_argument('--json', default='work/lean_inventory_draft.json')
    ap.add_argument('--audit', default='AxiomAudit.lean')
    args = ap.parse_args(); root = args.root.resolve()
    declarations, modules = [], []
    for path in sorted((root/'C2').glob('*.lean')):
        ds, sha = enumerate_file(path, root)
        declarations.extend(ds)
        modules.append(dict(module='.'.join(path.relative_to(root).with_suffix('').parts),source=str(path.relative_to(root)),
                            sha256=sha,declaration_count=len(ds),public_proof_count=sum(d['kind'] in ('theorem','lemma') and not d['private'] for d in ds)))
    public = [d for d in declarations if not d['private']]
    public_names = [d['name'] for d in public]
    duplicates = [n for n, c in collections.Counter(public_names).items() if c > 1]
    if duplicates:
        raise ValueError(f'Duplicate public declaration names in inventory: {duplicates}')
    counts = dict(collections.Counter(d['kind'] for d in declarations))
    result = dict(schema_version=1,inventory_method='namespace-aware source parser; generated AxiomAudit.lean validates names and kernel axiom dependencies',
                  module_count=len(modules),declaration_count=len(declarations),public_declaration_count=len(public),
                  public_proof_count=sum(d['kind'] in ('theorem','lemma') for d in public),counts_by_kind=counts,
                  modules=modules,declarations=declarations)
    jsonpath=root/args.json; jsonpath.parent.mkdir(parents=True,exist_ok=True)
    jsonpath.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    audit='\n'.join('import '+m['module'] for m in modules)+'\n\n'
    audit+='/- Generated by tools/theorem_inventory.py. Regenerate after editing Lean sources. -/\n\n'
    audit+='\n'.join('#print axioms '+d['name'] for d in public)+'\n'
    (root/args.audit).write_text(audit,encoding='utf-8')
    print(json.dumps({k:result[k] for k in ['module_count','declaration_count','public_declaration_count','public_proof_count','counts_by_kind']},ensure_ascii=False))

if __name__=='__main__': main()
