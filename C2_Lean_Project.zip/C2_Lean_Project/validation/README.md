# Evidence index — C2 v0.5.0, 21 November 2026

The current verdict is ../VERIFICATION.json: all 45 numbered manuscript labels
are COMPLETE (22 main, 23 appendix). There are 209 source modules, 1764 public
theorems/lemmas and 2205 audited explicit public declarations.

Current checks:

- direct_build_20261121T070421839715Z/results.json: fresh direct checks of all
  208 unchanged v0.4 modules plus their baseline umbrella.
- 20261121/robust_module_v05.execution.json and .log: fresh integrated new module.
- 20261121/final_umbrella_v05.execution.json and .log: complete 209-module import.
- 20261121/single_file_v05.execution.json and .log: independently checked exact
  final standalone bytes (isolated staging); inputs and hashes are recorded.
- ../work/axiom_audit.json and ../work/SharedAxiomAudit.log: fresh official
  collector audit of all 2205 roots, with only the three standard allowed axioms.
- ../work/lean_inventory_draft.json: current declaration inventory/source hashes.
- 20261121/v04_module_preservation.json: all 208 v0.4 modules byte-identical.
- 20261121/source_scan_v05.json: all current theorem-source declarations scanned.
- 20261121/environment_verification.json: compiler and pinned dependency evidence.
- 20261121/strengthening_verification.json and robust_asymmetric_scope_review.json:
  new Proposition 1 proof checks and independent actual-stability scope review.

The new module establishes sharp asymmetric robust budgets and unique optimal
centers, including both width regimes and actual robust-gain suprema. The prior
symmetric result remains unchanged. The gain-projection theorem is now Theorem
16, previously Theorem 3; its established semantic evidence remains
cad_native_theorem_completion_20261109.json and cad_end_to_end_review_20261109.json,
while all its source modules receive the fresh baseline compilation and audit.

Current checks do not imply that old dated files have been rewritten. All
20261109 records are historical evidence for their own frozen versions.
The former current release metadata, live source and audit are preserved in
../historical/20261121_v04. Earlier historical directories retain their scope
and dates. Stage records that described pending work do not supersede the
current VERIFICATION.json. No fresh lake build, online live.lean session or
verification of the separate Python/SymPy implementation is claimed.
