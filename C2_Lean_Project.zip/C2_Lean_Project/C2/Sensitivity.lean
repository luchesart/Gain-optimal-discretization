import Mathlib

/-! Exact frequency maxima for the one-delay gamma = 3/4 design.
The proofs use polynomial identities and square positivity, so no sampling
or unproved differentiation/critical-point hypothesis is involved. -/
noncomputable section
namespace C2.Sensitivity

def denominator (a x : ℝ) : ℝ :=
  a * x ^ 2 + (3 * a ^ 2 / 8 + a - 2) * x + 5 * a ^ 2 / 8 - 2 * a + 2

def sSquared (a x : ℝ) : ℝ := 2 * (1 - x) / denominator a x
def tSquared (a x : ℝ) : ℝ := a ^ 2 * (5 + 3 * x) / (8 * denominator a x)
def sLocation (a : ℝ) : ℝ := 1 - Real.sqrt a
def tLocation (a : ℝ) : ℝ := (-5 + 2 * Real.sqrt (12 / a - 2)) / 3
def sFactor (a : ℝ) : ℝ := (2 - Real.sqrt a) ^ 3 * (2 + 3 * Real.sqrt a)

theorem sqrt_bounds {a : ℝ} (ha : 0 < a) (ha4 : a < 4) :
    0 < Real.sqrt a ∧ Real.sqrt a < 2 := by
  have hs := Real.sq_sqrt ha.le
  have hpos := Real.sqrt_pos.mpr ha
  exact ⟨hpos, by nlinarith⟩

theorem sFactor_pos {a : ℝ} (ha : 0 < a) (ha4 : a < 4) : 0 < sFactor a := by
  obtain ⟨hs0, hs2⟩ := sqrt_bounds ha ha4
  have hsub : 0 < 2 - Real.sqrt a := by linarith
  unfold sFactor
  positivity

theorem denominator_square_identity {a : ℝ} (ha : 0 ≤ a) (x : ℝ) :
    denominator a x = a * (x - sLocation a) ^ 2 + (1 - x) * sFactor a / 8 := by
  have hs := Real.sq_sqrt ha
  unfold denominator sLocation sFactor
  generalize Real.sqrt a = s at *
  rw [← hs]
  ring

theorem denominator_pos {a x : ℝ} (ha : 0 < a) (ha4 : a < 4)
    (hx : x ≤ 1) : 0 < denominator a x := by
  rw [denominator_square_identity ha.le]
  have hF := sFactor_pos ha ha4
  by_cases he : x = 1
  · subst x
    simp only [sub_self, zero_mul, zero_div, add_zero, sLocation]
    have hs := Real.sq_sqrt ha.le
    nlinarith [mul_pos ha ha]
  · have hxlt : x < 1 := lt_of_le_of_ne hx he
    have h1 := mul_nonneg ha.le (sq_nonneg (x - sLocation a))
    have h2 := mul_pos (sub_pos.mpr hxlt) hF
    linarith

theorem sLocation_mem {a : ℝ} (ha : 0 < a) (ha4 : a < 4) :
    sLocation a ∈ Set.Ioo (-1 : ℝ) 1 := by
  have hs := sqrt_bounds ha ha4
  constructor <;> dsimp [sLocation] <;> linarith

theorem sSquared_at_max {a : ℝ} (ha : 0 < a) (ha4 : a < 4) :
    sSquared a (sLocation a) = 16 / sFactor a := by
  have hs : 1 - sLocation a ≠ 0 := by
    have h := sLocation_mem ha ha4
    linarith [h.2]
  have hF := ne_of_gt (sFactor_pos ha ha4)
  unfold sSquared
  rw [denominator_square_identity ha.le]
  simp only [sub_self, zero_pow, mul_zero, zero_add]
  field_simp [hs, hF]
  <;> ring

theorem sSquared_le_max {a x : ℝ} (ha : 0 < a) (ha4 : a < 4)
    (hx : x ≤ 1) : sSquared a x ≤ 16 / sFactor a := by
  have hD := denominator_pos ha ha4 hx
  have hF := sFactor_pos ha ha4
  unfold sSquared
  apply (div_le_div_iff₀ hD hF).mpr
  rw [denominator_square_identity ha.le]
  nlinarith [mul_nonneg ha.le (sq_nonneg (x - sLocation a))]

theorem sSquared_greatest {a : ℝ} (ha : 0 < a) (ha4 : a < 4) :
    IsGreatest (sSquared a '' Set.Icc (-1 : ℝ) 1) (16 / sFactor a) := by
  constructor
  · exact ⟨sLocation a, ⟨(sLocation_mem ha ha4).1.le,
      (sLocation_mem ha ha4).2.le⟩, sSquared_at_max ha ha4⟩
  · rintro y ⟨x, hx, rfl⟩
    exact sSquared_le_max ha ha4 hx.2

theorem denominator_one (a : ℝ) : denominator a 1 = a ^ 2 := by
  unfold denominator
  ring

theorem tSquared_one {a : ℝ} (ha : 0 < a) : tSquared a 1 = 1 := by
  unfold tSquared
  rw [denominator_one]
  field_simp [ne_of_gt ha]
  <;> ring

theorem tSquared_low_le_one {a x : ℝ} (ha : 0 < a) (ha23 : a ≤ 2 / 3)
    (hx : x ≤ 1) : tSquared a x ≤ 1 := by
  have hD := denominator_pos ha (by linarith) hx
  unfold tSquared
  apply (div_le_one (by positivity : 0 < 8 * denominator a x)).mpr
  have hm : 0 ≤ (x - 1) * (a * x + 2 * a - 2) := by
    apply mul_nonneg_of_nonpos_of_nonpos (by linarith)
    nlinarith
  unfold denominator
  nlinarith

theorem tSquared_low_greatest {a : ℝ} (ha : 0 < a) (ha23 : a ≤ 2 / 3) :
    IsGreatest (tSquared a '' Set.Icc (-1 : ℝ) 1) 1 := by
  refine ⟨⟨1, ⟨by norm_num, le_rfl⟩, tSquared_one ha⟩, ?_⟩
  rintro y ⟨x, hx, rfl⟩
  exact tSquared_low_le_one ha ha23 hx.2

theorem tLocation_properties {a : ℝ} (ha23 : 2 / 3 < a) (ha4 : a < 4) :
    -1 < tLocation a ∧ tLocation a < 1 ∧
      3 * a * tLocation a ^ 2 + 10 * a * tLocation a + 11 * a - 16 = 0 := by
  have ha : 0 < a := by linarith
  have hrad : 0 < 12 / a - 2 := by
    have : 2 * a < 12 := by linarith
    have := (lt_div_iff₀ ha).mpr this
    linarith
  have hs := Real.sq_sqrt hrad.le
  have hs0 := Real.sqrt_nonneg (12 / a - 2)
  have he : a * Real.sqrt (12 / a - 2) ^ 2 = 12 - 2 * a := by
    calc
      _ = a * (12 / a - 2) := by rw [hs]
      _ = _ := by field_simp; ring
  have hlow : 1 < Real.sqrt (12 / a - 2) := by
    by_contra! hn
    have hsle : Real.sqrt (12 / a - 2) ^ 2 ≤ 1 := by nlinarith
    nlinarith [mul_le_mul_of_nonneg_left hsle ha.le]
  have hupp : Real.sqrt (12 / a - 2) < 4 := by
    by_contra! hn
    have hsle : 16 ≤ Real.sqrt (12 / a - 2) ^ 2 := by nlinarith
    nlinarith [mul_le_mul_of_nonneg_left hsle ha.le]
  unfold tLocation
  refine ⟨by linarith, by linarith, ?_⟩
  nlinarith

theorem t_difference_identity (a k x : ℝ) :
    (5 + 3 * k) * denominator a x - (5 + 3 * x) * denominator a k =
      a * (5 + 3 * k) * (x - k) ^ 2 +
        (x - k) * (3 * a * k ^ 2 + 10 * a * k + 11 * a - 16) := by
  unfold denominator
  ring

theorem tSquared_high_le_max {a x : ℝ} (ha23 : 2 / 3 < a) (ha4 : a < 4)
    (hx : x ≤ 1) : tSquared a x ≤ tSquared a (tLocation a) := by
  have ha : 0 < a := by linarith
  obtain ⟨hklo, hkhi, hk⟩ := tLocation_properties ha23 ha4
  have hDx := denominator_pos ha ha4 hx
  have hDk := denominator_pos ha ha4 hkhi.le
  unfold tSquared
  apply (div_le_div_iff₀ (by positivity : 0 < 8 * denominator a x)
    (by positivity : 0 < 8 * denominator a (tLocation a))).mpr
  have hid := t_difference_identity a (tLocation a) x
  rw [hk, mul_zero, add_zero] at hid
  have hprod : 0 ≤ a * (5 + 3 * tLocation a) * (x - tLocation a) ^ 2 := by
    apply mul_nonneg (mul_nonneg ha.le (by linarith)) (sq_nonneg _)
  have h := mul_nonneg (sq_nonneg a) hprod
  nlinarith

theorem tSquared_high_gt_one {a : ℝ} (ha23 : 2 / 3 < a) (ha4 : a < 4) :
    1 < tSquared a (tLocation a) := by
  have ha : 0 < a := by linarith
  obtain ⟨hklo, hkhi, hk⟩ := tLocation_properties ha23 ha4
  have hDk := denominator_pos ha ha4 hkhi.le
  have hid := t_difference_identity a (tLocation a) 1
  rw [hk, mul_zero, add_zero, denominator_one] at hid
  have hprod : 0 < a * (5 + 3 * tLocation a) * (1 - tLocation a) ^ 2 :=
    mul_pos (mul_pos ha (by linarith)) (sq_pos_of_pos (by linarith))
  unfold tSquared
  apply (one_lt_div (by positivity : 0 < 8 * denominator a (tLocation a))).mpr
  nlinarith

theorem tSquared_high_greatest {a : ℝ} (ha23 : 2 / 3 < a) (ha4 : a < 4) :
    IsGreatest (tSquared a '' Set.Icc (-1 : ℝ) 1) (tSquared a (tLocation a)) := by
  obtain ⟨hlo, hhi, _⟩ := tLocation_properties ha23 ha4
  refine ⟨⟨tLocation a, ⟨hlo.le, hhi.le⟩, rfl⟩, ?_⟩
  rintro y ⟨x, hx, rfl⟩
  exact tSquared_high_le_max ha23 ha4 hx.2

def characteristic (a : ℝ) (z : ℂ) : ℂ :=
  z ^ 2 + ((3 * a / 4 - 1 : ℝ) : ℂ) * z + ((a / 4 : ℝ) : ℂ)
def sensitivity (a : ℝ) (z : ℂ) : ℂ := z * (z - 1) / characteristic a z
def complementary (a : ℝ) (z : ℂ) : ℂ :=
  (((3 * a / 4 : ℝ) : ℂ) * z + ((a / 4 : ℝ) : ℂ)) / characteristic a z

theorem unit_re_mem {z : ℂ} (hz : ‖z‖ = 1) : z.re ∈ Set.Icc (-1 : ℝ) 1 := by
  have h := Complex.abs_re_le_norm z
  rw [hz] at h
  exact abs_le.mp h

theorem unit_parts {z : ℂ} (hz : ‖z‖ = 1) : z.re ^ 2 + z.im ^ 2 = 1 := by
  have h : ‖z‖ ^ 2 = z.re ^ 2 + z.im ^ 2 := by
    rw [Complex.sq_norm, Complex.normSq_apply]
    ring
  rw [hz] at h
  linarith

theorem characteristic_norm_sq {z : ℂ} (hz : ‖z‖ = 1) (a : ℝ) :
    ‖characteristic a z‖ ^ 2 = denominator a z.re := by
  have h := unit_parts hz
  calc
    _ = (z.re ^ 2 + z.im ^ 2) ^ 2 +
        (3 * a / 4 - 1) ^ 2 * (z.re ^ 2 + z.im ^ 2) + (a / 4) ^ 2 +
        2 * (3 * a / 4 - 1) * z.re * (z.re ^ 2 + z.im ^ 2 + a / 4) +
        2 * (a / 4) * (z.re ^ 2 - z.im ^ 2) := by
      rw [Complex.sq_norm, Complex.normSq_apply]
      simp [characteristic, Complex.add_re, Complex.add_im, Complex.mul_re, Complex.mul_im, pow_two]
      ring
    _ = _ := by
      rw [h]
      unfold denominator
      linear_combination -(a / 2) * h

theorem sensitivity_norm_sq {z : ℂ} (hz : ‖z‖ = 1) (a : ℝ) :
    ‖sensitivity a z‖ ^ 2 = sSquared a z.re := by
  have h := unit_parts hz
  have hn : ‖z * (z - 1)‖ ^ 2 = 2 * (1 - z.re) := by
    rw [norm_mul, mul_pow, hz]
    simp only [one_pow, one_mul]
    rw [Complex.sq_norm, Complex.normSq_apply]
    simp only [Complex.sub_re, Complex.sub_im, Complex.one_re, Complex.one_im, sub_zero]
    nlinarith [h]
  unfold sensitivity sSquared
  rw [norm_div, div_pow, hn, characteristic_norm_sq hz]

theorem complementary_norm_sq {z : ℂ} (hz : ‖z‖ = 1) (a : ℝ) :
    ‖complementary a z‖ ^ 2 = tSquared a z.re := by
  have h := unit_parts hz
  have hn : ‖((3 * a / 4 : ℝ) : ℂ) * z + ((a / 4 : ℝ) : ℂ)‖ ^ 2 =
      a ^ 2 * (5 + 3 * z.re) / 8 := by
    calc
      _ = 9 * a ^ 2 / 16 * (z.re ^ 2 + z.im ^ 2) +
          3 * a ^ 2 / 8 * z.re + a ^ 2 / 16 := by
        rw [Complex.sq_norm, Complex.normSq_apply]
        simp [pow_two]
        ring
      _ = _ := by rw [h]; ring
  unfold complementary tSquared
  rw [norm_div, div_pow, hn, characteristic_norm_sq hz]
  ring

def unitPoint (x : ℝ) : ℂ := ⟨x, Real.sqrt (1 - x ^ 2)⟩

theorem unitPoint_norm {x : ℝ} (hx : x ∈ Set.Icc (-1 : ℝ) 1) :
    ‖unitPoint x‖ = 1 := by
  have hrad : 0 ≤ 1 - x ^ 2 := by nlinarith [hx.1, hx.2]
  have hs := Real.sq_sqrt hrad
  have hn : ‖unitPoint x‖ ^ 2 = 1 := by
    rw [Complex.sq_norm, Complex.normSq_apply]
    dsimp [unitPoint]
    nlinarith
  nlinarith [norm_nonneg (unitPoint x)]

def circleNorm (f : ℂ → ℂ) : ℝ := sSup {v | ∃ z : ℂ, ‖z‖ = 1 ∧ v = ‖f z‖}

theorem circleNorm_of_squared_greatest {f : ℂ → ℂ} {q : ℝ → ℝ} {M : ℝ}
    (hq : ∀ z : ℂ, ‖z‖ = 1 → ‖f z‖ ^ 2 = q z.re)
    (hM : IsGreatest (q '' Set.Icc (-1 : ℝ) 1) M) :
    circleNorm f = Real.sqrt M := by
  obtain ⟨k, hk, hkM⟩ := hM.1
  have hkN := hq (unitPoint k) (unitPoint_norm hk)
  change ‖f (unitPoint k)‖ ^ 2 = q k at hkN
  have hM0 : 0 ≤ M := by rw [← hkM, ← hkN]; positivity
  have hval : ‖f (unitPoint k)‖ = Real.sqrt M := by
    have hs := Real.sq_sqrt hM0
    rw [hkM] at hkN
    nlinarith [norm_nonneg (f (unitPoint k)), Real.sqrt_nonneg M]
  apply IsGreatest.csSup_eq
  constructor
  · exact ⟨unitPoint k, unitPoint_norm hk, hval.symm⟩
  · rintro v ⟨z, hz, rfl⟩
    have hb := hM.2 (Set.mem_image_of_mem q (unit_re_mem hz))
    rw [← hq z hz] at hb
    have hs := Real.sq_sqrt hM0
    nlinarith [norm_nonneg (f z), Real.sqrt_nonneg M]

/-- The actual unit-circle sensitivity norm, with the explicit attained value. -/
theorem exact_sensitivity_peak {a : ℝ} (ha : 0 < a) (ha4 : a < 4) :
    circleNorm (sensitivity a) = 4 / Real.sqrt (sFactor a) := by
  rw [circleNorm_of_squared_greatest (fun z hz => sensitivity_norm_sq hz a)
    (sSquared_greatest ha ha4)]
  rw [Real.sqrt_div (by norm_num : (0 : ℝ) ≤ 16)]
  norm_num

theorem exact_complementary_low_peak {a : ℝ} (ha : 0 < a) (ha23 : a ≤ 2 / 3) :
    circleNorm (complementary a) = 1 := by
  rw [circleNorm_of_squared_greatest (fun z hz => complementary_norm_sq hz a)
    (tSquared_low_greatest ha ha23)]
  norm_num

theorem exact_complementary_high_peak {a : ℝ} (ha23 : 2 / 3 < a) (ha4 : a < 4) :
    circleNorm (complementary a) = Real.sqrt (tSquared a (tLocation a)) ∧
      1 < circleNorm (complementary a) := by
  have he := circleNorm_of_squared_greatest (fun z hz => complementary_norm_sq hz a)
    (tSquared_high_greatest ha23 ha4)
  refine ⟨he, ?_⟩
  rw [he]
  have hg := tSquared_high_gt_one ha23 ha4
  have hs := Real.sq_sqrt (show 0 ≤ tSquared a (tLocation a) by linarith)
  nlinarith [Real.sqrt_nonneg (tSquared a (tLocation a))]

theorem sensitivity_peak_attained {a : ℝ} (ha : 0 < a) (ha4 : a < 4) :
    ‖unitPoint (sLocation a)‖ = 1 ∧
      ‖sensitivity a (unitPoint (sLocation a))‖ = circleNorm (sensitivity a) := by
  have hk := sLocation_mem ha ha4
  have hz := unitPoint_norm ⟨hk.1.le, hk.2.le⟩
  refine ⟨hz, ?_⟩
  rw [circleNorm_of_squared_greatest (fun z h => sensitivity_norm_sq h a)
    (sSquared_greatest ha ha4)]
  have h := sensitivity_norm_sq hz a
  change ‖sensitivity a (unitPoint (sLocation a))‖ ^ 2 = sSquared a (sLocation a) at h
  rw [sSquared_at_max ha ha4] at h
  rw [← h, Real.sqrt_sq_eq_abs, abs_of_nonneg (norm_nonneg _)]

theorem complementary_high_peak_attained {a : ℝ} (ha23 : 2 / 3 < a) (ha4 : a < 4) :
    ‖unitPoint (tLocation a)‖ = 1 ∧
      ‖complementary a (unitPoint (tLocation a))‖ = circleNorm (complementary a) := by
  obtain ⟨hlo, hhi, _⟩ := tLocation_properties ha23 ha4
  have hz := unitPoint_norm ⟨hlo.le, hhi.le⟩
  refine ⟨hz, ?_⟩
  rw [(exact_complementary_high_peak ha23 ha4).1]
  have h := complementary_norm_sq hz a
  change ‖complementary a (unitPoint (tLocation a))‖ ^ 2 = tSquared a (tLocation a) at h
  rw [← h, Real.sqrt_sq_eq_abs, abs_of_nonneg (norm_nonneg _)]

end C2.Sensitivity
