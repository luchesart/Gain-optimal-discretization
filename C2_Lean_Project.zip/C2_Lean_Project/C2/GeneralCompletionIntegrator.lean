import C2.GeneralCompletionSmallGain

/-! The simple-integrator small-gain stability theorem.  Every possible
exterior root is excluded quantitatively; no root-continuity theorem or
chosen root branch is assumed. -/
noncomputable section
set_option maxHeartbeats 1200000
open Polynomial
namespace C2.GeneralCompletion

theorem polynomial_expansion_at_one (p : Polynomial ℂ) :
    ∃ q : Polynomial ℂ, ∀ z : ℂ, p.eval z = p.eval 1 + (z-1)*q.eval z := by
  have hd : (Polynomial.X - Polynomial.C (1 : ℂ)) ∣ (p-Polynomial.C (p.eval 1)) := by
    apply dvd_iff_isRoot.mpr
    simp
  obtain ⟨q,hq⟩ := hd
  refine ⟨q, ?_⟩
  intro z
  have h := congrArg (Polynomial.eval z) hq
  simp only [Polynomial.eval_sub, Polynomial.eval_C, Polynomial.eval_mul,
    Polynomial.eval_X] at h
  linear_combination h

theorem polynomial_norm_le_on_two {p : Polynomial ℂ} {z : ℂ}
    (hz : 1 ≤ ‖z‖) (hz2 : ‖z‖ ≤ 2) :
    ‖p.eval z‖ ≤ coefficientNormSum p * 2^p.natDegree := by
  apply (eval_norm_le_coefficientNormSum le_rfl hz).trans
  apply mul_le_mul_of_nonneg_left _ (coefficientNormSum_nonneg p)
  exact pow_le_pow_left₀ (norm_nonneg z) hz2 _

/-- A simple pole at one with positive feedback residue moves into the disk,
and every remaining pole remains strictly inside it. The conclusion is about
all actual complex roots, including their multiplicities. -/
theorem simple_integrator_small_positive_gains {Q N : Polynomial ℂ}
    (hQ : Q ≠ 0)
    (hstable : ∀ z : ℂ, Q.eval z = 0 → ‖z‖ < 1)
    (hdegree : N.natDegree ≤ Q.natDegree+1)
    {c : ℝ} (hc : 0 < c) (hratio : N.eval 1 = (c : ℂ)*Q.eval 1) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℝ, 0 < k → k < ε →
      ∀ z : ℂ, ((Polynomial.X-1)*Q+Polynomial.C (k : ℂ)*N).eval z = 0 → ‖z‖ < 1 := by
  obtain ⟨S,hS⟩ := polynomial_expansion_at_one Q
  obtain ⟨R,hR⟩ := polynomial_expansion_at_one N
  have hQ1 : Q.eval 1 ≠ 0 := by
    intro hz
    have h := hstable 1 hz
    simpa using h
  have hQ1p : 0 < ‖Q.eval 1‖ := norm_pos_iff.mpr hQ1
  let g := radialGap Q
  let C := coefficientNormSum N+1
  let α := 2*C/g
  let CS := coefficientNormSum S*2^S.natDegree
  let CR := coefficientNormSum R*2^R.natDegree
  let B := (α^2*CS+α*CR)/‖Q.eval 1‖
  let D := 2*B+α^2+1
  have hg : 0 < g := radialGap_pos hQ hstable
  have hCN := coefficientNormSum_nonneg N
  have hC : 0 < C := by dsimp [C]; linarith
  have hα : 0 < α := by dsimp [α]; positivity
  have hCS : 0 ≤ CS := mul_nonneg (coefficientNormSum_nonneg S) (by positivity)
  have hCR : 0 ≤ CR := mul_nonneg (coefficientNormSum_nonneg R) (by positivity)
  have hB : 0 ≤ B := by dsimp [B]; positivity
  have hD : 0 < D := by dsimp [D]; positivity
  have hαg : α*g = 2*C := by dsimp [α]; field_simp [hg.ne']
  have hBQ : B*‖Q.eval 1‖ = α^2*CS+α*CR := by
    dsimp [B]
    exact div_mul_cancel₀ _ hQ1p.ne'
  refine ⟨min (g/(2*C)) (c/D), lt_min (by positivity) (by positivity), ?_⟩
  intro k hk hsmall z hroot
  by_contra hbad
  have hz : 1 ≤ ‖z‖ := le_of_not_gt hbad
  have hk1 : k < g/(2*C) := hsmall.trans_le (min_le_left _ _)
  have hk2 : k < c/D := hsmall.trans_le (min_le_right _ _)
  have hkg : 2*k*C < g := by
    have h := (lt_div_iff₀ (show 0 < 2*C by positivity)).mp hk1
    nlinarith
  have hαk : α*k < 1 := by
    apply (mul_lt_mul_right hg).mp
    calc
      α*k*g = k*(α*g) := by ring
      _ = 2*k*C := by rw [hαg]; ring
      _ < g := hkg
      _ = 1*g := by ring
  let w := z-1
  have heq : w*Q.eval z + (k : ℂ)*N.eval z = 0 := by
    simpa only [Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_sub,
      Polynomial.eval_X, Polynomial.eval_one, Polynomial.eval_C] using hroot
  have hnormeq : ‖w‖*‖Q.eval z‖ = k*‖N.eval z‖ := by
    have h := congrArg norm (add_eq_zero_iff_eq_neg.mp heq)
    simpa only [norm_mul,norm_neg,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hk] using h
  have hQlo := radialGap_eval_lower_bound hstable hz
  have hNup := eval_norm_le_coefficientNormSum hdegree hz
  have hzpow : 0 < ‖z‖^Q.natDegree := pow_pos (by linarith) _
  have hbasic : g*‖w‖ ≤ k*C*‖z‖ := by
    apply (mul_le_mul_right hzpow).mp
    have hC' : coefficientNormSum N ≤ C := by dsimp [C]; linarith
    calc
      g*‖w‖*‖z‖^Q.natDegree = ‖w‖*(g*‖z‖^Q.natDegree) := by ring
      _ ≤ ‖w‖*‖Q.eval z‖ := mul_le_mul_of_nonneg_left hQlo (norm_nonneg w)
      _ = k*‖N.eval z‖ := hnormeq
      _ ≤ k*(coefficientNormSum N*‖z‖^(Q.natDegree+1)) :=
        mul_le_mul_of_nonneg_left hNup hk.le
      _ ≤ k*(C*‖z‖^(Q.natDegree+1)) := by gcongr
      _ = (k*C*‖z‖)*‖z‖^Q.natDegree := by rw [pow_succ]; ring
  have hzw : ‖z‖ ≤ ‖w‖+1 := by
    have h := norm_sub_norm_le z (1 : ℂ)
    simp only [norm_one] at h
    change ‖z‖-1 ≤ ‖w‖ at h
    linarith
  have hw : ‖w‖ ≤ α*k := by
    apply (mul_le_mul_right hg).mp
    have hnon : 0 ≤ (g-2*k*C)*‖w‖ := mul_nonneg (by linarith) (norm_nonneg _)
    have hsub : k*C*‖z‖ ≤ k*C*(‖w‖+1) :=
      mul_le_mul_of_nonneg_left hzw (by positivity)
    have he : α*k*g = 2*k*C := by calc
      _ = k*(α*g) := by ring
      _ = _ := by rw [hαg]; ring
    rw [he]
    nlinarith
  have hz2 : ‖z‖ ≤ 2 := by linarith
  have hSbound : ‖S.eval z‖ ≤ CS := polynomial_norm_le_on_two hz hz2
  have hRbound : ‖R.eval z‖ ≤ CR := polynomial_norm_le_on_two hz hz2
  have hres : (w+(k*c : ℝ))*Q.eval 1 =
      -(w^2*S.eval z + (k : ℂ)*w*R.eval z) := by
    rw [hS z, hR z, hratio] at heq
    change w*(Q.eval 1+w*S.eval z)+(k : ℂ)*((c : ℂ)*Q.eval 1+w*R.eval z)=0 at heq
    push_cast
    linear_combination heq
  have hresnorm : ‖w+(k*c : ℝ)‖ ≤ B*k^2 := by
    apply (mul_le_mul_right hQ1p).mp
    have hnorm := congrArg norm hres
    simp only [norm_mul,norm_neg] at hnorm
    calc
      _ = ‖w^2*S.eval z+(k : ℂ)*w*R.eval z‖ := hnorm
      _ ≤ ‖w^2*S.eval z‖+‖(k : ℂ)*w*R.eval z‖ := norm_add_le _ _
      _ = ‖w‖^2*‖S.eval z‖+k*‖w‖*‖R.eval z‖ := by
        simp [norm_mul,norm_pow,abs_of_pos hk]
      _ ≤ (α*k)^2*CS+k*(α*k)*CR := by gcongr
      _ = (α^2*CS+α*CR)*k^2 := by ring
      _ = (B*k^2)*‖Q.eval 1‖ := by rw [← hBQ]; ring
  have hre : w.re+k*c ≤ B*k^2 := by
    have h := (Complex.re_le_norm (w+(k*c : ℝ))).trans hresnorm
    simpa using h
  have hw2 : ‖w‖^2 ≤ (α*k)^2 := by gcongr
  have hid : ‖z‖^2 = 1+2*w.re+‖w‖^2 := by
    simp only [w,Complex.sq_norm,Complex.normSq_sub,Complex.normSq_one,
      map_one,mul_one,Complex.sub_re,Complex.one_re]
    ring
  have hkD : k*D < c := (lt_div_iff₀ hD).mp hk2
  have hkDk := mul_lt_mul_of_pos_right hkD hk
  dsimp [D] at hkDk
  nlinarith [mul_pos hk hc]

theorem simple_root_small_positive_gains {H N : Polynomial ℂ}
    (hH0 : H.eval 1 = 0) (hHd : H.derivative.eval 1 ≠ 0)
    (hstable : ∀ z : ℂ, H.eval z = 0 → z ≠ 1 → ‖z‖ < 1)
    (hdegree : N.natDegree ≤ H.natDegree)
    {c : ℝ} (hc : 0 < c) (hratio : N.eval 1 = (c : ℂ)*H.derivative.eval 1) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℝ, 0 < k → k < ε →
      ∀ z : ℂ, (H+Polynomial.C (k : ℂ)*N).eval z = 0 → ‖z‖ < 1 := by
  have hd : (Polynomial.X-Polynomial.C (1 : ℂ)) ∣ H := dvd_iff_isRoot.mpr hH0
  obtain ⟨Q,hQ⟩ := hd
  have hQne : Q ≠ 0 := by
    intro hq
    apply hHd
    simp [hQ,hq]
  have hder : H.derivative.eval 1 = Q.eval 1 := by
    rw [hQ]
    simp [Polynomial.derivative_mul]
  have hQstable : ∀ z : ℂ, Q.eval z = 0 → ‖z‖ < 1 := by
    intro z hz
    apply hstable z
    · simp [hQ,hz]
    · intro hz1
      apply hHd
      simpa [hz1, hder] using hz
  have hdegH : H.natDegree = Q.natDegree+1 := by
    rw [hQ,natDegree_mul (monic_X_sub_C 1).ne_zero hQne,natDegree_X_sub_C]
    omega
  rw [hdegH] at hdegree
  rw [hder] at hratio
  obtain ⟨ε,hε,hs⟩ := simple_integrator_small_positive_gains hQne hQstable hdegree hc hratio
  refine ⟨ε,hε,?_⟩
  intro k hk hkε z hz
  apply hs k hk hkε z
  simpa [hQ] using hz

theorem real_simple_root_small_positive_gains {H N : Polynomial ℝ}
    (hH0 : H.eval 1 = 0) (hHd : H.derivative.eval 1 ≠ 0)
    (hstable : ∀ z : ℂ, (H.map Complex.ofRealHom).eval z = 0 → z ≠ 1 → ‖z‖ < 1)
    (hdegree : N.natDegree ≤ H.natDegree)
    (hratio : 0 < N.eval 1/H.derivative.eval 1) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ k : ℝ, 0 < k → k < ε →
      ∀ z : ℂ, ((H+Polynomial.C k*N).map Complex.ofRealHom).eval z = 0 → ‖z‖ < 1 := by
  have hH0c : (H.map Complex.ofRealHom).eval 1 = 0 := by
    simp [Polynomial.eval_map,hH0]
  have hHdc : (H.map Complex.ofRealHom).derivative.eval 1 ≠ 0 := by
    simpa using hHd
  have hdegc : (N.map Complex.ofRealHom).natDegree ≤ (H.map Complex.ofRealHom).natDegree := by
    simpa using hdegree
  have hrc : (N.map Complex.ofRealHom).eval 1 =
      ((N.eval 1/H.derivative.eval 1 : ℝ) : ℂ)*(H.map Complex.ofRealHom).derivative.eval 1 := by
    simp only [Polynomial.derivative_map,Polynomial.eval_map,Polynomial.eval₂_at_one,
      Complex.ofRealHom_eq_coe]
    exact_mod_cast (div_mul_cancel₀ (N.eval 1) hHd).symm
  obtain ⟨ε,hε,hs⟩ := simple_root_small_positive_gains hH0c hHdc hstable hdegc hratio hrc
  refine ⟨ε,hε,?_⟩
  intro k hk hkε z hz
  apply hs k hk hkε z
  simpa using hz

end C2.GeneralCompletion
