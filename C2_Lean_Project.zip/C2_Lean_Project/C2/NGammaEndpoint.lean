import Mathlib.Tactic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Data.Real.Sqrt

/-!
# Constructive endpoint allocation for independent cascade parameters

This module treats the actual rational endpoint cost and the clipped scalar
allocation.  All hypotheses are explicit; the root-count and complex-root
placement statements belong to the separate phase analysis.
-/

noncomputable section
open scoped BigOperators
namespace C2.NGamma

/-- Endpoint phase resource in the original positive parameter. -/
def endpointCost (r x : ℝ) : ℝ := 1 / (x * (2 + r*x))

/-- Convex endpoint resource, before division by four. -/
def resource (r t : ℝ) : ℝ := t + r^2/t - 2*r

/-- Unconstrained stationary allocation with common multiplier reciprocal. -/
def freeAllocation (r c : ℝ) : ℝ := (c + Real.sqrt (c^2+4*r^2))/2

/-- Allocation including the active backward-Euler lower bound. -/
def endpointAllocation (r c : ℝ) : ℝ := max (r+2) (freeAllocation r c)

theorem endpointCost_pos {r x : ℝ} (hr : 0 < r) (hx : 0 < x) :
    0 < endpointCost r x := by
  unfold endpointCost
  positivity

theorem endpointCost_one (r : ℝ) : endpointCost r 1 = 1/(r+2) := by
  unfold endpointCost
  ring

theorem endpointCost_antitone {r x y : ℝ} (hr : 0 < r)
    (hx : 0 < x) (hxy : x ≤ y) : endpointCost r y ≤ endpointCost r x := by
  have hy : 0 < y := lt_of_lt_of_le hx hxy
  unfold endpointCost
  apply one_div_le_one_div_of_le
  · positivity
  · nlinarith [mul_self_le_mul_self (le_of_lt hx) hxy]

theorem endpointCost_strict_antitone {r x y : ℝ} (hr : 0 < r)
    (hx : 0 < x) (hxy : x < y) : endpointCost r y < endpointCost r x := by
  have hy : 0 < y := lt_trans hx hxy
  unfold endpointCost
  apply one_div_lt_one_div_of_lt
  · positivity
  · nlinarith [sq_lt_sq₀ (le_of_lt hx) (le_of_lt hy) |>.2 hxy]

theorem resource_identity {r t : ℝ} (ht : t ≠ 0) :
    resource r t = (t-r)^2/t := by
  unfold resource
  field_simp
  <;> ring

theorem resource_nonneg {r t : ℝ} (ht : 0 < t) : 0 ≤ resource r t := by
  rw [resource_identity (ne_of_gt ht)]
  positivity

theorem endpoint_change_variables {r x : ℝ} (hr : 0 < r) (hx : 0 < x) :
    resource r (r+2/x) = 4*endpointCost r x := by
  unfold resource endpointCost
  have h : r+2/x ≠ 0 := ne_of_gt (by positivity : 0 < r+2/x)
  field_simp
  <;> ring

theorem resource_lower_bound (r : ℝ) (hr : r+2 ≠ 0) :
    resource r (r+2) = 4/(r+2) := by
  unfold resource
  field_simp
  <;> ring

theorem resource_strict_mono {r s t : ℝ} (hr : 0 < r)
    (hs : r < s) (hst : s < t) : resource r s < resource r t := by
  have hs0 : 0 < s := lt_trans hr hs
  have ht0 : 0 < t := lt_trans hs0 hst
  have hstpos : 0 < s*t-r^2 := by nlinarith
  have hid : resource r t - resource r s = (t-s)*(s*t-r^2)/(s*t) := by
    unfold resource
    field_simp
    <;> ring
  have : 0 < resource r t - resource r s := by
    rw [hid]
    exact div_pos (mul_pos (sub_pos.mpr hst) hstpos) (mul_pos hs0 ht0)
  linarith

theorem resource_mono {r s t : ℝ} (hr : 0 < r)
    (hs : r < s) (hst : s ≤ t) : resource r s ≤ resource r t := by
  rcases hst.eq_or_lt with h | h
  · subst t; rfl
  · exact le_of_lt (resource_strict_mono hr hs h)

variable {ι : Type*} [Fintype ι]

/-- Feasibility of the endpoint regime, for every finite positive cascade. -/
theorem endpoint_feasible_iff (r : ι → ℝ) (hr : ∀ i, 0 < r i) :
    (∃ x : ι → ℝ, (∀ i, 0 < x i ∧ x i ≤ 1) ∧
      (∑ i, endpointCost (r i) (x i)) ≤ 1) ↔
      (∑ i, 1/(r i+2)) ≤ 1 := by
  constructor
  · rintro ⟨x,hx,hs⟩
    calc
      (∑ i, 1/(r i+2)) = ∑ i, endpointCost (r i) 1 := by simp [endpointCost_one]
      _ ≤ ∑ i, endpointCost (r i) (x i) := by
        exact Finset.sum_le_sum fun i _ => endpointCost_antitone (hr i) (hx i).1 (hx i).2
      _ ≤ 1 := hs
  · intro hs
    exact ⟨fun _ => 1, by simp, by simpa [endpointCost_one] using hs⟩

/-- At equality in the feasibility bound the all-one vector is the only design. -/
theorem endpoint_feasible_equality_unique (r x : ι → ℝ) (hr : ∀ i, 0 < r i)
    (hx : ∀ i, 0 < x i ∧ x i ≤ 1)
    (hbase : (∑ i, 1/(r i+2)) = 1)
    (hres : (∑ i, endpointCost (r i) (x i)) ≤ 1) : x = fun _ => 1 := by
  classical
  funext i
  by_contra hne
  have hxi : x i < 1 := lt_of_le_of_ne (hx i).2 hne
  have hlt : (∑ j, endpointCost (r j) 1) < ∑ j, endpointCost (r j) (x j) := by
    apply Finset.sum_lt_sum
    · intro j _
      exact endpointCost_antitone (hr j) (hx j).1 (hx j).2
    · exact ⟨i, Finset.mem_univ i, endpointCost_strict_antitone (hr i) (hx i).1 hxi⟩
  have hbase' : (∑ j, endpointCost (r j) 1) = 1 := by simpa [endpointCost_one] using hbase
  linarith


/-- The positive quadratic branch is positive even when the multiplier is zero. -/
theorem freeAllocation_pos {r c : ℝ} (hr : 0 < r) (hc : 0 ≤ c) :
    0 < freeAllocation r c := by
  unfold freeAllocation
  have hs : 0 < Real.sqrt (c^2+4*r^2) := Real.sqrt_pos.2 (by positivity)
  positivity

theorem freeAllocation_quadratic (r c : ℝ) :
    (freeAllocation r c)^2 - c*freeAllocation r c - r^2 = 0 := by
  have hs := Real.sq_sqrt (show 0 ≤ c^2+4*r^2 by positivity)
  unfold freeAllocation
  nlinarith

theorem freeAllocation_stationarity {r c : ℝ} (hr : 0 < r) (hc : 0 ≤ c) :
    freeAllocation r c - r^2 / freeAllocation r c = c := by
  have hp := freeAllocation_pos hr hc
  have hq := freeAllocation_quadratic r c
  field_simp [ne_of_gt hp]
  nlinarith

theorem freeAllocation_zero {r : ℝ} (hr : 0 ≤ r) : freeAllocation r 0 = r := by
  unfold freeAllocation
  have : Real.sqrt (4*r^2) = 2*r := by
    have hh := Real.sq_sqrt (show 0 ≤ 4*r^2 by positivity)
    have hn := Real.sqrt_nonneg (4*r^2)
    nlinarith
  simpa using congrArg (fun z : ℝ => z/2) this

theorem endpointAllocation_zero {r : ℝ} (hr : 0 ≤ r) :
    endpointAllocation r 0 = r+2 := by
  unfold endpointAllocation
  rw [freeAllocation_zero hr, max_eq_left (by linarith)]

theorem freeAllocation_strict_mono {r c d : ℝ} (hc : 0 ≤ c) (hcd : c < d) :
    freeAllocation r c < freeAllocation r d := by
  have hsq : c^2+4*r^2 ≤ d^2+4*r^2 := by nlinarith
  have hs := Real.sqrt_le_sqrt hsq
  unfold freeAllocation
  linarith

theorem freeAllocation_mono {r c d : ℝ} (hc : 0 ≤ c) (hcd : c ≤ d) :
    freeAllocation r c ≤ freeAllocation r d := by
  rcases hcd.eq_or_lt with h | h
  · subst d; rfl
  · exact le_of_lt (freeAllocation_strict_mono hc h)

theorem endpointAllocation_mono {r c d : ℝ} (hc : 0 ≤ c) (hcd : c ≤ d) :
    endpointAllocation r c ≤ endpointAllocation r d := by
  exact max_le_max_left _ (freeAllocation_mono hc hcd)

theorem endpointAllocation_ge_lower (r c : ℝ) : r+2 ≤ endpointAllocation r c :=
  le_max_left _ _

theorem endpointAllocation_gt_r (r c : ℝ) : r < endpointAllocation r c := by
  have := endpointAllocation_ge_lower r c
  linarith

theorem endpointAllocation_pos {r : ℝ} (hr : 0 < r) (c : ℝ) :
    0 < endpointAllocation r c := lt_trans hr (endpointAllocation_gt_r r c)

theorem endpointAllocation_continuous (r : ℝ) : Continuous (endpointAllocation r) := by
  unfold endpointAllocation freeAllocation
  exact continuous_const.max (by fun_prop)

/-- An active coordinate increases strictly with the common scalar. -/
theorem endpointAllocation_strict_of_active {r c d : ℝ} (hc : 0 ≤ c)
    (hcd : c < d) (ha : r+2 < endpointAllocation r c) :
    endpointAllocation r c < endpointAllocation r d := by
  have hx : r+2 < freeAllocation r c := by
    simpa [endpointAllocation, lt_max_iff, lt_irrefl, false_or] using ha
  rw [endpointAllocation, max_eq_right (le_of_lt hx)]
  exact lt_of_lt_of_le (freeAllocation_strict_mono hc hcd) (le_max_right _ _)

/-- Actual scalar resource function for the clipped finite cascade. -/
def allocatedResource (r : ι → ℝ) (c : ℝ) : ℝ :=
  ∑ i, resource (r i) (endpointAllocation (r i) c)

theorem allocatedResource_zero (r : ι → ℝ) (hr : ∀ i, 0 < r i) :
    allocatedResource r 0 = 4 * ∑ i, 1/(r i+2) := by
  unfold allocatedResource
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  rw [endpointAllocation_zero (le_of_lt (hr i)), resource_lower_bound _ (by linarith [hr i])]
  ring

theorem allocatedResource_continuous (r : ι → ℝ) (hr : ∀ i, 0 < r i) :
    Continuous (allocatedResource r) := by
  unfold allocatedResource resource
  apply continuous_finset_sum
  intro i _
  exact ((endpointAllocation_continuous (r i)).add
    (continuous_const.div (endpointAllocation_continuous (r i))
      (fun c => ne_of_gt (endpointAllocation_pos (hr i) c)))).sub continuous_const

theorem allocatedResource_mono (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {c d : ℝ} (hc : 0 ≤ c) (hcd : c ≤ d) :
    allocatedResource r c ≤ allocatedResource r d := by
  apply Finset.sum_le_sum
  intro i _
  exact resource_mono (hr i) (endpointAllocation_gt_r (r i) c)
    (endpointAllocation_mono hc hcd)


/-- A direct supporting inequality, derived from the two elementary log bounds. -/
theorem resource_log_support {r s t : ℝ} (hs : 0 < s) (ht : 0 < t) :
    (s-r^2/s)*(Real.log t-Real.log s) ≤ resource r t-resource r s := by
  have hq : 0 < t/s := div_pos ht hs
  have hl := Real.log_le_sub_one_of_pos hq
  have hi := Real.log_le_sub_one_of_pos (inv_pos.2 hq)
  rw [Real.log_inv] at hi
  have hcoef : 0 ≤ r^2/s := by positivity
  have hA := mul_nonneg (le_of_lt hs) (sub_nonneg.mpr hl)
  have hB := mul_nonneg hcoef (show 0 ≤ (t/s)⁻¹-1+Real.log (t/s) by linarith)
  have hid : resource r t-resource r s -
      (s-r^2/s)*(Real.log t-Real.log s) =
      s*((t/s)-1-Real.log (t/s)) +
        (r^2/s)*((t/s)⁻¹-1+Real.log (t/s)) := by
    rw [Real.log_div (ne_of_gt ht) (ne_of_gt hs)]
    unfold resource
    field_simp
    <;> ring
  linarith

theorem resource_log_support_strict {r s t : ℝ} (hs : 0 < s) (ht : 0 < t)
    (hne : t ≠ s) :
    (s-r^2/s)*(Real.log t-Real.log s) < resource r t-resource r s := by
  have hq : 0 < t/s := div_pos ht hs
  have hqn : t/s ≠ 1 := by intro h; apply hne; exact (div_eq_one_iff_eq (ne_of_gt hs)).mp h
  have hl := Real.log_lt_sub_one_of_pos hq hqn
  have hi := Real.log_le_sub_one_of_pos (inv_pos.2 hq)
  rw [Real.log_inv] at hi
  have hcoef : 0 ≤ r^2/s := by positivity
  have hA := mul_pos hs (sub_pos.mpr hl)
  have hB := mul_nonneg hcoef (show 0 ≤ (t/s)⁻¹-1+Real.log (t/s) by linarith)
  have hid : resource r t-resource r s -
      (s-r^2/s)*(Real.log t-Real.log s) =
      s*((t/s)-1-Real.log (t/s)) +
        (r^2/s)*((t/s)⁻¹-1+Real.log (t/s)) := by
    rw [Real.log_div (ne_of_gt ht) (ne_of_gt hs)]
    unfold resource
    field_simp
    <;> ring
  linarith

/-- The stationary derivative is strictly increasing on the positive half-line. -/
theorem stationaryRate_strict_mono {r s t : ℝ} (hs : 0 < s) (hst : s < t) :
    s-r^2/s < t-r^2/t := by
  have ht : 0 < t := lt_trans hs hst
  have hdiv : r^2/t ≤ r^2/s := div_le_div_of_nonneg_left (sq_nonneg r) hs (le_of_lt hst)
  linarith

theorem stationaryRate_mono {r s t : ℝ} (hs : 0 < s) (hst : s ≤ t) :
    s-r^2/s ≤ t-r^2/t := by
  rcases hst.eq_or_lt with h | h
  · subst t; rfl
  · exact le_of_lt (stationaryRate_strict_mono hs h)

/-- The clipped allocation satisfies the actual one-dimensional KKT inequalities. -/
theorem endpointAllocation_kkt {r c : ℝ} (hr : 0 < r) (hc : 0 ≤ c) :
    c ≤ endpointAllocation r c-r^2/endpointAllocation r c ∧
      (r+2 < endpointAllocation r c →
        endpointAllocation r c-r^2/endpointAllocation r c = c) := by
  constructor
  · calc
      c = freeAllocation r c-r^2/freeAllocation r c := (freeAllocation_stationarity hr hc).symm
      _ ≤ endpointAllocation r c-r^2/endpointAllocation r c :=
        stationaryRate_mono (freeAllocation_pos hr hc) (le_max_right _ _)
  · intro ha
    have hf : r+2 < freeAllocation r c := by
      simpa [endpointAllocation, lt_max_iff, lt_irrefl, false_or] using ha
    rw [endpointAllocation, max_eq_right (le_of_lt hf)]
    exact freeAllocation_stationarity hr hc

theorem endpointAllocation_support {r c t : ℝ} (hr : 0 < r) (hc : 0 ≤ c)
    (ht : r+2 ≤ t) :
    c*(Real.log t-Real.log (endpointAllocation r c)) ≤
      resource r t-resource r (endpointAllocation r c) := by
  have hs := endpointAllocation_pos hr c
  have ht0 : 0 < t := by linarith
  have hk := endpointAllocation_kkt hr hc
  by_cases ha : r+2 < endpointAllocation r c
  · have hh := resource_log_support (r := r) hs ht0
    rw [hk.2 ha] at hh
    exact hh
  · have heq : endpointAllocation r c = r+2 := le_antisymm (le_of_not_gt ha) (endpointAllocation_ge_lower r c)
    have hlog : 0 ≤ Real.log t-Real.log (endpointAllocation r c) :=
      sub_nonneg.mpr (Real.log_le_log hs (by simpa [heq] using ht))
    exact le_trans (mul_le_mul_of_nonneg_right hk.1 hlog) (resource_log_support hs ht0)

theorem endpointAllocation_support_strict {r c t : ℝ} (hr : 0 < r) (hc : 0 ≤ c)
    (ht : r+2 ≤ t) (hne : t ≠ endpointAllocation r c) :
    c*(Real.log t-Real.log (endpointAllocation r c)) <
      resource r t-resource r (endpointAllocation r c) := by
  have hs := endpointAllocation_pos hr c
  have ht0 : 0 < t := by linarith
  have hk := endpointAllocation_kkt hr hc
  by_cases ha : r+2 < endpointAllocation r c
  · have hh := resource_log_support_strict (r := r) hs ht0 hne
    rw [hk.2 ha] at hh
    exact hh
  · have heq : endpointAllocation r c = r+2 := le_antisymm (le_of_not_gt ha) (endpointAllocation_ge_lower r c)
    have hlog : 0 ≤ Real.log t-Real.log (endpointAllocation r c) :=
      sub_nonneg.mpr (Real.log_le_log hs (by simpa [heq] using ht))
    exact lt_of_le_of_lt (mul_le_mul_of_nonneg_right hk.1 hlog) (resource_log_support_strict hs ht0 hne)

/-- The resource equation is sufficient for the global endpoint maximum. -/
theorem endpointAllocation_log_optimal (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {c : ℝ} (hc : 0 < c) (hbudget : allocatedResource r c = 4)
    (t : ι → ℝ) (ht : ∀ i, r i+2 ≤ t i)
    (htres : (∑ i, resource (r i) (t i)) ≤ 4) :
    (∑ i, Real.log (t i)) ≤ ∑ i, Real.log (endpointAllocation (r i) c) := by
  have hs := Finset.sum_le_sum (s := Finset.univ) fun i _ =>
    endpointAllocation_support (hr i) (le_of_lt hc) (ht i)
  simp_rw [mul_sub, Finset.sum_sub_distrib, ← Finset.mul_sum] at hs
  unfold allocatedResource at hbudget
  nlinarith

/-- A distinct feasible vector has strictly smaller log gain. -/
theorem endpointAllocation_log_optimal_strict (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {c : ℝ} (hc : 0 < c) (hbudget : allocatedResource r c = 4)
    (t : ι → ℝ) (ht : ∀ i, r i+2 ≤ t i)
    (htres : (∑ i, resource (r i) (t i)) ≤ 4)
    (hne : t ≠ fun i => endpointAllocation (r i) c) :
    (∑ i, Real.log (t i)) < ∑ i, Real.log (endpointAllocation (r i) c) := by
  classical
  obtain ⟨i,hi⟩ : ∃ i, t i ≠ endpointAllocation (r i) c := by
    by_contra h
    apply hne
    funext i
    by_contra hi
    exact h ⟨i,hi⟩
  have hs : (∑ i, c*(Real.log (t i)-Real.log (endpointAllocation (r i) c))) <
      ∑ i, (resource (r i) (t i)-resource (r i) (endpointAllocation (r i) c)) := by
    apply Finset.sum_lt_sum
    · intro j _
      exact endpointAllocation_support (hr j) (le_of_lt hc) (ht j)
    · exact ⟨i, Finset.mem_univ i, endpointAllocation_support_strict (hr i) (le_of_lt hc) (ht i) hi⟩
  simp_rw [mul_sub, Finset.sum_sub_distrib, ← Finset.mul_sum] at hs
  unfold allocatedResource at hbudget
  nlinarith


theorem freeAllocation_ge_scalar {r c : ℝ} (hc : 0 ≤ c) : c ≤ freeAllocation r c := by
  have hs : c ≤ Real.sqrt (c^2+4*r^2) := Real.le_sqrt_of_sq_le (by nlinarith [sq_nonneg r])
  unfold freeAllocation
  linarith

theorem allocatedResource_large (r : ι → ℝ) (hr : ∀ i, 0 < r i) (i : ι) :
    4 < allocatedResource r (5+2*r i) := by
  classical
  have hc : 0 ≤ 5+2*r i := by linarith [hr i]
  have hs := endpointAllocation_pos (hr i) (5+2*r i)
  have ha : 5+2*r i ≤ endpointAllocation (r i) (5+2*r i) :=
    le_trans (freeAllocation_ge_scalar hc) (le_max_right _ _)
  have hcost : 4 < resource (r i) (endpointAllocation (r i) (5+2*r i)) := by
    unfold resource
    have hq : 0 ≤ (r i)^2 / endpointAllocation (r i) (5+2*r i) := by positivity
    linarith
  exact lt_of_lt_of_le hcost (Finset.single_le_sum
    (fun j _ => resource_nonneg (endpointAllocation_pos (hr j) _)) (Finset.mem_univ i))

theorem allocatedResource_strict_after_base (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {c d : ℝ} (hc : 0 ≤ c) (hcd : c < d)
    (hactive : allocatedResource r 0 < allocatedResource r c) :
    allocatedResource r c < allocatedResource r d := by
  classical
  have hex : ∃ i, r i+2 < endpointAllocation (r i) c := by
    by_contra hn
    have heq : allocatedResource r c = allocatedResource r 0 := by
      unfold allocatedResource
      apply Finset.sum_congr rfl
      intro i _
      have hlow := endpointAllocation_ge_lower (r i) c
      have hu : endpointAllocation (r i) c ≤ r i+2 := by
        by_contra h
        exact hn ⟨i, lt_of_not_ge h⟩
      rw [le_antisymm hu hlow, endpointAllocation_zero (le_of_lt (hr i))]
    linarith
  obtain ⟨i,hi⟩ := hex
  apply Finset.sum_lt_sum
  · intro j _
    exact resource_mono (hr j) (endpointAllocation_gt_r (r j) c)
      (endpointAllocation_mono hc (le_of_lt hcd))
  · exact ⟨i, Finset.mem_univ i, resource_strict_mono (hr i)
      (endpointAllocation_gt_r (r i) c) (endpointAllocation_strict_of_active hc hcd hi)⟩

/-- Existence and uniqueness of the positive common scalar, without a KKT assumption. -/
theorem existsUnique_endpoint_scalar [Nonempty ι] (r : ι → ℝ)
    (hr : ∀ i, 0 < r i) (hbase : (∑ i, 1/(r i+2)) < 1) :
    ∃! c : ℝ, 0 < c ∧ allocatedResource r c = 4 := by
  classical
  let i : ι := Classical.choice inferInstance
  have hi : 0 < r i := hr i
  have hc : 0 ≤ 5+2*r i := by linarith
  have hzero : allocatedResource r 0 < 4 := by
    rw [allocatedResource_zero r hr]
    linarith
  have hlarge := allocatedResource_large r hr i
  obtain ⟨c,hcI,hcEq⟩ := intermediate_value_Icc hc
    (allocatedResource_continuous r hr).continuousOn
      (show 4 ∈ Set.Icc (allocatedResource r 0) (allocatedResource r (5+2*r i)) from
        ⟨le_of_lt hzero, le_of_lt hlarge⟩)
  have hcpos : 0 < c := by
    have hc0 := hcI.1
    by_contra hn
    have : c = 0 := le_antisymm (le_of_not_gt hn) hc0
    subst c
    linarith
  refine ⟨c,⟨hcpos,hcEq⟩,?_⟩
  rintro d ⟨hdpos,hdEq⟩
  rcases lt_trichotomy d c with h | h | h
  · have hs := allocatedResource_strict_after_base r hr (le_of_lt hdpos) h
      (by linarith : allocatedResource r 0 < allocatedResource r d)
    linarith
  · exact h
  · have hs := allocatedResource_strict_after_base r hr (le_of_lt hcpos) h
      (by linarith : allocatedResource r 0 < allocatedResource r c)
    linarith


/-- Product-gain form of the endpoint optimum. -/
theorem endpointAllocation_product_optimal (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {c : ℝ} (hc : 0 < c) (hbudget : allocatedResource r c = 4)
    (t : ι → ℝ) (ht : ∀ i, r i+2 ≤ t i)
    (htres : (∑ i, resource (r i) (t i)) ≤ 4) :
    (∏ i, t i) ≤ ∏ i, endpointAllocation (r i) c := by
  have htpos : ∀ i, 0 < t i := fun i => by linarith [hr i,ht i]
  have hspos : ∀ i, 0 < endpointAllocation (r i) c := fun i => endpointAllocation_pos (hr i) c
  apply (Real.log_le_log_iff (Finset.prod_pos (fun i _ => htpos i))
    (Finset.prod_pos (fun i _ => hspos i))).mp
  rw [Real.log_prod _ _ (fun i _ => ne_of_gt (htpos i)),
    Real.log_prod _ _ (fun i _ => ne_of_gt (hspos i))]
  exact endpointAllocation_log_optimal r hr hc hbudget t ht htres

theorem endpointAllocation_product_optimal_strict (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {c : ℝ} (hc : 0 < c) (hbudget : allocatedResource r c = 4)
    (t : ι → ℝ) (ht : ∀ i, r i+2 ≤ t i)
    (htres : (∑ i, resource (r i) (t i)) ≤ 4)
    (hne : t ≠ fun i => endpointAllocation (r i) c) :
    (∏ i, t i) < ∏ i, endpointAllocation (r i) c := by
  have htpos : ∀ i, 0 < t i := fun i => by linarith [hr i,ht i]
  have hspos : ∀ i, 0 < endpointAllocation (r i) c := fun i => endpointAllocation_pos (hr i) c
  apply (Real.log_lt_log_iff (Finset.prod_pos (fun i _ => htpos i))
    (Finset.prod_pos (fun i _ => hspos i))).mp
  rw [Real.log_prod _ _ (fun i _ => ne_of_gt (htpos i)),
    Real.log_prod _ _ (fun i _ => ne_of_gt (hspos i))]
  exact endpointAllocation_log_optimal_strict r hr hc hbudget t ht htres hne

/-- The original design parameter recovered from the constructive allocation. -/
def endpointParameter (r c : ℝ) : ℝ := 2/(endpointAllocation r c-r)

theorem endpointParameter_pos (r c : ℝ) : 0 < endpointParameter r c := by
  unfold endpointParameter
  exact div_pos (by norm_num) (sub_pos.mpr (endpointAllocation_gt_r r c))

theorem endpointParameter_le_one (r c : ℝ) : endpointParameter r c ≤ 1 := by
  unfold endpointParameter
  apply (div_le_one (sub_pos.mpr (endpointAllocation_gt_r r c))).2
  linarith [endpointAllocation_ge_lower r c]

theorem endpointParameter_inverse (r c : ℝ) :
    r+2/endpointParameter r c = endpointAllocation r c := by
  unfold endpointParameter
  field_simp
  <;> ring

theorem endpointParameter_resource {r c : ℝ} (hr : 0 < r) :
    4*endpointCost r (endpointParameter r c) = resource r (endpointAllocation r c) := by
  rw [← endpointParameter_inverse r c]
  exact (endpoint_change_variables hr (endpointParameter_pos r c)).symm

theorem endpointParameter_budget (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {c : ℝ} (hbudget : allocatedResource r c = 4) :
    (∑ i, endpointCost (r i) (endpointParameter (r i) c)) = 1 := by
  have hsum : 4*(∑ i, endpointCost (r i) (endpointParameter (r i) c)) = allocatedResource r c := by
    rw [Finset.mul_sum]
    unfold allocatedResource
    exact Finset.sum_congr rfl (fun i _ => endpointParameter_resource (hr i))
  linarith

theorem endpointGain_product_optimal (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {c : ℝ} (hc : 0 < c) (hbudget : allocatedResource r c = 4)
    (x : ι → ℝ) (hx : ∀ i, 0 < x i ∧ x i ≤ 1)
    (hcost : (∑ i, endpointCost (r i) (x i)) ≤ 1) :
    (∏ i, (r i+2/x i)) ≤ ∏ i, endpointAllocation (r i) c := by
  apply endpointAllocation_product_optimal r hr hc hbudget (fun i => r i+2/x i)
  · intro i
    have hh : 2 ≤ 2/x i := (le_div_iff₀ (hx i).1).2 (by nlinarith [(hx i).2])
    linarith
  · have hsum : (∑ i, resource (r i) (r i+2/x i)) = 4*∑ i, endpointCost (r i) (x i) := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun i _ => endpoint_change_variables (hr i) (hx i).1)
    rw [hsum]
    linarith

theorem endpointGain_product_optimal_strict (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    {c : ℝ} (hc : 0 < c) (hbudget : allocatedResource r c = 4)
    (x : ι → ℝ) (hx : ∀ i, 0 < x i ∧ x i ≤ 1)
    (hcost : (∑ i, endpointCost (r i) (x i)) ≤ 1)
    (hne : x ≠ fun i => endpointParameter (r i) c) :
    (∏ i, (r i+2/x i)) < ∏ i, endpointAllocation (r i) c := by
  apply endpointAllocation_product_optimal_strict r hr hc hbudget (fun i => r i+2/x i)
  · intro i
    have hh : 2 ≤ 2/x i := (le_div_iff₀ (hx i).1).2 (by nlinarith [(hx i).2])
    linarith
  · have hsum : (∑ i, resource (r i) (r i+2/x i)) = 4*∑ i, endpointCost (r i) (x i) := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun i _ => endpoint_change_variables (hr i) (hx i).1)
    rw [hsum]
    linarith
  · intro heq
    apply hne
    funext i
    have hh := congrFun heq i
    change r i+2/x i = endpointAllocation (r i) c at hh
    unfold endpointParameter
    apply (eq_div_iff (ne_of_gt (sub_pos.mpr (endpointAllocation_gt_r (r i) c)))).2
    have hh' : (r i)*x i+2 = endpointAllocation (r i) c*x i := by
      have ht := (div_eq_iff (ne_of_gt (hx i).1)).mp (show 2/x i = endpointAllocation (r i) c-r i by linarith)
      nlinarith
    nlinarith

/-- Constructive original-parameter endpoint optimizer.  It states the allocation
    and gain optimization; root multiplicities are treated separately. -/
theorem exists_endpoint_optimizer [Nonempty ι] (r : ι → ℝ) (hr : ∀ i, 0 < r i)
    (hbase : (∑ i, 1/(r i+2)) < 1) :
    ∃ c : ℝ, 0 < c ∧ allocatedResource r c = 4 ∧
      (∀ i, 0 < endpointParameter (r i) c ∧ endpointParameter (r i) c ≤ 1) ∧
      (∑ i, endpointCost (r i) (endpointParameter (r i) c)) = 1 ∧
      ∀ x : ι → ℝ, (∀ i, 0 < x i ∧ x i ≤ 1) →
        (∑ i, endpointCost (r i) (x i)) ≤ 1 →
          ((∏ i, (r i+2/x i)) ≤ (∏ i, endpointAllocation (r i) c) ∧
          (x ≠ (fun i => endpointParameter (r i) c) →
            (∏ i, (r i+2/x i)) < (∏ i, endpointAllocation (r i) c))) := by
  obtain ⟨c,⟨hc,hbudget⟩,_⟩ := existsUnique_endpoint_scalar r hr hbase
  refine ⟨c,hc,hbudget,?_,endpointParameter_budget r hr hbudget,?_⟩
  · exact fun i => ⟨endpointParameter_pos _ _, endpointParameter_le_one _ _⟩
  · intro x hx hcost
    exact ⟨endpointGain_product_optimal r hr hc hbudget x hx hcost,
      fun hne => endpointGain_product_optimal_strict r hr hc hbudget x hx hcost hne⟩

end C2.NGamma
