import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Tactic

/-!
# Analytic cores for the independent-parameter global optimization

These results prove exact phase feasibility and the strict reflection comparisons.
They do not assume or assert an argument-principle root count, continuity of a
parametric maximizer, or the full global gain-margin theorem.
-/

noncomputable section
open scoped BigOperators Topology
open Set
open Filter

namespace C2.NGamma.Global

def phase (r x w : ℝ) : ℝ :=
  Real.arctan ((x + 2 / r) / w) - Real.arctan (x / w)

def phaseDenom (r x w : ℝ) : ℝ := r * (x ^ 2 + w ^ 2) + 2 * x

theorem phaseDenom_pos {r x w : ℝ} (hr : 0 < r) (hx : 0 ≤ x) (hw : 0 < w) :
    0 < phaseDenom r x w := by
  unfold phaseDenom
  have : 0 < w ^ 2 := sq_pos_of_pos hw
  positivity

theorem phase_pos {r x w : ℝ} (hr : 0 < r) (hw : 0 < w) :
    0 < phase r x w := by
  unfold phase
  apply sub_pos.mpr
  apply Real.arctan_strictMono
  apply (div_lt_div_iff_of_pos_right hw).2
  have : 0 < 2 / r := div_pos (by norm_num) hr
  linarith

theorem phase_lt_pi_div_two {r x w : ℝ} (hx : 0 ≤ x) (hw : 0 < w) :
    phase r x w < Real.pi / 2 := by
  have hx' : 0 ≤ Real.arctan (x / w) := by
    simpa only [Real.arctan_zero] using Real.arctan_strictMono.monotone (div_nonneg hx hw.le)
  have h := Real.arctan_lt_pi_div_two ((x + 2/r) / w)
  unfold phase
  linarith

theorem phase_eq_arctan {r x w : ℝ} (hr : 0 < r) (hx : 0 ≤ x) (hw : 0 < w) :
    phase r x w = Real.arctan (2 * w / phaseDenom r x w) := by
  have hnon : 0 ≤ (x + 2 / r) / w := by positivity
  have hprod : ((x + 2 / r) / w) * (-(x / w)) < 1 := by
    have := mul_nonpos_of_nonneg_of_nonpos hnon (neg_nonpos.mpr (div_nonneg hx hw.le))
    linarith
  have h := Real.arctan_add hprod
  rw [Real.arctan_neg] at h
  change phase r x w = _ at h
  rw [h]
  congr 1
  have hd := ne_of_gt (phaseDenom_pos hr hx hw)
  unfold phaseDenom at *
  field_simp [ne_of_gt hr, ne_of_gt hw, hd]
  <;> ring

theorem phase_strictAntiOn {r w : ℝ} (hr : 0 < r) (hw : 0 < w) :
    StrictAntiOn (fun x => phase r x w) (Ici 0) := by
  intro a ha b hb hab
  dsimp only
  rw [phase_eq_arctan hr ha hw, phase_eq_arctan hr hb hw]
  apply Real.arctan_strictMono
  apply div_lt_div_of_pos_left (by positivity) (phaseDenom_pos hr ha hw)
  unfold phaseDenom
  have hsq : a ^ 2 < b ^ 2 := sq_lt_sq₀ ha hb |>.2 hab
  nlinarith

theorem phase_continuous (r w : ℝ) : Continuous (fun x => phase r x w) := by
  unfold phase
  exact (Real.continuous_arctan.comp ((continuous_id.add continuous_const).div_const w)).sub
    (Real.continuous_arctan.comp (continuous_id.div_const w))

theorem phase_bounds {r x w : ℝ} (hr : 0 < r) (hw : 0 < w)
    (hx : x ∈ Icc (0:ℝ) 1) :
    phase r 1 w ≤ phase r x w ∧ phase r x w ≤ phase r 0 w := by
  have h := (phase_strictAntiOn hr hw).antitoneOn
  exact ⟨h hx.1 (by norm_num) hx.2, h (by norm_num) hx.1 hx.1⟩

/-- The finite-dimensional phase constraint is feasible exactly between its
two endpoint sums. A common coordinate already witnesses every intermediate
sum; no Lagrange-multiplier or optimizer-existence premise is used. -/
theorem phase_feasible_iff {n : ℕ} (r : Fin n → ℝ) (hr : ∀ j, 0 < r j)
    {w q : ℝ} (hw : 0 < w) :
    (∃ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) ∧
      ∑ j, phase (r j) (x j) w = q) ↔
    (∑ j, phase (r j) 1 w ≤ q ∧ q ≤ ∑ j, phase (r j) 0 w) := by
  constructor
  · rintro ⟨x,hx,hq⟩
    rw [← hq]
    constructor
    · exact Finset.sum_le_sum (fun j _ => (phase_bounds (hr j) hw (hx j)).1)
    · exact Finset.sum_le_sum (fun j _ => (phase_bounds (hr j) hw (hx j)).2)
  · intro hq
    let f : ℝ → ℝ := fun a => ∑ j, phase (r j) a w
    have hf : ContinuousOn f (Icc (0:ℝ) 1) := by
      apply Continuous.continuousOn
      exact continuous_finset_sum _ (fun j _ => phase_continuous (r j) w)
    obtain ⟨a,ha,heq⟩ := intermediate_value_Icc' (by norm_num : (0:ℝ) ≤ 1) hf hq
    exact ⟨fun _ => a, fun _ => ha, heq⟩

/-- If a phase sum is at its all-zero endpoint, each coordinate is zero. -/
theorem phase_upper_endpoint_unique {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) {w : ℝ} (hw : 0 < w)
    (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    (heq : (∑ j, phase (r j) (x j) w) = ∑ j, phase (r j) 0 w) :
    ∀ j, x j = 0 := by
  intro j
  by_contra hne
  have hp : 0 < x j := lt_of_le_of_ne (hx j).1 (Ne.symm hne)
  have hs : (∑ i, phase (r i) (x i) w) < ∑ i, phase (r i) 0 w := by
    apply Finset.sum_lt_sum
    · intro i _
      exact (phase_bounds (hr i) hw (hx i)).2
    · exact ⟨j, Finset.mem_univ j,
        phase_strictAntiOn (hr j) hw (by norm_num) (hx j).1 hp⟩
  exact (ne_of_lt hs) heq

/-- If a phase sum is at its all-one endpoint, each coordinate is one. -/
theorem phase_lower_endpoint_unique {n : ℕ} (r x : Fin n → ℝ)
    (hr : ∀ j, 0 < r j) {w : ℝ} (hw : 0 < w)
    (hx : ∀ j, x j ∈ Icc (0:ℝ) 1)
    (heq : (∑ j, phase (r j) (x j) w) = ∑ j, phase (r j) 1 w) :
    ∀ j, x j = 1 := by
  intro j
  by_contra hne
  have hp : x j < 1 := lt_of_le_of_ne (hx j).2 hne
  have hs : (∑ i, phase (r i) 1 w) < ∑ i, phase (r i) (x i) w := by
    apply Finset.sum_lt_sum
    · intro i _
      exact (phase_bounds (hr i) hw (hx i)).1
    · exact ⟨j, Finset.mem_univ j,
        phase_strictAntiOn (hr j) hw (hx j).1 (by norm_num) hp⟩
  exact (ne_of_gt hs) heq

theorem arctan_sum_le {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) :
    Real.arctan (a+b) ≤ Real.arctan a + Real.arctan b := by
  by_cases hab : a*b < 1
  · rw [Real.arctan_add hab]
    apply Real.arctan_strictMono.monotone
    apply (le_div_iff₀ (by linarith : 0 < 1-a*b)).2
    have := mul_nonneg (add_nonneg ha hb) (mul_nonneg ha hb)
    nlinarith
  · have hp : 0 < b := by
      by_contra hn
      have : b = 0 := le_antisymm (le_of_not_gt hn) hb
      simp [this] at hab
    have hba : b⁻¹ ≤ a := by
      rw [inv_eq_one_div]
      exact (div_le_iff₀ hp).2 (by linarith)
    have h := Real.arctan_strictMono.monotone hba
    rw [Real.arctan_inv_of_pos hp] at h
    exact le_trans (Real.arctan_lt_pi_div_two (a+b)).le (by linarith)

theorem arctan_double_lt {v : ℝ} (hv : 0 < v) :
    Real.arctan (2*v) < 2 * Real.arctan v := by
  by_cases hvv : v*v < 1
  · have h := Real.arctan_add hvv
    have hh : 2*v < (v+v)/(1-v*v) := by
      apply (lt_div_iff₀ (by linarith : 0 < 1-v*v)).2
      have := mul_pos hv (sq_pos_of_pos hv)
      nlinarith
    have := Real.arctan_strictMono hh
    rw [← h] at this
    linarith
  · have hinv : v⁻¹ ≤ v := by
      rw [inv_eq_one_div]
      exact (div_le_iff₀ hv).2 (by linarith)
    have h := Real.arctan_strictMono.monotone hinv
    rw [Real.arctan_inv_of_pos hv] at h
    have := Real.arctan_lt_pi_div_two (2*v)
    linarith

/-- Strict phase improvement under reflection, including the zero-gain
boundary case u=c. This is the analytical comparison used by the full-cube
initial-margin argument, not a statement about polynomial roots. -/
theorem reflection_phase_strict {c u t : ℝ} (hu : 0 < u) (huc : u ≤ c)
    (ht : 0 < t) :
    Real.arctan ((c+u)*t) - Real.arctan (u*t) <
      Real.arctan ((c-u)*t) + Real.arctan (u*t) := by
  have h₁ := arctan_sum_le (mul_nonneg (sub_nonneg.mpr huc) ht.le)
    (by positivity : 0 ≤ 2*(u*t))
  have heq : (c-u)*t + 2*(u*t) = (c+u)*t := by ring
  rw [heq] at h₁
  have h₂ := arctan_double_lt (mul_pos hu ht)
  linarith

theorem reflection_magnitude_sq_strict {c u t : ℝ} (hc : 0 < c)
    (hu : 0 < u) (ht : 0 < t) :
    (1+(c-u)^2*t^2)/(1+u^2*t^2) <
      (1+(c+u)^2*t^2)/(1+u^2*t^2) := by
  apply (div_lt_div_iff_of_pos_right (by positivity : 0 < 1+u^2*t^2)).2
  have := mul_pos (mul_pos hc hu) (sq_pos_of_pos ht)
  nlinarith

theorem reflection_magnitude_strict {r c u t : ℝ} (hr : 0 < r)
    (hc : 0 < c) (hu : 0 < u) (ht : 0 < t) :
    r * Real.sqrt ((1+(c-u)^2*t^2)/(1+u^2*t^2)) <
      r * Real.sqrt ((1+(c+u)^2*t^2)/(1+u^2*t^2)) := by
  apply mul_lt_mul_of_pos_left _ hr
  apply Real.sqrt_lt_sqrt (by positivity)
  exact reflection_magnitude_sq_strict hc hu ht

def marginal (r x w : ℝ) : ℝ :=
  (r * (x^2-w^2) + 2*x) / (2*w*(r*x+1))

def negPhaseDerivative (r x w : ℝ) : ℝ :=
  4*w*(r*x+1) / (((r*x+2)^2 + r^2*w^2)*(x^2+w^2))

theorem marginal_below_x_div_w {r x w : ℝ} (hr : 0 < r)
    (hx : 0 ≤ x) (hw : 0 < w) : marginal r x w < x/w := by
  unfold marginal
  have hy : 0 < r*x+1 := by positivity
  apply (div_lt_div_iff₀ (by positivity) hw).2
  have hsq : 0 < x^2+w^2 := by positivity
  nlinarith [mul_pos (mul_pos hr hw) hsq]

theorem negPhaseDerivative_pos {r x w : ℝ} (hr : 0 < r)
    (hx : 0 ≤ x) (hw : 0 < w) : 0 < negPhaseDerivative r x w := by
  unfold negPhaseDerivative
  positivity

/-- Algebraic factorization behind the positive-multiplier branch of the
envelope estimate. Every quantity is the actual rational derivative. -/
theorem positive_multiplier_component {r x w lam : ℝ} (hr : 0 < r)
    (hx : 0 ≤ x) (hw : 0 < w) (hlam : 0 < lam)
    (hbound : lam*w < x) :
    lam/w * (2*w/phaseDenom r x w) <
      negPhaseDerivative r x w * (1+lam*marginal r x w) := by
  let D := phaseDenom r x w
  let Q := ((r*x+2)^2 + r^2*w^2)*(x^2+w^2)
  have hD : 0 < D := phaseDenom_pos hr hx hw
  have hQ : 0 < Q := by dsimp [Q]; positivity
  have hy : 0 < r*x+1 := by positivity
  have hDgt : 2*x < D := by
    dsimp [D,phaseDenom]
    have : 0 < r*(x^2+w^2) := by positivity
    linarith
  have hrbound : lam*r*w < r*x := by nlinarith [mul_pos hr (sub_pos.mpr hbound)]
  have hinner : 0 < D*(r*x+1-lam*r*w)-2*lam*w := by
    have hprod := mul_pos hD (show 0 < r*x-lam*r*w by linarith)
    nlinarith
  have hid :
      negPhaseDerivative r x w * (1+lam*marginal r x w) -
        lam/w * (2*w/phaseDenom r x w) =
      4*w*(D*(r*x+1-lam*r*w)-2*lam*w)/(Q*D) := by
    dsimp [D,Q,negPhaseDerivative,marginal,phaseDenom]
    field_simp
    <;> ring
  apply sub_pos.mp
  rw [hid]
  exact div_pos (by positivity) (mul_pos hQ hD)

/-- The elementary finite-sum trigonometric estimate in the envelope proof.
This form works for any nonempty finite family of positive acute phases. -/
theorem sin_sum_lt_sum_tan {n : ℕ} (hn : 0 < n) (d : Fin n → ℝ)
    (hd : ∀ j, 0 < d j ∧ d j < Real.pi/2) :
    Real.sin (∑ j, d j) < ∑ j, Real.tan (d j) := by
  have hsum : 0 ≤ ∑ j, d j := Finset.sum_nonneg (fun j _ => (hd j).1.le)
  have hlt : (∑ j, d j) < ∑ j, Real.tan (d j) := by
    apply Finset.sum_lt_sum
    · intro j _
      exact (Real.lt_tan (hd j).1 (hd j).2).le
    · exact ⟨⟨0,hn⟩, Finset.mem_univ _, Real.lt_tan (hd ⟨0,hn⟩).1 (hd ⟨0,hn⟩).2⟩
  exact lt_of_le_of_lt (Real.sin_le hsum) hlt

/-- Scalar crossing used for the feasible-frequency endpoints. -/
theorem unique_positive_crossing_atTop {f : ℝ → ℝ}
    (hf : ContinuousOn f (Ioi 0)) (hm : StrictMonoOn f (Ioi 0))
    (hz : Tendsto f (𝓝[>] 0) (𝓝 0)) (hinf : Tendsto f atTop atTop) :
    ∃! t, 0 < t ∧ f t = 2 := by
  have hhi : (atTop : Filter ℝ) ≤ 𝓟 (Ioi 0) := by
    rw [Filter.le_principal_iff]
    exact eventually_gt_atTop 0
  obtain ⟨t,ht,hft⟩ := isPreconnected_Ioi.intermediate_value_Ioi
    (show (𝓝[>] (0:ℝ)) ≤ 𝓟 (Ioi 0) from inf_le_right) hhi hf hz hinf
    (by norm_num : (2:ℝ) ∈ Ioi 0)
  refine ⟨t,⟨ht,hft⟩,?_⟩
  intro s hs
  exact (hm.eq_iff_eq hs.1 ht).mp (hs.2.trans hft.symm)

theorem unique_positive_crossing_finite {f : ℝ → ℝ} {L : ℝ}
    (hf : ContinuousOn f (Ioi 0)) (hm : StrictMonoOn f (Ioi 0))
    (hz : Tendsto f (𝓝[>] 0) (𝓝 0)) (hinf : Tendsto f atTop (𝓝 L))
    (hL : 2 < L) :
    ∃! t, 0 < t ∧ f t = 2 := by
  have hhi : (atTop : Filter ℝ) ≤ 𝓟 (Ioi 0) := by
    rw [Filter.le_principal_iff]
    exact eventually_gt_atTop 0
  obtain ⟨t,ht,hft⟩ := isPreconnected_Ioi.intermediate_value_Ioo
    (show (𝓝[>] (0:ℝ)) ≤ 𝓟 (Ioi 0) from inf_le_right) hhi hf hz hinf
    (show (2:ℝ) ∈ Ioo 0 L from ⟨by norm_num,hL⟩)
  refine ⟨t,⟨ht,hft⟩,?_⟩
  intro s hs
  exact (hm.eq_iff_eq hs.1 ht).mp (hs.2.trans hft.symm)

theorem strictly_below_finite_limit {f : ℝ → ℝ} {L t : ℝ}
    (hm : StrictMonoOn f (Ioi 0)) (hinf : Tendsto f atTop (𝓝 L))
    (ht : 0 < t) : f t < L := by
  have ht1 : 0 < t+1 := by linarith
  have hle : f (t+1) ≤ L := by
    apply le_of_tendsto_of_tendsto tendsto_const_nhds hinf
    filter_upwards [eventually_ge_atTop (t+1)] with u hu
    exact hm.monotoneOn ht1 (show 0 < u by linarith) hu
  exact lt_of_lt_of_le (hm ht ht1 (by linarith)) hle

theorem crossing_order_iff {f : ℝ → ℝ} {s t : ℝ}
    (hm : StrictMonoOn f (Ioi 0)) (hs : 0 < s) (ht : 0 < t)
    (hfs : f s = 2) :
    (f t ≤ 2 ↔ t ≤ s) ∧ (2 ≤ f t ↔ s ≤ t) := by
  rw [← hfs]
  exact ⟨hm.le_iff_le ht hs,hm.le_iff_le hs ht⟩

end C2.NGamma.Global
