import Mathlib.Analysis.Normed.Algebra.Spectrum
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.Matrix
import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.Tactic

/-! Strict spectral-radius stability implies decay of the actual powers.
The proof uses Gelfand's formula and an eventual geometric norm bound. -/
noncomputable section
open scoped Topology
open Filter
namespace C2.NGamma.Realization

lemma powers_tendsto_zero_of_spectralRadius_lt_one
    {A : Type*} [NormedRing A] [NormedAlgebra ℂ A] [CompleteSpace A]
    (a : A) (ha : spectralRadius ℂ a < 1) :
    Tendsto (fun n : ℕ => a ^ n) atTop (𝓝 0) := by
  obtain ⟨q,hq,hq1⟩ := exists_between ha
  have hq0 : 0 < q := lt_of_le_of_lt bot_le hq
  have hqtop : q ≠ ⊤ := ne_of_lt (hq1.trans_le le_top)
  have hc0 : 0 < q.toReal := ENNReal.toReal_pos (ne_of_gt hq0) hqtop
  have hc1 : q.toReal < 1 := by
    simpa using (ENNReal.toReal_lt_toReal hqtop (by simp)).2 hq1
  have he := (spectrum.pow_norm_pow_one_div_tendsto_nhds_spectralRadius a).eventually
    (gt_mem_nhds hq)
  have hbound : ∀ᶠ n : ℕ in atTop, ‖a ^ n‖ ≤ q.toReal ^ n := by
    filter_upwards [he,eventually_gt_atTop (0:ℕ)] with n hn hn0
    have hnR : 0 < (n : ℝ) := by exact_mod_cast hn0
    have hroot : ‖a ^ n‖ ^ (1 / (n : ℝ)) < q.toReal := by
      rw [← ENNReal.ofReal_toReal hqtop] at hn
      exact (ENNReal.ofReal_lt_ofReal_iff hc0).mp hn
    have hp := (Real.rpow_inv_lt_iff_of_pos (norm_nonneg (a ^ n)) hc0.le hnR).mp
      (by simpa only [one_div] using hroot)
    exact (by simpa only [Real.rpow_natCast] using hp.le)
  exact squeeze_zero_norm' hbound
    (tendsto_pow_atTop_nhds_zero_of_lt_one hc0.le hc1)

end C2.NGamma.Realization
