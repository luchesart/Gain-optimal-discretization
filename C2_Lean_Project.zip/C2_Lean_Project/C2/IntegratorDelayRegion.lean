import C2.IntegratorDelayRootCount
import C2.IntegratorDelayHighGain
import C2.IntegratorDelayOptimum

noncomputable section
namespace C2.IntegratorDelay
open NGamma.PolynomialModel NGamma.Cayley

def criticalCayleyPoint (n : ℕ) (x : ℝ) : ℝ := Real.tan (frequency n x / 2)

theorem criticalCayleyPoint_pos {n : ℕ} (hn : 2 ≤ n) {x : ℝ}
    (hx0 : -1 ≤ x) (hx1 : x ≤ 1) : 0 < criticalCayleyPoint n x := by
  have hb := frequency_bounds hn (frequency_spec hn hx0 hx1).1
  exact Real.tan_pos_of_pos_of_lt_pi_div_two (by linarith [hb.1])
    (by linarith [hb.2.1, Real.pi_pos])

theorem criticalCayleyPoint_angle {n : ℕ} (hn : 2 ≤ n) {x : ℝ}
    (hx0 : -1 ≤ x) (hx1 : x ≤ 1) :
    2 * Real.arctan (criticalCayleyPoint n x) = frequency n x := by
  have hb := frequency_bounds hn (frequency_spec hn hx0 hx1).1
  unfold criticalCayleyPoint
  rw [Real.arctan_tan (by linarith [hb.1, Real.pi_pos]) (by linarith [hb.2.1, Real.pi_pos])]
  ring

theorem criticalCayleyPoint_phase {n : ℕ} (hn : 2 ≤ n) {x : ℝ}
    (hx0 : -1 ≤ x) (hx1 : x ≤ 1) :
    totalPhase n x (criticalCayleyPoint n x) = Real.pi := by
  rw [totalPhase_eq_lowPhase, criticalCayleyPoint_angle hn hx0 hx1,
    (frequency_spec hn hx0 hx1).2]
  ring

theorem criticalCayleyPoint_amplitude {n : ℕ} (hn : 2 ≤ n) {x : ℝ}
    (hx0 : -1 ≤ x) (hx1 : x ≤ 1) :
    amplitude x (criticalCayleyPoint n x) = boundaryGain n (frequency n x) := by
  have hf := (frequency_spec hn hx0 hx1).2
  have hat : Real.arctan (x * Real.tan (frequency n x / 2)) =
      (n : ℝ) * frequency n x - Real.pi / 2 := by
    unfold lowPhase at hf
    linarith
  have hs : 1 / Real.sqrt (1 + (x * Real.tan (frequency n x / 2)) ^ 2) =
      Real.sin ((n : ℝ) * frequency n x) := by
    rw [← Real.cos_arctan, hat, Real.cos_sub, Real.cos_pi_div_two, Real.sin_pi_div_two]
    ring
  unfold amplitude criticalCayleyPoint boundaryGain
  rw [div_eq_mul_inv, ← one_div, hs]

theorem poly_eval_characteristic (n : ℕ) (γ a : ℝ) (z : ℂ) :
    (poly n (2 * γ - 1) a).eval z = characteristic n γ a z := by
  rw [poly_eval, q_eval]
  unfold characteristic
  push_cast
  ring

theorem stable_iff_poly (n : ℕ) (γ a : ℝ) :
    Stable n γ a ↔ SchurStable (poly n (2 * γ - 1) a) := by
  simp only [Stable, SchurStable, poly_eval_characteristic]

theorem positive_gain_exact_region {n : ℕ} (hn : 2 ≤ n) {γ a : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) (ha : 0 < a) :
    Stable n γ a ↔ a < criticalGain n γ := by
  let x : ℝ := 2 * γ - 1
  have hx0 : -1 ≤ x := by dsimp [x]; linarith
  have hx1 : x ≤ 1 := by dsimp [x]; linarith
  have htstar := criticalCayleyPoint_pos hn hx0 hx1
  have hcrit : amplitude x (criticalCayleyPoint n x) = criticalGain n γ :=
    criticalCayleyPoint_amplitude hn hx0 hx1
  rw [stable_iff_poly]
  change SchurStable (poly n x a) ↔ a < criticalGain n γ
  by_cases hbound : a * |x| < 2
  · let tb := amplitudeCrossing x a
    have htb : 0 < tb := amplitudeCrossing_pos ha hbound
    have hBeq : amplitude x tb = a := amplitude_at_crossing ha hbound
    have hangle : (2 * Real.arctan tb < frequency n x) ↔ tb < criticalCayleyPoint n x := by
      rw [← criticalCayleyPoint_angle hn hx0 hx1]
      have h := Real.arctan_strictMono.lt_iff_lt (a := tb) (b := criticalCayleyPoint n x)
      constructor
      · intro hh
        apply h.mp
        linarith
      · intro hh
        have := h.mpr hh
        linarith
    calc
      SchurStable (poly n x a) ↔ totalPhase n x tb < Real.pi :=
        integrator_schur_iff_phase hn hx1 ha htb hBeq hbound
      _ ↔ 2 * Real.arctan tb < frequency n x := totalPhase_lt_pi_iff hn hx0 hx1 htb
      _ ↔ tb < criticalCayleyPoint n x := hangle
      _ ↔ a < criticalGain n γ := by
        rw [← hBeq, ← hcrit]
        exact ((amplitude_strictMonoOn x).lt_iff_lt htb.le htstar.le).symm
  · have hhigh : 2 ≤ a * |x| := le_of_not_gt hbound
    have hcritbound := amplitude_endpoint_bound x htstar.le
    rw [hcrit] at hcritbound
    have hnot : ¬ a < criticalGain n γ := by
      intro hh
      have hm := mul_le_mul_of_nonneg_right hh.le (abs_nonneg x)
      linarith
    exact iff_of_false (not_schur_of_high_gain (by omega) ha hhigh) hnot

/-- `thm:general`, with actual complex roots and every real gain. -/
theorem complete_region {n : ℕ} (hn : 2 ≤ n) {γ a : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    Stable n γ a ↔ 0 < a ∧ a < criticalGain n γ := by
  constructor
  · intro hs
    have ha := stable_gain_pos (by omega) hγ1 hs
    exact ⟨ha, (positive_gain_exact_region hn hγ0 hγ1 ha).1 hs⟩
  · rintro ⟨ha, hlt⟩
    exact (positive_gain_exact_region hn hγ0 hγ1 ha).2 hlt

theorem criticalGain_isLUB {n : ℕ} (hn : 2 ≤ n) {γ : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    IsLUB {a : ℝ | Stable n γ a} (criticalGain n γ) := by
  have he : {a : ℝ | Stable n γ a} = Set.Ioo 0 (criticalGain n γ) := by
    ext a
    exact complete_region hn hγ0 hγ1
  rw [he]
  exact isLUB_Ioo (criticalGain_pos hn hγ0 hγ1)

theorem criticalGain_boundary_root {n : ℕ} (hn : 2 ≤ n) {γ : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    ∃ z : ℂ, ‖z‖ = 1 ∧ characteristic n γ (criticalGain n γ) z = 0 := by
  let x := 2 * γ - 1
  have hx0 : -1 ≤ x := by dsimp [x]; linarith
  have hx1 : x ≤ 1 := by dsimp [x]; linarith
  let t := criticalCayleyPoint n x
  have ht : 0 < t := criticalCayleyPoint_pos hn hx0 hx1
  have hB : amplitude x t = criticalGain n γ := criticalCayleyPoint_amplitude hn hx0 hx1
  have hp : totalPhase n x t = Real.pi := criticalCayleyPoint_phase hn hx0 hx1
  refine ⟨point t, point_norm t, ?_⟩
  rw [← poly_eval_characteristic, poly_eval_point, transfer_polar n x t ht.le, hB, hp,
    Complex.exp_pi_mul_I]
  ring

/-- The unique maximizing integration parameter, formulated using the actual
least upper bound of stable gains rather than defining a margin by a formula. -/
theorem maximizing_parameter_iff {n : ℕ} (hn : 2 ≤ n) {γ : ℝ}
    (hγ0 : 0 ≤ γ) (hγ1 : γ ≤ 1) :
    IsLUB {a : ℝ | Stable n γ a}
      (2 * Real.sin (Real.pi / (4 * (n : ℝ) - 2))) ↔ γ = 1 := by
  rw [← criticalGain_one hn]
  constructor
  · intro hs
    have he := (criticalGain_isLUB hn hγ0 hγ1).unique hs
    exact (criticalGain_unique_max hn ⟨hγ0, hγ1⟩).2.mp he
  · rintro rfl
    exact criticalGain_isLUB hn (by norm_num) (by norm_num)

end C2.IntegratorDelay
