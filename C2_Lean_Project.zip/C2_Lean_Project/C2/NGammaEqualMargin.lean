import C2.NGammaEqualGlobal
import C2.NGammaMarginOptimization

/-! Equal-factor corollary for the actual initial Schur-stable gain margin.
Both explicit optimizers are identified with the supremum defined from roots
of the concrete characteristic polynomial, including the exact stable range. -/
noncomputable section
open scoped BigOperators
open Set C2.NGamma C2.NGamma.Global C2.NGamma.PolynomialModel
namespace C2.NGammaEqual

private lemma actual_margin_of_critical_optimizer {n : ℕ} (hn : 0 < n)
    (r xs : Fin n → ℝ) (hr : ∀ j, 0 < r j) (hxs : ∀ j, xs j ∈ Icc (0:ℝ) 1)
    (B : ℝ) (hB : CriticalGain r xs B)
    (hopt : ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) →
      ∀ C : ℝ, CriticalGain r x C → C ≤ B ∧ (C=B ↔ x=xs)) :
    initialGainMargin r xs 1 = B ∧
      (∀ b : ℝ, 0 ≤ b → (SchurStable (characteristic r xs 1 b) ↔ b<B)) ∧
      ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) →
        initialGainMargin r x 1 ≤ B ∧ (initialGainMargin r x 1=B ↔ x=xs) := by
  refine ⟨criticalGain_eq_initialMargin hn r xs hr hxs hB,
    fun b hb => criticalGain_exact_interval hn r xs hr hxs hB hb,?_⟩
  intro x hx
  obtain ⟨C,hC⟩ := criticalGain_exists hn r x hr hx
  rw [criticalGain_eq_initialMargin hn r x hr hx hC]
  exact hopt x hx C hC

/-- Full endpoint regime of the identical-factor corollary, for actual Schur
stability and its initial margin. The explicit vector is uniquely optimal. -/
theorem identical_endpoint_margin {n : ℕ} (hn : 0 < n) {r : ℝ}
    (hr : 0 < r) (hregime : (n:ℝ)-2 ≤ r) :
    initialGainMargin (fun _ : Fin n => r) (fun _ => endpointCoordinate (n:ℝ) r) 1 = endpointGain n r ∧
      (∀ b : ℝ, 0 ≤ b →
        (SchurStable (characteristic (fun _ : Fin n => r)
          (fun _ => endpointCoordinate (n:ℝ) r) 1 b) ↔ b < endpointGain n r)) ∧
      ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) →
        initialGainMargin (fun _ : Fin n => r) x 1 ≤ endpointGain n r ∧
          (initialGainMargin (fun _ : Fin n => r) x 1 = endpointGain n r ↔
            x=fun _ => endpointCoordinate (n:ℝ) r) := by
  let xs : Fin n → ℝ := fun _ => endpointCoordinate (n:ℝ) r
  have hxpos : 0 < endpointCoordinate (n:ℝ) r := endpointCoordinate_pos (by exact_mod_cast hn)
  have hxone : endpointCoordinate (n:ℝ) r ≤ 1 :=
    (endpointCoordinate_le_one_iff (by exact_mod_cast hn) hr).2 hregime
  have hxs : ∀ j, xs j ∈ Icc (0:ℝ) 1 := fun _ => ⟨hxpos.le,hxone⟩
  have hcost : (∑ _ : Fin n, endpointCost r (endpointCoordinate (n:ℝ) r)) = 1 :=
    equal_resource_sum hn hr.le
  have hgain : endpointGain n r = ∏ _ : Fin n, (r+2/endpointCoordinate (n:ℝ) r) := by
    rw [endpointGain_factor_identity hn]
    simp [endpointGain]
  have hstar : CriticalGain (fun _ : Fin n => r) xs (endpointGain n r) :=
    Or.inl ⟨fun _ => hxpos,hcost.le,hgain⟩
  apply actual_margin_of_critical_optimizer hn (fun _ => r) xs (fun _ => hr) hxs _ hstar
  intro x hx B hB
  have hle : B ≤ endpointGain n r ∧ (B=endpointGain n r → x=xs) := by
    rcases hB with ⟨hxp,hcost,rfl⟩ | ⟨t,ht,hphase,hgain⟩
    · have hh := identical_endpoint_optimal hn hr hregime x (fun j => ⟨hxp j,(hx j).2⟩) hcost
      refine ⟨hh.1,?_⟩
      intro heq
      by_contra hne
      exact (ne_of_lt (hh.2 hne)) heq
    · obtain ⟨w,hw,hp,hprod⟩ := finite_critical_to_frequency
        (fun _ : Fin n => r) x (fun _ => hr) ht hphase hgain
      have hh : B < endpointGain n r := by
        rw [hprod]
        exact identical_endpoint_dominates_finite hn hr hregime hw x hx hp
      exact ⟨hh.le,fun heq => ((ne_of_lt hh) heq).elim⟩
  refine ⟨hle.1,hle.2,?_⟩
  intro heq
  subst x
  exact criticalGain_unique hn _ _ (fun _ => hr) hxs hB hstar

/-- Full finite-frequency regime, with the explicit sine-power gain, unique
angle, exact actual-root Schur interval, and unique global initial-margin design. -/
theorem identical_finite_margin {n : ℕ} (hn : 3 ≤ n) {r : ℝ}
    (hr : 0 < r) (hrn : r < (n:ℝ)-2) :
    ∃ φ : ℝ, φ ∈ Ioo 0 (Real.pi/(n:ℝ)) ∧
      r+1=Real.sin (((n:ℝ)-1)*φ)/Real.sin φ ∧
      (∀ ψ : ℝ, ψ ∈ Ioo 0 (Real.pi/(n:ℝ)) →
        r+1=Real.sin (((n:ℝ)-1)*ψ)/Real.sin ψ → ψ=φ) ∧
      initialGainMargin (fun _ : Fin n => r) (fun _ => 1) 1 =
        (Real.sin ((n:ℝ)*φ)/Real.sin φ)^n ∧
      (∀ b : ℝ, 0 ≤ b →
        (SchurStable (characteristic (fun _ : Fin n => r) (fun _ => 1) 1 b) ↔
          b < (Real.sin ((n:ℝ)*φ)/Real.sin φ)^n)) ∧
      ∀ x : Fin n → ℝ, (∀ j, x j ∈ Icc (0:ℝ) 1) →
        initialGainMargin (fun _ : Fin n => r) x 1 ≤ (Real.sin ((n:ℝ)*φ)/Real.sin φ)^n ∧
        (initialGainMargin (fun _ : Fin n => r) x 1 = (Real.sin ((n:ℝ)*φ)/Real.sin φ)^n ↔
          x=fun _ => 1) := by
  have hn0 : 0 < n := by omega
  obtain ⟨w,φ,hw,hφ,hangle,hp,hgain,hopt⟩ := identical_finite_global_gain hn hr hrn
  have hstar : CriticalGain (fun _ : Fin n => r) (fun _ => 1)
      ((Real.sin ((n:ℝ)*φ)/Real.sin φ)^n) := by
    rw [← hgain]
    exact criticalGain_of_frequency (fun _ : Fin n => r) _ (fun _ => hr) hw hp
  refine ⟨φ,hφ,hangle,?_,?_⟩
  · intro ψ hψ hpψ
    exact finite_angle_unique hn r hψ hφ hpψ hangle
  · apply actual_margin_of_critical_optimizer hn0 (fun _ : Fin n => r) (fun _ => 1)
      (fun _ => hr) (fun _ => by norm_num) _ hstar
    intro x hx B hB
    have hle : B ≤ (Real.sin ((n:ℝ)*φ)/Real.sin φ)^n ∧ (B=(Real.sin ((n:ℝ)*φ)/Real.sin φ)^n → x=fun _ => 1) := by
      rcases hB with ⟨hxp,hcost,hgainB⟩ | ⟨t,ht,hphase,hgainB⟩
      · have hbase := (endpoint_feasible_iff (fun _ : Fin n => r) (fun _ => hr)).mp
          ⟨x,fun j => ⟨hxp j,(hx j).2⟩,hcost⟩
        have hsum : (∑ _ : Fin n, 1/(r+2)) = (n:ℝ)/(r+2) := by simp [div_eq_mul_inv]
        rw [hsum] at hbase
        have hh := (div_le_one (by positivity : 0 < r+2)).mp hbase
        linarith
      · obtain ⟨v,hv,hpv,hprod⟩ := finite_critical_to_frequency
          (fun _ : Fin n => r) x (fun _ => hr) ht hphase hgainB
        rw [hprod]
        have hh := hopt v hv x hx hpv
        exact ⟨hh.1,fun heq => ((hh.2).mp heq).2⟩
    refine ⟨hle.1,hle.2,?_⟩
    intro heq
    subst x
    exact criticalGain_unique hn0 _ _ (fun _ => hr) hx hB hstar

/-- The all-backward-Euler evaluation used above is exactly the project's
actual characteristic polynomial, including the harmless root at zero. -/
lemma identical_backward_characteristic_eval (n : ℕ) (r b : ℝ) (z : ℂ) :
    (characteristic (fun _ : Fin n => r) (fun _ => 1) 1 b).eval z =
      backwardCharacteristic n r b z := by
  simp [characteristic,factor,q,backwardCharacteristic]
  ring_nf
  simp

/-- The two explicitly stated boundary roots are roots of the concrete
characteristic polynomial and both lie on the unit circle. -/
theorem identical_finite_boundary_roots {n : ℕ} {r φ : ℝ}
    (hs : Real.sin φ ≠ 0)
    (hangle : r+1=Real.sin (((n:ℝ)-1)*φ)/Real.sin φ) :
    let B := (Real.sin ((n:ℝ)*φ)/Real.sin φ)^n
    let z := Complex.exp (((Real.pi-(n:ℝ)*φ : ℝ) : ℂ)*Complex.I)
    let zbar := Complex.exp (-(((Real.pi-(n:ℝ)*φ : ℝ) : ℂ)*Complex.I))
    (characteristic (fun _ : Fin n => r) (fun _ => 1) 1 B).eval z=0 ∧
    (characteristic (fun _ : Fin n => r) (fun _ => 1) 1 B).eval zbar=0 ∧
    ‖z‖=1 ∧ ‖zbar‖=1 := by
  dsimp only
  rw [identical_backward_characteristic_eval,identical_backward_characteristic_eval]
  have hh := equal_finite_boundary_pair hs hangle
  refine ⟨hh.1,hh.2,equal_finite_boundary_norm n φ,?_⟩
  rw [Complex.norm_exp]
  simp

lemma finite_angle_sin_ne_zero {n : ℕ} (hn : 0<n) {φ : ℝ}
    (hφ : φ ∈ Ioo 0 (Real.pi/(n:ℝ))) : Real.sin φ ≠ 0 := by
  have hnR : 0<(n:ℝ) := by exact_mod_cast hn
  have hn1 : 1≤(n:ℝ) := by exact_mod_cast hn
  have hh := (lt_div_iff₀ hnR).mp hφ.2
  exact ne_of_gt (Real.sin_pos_of_pos_of_lt_pi hφ.1 (by nlinarith [hφ.1]))

/-- The explicit cubic formula is the actual optimized initial margin. -/
theorem identical_order_three_margin {r : ℝ} (hr : 0<r) (hr1 : r<1) :
    initialGainMargin (fun _ : Fin 3 => r) (fun _ => 1) 1 = (r*(r+2))^3 := by
  obtain ⟨φ,hφ,hangle,huniq,hm,hstable,hmax⟩ :=
    identical_finite_margin (n := 3) (by norm_num) hr (by norm_num; exact hr1)
  rw [hm]
  have hh := order_three_gain (r := r) (φ := φ)
    (finite_angle_sin_ne_zero (by norm_num : 0<(3:ℕ)) hφ)
    (by norm_num at hangle ⊢; exact hangle)
  simpa using hh

/-- The explicit quartic formula is the actual optimized initial margin. -/
theorem identical_order_four_margin {r : ℝ} (hr : 0<r) (hr2 : r<2) :
    initialGainMargin (fun _ : Fin 4 => r) (fun _ => 1) 1 = r^4*(r+2)^2 := by
  obtain ⟨φ,hφ,hangle,huniq,hm,hstable,hmax⟩ :=
    identical_finite_margin (n := 4) (by norm_num) hr (by norm_num; exact hr2)
  rw [hm]
  have hh := order_four_gain (r := r) (φ := φ)
    (finite_angle_sin_ne_zero (by norm_num : 0<(4:ℕ)) hφ)
    (by norm_num at hangle ⊢; exact hangle)
  simpa using hh

/-- The displayed conjugate roots are distinct throughout the finite regime. -/
lemma identical_finite_boundary_distinct {n : ℕ} (hn : 0<n) {φ : ℝ}
    (hφ : φ ∈ Ioo 0 (Real.pi/(n:ℝ))) :
    Complex.exp (((Real.pi-(n:ℝ)*φ : ℝ) : ℂ)*Complex.I) ≠
      Complex.exp (-(((Real.pi-(n:ℝ)*φ : ℝ) : ℂ)*Complex.I)) := by
  have hnR : 0<(n:ℝ) := by exact_mod_cast hn
  have hangle : 0 < Real.pi-(n:ℝ)*φ := by
    have h := (lt_div_iff₀ hnR).mp hφ.2
    nlinarith
  have hanglepi : Real.pi-(n:ℝ)*φ < Real.pi := by nlinarith [mul_pos hnR hφ.1]
  have hs := Real.sin_pos_of_pos_of_lt_pi hangle hanglepi
  intro heq
  have him := congrArg Complex.im heq
  simp [Complex.exp_im] at him
  rw [Real.sin_pi_sub] at hs
  linarith

/-- The explicit endpoint gain has the claimed actual unit-circle root -1. -/
lemma identical_endpoint_boundary {n : ℕ} (hn : 0<n) (r : ℝ) :
    (characteristic (fun _ : Fin n => r) (fun _ => endpointCoordinate (n:ℝ) r)
      1 (endpointGain n r)).eval (-1) = 0 := by
  have hgain : endpointGain n r = ∏ _ : Fin n, (r+2/endpointCoordinate (n:ℝ) r) := by
    rw [endpointGain_factor_identity hn]
    simp [endpointGain]
  rw [hgain]
  exact endpoint_is_root (fun _ => ne_of_gt (endpointCoordinate_pos (by exact_mod_cast hn)))

end C2.NGammaEqual
