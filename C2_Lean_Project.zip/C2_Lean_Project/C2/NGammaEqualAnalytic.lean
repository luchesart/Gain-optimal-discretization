import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Tactic

/-! Exact uniqueness argument for the identical-factor finite-angle equation. -/
noncomputable section
namespace C2.NGammaEqual

/-- The function t cot t used in the paper's monotonicity argument. -/
def weightedCot (t : ℝ) : ℝ := t * Real.cos t / Real.sin t

lemma sin_mul_cos_lt {t : ℝ} (ht : 0 < t) :
    Real.sin t * Real.cos t < t := by
  have h := Real.sin_lt (show 0 < 2 * t by linarith)
  rw [Real.sin_two_mul] at h
  linarith

lemma weightedCot_hasDerivAt {t : ℝ} (ht : Real.sin t ≠ 0) :
    HasDerivAt weightedCot
      ((Real.sin t * Real.cos t - t) / Real.sin t ^ 2) t := by
  have h := ((hasDerivAt_id t).mul (Real.hasDerivAt_cos t)).div
    (Real.hasDerivAt_sin t) ht
  have hs := Real.sin_sq_add_cos_sq t
  have hmul := congrArg (fun y : ℝ => t * y) hs
  convert h using 1
  congr 1
  dsimp at hmul
  dsimp only [id]
  nlinarith [hmul]

lemma weightedCot_strictAntiOn : StrictAntiOn weightedCot (Set.Ioo 0 Real.pi) := by
  apply strictAntiOn_of_deriv_neg (convex_Ioo 0 Real.pi)
  · intro t ht
    exact (weightedCot_hasDerivAt (ne_of_gt (Real.sin_pos_of_pos_of_lt_pi ht.1 ht.2))).continuousAt.continuousWithinAt
  · intro t ht
    have ht' : t ∈ Set.Ioo 0 Real.pi := by simpa only [interior_Ioo] using ht
    have hs := Real.sin_pos_of_pos_of_lt_pi ht'.1 ht'.2
    rw [(weightedCot_hasDerivAt (ne_of_gt hs)).deriv]
    exact div_neg_of_neg_of_pos (sub_neg.mpr (sin_mul_cos_lt ht'.1)) (sq_pos_of_pos hs)

lemma sine_ratio_hasDerivAt (k t : ℝ) (ht : Real.sin t ≠ 0) :
    HasDerivAt (fun y : ℝ => Real.sin (k * y) / Real.sin y)
      ((k * Real.cos (k * t) * Real.sin t -
        Real.sin (k * t) * Real.cos t) / Real.sin t ^ 2) t := by
  convert ((Real.hasDerivAt_sin (k * t)).comp t ((hasDerivAt_id t).const_mul k)).div
    (Real.hasDerivAt_sin t) ht using 1 <;> simp only [Function.comp_apply] <;> ring

lemma sine_ratio_deriv_neg {k t : ℝ} (hk : 1 < k)
    (ht : 0 < t) (hkt : k * t < Real.pi) :
    deriv (fun y : ℝ => Real.sin (k * y) / Real.sin y) t < 0 := by
  have hktpos : 0 < k * t := mul_pos (by linarith) ht
  have htkt : t < k * t := by nlinarith
  have htpi : t < Real.pi := lt_trans htkt hkt
  have hs := Real.sin_pos_of_pos_of_lt_pi ht htpi
  have hks := Real.sin_pos_of_pos_of_lt_pi hktpos hkt
  have hcomp := weightedCot_strictAntiOn ⟨ht, htpi⟩ ⟨hktpos, hkt⟩ htkt
  unfold weightedCot at hcomp
  have hcross := (div_lt_div_iff₀ hks hs).mp hcomp
  have hmul : t * (k * Real.cos (k * t) * Real.sin t -
      Real.sin (k * t) * Real.cos t) < t * 0 := by nlinarith [hcross]
  have hnum := (mul_lt_mul_left ht).mp hmul
  rw [(sine_ratio_hasDerivAt k t (ne_of_gt hs)).deriv]
  exact div_neg_of_neg_of_pos hnum (sq_pos_of_pos hs)

lemma sine_ratio_strictAntiOn {k : ℝ} (hk : 1 < k) :
    StrictAntiOn (fun t : ℝ => Real.sin (k * t) / Real.sin t)
      (Set.Ioo 0 (Real.pi / (k + 1))) := by
  have hp : 0 < k + 1 := by linarith
  have bound : ∀ t ∈ Set.Ioo 0 (Real.pi / (k + 1)), k * t < Real.pi := by
    intro t ht
    have hh := (lt_div_iff₀ hp).mp ht.2
    nlinarith [ht.1]
  apply strictAntiOn_of_deriv_neg (convex_Ioo _ _)
  · intro t ht
    have hkt := bound t ht
    have htpi : t < Real.pi := by nlinarith [ht.1]
    exact (sine_ratio_hasDerivAt k t
      (ne_of_gt (Real.sin_pos_of_pos_of_lt_pi ht.1 htpi))).continuousAt.continuousWithinAt
  · intro t ht
    have ht' : t ∈ Set.Ioo 0 (Real.pi / (k + 1)) := by simpa only [interior_Ioo] using ht
    exact sine_ratio_deriv_neg hk ht'.1 (bound t ht')

/-- The finite-angle equation has at most one solution on the paper's interval. -/
lemma finite_angle_unique {n : ℕ} (hn : 3 ≤ n) (r : ℝ) {φ ψ : ℝ}
    (hφ : φ ∈ Set.Ioo 0 (Real.pi / (n : ℝ)))
    (hψ : ψ ∈ Set.Ioo 0 (Real.pi / (n : ℝ)))
    (hφeq : r + 1 = Real.sin (((n : ℝ) - 1) * φ) / Real.sin φ)
    (hψeq : r + 1 = Real.sin (((n : ℝ) - 1) * ψ) / Real.sin ψ) : φ = ψ := by
  have hnR : 3 ≤ (n : ℝ) := by exact_mod_cast hn
  have hmono := sine_ratio_strictAntiOn (show 1 < (n : ℝ) - 1 by linarith)
  have hsum : (n : ℝ) - 1 + 1 = n := by ring
  rw [hsum] at hmono
  exact hmono.injOn hφ hψ (hφeq.symm.trans hψeq)

open Filter Topology Set

lemma sine_ratio_tendsto_zero_right (k : ℝ) :
    Tendsto (fun t : ℝ => Real.sin (k * t) / Real.sin t) (𝓝[>] 0) (𝓝 k) := by
  have hnum : HasDerivAt (fun t : ℝ => Real.sin (k * t)) k 0 := by
    convert (Real.hasDerivAt_sin (k * 0)).comp 0 ((hasDerivAt_id 0).const_mul k) using 1 <;> simp
  have hn : Tendsto (fun t : ℝ => Real.sin (k * t) / t) (𝓝[>] 0) (𝓝 k) := by
    simpa [smul_eq_mul, div_eq_mul_inv, mul_comm] using hnum.tendsto_slope_zero_right
  have hd : Tendsto (fun t : ℝ => Real.sin t / t) (𝓝[>] 0) (𝓝 (1 : ℝ)) := by
    simpa [smul_eq_mul, div_eq_mul_inv, mul_comm] using
      (Real.hasDerivAt_sin 0).tendsto_slope_zero_right
  have hquot := hn.div hd (one_ne_zero : (1 : ℝ) ≠ 0)
  simp only [div_one] at hquot
  apply hquot.congr'
  filter_upwards [self_mem_nhdsWithin] with t ht
  have ht0 : t ≠ 0 := ne_of_gt ht
  field_simp

lemma sine_ratio_at_endpoint {k : ℝ} (hk : 1 < k) :
    Real.sin (k * (Real.pi / (k + 1))) / Real.sin (Real.pi / (k + 1)) = 1 := by
  have hp : 0 < k + 1 := by linarith
  have hc : 0 < Real.pi / (k + 1) := div_pos Real.pi_pos hp
  have hcpi : Real.pi / (k + 1) < Real.pi := by
    rw [div_lt_iff₀ hp]
    nlinarith [Real.pi_pos]
  have hangle : k * (Real.pi / (k + 1)) = Real.pi - Real.pi / (k + 1) := by
    field_simp; ring
  rw [hangle, Real.sin_pi_sub]
  exact div_self (ne_of_gt (Real.sin_pos_of_pos_of_lt_pi hc hcpi))

lemma sine_ratio_exists_unique {k r : ℝ} (hk : 1 < k) (hr : 0 < r) (hrk : r + 1 < k) :
    ∃! φ : ℝ, φ ∈ Set.Ioo 0 (Real.pi / (k + 1)) ∧
      r + 1 = Real.sin (k * φ) / Real.sin φ := by
  let c : ℝ := Real.pi / (k + 1)
  let f : ℝ → ℝ := fun t => Real.sin (k * t) / Real.sin t
  have hp : 0 < k + 1 := by linarith
  have hc : 0 < c := div_pos Real.pi_pos hp
  have hcpi : c < Real.pi := by
    dsimp [c]
    rw [div_lt_iff₀ hp]
    nlinarith [Real.pi_pos]
  have hf : ContinuousOn f (Set.Ioo 0 c) := by
    intro t ht
    exact ((Real.continuous_sin.comp (continuous_const.mul continuous_id)).continuousAt.div
      Real.continuous_sin.continuousAt
      (ne_of_gt (Real.sin_pos_of_pos_of_lt_pi ht.1 (lt_trans ht.2 hcpi)))).continuousWithinAt
  have hleft : Tendsto f (𝓝[Set.Ioo 0 c] 0) (𝓝 k) := by
    rw [nhdsWithin_Ioo_eq_nhdsGT hc]
    exact sine_ratio_tendsto_zero_right k
  have hright : Tendsto f (𝓝[Set.Ioo 0 c] c) (𝓝 1) := by
    have hfc : f c = 1 := sine_ratio_at_endpoint hk
    rw [← hfc]
    exact (((Real.continuous_sin.comp (continuous_const.mul continuous_id)).continuousAt.div
      Real.continuous_sin.continuousAt
      (ne_of_gt (Real.sin_pos_of_pos_of_lt_pi hc hcpi))).continuousWithinAt)
  haveI : NeBot (𝓝[Set.Ioo 0 c] 0) := left_nhdsWithin_Ioo_neBot hc
  haveI : NeBot (𝓝[Set.Ioo 0 c] c) := right_nhdsWithin_Ioo_neBot hc
  have hi := isPreconnected_Ioo.intermediate_value_Ioo
    (l₁ := 𝓝[Set.Ioo 0 c] c) (l₂ := 𝓝[Set.Ioo 0 c] 0)
    inf_le_right inf_le_right hf hright hleft
  obtain ⟨φ, hφ, heq⟩ := hi (show r + 1 ∈ Set.Ioo 1 k by constructor <;> linarith)
  refine ⟨φ, ⟨hφ, heq.symm⟩, ?_⟩
  intro ψ hψ
  exact (sine_ratio_strictAntiOn hk).injOn hψ.1 hφ (hψ.2.symm.trans heq.symm)

/-- Existence and uniqueness of the actual finite-angle equation, not a supplied witness. -/
lemma finite_angle_exists_unique {n : ℕ} (hn : 3 ≤ n) {r : ℝ}
    (hr : 0 < r) (hrn : r < (n : ℝ) - 2) :
    ∃! φ : ℝ, φ ∈ Set.Ioo 0 (Real.pi / (n : ℝ)) ∧
      r + 1 = Real.sin (((n : ℝ) - 1) * φ) / Real.sin φ := by
  have hnR : 3 ≤ (n : ℝ) := by exact_mod_cast hn
  simpa only [sub_add_cancel] using sine_ratio_exists_unique
    (show 1 < (n : ℝ) - 1 by linarith) hr (show r + 1 < (n : ℝ) - 1 by linarith)

end C2.NGammaEqual
